---
name: obsidian
description: Comprehensive knowledge management and note-taking with Obsidian. Use for vault organization, linking strategies, Markdown formatting, plugin development, Dataview queries, templates, themes, and advanced workflow automation.
---

# Obsidian Knowledge Management

Comprehensive assistance for Obsidian - the powerful, privacy-first knowledge management application that transforms your notes into a connected thinking workspace.

## When to Use This Skill

This skill should be triggered when:
- Setting up or configuring Obsidian vaults
- Learning Markdown formatting and editing techniques
- Implementing linking strategies and knowledge graphs
- Working with plugins (core or community)
- Creating templates and automation workflows
- Developing custom plugins or themes
- Using advanced features like Dataview, Canvas, or API
- Migrating data from other note-taking apps
- Optimizing workflow and productivity systems

## Quick Reference

### Essential Markdown Formatting

```markdown
# Headers
## Sub-headers

*Emphasis* or _emphasis_
**Strong** or __strong__
`Code spans`

- Unordered lists
1. Ordered lists

[Link text](https://example.com)
![Image alt text](image.jpg)

> Blockquotes

---
Horizontal rule

| Tables | Are | Cool |
|--------|-----|------|
| Col 1  | Col | Col 3 |
```

### Obsidian-Specific Syntax

```markdown
[[Internal Link]]                    # Link to another note
[[Internal Link|Display Text]]       # Custom link text
[[Internal Link#Heading]]            # Link to specific heading
[[Internal Link#^block-id]]          # Link to specific block
#^block-reference                    # Create block reference

![[Embed Note]]                     # Embed another note
![[Embed Note#Heading]]             # Embed specific section
![[image.jpg|200]]                  # Embed image with width

#tags                               # Tag
#nested/tag                         # Nested tag
```

### Dataview Queries

```markdown
<!-- Basic list of pages -->
```dataview
LIST
FROM ""
```

<!-- Table with file info -->
```dataview
TABLE file.mtime as "Modified", file.size as "Size"
FROM "Projects"
SORT file.mtime DESC
```

<!-- Tasks from project pages -->
```dataview
TASK
FROM "Projects"
WHERE !completed
GROUP BY file.folder
```

<!-- Count pages by folder -->
```dataview
TABLE rows.file.length as "Count"
FROM ""
GROUP BY file.folder
```
```

### Template Placeholders

```
{{title}}           # Note title
{{date}}            # Current date (YYYY-MM-DD)
{{time}}            # Current time (HH:mm)
{{date:YYYY-MM-DD}} # Custom date format
{{daily}}           # Daily note date
{{name}}            # Vault name
{{path}}            # Current file path
{{folder}}          # Current folder
```

### Front Matter Examples

```yaml
---
title: My Page Title
tags: [project, important, research]
created: 2024-01-15
modified: 2024-01-16
status: active
priority: high
related: [[Project A]], [[Research B]]
cssclass: custom-style
---

# Content here
```

## Core Concepts

### Vault Structure

- **Vault**: Your collection of notes stored as plain Markdown files
- **Files**: Individual `.md` files stored locally on your device
- **Folders**: Organizational structure within your vault
- **Attachments**: Images, PDFs, and other media files

### Linking System

1. **Wiki-Style Links**: `[[Note Name]]` for internal connections
2. **Backlinks**: Automatic tracking of all inbound links
3. **Unlinked Mentions**: Notes that reference your current note
4. **Graph View**: Visual representation of note connections

### Note Organization Strategies

- **Zettelkasten**: Atomic notes with unique IDs and cross-references
- **PARA Method**: Projects, Areas, Resources, Archives
- **Building a Second Brain**: CODE (Capture, Organize, Distill, Express)
- **Progressive Summarization**: Layered note refinement

## Key Features

### File Management

```bash
# File operations are handled through Obsidian's UI
# Files are stored as plain text Markdown files
# Supports drag-and-drop file organization
# Real-time file syncing across devices
```

### Search Capabilities

- **Basic Search**: Text search across all notes
- **Advanced Search**: Operators like `tag:`, `path:`, `file:`
- **Regular Expressions**: Pattern-based searching
- **Live Search**: Real-time results as you type
- **Search in Current File**: Quick content finding

### Plugin Ecosystem

**Core Plugins**:
- File explorer and search
- Tag pane and graph view
- Quick switcher and command palette
- Workspaces and daily notes
- Templates and outgoing links

**Community Plugins**:
- Dataview (data queries)
- Calendar integration
- Kanban boards
- Advanced tables
- Custom themes and styling

## Advanced Workflows

### Research System

```markdown
# Research Note Template
## Source
- **Type**: [Book/Paper/Article/Video]
- **Author**:
- **Date**:
- **URL**:

## Key Points
-

## Connections
[[Related Notes]]
#research #literature-review
```

### Project Management

```markdown
# Project: [Project Name]
**Status**: [[Active/On Hold/Completed]]
**Deadline**: {{date}}
**Priority**: [[High/Medium/Low]]

## Tasks
- [ ] Task 1 #task
- [ ] Task 2 #task

## Related Notes
[[Meeting Notes]], [[Research]], [[Ideas]]
#project #active
```

### Learning Journal

```markdown
# Learning: [Topic]
**Date**: {{date}}
**Source**: [Book/Course/Article]

## Key Concepts
-

## Questions
-

## Applications
-

## Connections
[[Related Topics]]
#learning #journal
```

## Development & Customization

### Plugin Development (JavaScript)

```javascript
// Plugin structure
export default class MyPlugin extends Plugin {
  settings: MyPluginSettings;

  async onload() {
    // Load settings
    await this.loadSettings();

    // Add commands
    this.addCommand({
      id: 'my-command',
      name: 'My Command',
      callback: () => {
        // Command logic
      }
    });

    // Add ribbon icon
    this.addRibbonIcon('my-icon', 'My Tool', () => {
      // Icon action
    });
  }

  onunload() {
    // Cleanup
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }
}
```

### CSS Snippets

```css
/* Custom styling for specific elements */
.markdown-preview-view h1 {
  color: #your-color;
  border-bottom: 2px solid #your-color;
}

/* Style for todo lists */
.markdown-preview-view .task-list-item-checkbox {
  accent-color: #your-color;
}

/* Custom callout styling */
.callout {
  border-left: 4px solid #your-accent;
  background-color: #your-bg;
}
```

### API Usage Examples

```javascript
// Get active file
const activeFile = app.workspace.getActiveFile();

// Create new note
const newFile = await app.vault.create("New Note.md", "# New Note");

// Read file content
const content = await app.vault.read(file);

// Write to file
await app.vault.modify(file, newContent);

// Search for files
const files = app.vault.getMarkdownFiles()
  .filter(file => file.path.includes("projects"));

// Get backlinks for current file
const backlinks = app.metadataCache.getBacklinksForFile(activeFile);
```

## Troubleshooting

### Common Issues

**Links Not Working**:
- Check file names for exact matches (case-sensitive)
- Use `[[Note Name|Display Text]]` for different display text
- Verify files are in the same vault

**Images Not Displaying**:
- Use relative paths: `[[folder/image.jpg]]`
- Check image file formats (JPG, PNG, GIF, SVG supported)
- Verify attachment folder settings

**Performance Issues**:
- Limit vault size or use nested folders
- Disable unnecessary plugins
- Clear cache regularly
- Consider using file exclusions

**Sync Problems**:
- Check internet connection
- Verify sync service settings
- Look for file conflicts
- Restart Obsidian if needed

### Tips & Best Practices

1. **Atomic Notes**: Keep notes focused on single topics
2. **Consistent Naming**: Use clear, descriptive file names
3. **Regular Maintenance**: Review and update connections
4. **Backup Strategy**: Regular vault backups
5. **Plugin Management**: Only install necessary plugins
6. **Performance**: Monitor vault size and file counts

## Integration Options

### External Tools

- **Zotero**: Academic reference management
- **Readwise**: Highlight and note syncing
- **Notion**: Data migration and syncing
- **GitHub**: Version control for notes
- **Pandoc**: Document format conversion

### Publishing

- **Obsidian Publish**: Direct publishing service
- **Digital Gardens**: Custom web publishing
- **Static Site Generators**: Quartz, Eleventy, Hugo
- **Documentation Sites**: GitBook, Docusaurus

## Resources

### Official Documentation
- Main help: https://help.obsidian.md/
- Community forums: https://forum.obsidian.md/
- Plugin documentation: https://docs.obsidian.md/Plugins

### Community Resources
- Obsidian Roundup (weekly newsletter)
- Reddit community: r/ObsidianMD
- Discord community
- YouTube tutorials and workflows

### Advanced Learning
- Plugin development tutorials
- Dataview query examples
- CSS snippet libraries
- Template collections
- Workflow templates

---

This skill provides comprehensive coverage of Obsidian's features for knowledge management, note-taking, and personal productivity workflows.