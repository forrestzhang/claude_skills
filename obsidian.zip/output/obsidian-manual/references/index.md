# Obsidian Documentation Reference

## Overview

This reference section contains comprehensive documentation for Obsidian's features and capabilities. Use these files for detailed information on specific topics.

## Reference Files

- **getting-started.md**: Installation, setup, and initial configuration
- **editing-formatting.md**: Markdown editing and formatting techniques
- **linking-organization.md**: Linking strategies and vault organization
- **plugins.md**: Core and community plugin management
- **advanced-features.md**: Dataview, Canvas, API, and developer topics
- **templates-workflows.md**: Template creation and workflow automation
- **customization.md**: Themes, CSS snippets, and appearance settings
- **troubleshooting.md**: Common issues and solutions

## How to Use These References

1. **For Beginners**: Start with getting-started.md for basic setup
2. **Learning Features**: Browse specific category files for targeted information
3. **Advanced Topics**: Check advanced-features.md for development and API usage
4. **Problem Solving**: Use troubleshooting.md for common issues

## Navigation

- Each reference file includes a table of contents
- Cross-references link between related topics
- Code examples are provided with syntax highlighting
- External links point to official documentation

## Notes

- These references are based on Obsidian's official documentation
- Content is updated to reflect current Obsidian features
- Examples use best practices and real-world scenarios