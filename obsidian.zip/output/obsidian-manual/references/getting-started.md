# Getting Started with Obsidian

## Installation

### System Requirements

- **Windows**: Windows 10 and later
- **macOS**: macOS 10.15 (Catalina) and later
- **Linux**: Most modern distributions
- **Mobile**: iOS 14+ and Android 8+

### Installation Steps

1. **Download Obsidian**: Visit https://obsidian.md/download
2. **Install Application**: Run installer for your platform
3. **Launch Obsidian**: Open the application
4. **Create or Open Vault**: Choose your first vault location

### Vault Creation

A **vault** is a folder that contains all your notes and attachments.

**New Vault Options**:
- Create new folder on your computer
- Use existing folder with Markdown files
- Connect to cloud-synced folder (Dropbox, iCloud, etc.)

## First Steps

### Understanding the Interface

**Main Components**:
- **File Explorer**: Left sidebar showing all files and folders
- **Editor**: Central area for writing and editing notes
- **Graph View**: Visual representation of note connections
- **Search Bar**: Quick access to search functionality
- **Command Palette**: `Ctrl/Cmd + P` for all commands

### Creating Your First Note

1. **Click New Note**: `+` button in file explorer
2. **Add Title**: Start with a clear, descriptive title
3. **Write Content**: Use Markdown formatting
4. **Save**: Notes are saved automatically

```markdown
# My First Note

Welcome to Obsidian! This is written in **Markdown** formatting.

## Key Features
- Links to other notes: [[Another Note]]
- Tags: #getting-started
- Checkboxes: - [ ] Task to complete
```

### Basic Navigation

**Keyboard Shortcuts**:
- `Ctrl/Cmd + N`: Create new note
- `Ctrl/Cmd + O`: Open file
- `Ctrl/Cmd + Shift + F`: Search
- `Ctrl/Cmd + E`: Toggle edit/preview mode
- `Ctrl/Cmd + /`: Toggle sidebar
- `Ctrl/Cmd + G`: Open graph view

**Mouse Navigation**:
- Double-click note to open
- Drag to rearrange panes
- Right-click for context menu
- Click links to navigate

## Configuration

### Settings Access

1. **Open Settings**: Click gear icon or use `Ctrl/Cmd + ,`
2. **Browse Categories**: Files, Editor, Appearance, Hotkeys, etc.
3. **Make Changes**: Adjust settings to your preference

### Essential Settings

**File & Links**:
- **Default location for new notes**: Choose folder
- **New link format**: Wiki links vs Markdown links
- **Always update links**: When renaming files

**Editor**:
- **Tab size**: Set indentation (usually 2 or 4)
- **Strict line breaks**: Control line ending behavior
- **Readable line length**: Enable for better readability

**Appearance**:
- **Base color**: Light, dark, or auto
- **Community themes**: Install from community theme browser
- **Font size**: Adjust for comfort

## Core Concepts

### Files and Folders

**File Organization**:
- Files are plain text with `.md` extension
- Folders help organize related content
- Supports nested folder structure
- Drag and drop for file management

**File Naming**:
- Use descriptive, consistent names
- Avoid special characters in file names
- Consider date prefixes for daily notes
- Use camelCase or kebab-case consistently

### Markdown Basics

**Text Formatting**:
```markdown
# Main Heading
## Subheading

**Bold text** and *italic text*

`Code snippets`

- Bullet points
1. Numbered lists

> Blockquotes

[Links](https://example.com)
```

### Internal Linking

**Wiki Links** (Obsidian default):
```
[[Note Name]]                    # Link to note
[[Note Name|Display Text]]       # Custom display text
[[Note Name#Heading]]            # Link to section
```

**Markdown Links**:
```
[Link text](note-name.md)
```

## Daily Notes

### Setting Up Daily Notes

1. **Enable Core Plugin**: Settings > Core plugins > Daily notes
2. **Configure Template**: Choose template file location
3. **Set Format**: Default is `YYYY-MM-DD`
4. **Open Daily Note**: Use command palette or click date

### Daily Note Template

```markdown
# {{date:YYYY-MM-DD}}

## Priorities
- [ ]

## Notes


## Links


#daily-notes
```

## Templates

### Creating Templates

1. **Create Template Folder**: e.g., `Templates/`
2. **Set Template Location**: Settings > Core plugins > Templates
3. **Create Template Files**: Markdown files with placeholders

### Template Placeholders

```
{{title}}           # Note title
{{date}}            # Current date (YYYY-MM-DD)
{{time}}            # Current time (HH:mm)
{{date:format}}     # Custom date format
{{daily}}           # Daily note date
{{name}}            # Vault name
{{path}}            # Current file path
```

### Example Templates

**Project Template**:
```markdown
# Project: {{title}}

**Status**: Planning
**Created**: {{date}}
**Deadline**:

## Goals


## Tasks
- [ ]

## Notes


#project #{{title}}
```

**Meeting Template**:
```markdown
# Meeting: {{title}}

**Date**: {{date}} {{time}}
**Attendees**:

## Agenda


## Notes


## Action Items
- [ ]

#meeting #{{date:YYYY-MM-DD}}
```

## Quick Switcher

### Using Quick Switcher

1. **Open**: `Ctrl/Cmd + O` or click search icon
2. **Type**: Start typing note name
3. **Navigate**: Use arrow keys to select
4. **Open**: Press Enter to open selected note

### Advanced Features

- **Create new**: Type note name and press `Ctrl/Cmd + Enter`
- **Search content**: Start search with `#` to find within files
- **Filter by folder**: Use folder syntax `folder/note`
- **Recent files**: Access recently opened files

## Command Palette

### Access and Use

1. **Open**: `Ctrl/Cmd + P`
2. **Type**: Start typing command name
3. **Select**: Choose from available commands
4. **Execute**: Press Enter to run

### Essential Commands

- `New note`: Create new file
- `Open command palette`: Access all commands
- `Search: Find and replace`: Text search and replace
- `Graph view: Open`: Show connection graph
- `Workspace: Save current workspace`: Save layout
- `Quick switcher: Open`: File navigation

## Tips for Success

### Best Practices

1. **Start Simple**: Begin with basic notes and organization
2. **Consistent Naming**: Use clear, consistent file names
3. **Regular Linking**: Connect related ideas as you write
4. **Template Usage**: Create templates for repeated tasks
5. **Backup Important**: Regular backups of vault

### Common Pitfalls to Avoid

- **Over-organization**: Don't create too many folders initially
- **Complex Naming**: Keep file names simple and searchable
- **No Backups**: Regularly backup your vault
- **Ignoring Links**: Don't forget to connect related ideas
- **Template Neglect**: Create templates for repeated content types

### Getting Help

- **Official Documentation**: https://help.obsidian.md/
- **Community Forum**: https://forum.obsidian.md/
- **YouTube Tutorials**: Search "Obsidian tutorial"
- **Community Discord**: Join for live discussions

## Next Steps

After mastering these basics, explore:

1. **Advanced Linking**: Learn about block references and embeds
2. **Plugins**: Explore community plugins for enhanced functionality
3. **Dataview**: Add dynamic content and queries
4. **Canvas**: Visual note-taking and mind mapping
5. **Themes**: Customize appearance with community themes
6. **Workspaces**: Save different layout configurations

---

This getting started guide covers the essential knowledge needed to begin using Obsidian effectively. Practice these fundamentals before moving to more advanced features.