# Tailwind Documentation Index

## Categories

### Backgrounds
**File:** `backgrounds.md`
**Pages:** 1

### Core Concepts
**File:** `core_concepts.md`
**Pages:** 3

### Customization
**File:** `customization.md`
**Pages:** 1

### Getting Started
**File:** `getting_started.md`
**Pages:** 1

### Layout
**File:** `layout.md`
**Pages:** 19

### Other
**File:** `other.md`
**Pages:** 69

### Typography
**File:** `typography.md`
**Pages:** 3
