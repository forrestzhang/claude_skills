# Tailwind - Other

**Pages:** 69

---

## Colors

**URL:** https://tailwindcss.com/docs/colors

**Contents:**
- Working with colors
  - Using color utilities
  - Adjusting opacity
  - Targeting dark mode
  - Referencing in CSS
- Customizing your colors
  - Overriding default colors
  - Disabling default colors
  - Using a custom palette
  - Referencing other variables

Tailwind CSS includes a vast, beautiful color palette out of the box, carefully crafted by expert designers and suitable for a wide range of different design styles.

Every color in the default palette includes 11 steps, with 50 being the lightest, and 950 being the darkest:

The entire color palette is available across all color related utilities, including things like background color, border color, fill, caret color, and many more.

Use color utilities like bg-white, border-pink-300, and text-gray-950 to set the different color properties of elements in your design:

Tom Watson mentioned you in Logo redesign

Here's a full list of utilities that use your color palette:

You can adjust the opacity of a color using syntax like bg-black/75, where 75 sets the alpha channel of the color to 75%:

This syntax also supports arbitrary values and the CSS variable shorthand:

Use the dark variant to write classes like dark:bg-gray-800 that only apply a color when dark mode is active:

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

Learn more about styling for dark mode in the dark mode documentation.

Colors are exposed as CSS variables in the --color-* namespace, so you can reference them in CSS with variables like --color-blue-500 and --color-pink-700:

You can also use these as arbitrary values in utility classes:

To quickly adjust the opacity of a color when referencing it as a variable in CSS, Tailwind includes a special --alpha() function:

Use @theme to add custom colors to your project under the --color-* theme namespace:

Now utilities like bg-midnight, text-tahiti, and fill-bermuda will be available in your project in addition to the default colors.

Learn more about theme variables in the theme variables documentation.

Override any of the default colors by defining new theme variables with the same name:

Disable any default color by setting the theme namespace for that color to initial:

This is especially useful for removing the corresponding CSS variables from your output for colors you don't intend to use.

Use --color-*: initial to completely disable all of the default colors and define your own custom color palette:

Use @theme inline when defining colors that reference other colors:

Learn more in the theme documentation on referencing other variables.

Here's a complete list of the default colors and their values for reference:

This can be useful if you want to reuse any of these scales but under a different name, like redefining --color-gray-* to use the --color-slate-* scale.

**Examples:**

Example 1 (unknown):
```unknown
<div>  <div class="bg-sky-50"></div>  <div class="bg-sky-100"></div>  <div class="bg-sky-200"></div>  <div class="bg-sky-300"></div>  <div class="bg-sky-400"></div>  <div class="bg-sky-500"></div>  <div class="bg-sky-600"></div>  <div class="bg-sky-700"></div>  <div class="bg-sky-800"></div>  <div class="bg-sky-900"></div>  <div class="bg-sky-950"></div></div>
```

Example 2 (unknown):
```unknown
<div class="flex items-center gap-4 rounded-lg bg-white p-6 shadow-md outline outline-black/5 dark:bg-gray-800">  <span class="inline-flex shrink-0 rounded-full border border-pink-300 bg-pink-100 p-2 dark:border-pink-300/10 dark:bg-pink-400/10">    <svg class="size-6 stroke-pink-700 dark:stroke-pink-500"><!-- ... --></svg>  </span>  <div>    <p class="text-gray-700 dark:text-gray-400">      <span class="font-medium text-gray-950 dark:text-white">Tom Watson</span> mentioned you in      <span class="font-medium text-gray-950 dark:text-white">Logo redesign</span>    </p>    <time class="mt-1 block text-gray-500" datetime="9:37">9:37am</time>  </div></div>
```

Example 3 (unknown):
```unknown
<div>  <div class="bg-sky-500/10"></div>  <div class="bg-sky-500/20"></div>  <div class="bg-sky-500/30"></div>  <div class="bg-sky-500/40"></div>  <div class="bg-sky-500/50"></div>  <div class="bg-sky-500/60"></div>  <div class="bg-sky-500/70"></div>  <div class="bg-sky-500/80"></div>  <div class="bg-sky-500/90"></div>  <div class="bg-sky-500/100"></div></div>
```

Example 4 (unknown):
```unknown
<div class="bg-pink-500/[71.37%]"><!-- ... --></div><div class="bg-cyan-400/(--my-alpha-value)"><!-- ... --></div>
```

---

## position

**URL:** https://tailwindcss.com/docs/position

**Contents:**
- Examples
  - Statically positioning elements
  - Relatively positioning elements
  - Absolutely positioning elements
  - Fixed positioning elements
  - Sticky positioning elements
  - Responsive design

Use the static utility to position an element according to the normal flow of the document:

With statically positioned elements, any offsets will be ignored and the element will not act as a position reference for absolutely positioned children.

Use the relative utility to position an element according to the normal flow of the document:

With relatively position elements, any offsets are calculated relative to the element's normal position and the element will act as a position reference for absolutely positioned children.

Use the absolute utility to position an element outside of the normal flow of the document, causing neighboring elements to act as if the element doesn't exist:

With static positioning

With absolute positioning

With absolutely positioned elements, any offsets are calculated relative to the nearest parent that has a position other than static, and the element will act as a position reference for other absolutely positioned children.

Use the fixed utility to position an element relative to the browser window:

Scroll this element to see the fixed positioning in action

With fixed positioned elements, any offsets are calculated relative to the viewport and the element will act as a position reference for absolutely positioned children:

Use the sticky utility to position an element as relative until it crosses a specified threshold, then treat it as fixed until its parent is off screen:

Scroll this element to see the sticky positioning in action

With sticky positioned elements, any offsets are calculated relative to the element's normal position and the element will act as a position reference for absolutely positioned children.

Prefix a position utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="static ...">  <p>Static parent</p>  <div class="absolute bottom-0 left-0 ...">    <p>Absolute child</p>  </div></div>
```

Example 2 (unknown):
```unknown
<div class="relative ...">  <p>Relative parent</p>  <div class="absolute bottom-0 left-0 ...">    <p>Absolute child</p>  </div></div>
```

Example 3 (unknown):
```unknown
<div class="static ...">  <!-- Static parent -->  <div class="static ..."><p>Static child</p></div>  <div class="inline-block ..."><p>Static sibling</p></div>  <!-- Static parent -->  <div class="absolute ..."><p>Absolute child</p></div>  <div class="inline-block ..."><p>Static sibling</p></div></div>
```

Example 4 (unknown):
```unknown
<div class="relative">  <div class="fixed top-0 right-0 left-0">Contacts</div>  <div>    <div>      <img src="/img/andrew.jpg" />      <strong>Andrew Alfred</strong>    </div>    <div>      <img src="/img/debra.jpg" />      <strong>Debra Houston</strong>    </div>    <!-- ... -->  </div></div>
```

---

## font-smoothing

**URL:** https://tailwindcss.com/docs/font-smoothing

**Contents:**
- Examples
  - Grayscale antialiasing
  - Subpixel antialiasing
  - Responsive design

Use the antialiased utility to render text using grayscale antialiasing:

The quick brown fox jumps over the lazy dog.

Use the subpixel-antialiased utility to render text using subpixel antialiasing:

The quick brown fox jumps over the lazy dog.

Prefix -webkit-font-smoothing and -moz-osx-font-smoothing utilities with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="antialiased ...">The quick brown fox ...</p>
```

Example 2 (unknown):
```unknown
<p class="subpixel-antialiased ...">The quick brown fox ...</p>
```

Example 3 (unknown):
```unknown
<p class="antialiased md:subpixel-antialiased ...">  Lorem ipsum dolor sit amet...</p>
```

---

## letter-spacing

**URL:** https://tailwindcss.com/docs/letter-spacing

**Contents:**
- Examples
  - Basic example
  - Using negative values
  - Using a custom value
  - Responsive design
- Customizing your theme

Use utilities like tracking-tight and tracking-wide to set the letter spacing of an element:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Using negative values doesn't make a ton of sense with the named letter spacing scale Tailwind includes out of the box, but if you've customized your scale to use numbers it can be useful:

To use a negative letter spacing value, prefix the class name with a dash to convert it to a negative value:

Use the tracking-[<value>] syntax to set the letter spacing based on a completely custom value:

For CSS variables, you can also use the tracking-(<custom-property>) syntax:

This is just a shorthand for tracking-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a letter-spacing utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --tracking-* theme variables to customize the letter spacing utilities in your project:

Now the tracking-tightest utility can be used in your markup:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="tracking-tight ...">The quick brown fox ...</p><p class="tracking-normal ...">The quick brown fox ...</p><p class="tracking-wide ...">The quick brown fox ...</p>
```

Example 2 (unknown):
```unknown
@theme {  --tracking-1: 0em;  --tracking-2: 0.025em;  --tracking-3: 0.05em;  --tracking-4: 0.1em;}
```

Example 3 (unknown):
```unknown
<p class="-tracking-2">The quick brown fox ...</p>
```

Example 4 (unknown):
```unknown
<p class="tracking-[.25em] ...">  Lorem ipsum dolor sit amet...</p>
```

---

## color

**URL:** https://tailwindcss.com/docs/color

**Contents:**
- Examples
  - Basic example
  - Changing the opacity
  - Using a custom value
  - Applying on hover
  - Responsive design
- Customizing your theme

Use utilities like text-blue-600 and text-sky-400 to control the text color of an element:

The quick brown fox jumps over the lazy dog.

Use the color opacity modifier to control the text color opacity of an element:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Use the text-[<value>] syntax to set the text color based on a completely custom value:

For CSS variables, you can also use the text-(<custom-property>) syntax:

This is just a shorthand for text-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a color utility with a variant like hover:* to only apply the utility in that state:

Hover over the text to see the expected behavior

Oh I gotta get on that internet, I'm late on everything!

Learn more about using variants in the variants documentation.

Prefix a color utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --color-* theme variables to customize the color utilities in your project:

Now the text-regal-blue utility can be used in your markup:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="text-blue-600 dark:text-sky-400">The quick brown fox...</p>
```

Example 2 (unknown):
```unknown
<p class="text-blue-600/100 dark:text-sky-400/100">The quick brown fox...</p><p class="text-blue-600/75 dark:text-sky-400/75">The quick brown fox...</p><p class="text-blue-600/50 dark:text-sky-400/50">The quick brown fox...</p><p class="text-blue-600/25 dark:text-sky-400/25">The quick brown fox...</p>
```

Example 3 (unknown):
```unknown
<p class="text-[#50d71e] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="text-(--my-color) ...">  Lorem ipsum dolor sit amet...</p>
```

---

## list-style-position

**URL:** https://tailwindcss.com/docs/list-style-position

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use utilities like list-inside and list-outside to control the position of the markers and text indentation in a list:

Prefix a list-style-position utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<ul class="list-inside">  <li>5 cups chopped Porcini mushrooms</li>  <!-- ... --></ul><ul class="list-outside">  <li>5 cups chopped Porcini mushrooms</li>  <!-- ... --></ul>
```

Example 2 (unknown):
```unknown
<ul class="list-outside md:list-inside ...">  <!-- ... --></ul>
```

---

## font-style

**URL:** https://tailwindcss.com/docs/font-style

**Contents:**
- Examples
  - Italicizing text
  - Displaying text normally
  - Responsive design

Use the italic utility to make text italic:

The quick brown fox jumps over the lazy dog.

Use the not-italic utility to display text normally:

The quick brown fox jumps over the lazy dog.

Prefix a font-style utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="italic ...">The quick brown fox ...</p>
```

Example 2 (unknown):
```unknown
<p class="not-italic ...">The quick brown fox ...</p>
```

Example 3 (unknown):
```unknown
<p class="italic md:not-italic ...">  Lorem ipsum dolor sit amet...</p>
```

---

## text-decoration-line

**URL:** https://tailwindcss.com/docs/text-decoration-line

**Contents:**
- Examples
  - Underling text
  - Adding an overline to text
  - Adding a line through text
  - Removing a line from text
  - Applying on hover
  - Responsive design

Use the underline utility to add an underline to the text of an element:

The quick brown fox jumps over the lazy dog.

Use the overline utility to add an overline to the text of an element:

The quick brown fox jumps over the lazy dog.

Use the line-through utility to add a line through the text of an element:

The quick brown fox jumps over the lazy dog.

Use the no-underline utility to remove a line from the text of an element:

The quick brown fox jumps over the lazy dog.

Prefix a text-decoration-line utility with a variant like hover:* to only apply the utility in that state:

Hover over the text to see the expected behavior

Learn more about using variants in the variants documentation.

Prefix a text-decoration-line utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="underline">The quick brown fox...</p>
```

Example 2 (unknown):
```unknown
<p class="overline">The quick brown fox...</p>
```

Example 3 (unknown):
```unknown
<p class="line-through">The quick brown fox...</p>
```

Example 4 (unknown):
```unknown
<p class="no-underline">The quick brown fox...</p>
```

---

## object-position

**URL:** https://tailwindcss.com/docs/object-position

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design

Use utilities like object-left and object-bottom-right to specify how a replaced element's content should be positioned within its container:

Hover over examples to see the full image

Use the object-[<value>] syntax to set the object position based on a completely custom value:

For CSS variables, you can also use the object-(<custom-property>) syntax:

This is just a shorthand for object-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix an object-position utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<img class="size-24 object-top-left ..." src="/img/mountains.jpg" /><img class="size-24 object-top ..." src="/img/mountains.jpg" /><img class="size-24 object-top-right ..." src="/img/mountains.jpg" /><img class="size-24 object-left ..." src="/img/mountains.jpg" /><img class="size-24 object-center ..." src="/img/mountains.jpg" /><img class="size-24 object-right ..." src="/img/mountains.jpg" /><img class="size-24 object-bottom-left ..." src="/img/mountains.jpg" /><img class="size-24 object-bottom ..." src="/img/mountains.jpg" /><img class="size-24 object-bottom-right ..." src="/img/mountains.jpg" />
```

Example 2 (unknown):
```unknown
<img class="object-[25%_75%] ..." src="/img/mountains.jpg" />
```

Example 3 (unknown):
```unknown
<img class="object-(--my-object) ..." src="/img/mountains.jpg" />
```

Example 4 (unknown):
```unknown
<img class="object-center md:object-top ..." src="/img/mountains.jpg" />
```

---

## text-overflow

**URL:** https://tailwindcss.com/docs/text-overflow

**Contents:**
- Examples
  - Truncating text
  - Adding an ellipsis
  - Clipping text
  - Responsive design

Use the truncate utility to prevent text from wrapping and truncate overflowing text with an ellipsis (…) if needed:

The longest word in any of the major English language dictionaries is pneumonoultramicroscopicsilicovolcanoconiosis, a word that refers to a lung disease contracted from the inhalation of very fine silica particles, specifically from a volcano; medically, it is the same as silicosis.

Use the text-ellipsis utility to truncate overflowing text with an ellipsis (…) if needed:

The longest word in any of the major English language dictionaries is pneumonoultramicroscopicsilicovolcanoconiosis, a word that refers to a lung disease contracted from the inhalation of very fine silica particles, specifically from a volcano; medically, it is the same as silicosis.

Use the text-clip utility to truncate the text at the limit of the content area:

The longest word in any of the major English language dictionaries is pneumonoultramicroscopicsilicovolcanoconiosis, a word that refers to a lung disease contracted from the inhalation of very fine silica particles, specifically from a volcano; medically, it is the same as silicosis.

This is the default browser behavior.

Prefix a text-overflow utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="truncate">The longest word in any of the major...</p>
```

Example 2 (unknown):
```unknown
<p class="overflow-hidden text-ellipsis">The longest word in any of the major...</p>
```

Example 3 (unknown):
```unknown
<p class="overflow-hidden text-clip">The longest word in any of the major...</p>
```

Example 4 (unknown):
```unknown
<p class="text-ellipsis md:text-clip ...">  Lorem ipsum dolor sit amet...</p>
```

---

## align-content

**URL:** https://tailwindcss.com/docs/align-content

**Contents:**
- Examples
  - Start
  - Center
  - End
  - Space between
  - Space around
  - Space evenly
  - Stretch
  - Normal
  - Responsive design

Use content-start to pack rows in a container against the start of the cross axis:

Use content-center to pack rows in a container in the center of the cross axis:

Use content-end to pack rows in a container against the end of the cross axis:

Use content-between to distribute rows in a container such that there is an equal amount of space between each line:

Use content-around to distribute rows in a container such that there is an equal amount of space around each line:

Use content-evenly to distribute rows in a container such that there is an equal amount of space around each item, but also accounting for the doubling of space you would normally see between each item when using content-around:

Use content-stretch to allow content items to fill the available space along the container’s cross axis:

Use content-normal to pack content items in their default position as if no align-content value was set:

Prefix an align-content utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid h-56 grid-cols-3 content-start gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid h-56 grid-cols-3 content-center gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div></div>
```

Example 3 (unknown):
```unknown
<div class="grid h-56 grid-cols-3 content-end gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div></div>
```

Example 4 (unknown):
```unknown
<div class="grid h-56 grid-cols-3 content-between gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div></div>
```

---

## float

**URL:** https://tailwindcss.com/docs/float

**Contents:**
- Examples
  - Floating elements to the right
  - Floating elements to the left
  - Using logical properties
  - Disabling a float
  - Responsive design

Use the float-right utility to float an element to the right of its container:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Use the float-left utility to float an element to the left of its container:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Use the float-start and float-end utilities, which use logical properties to map to either the left or right side based on the text direction:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

ربما يمكننا العيش بدون مكتبات، أشخاص مثلي ومثلك. ربما. بالتأكيد، نحن أكبر من أن نغير العالم، ولكن ماذا عن ذلك الطفل الذي يجلس ويفتح كتابًا الآن في أحد فروع المكتبة المحلية ويجد رسومات للتبول والبول على القطة في القبعة والإخوة الصينيون الخمسة؟ ألا يستحق الأفضل؟ ينظر. إذا كنت تعتقد أن الأمر يتعلق بالغرامات المتأخرة والكتب المفقودة، فمن الأفضل أن تفكر مرة أخرى. يتعلق الأمر بحق ذلك الطفل في قراءة كتاب دون أن يتشوه عقله! أو: ربما يثيرك هذا يا سينفيلد؛ ربما هذه هي الطريقة التي تحصل بها على ركلاتك. أنت ورفاقك الطيبين.

Use the float-none utility to reset any floats that are applied to an element:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Prefix a float utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<article>  <img class="float-right ..." src="/img/mountains.jpg" />  <p>Maybe we can live without libraries, people like you and me. ...</p></article>
```

Example 2 (unknown):
```unknown
<article>  <img class="float-left ..." src="/img/mountains.jpg" />  <p>Maybe we can live without libraries, people like you and me. ...</p></article>
```

Example 3 (unknown):
```unknown
<article>  <img class="float-start ..." src="/img/mountains.jpg" />  <p>Maybe we can live without libraries, people like you and me. ...</p></article><article dir="rtl">  <img class="float-start ..." src="/img/mountains.jpg" />  <p>... ربما يمكننا العيش بدون مكتبات، أشخاص مثلي ومثلك. ربما. بالتأكيد</p></article>
```

Example 4 (unknown):
```unknown
<article>  <img class="float-none ..." src="/img/mountains.jpg" />  <p>Maybe we can live without libraries, people like you and me. ...</p></article>
```

---

## text-underline-offset

**URL:** https://tailwindcss.com/docs/text-underline-offset

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design

Use underline-offset-<number> utilities like underline-offset-2 and underline-offset-4 to change the offset of a text underline:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Use the underline-offset-[<value>] syntax to set the text underline offset based on a completely custom value:

For CSS variables, you can also use the underline-offset-(<custom-property>) syntax:

This is just a shorthand for underline-offset-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a text-underline-offset utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="underline underline-offset-1">The quick brown fox...</p><p class="underline underline-offset-2">The quick brown fox...</p><p class="underline underline-offset-4">The quick brown fox...</p><p class="underline underline-offset-8">The quick brown fox...</p>
```

Example 2 (unknown):
```unknown
<p class="underline-offset-[3px] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 3 (unknown):
```unknown
<p class="underline-offset-(--my-underline-offset) ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="underline md:underline-offset-4 ...">  Lorem ipsum dolor sit amet...</p>
```

---

## text-decoration-color

**URL:** https://tailwindcss.com/docs/text-decoration-color

**Contents:**
- Examples
  - Basic example
  - Changing the opacity
  - Using a custom value
  - Applying on hover
  - Responsive design
- Customizing your theme

Use utilities like decoration-sky-500 and decoration-pink-500 to change the text decoration color of an element:

I’m Derek, an astro-engineer based in Tattooine. I like to build X-Wings at My Company, Inc. Outside of work, I like to watch pod-racing and have light-saber fights.

Use the color opacity modifier to control the text decoration color opacity of an element:

I’m Derek, an astro-engineer based in Tattooine. I like to build X-Wings at My Company, Inc. Outside of work, I like to watch pod-racing and have light-saber fights.

Use the decoration-[<value>] syntax to set the text decoration color based on a completely custom value:

For CSS variables, you can also use the decoration-(<custom-property>) syntax:

This is just a shorthand for decoration-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a text-decoration-color utility with a variant like hover:* to only apply the utility in that state:

Hover over the text to see the expected behavior

Learn more about using variants in the variants documentation.

Prefix a text-decoration-color utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --color-* theme variables to customize the color utilities in your project:

Now the decoration-regal-blue utility can be used in your markup:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p>  I’m Derek, an astro-engineer based in Tattooine. I like to build X-Wings  at <a class="underline decoration-sky-500">My Company, Inc</a>. Outside  of work, I like to <a class="underline decoration-pink-500">watch pod-racing</a>  and have <a class="underline decoration-indigo-500">light-saber</a> fights.</p>
```

Example 2 (unknown):
```unknown
<p>  I’m Derek, an astro-engineer based in Tattooine. I like to build X-Wings  at <a class="underline decoration-sky-500/30">My Company, Inc</a>. Outside  of work, I like to <a class="underline decoration-pink-500/30">watch pod-racing</a>  and have <a class="underline decoration-indigo-500/30">light-saber</a> fights.</p>
```

Example 3 (unknown):
```unknown
<p class="decoration-[#50d71e] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="decoration-(--my-color) ...">  Lorem ipsum dolor sit amet...</p>
```

---

## z-index

**URL:** https://tailwindcss.com/docs/z-index

**Contents:**
- Examples
  - Basic example
  - Using negative values
  - Using a custom value
  - Responsive design

Use the z-<number> utilities like z-10 and z-50 to control the stack order (or three-dimensional positioning) of an element, regardless of the order it has been displayed:

To use a negative z-index value, prefix the class name with a dash to convert it to a negative value:

Use the z-[<value>] syntax to set the stack order based on a completely custom value:

For CSS variables, you can also use the z-(<custom-property>) syntax:

This is just a shorthand for z-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a z-index utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="z-40 ...">05</div><div class="z-30 ...">04</div><div class="z-20 ...">03</div><div class="z-10 ...">02</div><div class="z-0 ...">01</div>
```

Example 2 (unknown):
```unknown
<div class="...">05</div><div class="...">04</div><div class="-z-10 ...">03</div><div class="...">02</div><div class="...">01</div>
```

Example 3 (unknown):
```unknown
<div class="z-[calc(var(--index)+1)] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="z-(--my-z) ...">  <!-- ... --></div>
```

---

## font-stretch

**URL:** https://tailwindcss.com/docs/font-stretch

**Contents:**
- Examples
  - Basic example
  - Using percentages
  - Using a custom value
  - Responsive design

Use utilities like font-stretch-condensed and font-stretch-expanded to set the width of a font face:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

This only applies to fonts that have multiple width variations available, otherwise the browser selects the closest match.

Use font-stretch-<percentage> utilities like font-stretch-50% and font-stretch-125% to set the width of a font face using a percentage:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Use the font-stretch-[<value>] syntax to set the font width based on a completely custom value:

For CSS variables, you can also use the font-stretch-(<custom-property>) syntax:

This is just a shorthand for font-stretch-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a font-stretch utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="font-stretch-extra-condensed">The quick brown fox...</p><p class="font-stretch-condensed">The quick brown fox...</p><p class="font-stretch-normal">The quick brown fox...</p><p class="font-stretch-expanded">The quick brown fox...</p><p class="font-stretch-extra-expanded">The quick brown fox...</p>
```

Example 2 (unknown):
```unknown
<p class="font-stretch-50%">The quick brown fox...</p><p class="font-stretch-100%">The quick brown fox...</p><p class="font-stretch-150%">The quick brown fox...</p>
```

Example 3 (unknown):
```unknown
<p class="font-stretch-[66.66%] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="font-stretch-(--my-font-width) ...">  Lorem ipsum dolor sit amet...</p>
```

---

## visibility

**URL:** https://tailwindcss.com/docs/visibility

**Contents:**
- Examples
  - Making elements invisible
  - Collapsing elements
  - Making elements visible
  - Responsive design

Use the invisible utility to hide an element, but still maintain its place in the document, affecting the layout of other elements:

To completely remove an element from the document, use the display property instead.

Use the collapse utility to hide table rows, row groups, columns, and column groups as if they were set to display: none, but without impacting the size of other rows and columns:

This makes it possible to dynamically toggle rows and columns without affecting the table layout.

Use the visible utility to make an element visible:

This is mostly useful for undoing the invisible utility at different screen sizes.

Prefix a visibility utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-cols-3 gap-4">  <div>01</div>  <div class="invisible ...">02</div>  <div>03</div></div>
```

Example 2 (unknown):
```unknown
<table>  <thead>    <tr>      <th>Invoice #</th>      <th>Client</th>      <th>Amount</th>    </tr>  </thead>  <tbody>    <tr>      <td>#100</td>      <td>Pendant Publishing</td>      <td>$2,000.00</td>    </tr>    <tr class="collapse">      <td>#101</td>      <td>Kruger Industrial Smoothing</td>      <td>$545.00</td>    </tr>    <tr>      <td>#102</td>      <td>J. Peterman</td>      <td>$10,000.25</td>    </tr>  </tbody></table>
```

Example 3 (unknown):
```unknown
<div class="grid grid-cols-3 gap-4">  <div>01</div>  <div class="visible ...">02</div>  <div>03</div></div>
```

Example 4 (unknown):
```unknown
<div class="visible md:invisible ...">  <!-- ... --></div>
```

---

## isolation

**URL:** https://tailwindcss.com/docs/isolation

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use the isolate and isolation-auto utilities to control whether an element should explicitly create a new stacking context:

Prefix an isolation utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="isolate ...">  <!-- ... --></div>
```

Example 2 (unknown):
```unknown
<div class="isolate md:isolation-auto ...">  <!-- ... --></div>
```

---

## Styling with utility classes

**URL:** https://tailwindcss.com/docs/styling-with-utility-classes

**Contents:**
- Overview
  - Why not just use inline styles?
- Thinking in utility classes
  - Styling hover and focus states
  - Media queries and breakpoints
  - Targeting dark mode
  - Using class composition
  - Using arbitrary values
    - How does this even work?
  - Complex selectors

You style things with Tailwind by combining many single-purpose presentational classes (utility classes) directly in your markup:

You have a new message!

For example, in the UI above we've used:

Styling things this way contradicts a lot of traditional best practices, but once you try it you'll quickly notice some really important benefits:

These benefits make a big difference on small projects, but they are even more valuable for teams working on long-running projects at scale.

A common reaction to this approach is wondering, “isn’t this just inline styles?” and in some ways it is — you’re applying styles directly to elements instead of assigning them a class name and then styling that class.

But using utility classes has many important advantages over inline styles, for example:

This component is fully responsive and includes a button with hover and active styles, and is built entirely with utility classes:

To style an element on states like hover or focus, prefix any utility with the state you want to target, for example hover:bg-sky-700:

Hover over this button to see the background color change

These prefixes are called variants in Tailwind, and they only apply the styles from a utility class when the condition for that variant matches.

Here's what the generated CSS looks like for the hover:bg-sky-700 class:

Notice how this class does nothing unless the element is hovered? Its only job is to provide hover styles — nothing else.

This is different from how you'd write traditional CSS, where a single class would usually provide the styles for many states:

You can even stack variants in Tailwind to apply a utility when multiple conditions match, like combining hover: and disabled:

Learn more in the documentation styling elements on hover, focus, and other states.

Just like hover and focus states, you can style elements at different breakpoints by prefixing any utility with the breakpoint where you want that style to apply:

Resize this example to see the layout change

In the example above, the sm: prefix makes sure that grid-cols-3 only triggers at the sm breakpoint and above, which is 40rem out of the box:

Learn more in the responsive design documentation.

Styling an element in dark mode is just a matter of adding the dark: prefix to any utility you want to apply when dark mode is active:

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

Just like with hover states or media queries, the important thing to understand is that a single utility class will never include both the light and dark styles — you style things in dark mode by using multiple classes, one for the light mode styles and another for the dark mode styles.

Learn more in the dark mode documentation.

A lot of the time with Tailwind you'll even use multiple classes to build up the value for a single CSS property, for example adding multiple filters to an element:

Both of these effects rely on the filter property in CSS, so Tailwind uses CSS variables to make it possible to compose these effects together:

The generated CSS above is slightly simplified, but the trick here is that each utility sets a CSS variable just for the effect it's meant to apply. Then the filter property looks at all of these variables, falling back to nothing if the variable hasn't been set.

Tailwind uses this same approach for gradients, shadow colors, transforms, and more.

Many utilities in Tailwind are driven by theme variables, like bg-blue-500, text-xl, and shadow-md, which map to your underlying color palette, type scale, and shadows.

When you need to use a one-off value outside of your theme, use the special square bracket syntax for specifying arbitrary values:

This can be useful for one-off colors outside of your color palette (like the Facebook blue above), but also when you need a complex custom value like a very specific grid:

It's also useful when you need to use CSS features like calc(), even if you are using your theme values:

There's even a syntax for generating completely arbitrary CSS including an arbitrary property name, which can be useful for setting CSS variables:

Learn more in the documentation on using arbitrary values.

Tailwind CSS isn't one big static stylesheet like you might be used to with other CSS frameworks — it generates the CSS needed based on the classes you're actually using when you compile your CSS.

It does this by scanning all of the files in your project looking for any symbol that looks like it could be a class name:

After it's found all of the potential classes, Tailwind generates the CSS for each one and compiles it all into one stylesheet of just the styles you actually need.

Since the CSS is generated based on the class name, Tailwind can recognize classes using arbitrary values like bg-[#316ff6] and generate the necessary CSS, even when the value isn't part of your theme.

Learn more about how this works in detecting classes in source files.

Sometimes you need to style an element under a combination of conditions, for example in dark mode, at a specific breakpoint, when hovered, and when the element has a specific data attribute.

Here's an example of what that looks like with Tailwind:

Tailwind also supports things like group-hover, which let you style an element when a specific parent is hovered:

This group-* syntax works with other variants too, like group-focus, group-active, and many more.

For really complex scenarios (especially when styling HTML you don't control), Tailwind supports arbitrary variants which let you write any selector you want, directly in a class name:

Inline styles are still very useful in Tailwind CSS projects, particularly when a value is coming from a dynamic source like a database or API:

You might also reach for an inline style for very complicated arbitrary values that are difficult to read when formatted as a class name:

Another useful pattern is setting CSS variables based on dynamic sources using inline styles, then referencing those variables with utility classes:

When you build entire projects with just utility classes, you'll inevitably find yourself repeating certain patterns to recreate the same design in different places.

For example, here the utility classes for each avatar image are repeated five separate times:

Don't panic! In practice this isn't the problem you might be worried it is, and the strategies for dealing with it are things you already do every day.

A lot of the time a design element that shows up more than once in the rendered page is only actually authored once because the actual markup is rendered in a loop.

For example, the duplicate avatars at the beginning of this guide would almost certainly be rendered in a loop in a real project:

When elements are rendered in a loop like this, the actual class list is only written once so there's no actual duplication problem to solve.

When duplication is localized to a group of elements in a single file, the easiest way to deal with it is to use multi-cursor editing to quickly select and edit the class list for each element at once:

You'd be surprised at how often this ends up being the best solution. If you can quickly edit all of the duplicated class lists simultaneously, there's no benefit to introducing any additional abstraction.

If you need to reuse some styles across multiple files, the best strategy is to create a component if you're using a front-end framework like React, Svelte, or Vue, or a template partial if you're using a templating language like Blade, ERB, Twig, or Nunjucks.

Now you can use this component in as many places as you like, while still having a single source of truth for the styles so they can easily be updated together in one place.

If you're using a templating language like ERB or Twig instead of something like React or Vue, creating a template partial for something as small as a button can feel like overkill compared to a simple CSS class like btn.

While it's highly recommended that you create proper template partials for more complex components, writing some custom CSS is totally fine when a template partial feels heavy-handed.

Here's what a btn-primary class might look like, using theme variables to keep the design consistent:

Again though, for anything that's more complicated than just a single HTML element, we highly recommend using template partials so the styles and structure can be encapsulated in one place.

When you add two classes that target the same CSS property, the class that appears later in the stylesheet wins. So in this example, the element will receive display: grid even though flex comes last in the actual class attribute:

In general, you should just never add two conflicting classes to the same element — only ever add the one you actually want to take effect:

Using component-based libraries like React or Vue, this often means exposing specific props for styling customizations instead of letting consumers add extra classes from outside of a component, since those styles will often conflict.

When you really need to force a specific utility class to take effect and have no other means of managing the specificity, you can add ! to the end of the class name to make all of the declarations !important:

If you're adding Tailwind to a project that has existing complex CSS with high specificity rules, you can use the important flag when importing Tailwind to mark all utilities as !important:

If your project has class names that conflict with Tailwind CSS utilities, you can prefix all Tailwind-generated classes and CSS variables using the prefix option:

**Examples:**

Example 1 (unknown):
```unknown
<div class="mx-auto flex max-w-sm items-center gap-x-4 rounded-xl bg-white p-6 shadow-lg outline outline-black/5 dark:bg-slate-800 dark:shadow-none dark:-outline-offset-1 dark:outline-white/10">  <img class="size-12 shrink-0" src="/img/logo.svg" alt="ChitChat Logo" />  <div>    <div class="text-xl font-medium text-black dark:text-white">ChitChat</div>    <p class="text-gray-500 dark:text-gray-400">You have a new message!</p>  </div></div>
```

Example 2 (unknown):
```unknown
<div class="flex flex-col gap-2 p-8 sm:flex-row sm:items-center sm:gap-6 sm:py-4 ...">  <img class="mx-auto block h-24 rounded-full sm:mx-0 sm:shrink-0" src="/img/erin-lindford.jpg" alt="" />  <div class="space-y-2 text-center sm:text-left">    <div class="space-y-0.5">      <p class="text-lg font-semibold text-black">Erin Lindford</p>      <p class="font-medium text-gray-500">Product Engineer</p>    </div>    <button class="border-purple-200 text-purple-600 hover:border-transparent hover:bg-purple-600 hover:text-white active:bg-purple-700 ...">      Message    </button>  </div></div>
```

Example 3 (unknown):
```unknown
<button class="bg-sky-500 hover:bg-sky-700 ...">Save changes</button>
```

Example 4 (unknown):
```unknown
.hover\:bg-sky-700 {  &:hover {    background-color: var(--color-sky-700);  }}
```

---

## object-fit

**URL:** https://tailwindcss.com/docs/object-fit

**Contents:**
- Examples
  - Resizing to cover
  - Containing within
  - Stretching to fit
  - Scaling down
  - Using the original size
  - Responsive design

Use the object-cover utility to resize an element's content to cover its container:

Use the object-contain utility to resize an element's content to stay contained within its container:

Use the object-fill utility to stretch an element's content to fit its container:

Use the object-scale-down utility to display an element's content at its original size but scale it down to fit its container if necessary:

Use the object-none utility to display an element's content at its original size ignoring the container size:

Prefix an object-fit utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<img class="h-48 w-96 object-cover ..." src="/img/mountains.jpg" />
```

Example 2 (unknown):
```unknown
<img class="h-48 w-96 object-contain ..." src="/img/mountains.jpg" />
```

Example 3 (unknown):
```unknown
<img class="h-48 w-96 object-fill ..." src="/img/mountains.jpg" />
```

Example 4 (unknown):
```unknown
<img class="h-48 w-96 object-scale-down ..." src="/img/mountains.jpg" />
```

---

## background-clip

**URL:** https://tailwindcss.com/docs/background-clip

**Contents:**
- Examples
  - Basic example
  - Cropping to text
  - Responsive design

Use the bg-clip-border, bg-clip-padding, and bg-clip-content utilities to control the bounding box of an element's background:

Use the bg-clip-text utility to crop an element's background to match the shape of the text:

Prefix a background-clip utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="border-4 bg-indigo-500 bg-clip-border p-3"></div><div class="border-4 bg-indigo-500 bg-clip-padding p-3"></div><div class="border-4 bg-indigo-500 bg-clip-content p-3"></div>
```

Example 2 (unknown):
```unknown
<p class="bg-linear-to-r from-pink-500 to-violet-500 bg-clip-text text-5xl font-extrabold text-transparent ...">  Hello world</p>
```

Example 3 (unknown):
```unknown
<div class="bg-clip-border md:bg-clip-padding ...">  <!-- ... --></div>
```

---

## Compatibility

**URL:** https://tailwindcss.com/docs/compatibility

**Contents:**
- Browser support
- Sass, Less, and Stylus
  - Build-time imports
  - Variables
  - Nesting
  - Loops
  - Color and math functions
- CSS modules
  - Scoping concerns
  - Performance

Tailwind CSS v4.0 is designed for and tested on modern browsers, and the core functionality of the framework specifically depends on these browser versions:

Tailwind also includes support for many bleeding-edge platform features like field-sizing: content, @starting-style, and text-wrap: balance that have limited browser support. It's up to you if you want to use these modern features in your projects — if the browsers you're targeting don't support them, simply don't use those utilities and variants.

If you're unsure about the support for a modern platform feature, the Can I use database is a great resource.

Tailwind CSS v4.0 is a full-featured CSS build tool designed for a specific workflow, and is not designed to be used with CSS preprocessors like Sass, Less, or Stylus.

Think of Tailwind CSS itself as your preprocessor — you shouldn't use Tailwind with Sass for the same reason you wouldn't use Sass with Stylus.

Since Tailwind is designed for modern browsers, you actually don't need a preprocessor for things like nesting or variables, and Tailwind itself will do things like bundle your imports and add vendor prefixes.

Tailwind will automatically bundle other CSS files you include with @import, without the need for a separate preprocessing tool.

In this example, the typography.css file will be bundled into your compiled CSS for you by Tailwind, without any other tooling like Sass or postcss-import.

All modern browsers support native CSS variables without the need for any sort of preprocessor:

Tailwind relies on CSS variables heavily internally, so if you can use Tailwind in your project, you can use native CSS variables.

Under the hood Tailwind uses Lightning CSS to process nested CSS like this:

Tailwind flattens that nested CSS for you so it can be understood by all modern browsers:

Native CSS nesting support is also very good these days, so you don't really need a preprocessor for nesting even if you aren't using Tailwind.

In Tailwind, the sorts of classes you may have used loops for in the past (like col-span-1, col-span-2, etc.) are generated for you on-demand by Tailwind whenever you use them instead of having to be predefined.

On top of that, when you're building things with Tailwind CSS, you do the vast majority of your styling in your HTML, not in CSS files. Since you're not writing tons of CSS in the first place, you just don't need features like loops that are designed for programmatically generating lots of custom CSS rules.

When using preprocessors like Sass or Less, you may have used functions like darken or lighten to adjust colors.

When using Tailwind, the recommended workflow is to use a predefined color palette that includes light and dark shades of each color, like the expertly designed default color palette included with the framework.

You can also use modern CSS features like color-mix() to adjust colors at run-time directly in the browser. This even lets you adjust colors defined using CSS variables or the currentcolor keyword, which isn't possible with preprocessors.

Similarly, browsers support math functions like min(), max(), and round() natively now, so there's no need to rely on a preprocessor for these features anymore either.

Tailwind is compatible with CSS modules and can co-exist with them if you are introducing Tailwind into a project that already uses them, but we don't recommend using CSS modules and Tailwind together if you can avoid it.

CSS modules are designed to solve scoping problems that just don't exist when composing utility classes in your HTML instead of writing custom CSS.

Styles are naturally scoped with Tailwind because each utility class always does the same thing, no matter where it's used — there's no risk that adding a utility class to one part of your UI creates some unexpected side effect somewhere else.

When using CSS modules, build tools like Vite, Parcel, and Turbopack process each CSS module separately. That means if you have 50 CSS modules in a project, Tailwind needs to run 50 separate times, which leads to much slower build times and a worse developer experience.

Since CSS modules are each processed separately, they have no @theme unless you import one.

This means features like @apply won't work the way you expect unless you explicitly import your global styles as reference:

Import your global styles as reference to make sure your theme variables are defined

Alternatively, you can also just use CSS variables instead of @apply which has the added benefit of letting Tailwind skip processing those files and will improve your build performance:

Vue, Svelte, and Astro support <style> blocks in component files that behave very much like CSS modules, which means they are each processed by your build tooling totally separately and have all of the same drawbacks.

If you're using Tailwind with these tools, we recommend avoiding <style> blocks in your components and just styling things with utility classes directly in your markup, the way Tailwind is meant to be used.

If you do use <style> blocks, make sure to import your global styles as reference if you want features like @apply to work as expected:

Import your global styles as reference to make sure your theme variables are defined

Or just use your globally defined CSS variables instead of features like @apply, which don't require Tailwind to process your component CSS at all:

**Examples:**

Example 1 (unknown):
```unknown
@import "tailwindcss";@import "./typography.css";
```

Example 2 (unknown):
```unknown
.typography {  font-size: var(--text-base);  color: var(--color-gray-700);}
```

Example 3 (unknown):
```unknown
.typography {  p {    font-size: var(--text-base);  }  img {    border-radius: var(--radius-lg);  }}
```

Example 4 (unknown):
```unknown
.typography p {  font-size: var(--text-base);}.typography img {  border-radius: var(--radius-lg);}
```

---

## Functions and directives

**URL:** https://tailwindcss.com/docs/functions-and-directives

**Contents:**
- Directives
  - @import
  - @theme
  - @source
  - @utility
  - @variant
  - @custom-variant
  - @apply
  - @reference
  - Subpath Imports

Directives are custom Tailwind-specific at-rules you can use in your CSS that offer special functionality for Tailwind CSS projects.

Use the @import directive to inline import CSS files, including Tailwind itself:

Use the @theme directive to define your project's custom design tokens, like fonts, colors, and breakpoints:

Learn more about customizing your theme in the theme variables documentation.

Use the @source directive to explicitly specify source files that aren't picked up by Tailwind's automatic content detection:

Learn more about automatic content detection in the detecting classes in source files documentation.

Use the @utility directive to add custom utilities to your project that work with variants like hover, focus and lg:

Learn more about registering custom utilities in the adding custom utilities documentation.

Use the @variant directive to apply a Tailwind variant to styles in your CSS:

Learn more using variants in the using variants documentation.

Use the @custom-variant directive to add a custom variant in your project:

This lets you write utilities theme-midnight:bg-black and theme-midnight:text-white.

Learn more about adding custom variants in the adding custom variants documentation.

Use the @apply directive to inline any existing utility classes into your own custom CSS:

This is useful when you need to write custom CSS (like to override the styles in a third-party library) but still want to work with your design tokens and use the same syntax you’re used to using in your HTML.

If you want to use @apply or @variant in the <style> block of a Vue or Svelte component, or within CSS modules, you will need to import your theme variables, custom utilities, and custom variants to make those values available in that context.

To do this without duplicating any CSS in your output, use the @reference directive to import your main stylesheet for reference without actually including the styles:

If you’re just using the default theme with no customizations (e.g. by using things like @theme, @custom-variant, @plugin, etc…), you can import tailwindcss directly:

When using the CLI, Vite, or PostCSS the directives @import, @reference, @plugin, and @config all support subpath imports which work similarly to bundler and TypeScript path aliases:

Tailwind provides the following build-time functions to make working with colors and the spacing scale easier.

Use the --alpha() function to adjust the opacity of a color:

Use the --spacing() function to generate a spacing value based on your theme:

This can also be useful in arbitrary values, especially in combination with calc():

The following directives and functions exist solely for compatibility with Tailwind CSS v3.x.

The @config and @plugin directives may be used in conjunction with @theme, @utility, and other CSS-driven features. This can be used to incrementally move over your theme, custom configuration, utilities, variants, and presets to CSS. Things defined in CSS will be merged where possible and otherwise take precedence over those defined in configs, presets, and plugins.

Use the @config directive to load a legacy JavaScript-based configuration file:

The corePlugins, safelist, and separator options from the JavaScript-based config are not supported in v4.0. To safelist utilities in v4 use @source inline().

Use the @plugin directive to load a legacy JavaScript-based plugin:

The @plugin directive accepts either a package name or a local path.

Use the theme() function to access your Tailwind theme values using dot notation:

This function is deprecated, and we recommend using CSS theme variables instead.

**Examples:**

Example 1 (unknown):
```unknown
@import "tailwindcss";
```

Example 2 (unknown):
```unknown
@theme {  --font-display: "Satoshi", "sans-serif";  --breakpoint-3xl: 120rem;  --color-avocado-100: oklch(0.99 0 0);  --color-avocado-200: oklch(0.98 0.04 113.22);  --color-avocado-300: oklch(0.94 0.11 115.03);  --color-avocado-400: oklch(0.92 0.19 114.08);  --color-avocado-500: oklch(0.84 0.18 117.33);  --color-avocado-600: oklch(0.53 0.12 118.34);  --ease-fluid: cubic-bezier(0.3, 0, 0, 1);  --ease-snappy: cubic-bezier(0.2, 0, 0, 1);  /* ... */}
```

Example 3 (unknown):
```unknown
@source "../node_modules/@my-company/ui-lib";
```

Example 4 (unknown):
```unknown
@utility tab-4 {  tab-size: 4;}
```

---

## box-sizing

**URL:** https://tailwindcss.com/docs/box-sizing

**Contents:**
- Examples
  - Including borders and padding
  - Excluding borders and padding
  - Responsive design

Use the box-border utility to set an element's box-sizing to border-box, telling the browser to include the element's borders and padding when you give it a height or width.

This means a 100px × 100px element with a 2px border and 4px of padding on all sides will be rendered as 100px × 100px, with an internal content area of 88px × 88px:

Tailwind makes this the default for all elements in our preflight base styles.

Use the box-content utility to set an element's box-sizing to content-box, telling the browser to add borders and padding on top of the element's specified width or height.

This means a 100px × 100px element with a 2px border and 4px of padding on all sides will actually be rendered as 112px × 112px, with an internal content area of 100px × 100px:

Prefix a box-sizing utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="box-border size-32 border-4 p-4 ...">  <!-- ... --></div>
```

Example 2 (unknown):
```unknown
<div class="box-content size-32 border-4 p-4 ...">  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="box-content md:box-border ...">  <!-- ... --></div>
```

---

## hyphens

**URL:** https://tailwindcss.com/docs/hyphens

**Contents:**
- Examples
  - Preventing hyphenation
  - Manual hyphenation
  - Automatic hyphenation
  - Responsive design

Use the hyphens-none utility to prevent words from being hyphenated even if the line break suggestion &shy; is used:

Officially recognized by the Duden dictionary as the longest word in German, Kraftfahrzeug­haftpflichtversicherung is a 36 letter word for motor vehicle liability insurance.

Use the hyphens-manual utility to only set hyphenation points where the line break suggestion &shy; is used:

Officially recognized by the Duden dictionary as the longest word in German, Kraftfahrzeug­haftpflichtversicherung is a 36 letter word for motor vehicle liability insurance.

This is the default browser behavior.

Use the hyphens-auto utility to allow the browser to automatically choose hyphenation points based on the language:

Officially recognized by the Duden dictionary as the longest word in German, Kraftfahrzeughaftpflichtversicherung is a 36 letter word for motor vehicle liability insurance.

The line break suggestion &shy; will be preferred over automatic hyphenation points.

Prefix a hyphens utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="hyphens-none">  ... Kraftfahrzeug&shy;haftpflichtversicherung is a ...</p>
```

Example 2 (unknown):
```unknown
<p class="hyphens-manual">  ... Kraftfahrzeug&shy;haftpflichtversicherung is a ...</p>
```

Example 3 (unknown):
```unknown
<p class="hyphens-auto" lang="de">  ... Kraftfahrzeughaftpflichtversicherung is a ...</p>
```

Example 4 (unknown):
```unknown
<p class="hyphens-none md:hyphens-auto ...">  Lorem ipsum dolor sit amet...</p>
```

---

## align-self

**URL:** https://tailwindcss.com/docs/align-self

**Contents:**
- Examples
  - Auto
  - Start
  - Center
  - End
  - Stretch
  - Baseline
  - Last baseline
  - Responsive design

Use the self-auto utility to align an item based on the value of the container's align-items property:

Use the self-start utility to align an item to the start of the container's cross axis, despite the container's align-items value:

Use the self-center utility to align an item along the center of the container's cross axis, despite the container's align-items value:

Use the self-end utility to align an item to the end of the container's cross axis, despite the container's align-items value:

Use the self-stretch utility to stretch an item to fill the container's cross axis, despite the container's align-items value:

Use the self-baseline utility to align an item such that its baseline aligns with the baseline of the flex container's cross axis:

Use the self-baseline-last utility to align an item along the container's cross axis such that its baseline aligns with the last baseline in the container:

Working on the future of astronaut recruitment at Space Recruit.

A multidisciplinary designer.

This is useful for ensuring that text items align with each other, even if they have different heights.

Prefix an align-self utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex items-stretch ...">  <div>01</div>  <div class="self-auto ...">02</div>  <div>03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex items-stretch ...">  <div>01</div>  <div class="self-start ...">02</div>  <div>03</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex items-stretch ...">  <div>01</div>  <div class="self-center ...">02</div>  <div>03</div></div>
```

Example 4 (unknown):
```unknown
<div class="flex items-stretch ...">  <div>01</div>  <div class="self-end ...">02</div>  <div>03</div></div>
```

---

## aspect-ratio

**URL:** https://tailwindcss.com/docs/aspect-ratio

**Contents:**
- Examples
  - Basic example
  - Using a video aspect ratio
  - Using a custom value
  - Responsive design
- Customizing your theme

Use aspect-<ratio> utilities like aspect-3/2 to give an element a specific aspect ratio:

Resize the example to see the expected behavior

Use the aspect-video utility to give a video element a 16 / 9 aspect ratio:

Resize the example to see the expected behavior

Use the aspect-[<value>] syntax to set the aspect ratio based on a completely custom value:

For CSS variables, you can also use the aspect-(<custom-property>) syntax:

This is just a shorthand for aspect-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix an aspect-ratio utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --aspect-* theme variables to customize the aspect ratio utilities in your project:

Now the aspect-retro utility can be used in your markup:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<img class="aspect-3/2 object-cover ..." src="/img/villas.jpg" />
```

Example 2 (unknown):
```unknown
<iframe class="aspect-video ..." src="https://www.youtube.com/embed/dQw4w9WgXcQ"></iframe>
```

Example 3 (unknown):
```unknown
<img class="aspect-[calc(4*3+1)/3] ..." src="/img/villas.jpg" />
```

Example 4 (unknown):
```unknown
<img class="aspect-(--my-aspect-ratio) ..." src="/img/villas.jpg" />
```

---

## text-decoration-thickness

**URL:** https://tailwindcss.com/docs/text-decoration-thickness

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design

Use decoration-<number> utilities like decoration-2 and decoration-4 to change the text decoration thickness of an element:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Use the decoration-[<value>] syntax to set the text decoration thickness based on a completely custom value:

For CSS variables, you can also use the decoration-(length:<custom-property>) syntax:

This is just a shorthand for decoration-[length:var(<custom-property>)] that adds the var() function for you automatically.

Prefix a text-decoration-thickness utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="underline decoration-1">The quick brown fox...</p><p class="underline decoration-2">The quick brown fox...</p><p class="underline decoration-4">The quick brown fox...</p>
```

Example 2 (unknown):
```unknown
<p class="decoration-[0.25rem] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 3 (unknown):
```unknown
<p class="decoration-(length:--my-decoration-thickness) ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="underline md:decoration-4 ...">  Lorem ipsum dolor sit amet...</p>
```

---

## content

**URL:** https://tailwindcss.com/docs/content

**Contents:**
- Examples
  - Basic example
  - Referencing an attribute value
  - Using spaces and underscores
  - Using a CSS variable
  - Responsive design

Use the content-[<value>] syntax, along with the before and after variants, to set the contents of the ::before and ::after pseudo-elements:

Use the content-[attr(<name>)] syntax to reference a value stored in an attribute using the attr() CSS function:

Since whitespace denotes the end of a class in HTML, replace any spaces in an arbitrary value with an underscore:

If you need to include an actual underscore, you can do this by escaping it with a backslash:

Use the content-(<custom-property>) syntax to control the contents of the ::before and ::after pseudo-elements using a CSS variable:

This is just a shorthand for content-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a content utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p>Higher resolution means more than just a better-quality image. With aRetina 6K display, <a class="text-blue-600 after:content-['_↗']" href="...">Pro Display XDR</a> gives you nearly 40 percent more screen real estate thana 5K display.</p>
```

Example 2 (unknown):
```unknown
<p before="Hello World" class="before:content-[attr(before)] ...">  <!-- ... --></p>
```

Example 3 (unknown):
```unknown
<p class="before:content-['Hello_World'] ..."></p>
```

Example 4 (unknown):
```unknown
<p class="before:content-['Hello\_World']"></p>
```

---

## min-height

**URL:** https://tailwindcss.com/docs/min-height

**Contents:**
- Examples
  - Basic example
  - Using a percentage
  - Using a custom value
  - Responsive design
- Customizing your theme

Use min-h-<number> utilities like min-h-24 and min-h-64 to set an element to a fixed minimum height based on the spacing scale:

Use min-h-full or min-h-<fraction> utilities like min-h-1/2, and min-h-2/5 to give an element a percentage-based minimum height:

Use the min-h-[<value>] syntax to set the minimum height based on a completely custom value:

For CSS variables, you can also use the min-h-(<custom-property>) syntax:

This is just a shorthand for min-h-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a min-height utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The min-h-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="h-20 ...">  <div class="min-h-80 ...">min-h-80</div>  <div class="min-h-64 ...">min-h-64</div>  <div class="min-h-48 ...">min-h-48</div>  <div class="min-h-40 ...">min-h-40</div>  <div class="min-h-32 ...">min-h-32</div>  <div class="min-h-24 ...">min-h-24</div></div>
```

Example 2 (unknown):
```unknown
<div class="min-h-full ...">min-h-full</div><div class="min-h-9/10 ...">min-h-9/10</div><div class="min-h-3/4 ...">min-h-3/4</div><div class="min-h-1/2 ...">min-h-1/2</div><div class="min-h-1/3 ...">min-h-1/3</div>
```

Example 3 (unknown):
```unknown
<div class="min-h-[220px] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="min-h-(--my-min-height) ...">  <!-- ... --></div>
```

---

## Upgrade guide

**URL:** https://tailwindcss.com/docs/upgrade-guide

**Contents:**
- Using the upgrade tool
- Upgrading manually
  - Using PostCSS
  - Using Vite
  - Using Tailwind CLI
- Changes from v3
  - Browser requirements
  - Removed @tailwind directives
  - Removed deprecated utilities
  - Renamed utilities

Tailwind CSS v4.0 is a new major version of the framework, so while we've worked really hard to minimize breaking changes, some updates are necessary. This guide outlines all the steps required to upgrade your projects from v3 to v4.

Tailwind CSS v4.0 is designed for Safari 16.4+, Chrome 111+, and Firefox 128+. If you need to support older browsers, stick with v3.4 until your browser support requirements change.

If you'd like to upgrade a project from v3 to v4, you can use our upgrade tool to do the vast majority of the heavy lifting for you:

For most projects, the upgrade tool will automate the entire migration process including updating your dependencies, migrating your configuration file to CSS, and handling any changes to your template files.

The upgrade tool requires Node.js 20 or higher, so ensure your environment is updated before running it.

We recommend running the upgrade tool in a new branch, then carefully reviewing the diff and testing your project in the browser to make sure all of the changes look correct. You may need to tweak a few things by hand in complex projects, but the tool will save you a ton of time either way.

It's also a good idea to go over all of the breaking changes in v4 and get a good understanding of what's changed, in case there are other things you need to update in your project that the upgrade tool doesn't catch.

In v3, the tailwindcss package was a PostCSS plugin, but in v4 the PostCSS plugin lives in a dedicated @tailwindcss/postcss package.

Additionally, in v4 imports and vendor prefixing is now handled for you automatically, so you can remove postcss-import and autoprefixer if they are in your project:

If you're using Vite, we recommend migrating from the PostCSS plugin to our new dedicated Vite plugin for improved performance and the best developer experience:

In v4, Tailwind CLI lives in a dedicated @tailwindcss/cli package. Update any of your build commands to use the new package instead:

Here's a comprehensive list of all the breaking changes in Tailwind CSS v4.0.

Our upgrade tool will handle most of these changes for you automatically, so we highly recommend using it if you can.

Tailwind CSS v4.0 is designed for modern browsers and targets Safari 16.4, Chrome 111, and Firefox 128. We depend on modern CSS features like @property and color-mix() for core framework features, and Tailwind CSS v4.0 will not work in older browsers.

If you need to support older browsers, we recommend sticking with v3.4 for now. We're actively exploring a compatibility mode to help people upgrade sooner that we hope to share more news on in the future.

In v4 you import Tailwind using a regular CSS @import statement, not using the @tailwind directives you used in v3:

We've removed any utilities that were deprecated in v3 and have been undocumented for several years. Here's a list of what's been removed along with the modern alternative:

We've renamed the following utilities in v4 to make them more consistent and predictable:

We've renamed the default shadow, radius and blur scales to make sure every utility has a named value. The "bare" versions still work for backward compatibility, but the <utility>-sm utilities will look different unless updated to their respective <utility>-xs versions.

To update your project for these changes, replace all the v3 utilities with their v4 versions:

The outline utility now sets outline-width: 1px by default to be more consistent with border and ring utilities. Furthermore all outline-<number> utilities default outline-style to solid, omitting the need to combine them with outline:

The outline-none utility previously didn't actually set outline-style: none, and instead set an invisible outline that would still show up in forced colors mode for accessibility reasons.

To make this more clear we've renamed this utility to outline-hidden and added a new outline-none utility that actually sets outline-style: none.

To update your project for this change, replace any usage of outline-none with outline-hidden:

In v3, the ring utility added a 3px ring. We've changed this in v4 to be 1px to make it consistent with borders and outlines.

To update your project for this change, replace any usage of ring with ring-3:

We've changed the selector used by the space-x-* and space-y-* utilities to address serious performance issues on large pages:

You might see changes in your project if you were ever using these utilities with inline elements, or if you were adding other margins to child elements to tweak their spacing.

If this change causes any issues in your project, we recommend migrating to a flex or grid layout and using gap instead:

In v3, overriding part of a gradient with a variant would "reset" the entire gradient, so in this example the to-* color would be transparent in dark mode instead of yellow:

In v4, these values are preserved which is more consistent with how other utilities in Tailwind work.

This means you may need to explicitly use via-none if you want to "unset" a three-stop gradient back to a two-stop gradient in a specific state:

In v3, the container utility had several configuration options like center and padding that no longer exist in v4.

To customize the container utility in v4, extend it using the @utility directive:

In v3, the border-* and divide-* utilities used your configured gray-200 color by default. We've changed this to currentColor in v4 to make Tailwind less opinionated and match browser defaults.

To update your project for this change, make sure you specify a color anywhere you're using a border-* or divide-* utility:

Alternatively, add these base styles to your project to preserve the v3 behavior:

We've changed the width of the ring utility from 3px to 1px and changed the default color from blue-500 to currentColor to make things more consistent the border-*, divide-*, and outline-* utilities.

To update your project for these changes, replace any use of ring with ring-3:

Then make sure to add ring-blue-500 anywhere you were depending on the default ring color:

Alternatively, add these theme variables to your CSS to preserve the v3 behavior:

Note though that these variables are only supported for compatibility reasons, and are not considered idiomatic usage of Tailwind CSS v4.0.

We've made a couple small changes to the base styles in Preflight in v4:

In v3, placeholder text used your configured gray-400 color by default. We've simplified this in v4 to just use the current text color at 50% opacity.

You probably won't even notice this change (it might even make your project look better), but if you want to preserve the v3 behavior, add this CSS to your project:

Buttons now use cursor: default instead of cursor: pointer to match the default browser behavior.

If you'd like to continue using cursor: pointer by default, add these base styles to your CSS:

Preflight now resets margins on <dialog> elements to be consistent with how other elements are reset.

If you still want dialogs to be centered by default, add this CSS to your project:

Display classes like block or flex no longer take priority over the hidden attribute on an element. Remove the hidden attribute if you want an element to be visible to the user. Note that this does not apply to hidden="until-found".

Prefixes now look like variants and are always at the beginning of the class name:

When using a prefix, you should still configure your theme variables as if you aren't using a prefix:

The generated CSS variables will include a prefix to avoid conflicts with any existing variables in your project:

In v3, any custom classes you defined within @layer utilities or @layer components would get picked up by Tailwind as a true utility class and would automatically work with variants like hover, focus, or lg with the difference being that @layer components would always come first in the generated stylesheet.

In v4 we are using native cascade layers and no longer hijacking the @layer at-rule, so we've introduced the @utility API as a replacement:

Custom utilities are now also sorted based on the amount of properties they define. This means that component utilities like this .btn can be overwritten by other Tailwind utilities without additional configuration:

Learn more about registering custom utilities in the adding custom utilities documentation.

In v3, stacked variants were applied from right to left, but in v4 we've updated them to apply left to right to look more like CSS syntax.

To update your project for this change, reverse the order of any order-sensitive stacked variants in your project:

You likely have very few of these if any—the direct child variant (*) and any typography plugin variants (prose-headings) are the most likely ones you might be using, and even then it's only if you've stacked them with other variants.

In v3 you were able to use CSS variables as arbitrary values without var(), but recent updates to CSS mean that this can often be ambiguous, so we've changed the syntax for this in v4 to use parentheses instead of square brackets.

To update your project for this change, replace usage of the old variable shorthand syntax with the new variable shorthand syntax:

Commas were previously replaced with spaces in the grid-cols-*, grid-rows-*, and object-* utilities inside arbitrary values. This special behavior existed in Tailwind CSS v3 for compatibility with v2. This compatibility no longer exists in v4.0 and underscores must be used to represent spaces.

To update your project for this change, replace usage of commas that were intended to be spaces with underscores:

In v4 we've updated the hover variant to only apply when the primary input device supports hover:

This can create problems if you've built your site in a way that depends on touch devices triggering hover on tap. If this is an issue for you, you can override the hover variant with your own variant that uses the old implementation:

Generally though we recommend treating hover functionality as an enhancement, and not depending on it for your site to work since touch devices don't truly have the ability to hover.

The transition and transition-color utilities now include the outline-color property.

This means if you were adding an outline with a custom color on focus, you will see the color transition from the default color. To avoid this, make sure you set the outline color unconditionally, or explicitly set it for both states:

In v3 there was a corePlugins option you could use to completely disable certain utilities in the framework. This is no longer supported in v4.

Since v4 includes CSS variables for all of your theme values, we recommend using those variables instead of the theme() function whenever possible:

For cases where you still need to use the theme() function (like in media queries where CSS variables aren't supported), you should use the CSS variable name instead of the old dot notation:

JavaScript config files are still supported for backward compatibility, but they are no longer detected automatically in v4.

If you still need to use a JavaScript config file, you can load it explicitly using the @config directive:

The corePlugins, safelist, and separator options from the JavaScript-based config are not supported in v4.0. To safelist utilities in v4 use @source inline().

In v3 we exported a resolveConfig function that you could use to turn your JavaScript-based config into a flat object that you could use in your other JavaScript.

We've removed this in v4 in hopes that people can use the CSS variables we generate directly instead, which is much simpler and will significantly reduce your bundle size.

For example, the popular Motion library for React lets you animate to and from CSS variable values:

If you need access to a resolved CSS variable value in JS, you can use getComputedStyle to get the value of a theme variable on the document root:

In v4, stylesheets that are bundled separately from your main CSS file (e.g. CSS modules files, <style> blocks in Vue, Svelte, or Astro, etc.) do not have access to theme variables, custom utilities, and custom variants defined in other files.

To make these definitions available in these contexts, use @reference to import them without duplicating any CSS in your bundle:

Alternatively, you can use your CSS theme variables directly instead of using @apply at all, which will also improve performance since Tailwind won't need to process these styles:

You can find more documentation on using Tailwind with CSS modules.

Tailwind CSS v4.0 is not designed to be used with CSS preprocessors like Sass, Less, or Stylus. Think of Tailwind CSS itself as your preprocessor — you shouldn't use Tailwind with Sass for the same reason you wouldn't use Sass with Stylus. Because of this it is not possible to use Sass, Less, or Stylus for your stylesheets or <style> blocks in Vue, Svelte, Astro, etc.

Learn more in the compatibility documentation.

**Examples:**

Example 1 (unknown):
```unknown
$ npx @tailwindcss/upgrade
```

Example 2 (unknown):
```unknown
export default {  plugins: {    "postcss-import": {},    tailwindcss: {},    autoprefixer: {},    "@tailwindcss/postcss": {},  },};
```

Example 3 (python):
```python
import { defineConfig } from "vite";import tailwindcss from "@tailwindcss/vite";export default defineConfig({  plugins: [    tailwindcss(),  ],});
```

Example 4 (unknown):
```unknown
npx tailwindcss -i input.css -o output.cssnpx @tailwindcss/cli -i input.css -o output.css
```

---

## font-variant-numeric

**URL:** https://tailwindcss.com/docs/font-variant-numeric

**Contents:**
- Examples
  - Using ordinal glyphs
  - Using slashed zeroes
  - Using lining figures
  - Using oldstyle figures
  - Using proportional figures
  - Using tabular figures
  - Using diagonal fractions
  - Using stacked fractions
  - Stacking multiple utilities

Use the ordinal utility to enable special glyphs for the ordinal markers in fonts that support them:

Use the slashed-zero utility to force a zero with a slash in fonts that support them:

Use the lining-nums utility to use numeric glyphs that are aligned by their baseline in fonts that support them:

Use the oldstyle-nums utility to use numeric glyphs where some numbers have descenders in fonts that support them:

Use the proportional-nums utility to use numeric glyphs that have proportional widths in fonts that support them:

Use the tabular-nums utility to use numeric glyphs that have uniform/tabular widths in fonts that support them:

Use the diagonal-fractions utility to replace numbers separated by a slash with common diagonal fractions in fonts that support them:

Use the stacked-fractions utility to replace numbers separated by a slash with common stacked fractions in fonts that support them:

The font-variant-numeric utilities are composable so you can enable multiple variants by combining them:

Use the normal-nums property to reset numeric font variants:

Prefix a font-variant-numeric utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="ordinal ...">1st</p>
```

Example 2 (unknown):
```unknown
<p class="slashed-zero ...">0</p>
```

Example 3 (unknown):
```unknown
<p class="lining-nums ...">1234567890</p>
```

Example 4 (unknown):
```unknown
<p class="oldstyle-nums ...">1234567890</p>
```

---

## clear

**URL:** https://tailwindcss.com/docs/clear

**Contents:**
- Examples
  - Clearing left
  - Clearing right
  - Clearing all
  - Using logical properties
  - Disabling clears
  - Responsive design

Use the clear-left utility to position an element below any preceding left-floated elements:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Use the clear-right utility to position an element below any preceding right-floated elements:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Use the clear-both utility to position an element below all preceding floated elements:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Use the clear-start and clear-end utilities, which use logical properties to map to either the left or right side based on the text direction:

ربما يمكننا العيش بدون مكتبات، أشخاص مثلي ومثلك. ربما. بالتأكيد، نحن أكبر من أن نغير العالم، ولكن ماذا عن ذلك الطفل الذي يجلس ويفتح كتابًا الآن في أحد فروع المكتبة المحلية ويجد رسومات للتبول والبول على القطة في القبعة والإخوة الصينيون الخمسة؟ ألا يستحق الأفضل؟ ينظر. إذا كنت تعتقد أن الأمر يتعلق بالغرامات المتأخرة والكتب المفقودة، فمن الأفضل أن تفكر مرة أخرى. يتعلق الأمر بحق ذلك الطفل في قراءة كتاب دون أن يتشوه عقله! أو: ربما يثيرك هذا يا سينفيلد؛ ربما هذه هي الطريقة التي تحصل بها على ركلاتك. أنت ورفاقك الطيبين.

Use the clear-none utility to reset any clears that are applied to an element:

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better? Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Prefix a clear utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<article>  <img class="float-left ..." src="/img/snow-mountains.jpg" />  <img class="float-right ..." src="/img/green-mountains.jpg" />  <p class="clear-left ...">Maybe we can live without libraries...</p></article>
```

Example 2 (unknown):
```unknown
<article>  <img class="float-left ..." src="/img/green-mountains.jpg" />  <img class="float-right ..." src="/img/snow-mountains.jpg" />  <p class="clear-right ...">Maybe we can live without libraries...</p></article>
```

Example 3 (unknown):
```unknown
<article>  <img class="float-left ..." src="/img/snow-mountains.jpg" />  <img class="float-right ..." src="/img/green-mountains.jpg" />  <p class="clear-both ...">Maybe we can live without libraries...</p></article>
```

Example 4 (unknown):
```unknown
<article dir="rtl">  <img class="float-left ..." src="/img/green-mountains.jpg" />  <img class="float-right ..." src="/img/green-mountains.jpg" />  <p class="clear-end ...">...ربما يمكننا العيش بدون مكتبات،</p></article>
```

---

## margin

**URL:** https://tailwindcss.com/docs/margin

**Contents:**
- Examples
  - Basic example
  - Adding margin to a single side
  - Adding horizontal margin
  - Adding vertical margin
  - Using negative values
  - Using logical properties
  - Adding space between children
    - Reversing children order
    - Limitations

Use m-<number> utilities like m-4 and m-8 to control the margin on all sides of an element:

Use mt-<number>, mr-<number>, mb-<number>, and ml-<number> utilities like ml-2 and mt-6 to control the margin on one side of an element:

Use mx-<number> utilities like mx-4 and mx-8 to control the horizontal margin of an element:

Use my-<number> utilities like my-4 and my-8 to control the vertical margin of an element:

To use a negative margin value, prefix the class name with a dash to convert it to a negative value:

Use ms-<number> or me-<number> utilities like ms-4 and me-8 to set the margin-inline-start and margin-inline-end logical properties:

Use space-x-<number> or space-y-<number> utilities like space-x-4 and space-y-8 to control the space between elements:

If your elements are in reverse order (using say flex-row-reverse or flex-col-reverse), use the space-x-reverse or space-y-reverse utilities to ensure the space is added to the correct side of each element:

The space utilities are really just a shortcut for adding margin to all-but-the-last-item in a group, and aren't designed to handle complex cases like grids, layouts that wrap, or situations where the children are rendered in a complex custom order rather than their natural DOM order.

For those situations, it's better to use the gap utilities when possible, or add margin to every element with a matching negative margin on the parent.

Additionally, the space utilities are not designed to work together with the divide utilities. For those situations, consider adding margin/padding utilities to the children instead.

Use utilities like m-[<value>],mx-[<value>], and mb-[<value>] to set the margin based on a completely custom value:

For CSS variables, you can also use the m-(<custom-property>) syntax:

This is just a shorthand for m-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a margin utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The m-<number>,mx-<number>,my-<number>,ms-<number>,me-<number>,mt-<number>,mr-<number>,mb-<number>, and ml-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="m-8 ...">m-8</div>
```

Example 2 (unknown):
```unknown
<div class="mt-6 ...">mt-6</div><div class="mr-4 ...">mr-4</div><div class="mb-8 ...">mb-8</div><div class="ml-2 ...">ml-2</div>
```

Example 3 (unknown):
```unknown
<div class="mx-8 ...">mx-8</div>
```

Example 4 (unknown):
```unknown
<div class="my-8 ...">my-8</div>
```

---

## max-height

**URL:** https://tailwindcss.com/docs/max-height

**Contents:**
- Examples
  - Basic example
  - Using a percentage
  - Using a custom value
  - Responsive design
- Customizing your theme

Use max-h-<number> utilities like max-h-24 and max-h-64 to set an element to a fixed maximum height based on the spacing scale:

Use max-h-full or max-h-<fraction> utilities like max-h-1/2 and max-h-2/5 to give an element a percentage-based maximum height:

Use the max-h-[<value>] syntax to set the maximum height based on a completely custom value:

For CSS variables, you can also use the max-h-(<custom-property>) syntax:

This is just a shorthand for max-h-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a max-height utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The max-h-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="h-96 ...">  <div class="h-full max-h-80 ...">max-h-80</div>  <div class="h-full max-h-64 ...">max-h-64</div>  <div class="h-full max-h-48 ...">max-h-48</div>  <div class="h-full max-h-40 ...">max-h-40</div>  <div class="h-full max-h-32 ...">max-h-32</div>  <div class="h-full max-h-24 ...">max-h-24</div></div>
```

Example 2 (unknown):
```unknown
<div class="h-96 ...">  <div class="h-full max-h-9/10 ...">max-h-9/10</div>  <div class="h-full max-h-3/4 ...">max-h-3/4</div>  <div class="h-full max-h-1/2 ...">max-h-1/2</div>  <div class="h-full max-h-1/4 ...">max-h-1/4</div>  <div class="h-full max-h-full ...">max-h-full</div></div>
```

Example 3 (unknown):
```unknown
<div class="max-h-[220px] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="max-h-(--my-max-height) ...">  <!-- ... --></div>
```

---

## place-items

**URL:** https://tailwindcss.com/docs/place-items

**Contents:**
- Examples
  - Start
  - End
  - Center
  - Stretch
- Responsive design

Use place-items-start to place grid items on the start of their grid areas on both axes:

Use place-items-end to place grid items on the end of their grid areas on both axes:

Use place-items-center to place grid items on the center of their grid areas on both axes:

Use place-items-stretch to stretch items along their grid areas on both axes:

Prefix a place-items utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-cols-3 place-items-start gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid h-56 grid-cols-3 place-items-end gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 3 (unknown):
```unknown
<div class="grid h-56 grid-cols-3 place-items-center gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 4 (unknown):
```unknown
<div class="grid h-56 grid-cols-3 place-items-stretch gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

---

## vertical-align

**URL:** https://tailwindcss.com/docs/vertical-align

**Contents:**
- Examples
  - Aligning to baseline
  - Aligning to top
  - Aligning to middle
  - Aligning to bottom
  - Aligning to parent top
  - Aligning to parent bottom
  - Using a custom value
  - Responsive design

Use the align-baseline utility to align the baseline of an element with the baseline of its parent:

Use the align-top utility to align the top of an element and its descendants with the top of the entire line:

Use the align-middle utility to align the middle of an element with the baseline plus half the x-height of the parent:

Use the align-bottom utility to align the bottom of an element and its descendants with the bottom of the entire line:

Use the align-text-top utility to align the top of an element with the top of the parent element's font:

Use the align-text-bottom utility to align the bottom of an element with the bottom of the parent element's font:

Use the align-[<value>] syntax to set the vertical alignment based on a completely custom value:

For CSS variables, you can also use the align-(<custom-property>) syntax:

This is just a shorthand for align-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a vertical-align utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<span class="inline-block align-baseline">The quick brown fox...</span>
```

Example 2 (unknown):
```unknown
<span class="inline-block align-top">The quick brown fox...</span>
```

Example 3 (unknown):
```unknown
<span class="inline-block align-middle">The quick brown fox...</span>
```

Example 4 (unknown):
```unknown
<span class="inline-block align-bottom">The quick brown fox...</span>
```

---

## height

**URL:** https://tailwindcss.com/docs/height

**Contents:**
- Examples
  - Basic example
  - Using a percentage
  - Matching viewport
  - Matching dynamic viewport
  - Matching large viewport
  - Matching small viewport
  - Setting both width and height
  - Using a custom value
  - Responsive design

Use h-<number> utilities like h-24 and h-64 to set an element to a fixed height based on the spacing scale:

Use h-full or h-<fraction> utilities like h-1/2 and h-2/5 to give an element a percentage-based height:

Use the h-screen utility to make an element span the entire height of the viewport:

Use the h-dvh utility to make an element span the entire height of the viewport, which changes as the browser UI expands or contracts:

Scroll the viewport to see the viewport height change

Use the h-lvh utility to set an element's height to the largest possible height of the viewport:

Scroll the viewport to see the viewport height change

Use the h-svh utility to set an element's height to the smallest possible height of the viewport:

Scroll the viewport to see the viewport height change

Use utilities like size-px, size-4, and size-full to set both the width and height of an element at the same time:

Use the h-[<value>] syntax to set the height based on a completely custom value:

For CSS variables, you can also use the h-(<custom-property>) syntax:

This is just a shorthand for h-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a height utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The h-<number> and size-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="h-96 ...">h-96</div><div class="h-80 ...">h-80</div><div class="h-64 ...">h-64</div><div class="h-48 ...">h-48</div><div class="h-40 ...">h-40</div><div class="h-32 ...">h-32</div><div class="h-24 ...">h-24</div>
```

Example 2 (unknown):
```unknown
<div class="h-full ...">h-full</div><div class="h-9/10 ...">h-9/10</div><div class="h-3/4 ...">h-3/4</div><div class="h-1/2 ...">h-1/2</div><div class="h-1/3 ...">h-1/3</div>
```

Example 3 (unknown):
```unknown
<div class="h-screen">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="h-dvh">  <!-- ... --></div>
```

---

## overflow-wrap

**URL:** https://tailwindcss.com/docs/overflow-wrap

**Contents:**
- Examples
  - Wrapping mid-word
  - Wrapping anywhere
  - Wrapping normally
  - Responsive design

Use the wrap-break-word utility to allow line breaks between letters in a word if needed:

The longest word in any of the major English language dictionaries is pneumonoultramicroscopicsilicovolcanoconiosis, a word that refers to a lung disease contracted from the inhalation of very fine silica particles, specifically from a volcano; medically, it is the same as silicosis.

The wrap-anywhere utility behaves similarly to wrap-break-word, except that the browser factors in mid-word line breaks when calculating the intrinsic size of the element:

jason.riemenschneider@vandelayindustries.com

jason.riemenschneider@vandelayindustries.com

This is useful for wrapping text inside of flex containers, where you would usually need to set min-width: 0 on the child element to allow it to shrink below its content size.

Use the wrap-normal utility to only allow line breaks at natural wrapping points, like spaces, hyphens, and punctuation:

The longest word in any of the major English language dictionaries is pneumonoultramicroscopicsilicovolcanoconiosis, a word that refers to a lung disease contracted from the inhalation of very fine silica particles, specifically from a volcano; medically, it is the same as silicosis.

Prefix an overflow-wrap utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="wrap-break-word">The longest word in any of the major...</p>
```

Example 2 (unknown):
```unknown
<div class="flex max-w-sm">  <img class="size-16 rounded-full" src="/img/profile.jpg" />  <div class="wrap-break-word">    <p class="font-medium">Jay Riemenschneider</p>    <p>jason.riemenschneider@vandelayindustries.com</p>  </div></div><div class="flex max-w-sm">  <img class="size-16 rounded-full" src="/img/profile.jpg" />  <div class="wrap-anywhere">    <p class="font-medium">Jay Riemenschneider</p>    <p>jason.riemenschneider@vandelayindustries.com</p>  </div></div>
```

Example 3 (unknown):
```unknown
<p class="wrap-normal">The longest word in any of the major...</p>
```

Example 4 (unknown):
```unknown
<p class="wrap-normal md:wrap-break-word ...">  Lorem ipsum dolor sit amet...</p>
```

---

## text-transform

**URL:** https://tailwindcss.com/docs/text-transform

**Contents:**
- Examples
  - Uppercasing text
  - Lowercasing text
  - Capitalizing text
  - Resetting text casing
  - Responsive design

Use the uppercase utility to uppercase the text of an element:

The quick brown fox jumps over the lazy dog.

Use the lowercase utility to lowercase the text of an element:

The quick brown fox jumps over the lazy dog.

Use the capitalize utility to capitalize text of an element:

The quick brown fox jumps over the lazy dog.

Use the normal-case utility to preserve the original text casing of an element—typically used to reset capitalization at different breakpoints:

The quick brown fox jumps over the lazy dog.

Prefix a text-transform utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="uppercase">The quick brown fox ...</p>
```

Example 2 (unknown):
```unknown
<p class="lowercase">The quick brown fox ...</p>
```

Example 3 (unknown):
```unknown
<p class="capitalize">The quick brown fox ...</p>
```

Example 4 (unknown):
```unknown
<p class="normal-case">The quick brown fox ...</p>
```

---

## align-items

**URL:** https://tailwindcss.com/docs/align-items

**Contents:**
- Examples
  - Stretch
  - Start
  - Center
  - End
  - Baseline
  - Last baseline
  - Responsive design

Use the items-stretch utility to stretch items to fill the container's cross axis:

Use the items-start utility to align items to the start of the container's cross axis:

Use the items-center utility to align items along the center of the container's cross axis:

Use the items-end utility to align items to the end of the container's cross axis:

Use the items-baseline utility to align items along the container's cross axis such that all of their baselines align:

Use the items-baseline-last utility to align items along the container's cross axis such that all of their baselines align with the last baseline in the container:

Working on the future of astronaut recruitment at Space Recruit.

A multidisciplinary designer.

This is useful for ensuring that text items align with each other, even if they have different heights.

Prefix an align-items utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex items-stretch ...">  <div class="py-4">01</div>  <div class="py-12">02</div>  <div class="py-8">03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex items-start ...">  <div class="py-4">01</div>  <div class="py-12">02</div>  <div class="py-8">03</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex items-center ...">  <div class="py-4">01</div>  <div class="py-12">02</div>  <div class="py-8">03</div></div>
```

Example 4 (unknown):
```unknown
<div class="flex items-end ...">  <div class="py-4">01</div>  <div class="py-12">02</div>  <div class="py-8">03</div></div>
```

---

## line-height

**URL:** https://tailwindcss.com/docs/line-height

**Contents:**
- Examples
  - Basic example
  - Setting independently
  - Removing the leading
  - Using a custom value
  - Responsive design
- Customizing your theme

Use font size utilities like text-sm/6 and text-lg/7 to set the font size and line-height of an element at the same time:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Each font size utility also sets a default line height when one isn't provided. You can learn more about these values and how to customize them in the font-size documentation.

Use leading-<number> utilities like leading-6 and leading-7 to set the line height of an element independent of the font-size:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Use the leading-none utility to set the line height of an element equal to its font size:

The quick brown fox jumps over the lazy dog.

Use the leading-[<value>] syntax to set the line height based on a completely custom value:

For CSS variables, you can also use the leading-(<custom-property>) syntax:

This is just a shorthand for leading-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a line-height utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The leading-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="text-base/6 ...">So I started to walk into the water...</p><p class="text-base/7 ...">So I started to walk into the water...</p><p class="text-base/8 ...">So I started to walk into the water...</p>
```

Example 2 (unknown):
```unknown
<p class="text-sm leading-6">So I started to walk into the water...</p><p class="text-sm leading-7">So I started to walk into the water...</p><p class="text-sm leading-8">So I started to walk into the water...</p>
```

Example 3 (unknown):
```unknown
<p class="text-2xl leading-none ...">The quick brown fox...</p>
```

Example 4 (unknown):
```unknown
<p class="leading-[1.5] ...">  Lorem ipsum dolor sit amet...</p>
```

---

## text-indent

**URL:** https://tailwindcss.com/docs/text-indent

**Contents:**
- Examples
  - Basic example
  - Using negative values
  - Using a custom value
  - Responsive design

Use indent-<number> utilities like indent-2 and indent-8 to set the amount of empty space (indentation) that's shown before text in a block:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

To use a negative text indent value, prefix the class name with a dash to convert it to a negative value:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Use the indent-[<value>] syntax to set the text indentation based on a completely custom value:

For CSS variables, you can also use the indent-(<custom-property>) syntax:

This is just a shorthand for indent-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a text-indent utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="indent-8">So I started to walk into the water...</p>
```

Example 2 (unknown):
```unknown
<p class="-indent-8">So I started to walk into the water...</p>
```

Example 3 (unknown):
```unknown
<p class="indent-[50%] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="indent-(--my-indentation) ...">  Lorem ipsum dolor sit amet...</p>
```

---

## line-clamp

**URL:** https://tailwindcss.com/docs/line-clamp

**Contents:**
- Examples
  - Basic example
  - Undoing line clamping
  - Using a custom value
  - Responsive design

Use line-clamp-<number> utilities like line-clamp-2 and line-clamp-3 to truncate multi-line text after a specific number of lines:

Nulla dolor velit adipisicing duis excepteur esse in duis nostrud occaecat mollit incididunt deserunt sunt. Ut ut sunt laborum ex occaecat eu tempor labore enim adipisicing minim ad. Est in quis eu dolore occaecat excepteur fugiat dolore nisi aliqua fugiat enim ut cillum. Labore enim duis nostrud eu. Est ut eiusmod consequat irure quis deserunt ex. Enim laboris dolor magna pariatur. Dolor et ad sint voluptate sunt elit mollit officia ad enim sit consectetur enim.

Use line-clamp-none to undo a previously applied line clamp utility:

Use the line-clamp-[<value>] syntax to set the number of lines based on a completely custom value:

For CSS variables, you can also use the line-clamp-(<custom-property>) syntax:

This is just a shorthand for line-clamp-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a line-clamp utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<article>  <time>Mar 10, 2020</time>  <h2>Boost your conversion rate</h2>  <p class="line-clamp-3">    Nulla dolor velit adipisicing duis excepteur esse in duis nostrud occaecat mollit incididunt deserunt sunt. Ut ut    sunt laborum ex occaecat eu tempor labore enim adipisicing minim ad. Est in quis eu dolore occaecat excepteur fugiat    dolore nisi aliqua fugiat enim ut cillum. Labore enim duis nostrud eu. Est ut eiusmod consequat irure quis deserunt    ex. Enim laboris dolor magna pariatur. Dolor et ad sint voluptate sunt elit mollit officia ad enim sit consectetur    enim.  </p>  <div>    <img src="/img/lindsay.jpg" />    Lindsay Walton  </div></article>
```

Example 2 (unknown):
```unknown
<p class="line-clamp-3 lg:line-clamp-none">  <!-- ... --></p>
```

Example 3 (unknown):
```unknown
<p class="line-clamp-[calc(var(--characters)/100)] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="line-clamp-(--my-line-count) ...">  Lorem ipsum dolor sit amet...</p>
```

---

## place-content

**URL:** https://tailwindcss.com/docs/place-content

**Contents:**
- Examples
  - Center
  - Start
  - End
  - Space between
  - Space around
  - Space evenly
  - Stretch
  - Responsive design

Use place-content-center to pack items in the center of the inline and block axes:

Use place-content-start to pack items against the start of the inline and block axes:

Use place-content-end to pack items against the end of the inline and block axes:

Use place-content-between to distribute grid items along the inline and block axes so that there is an equal amount of space between each row and column on each axis respectively:

Use place-content-around to distribute grid items along the inline and block axes so that there is an equal amount of space around each row and column on each axis respectively:

Use place-content-evenly to distribute grid items such that they are evenly spaced on the inline and block axes:

Use place-content-stretch to stretch grid items along their grid areas on the inline and block axes:

Prefix a place-content utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid h-48 grid-cols-2 place-content-center gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid h-48 grid-cols-2 place-content-start gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div></div>
```

Example 3 (unknown):
```unknown
<div class="grid h-48 grid-cols-2 place-content-end gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div></div>
```

Example 4 (unknown):
```unknown
<div class="grid h-48 grid-cols-2 place-content-between gap-4 ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div></div>
```

---

## overscroll-behavior

**URL:** https://tailwindcss.com/docs/overscroll-behavior

**Contents:**
- Examples
  - Preventing parent overscrolling
  - Preventing overscroll bouncing
  - Using the default overscroll behavior
  - Responsive design

Use the overscroll-contain utility to prevent scrolling in the target area from triggering scrolling in the parent element, but preserve "bounce" effects when scrolling past the end of the container in operating systems that support it:

Scroll to see behavior

Well, let me tell you something, funny boy. Y'know that little stamp, the one that says "New York Public Library"? Well that may not mean anything to you, but that means a lot to me. One whole hell of a lot.

Sure, go ahead, laugh if you want to. I've seen your type before: Flashy, making the scene, flaunting convention. Yeah, I know what you're thinking. What's this guy making such a big stink about old library books? Well, let me give you a hint, junior.

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better?

Use the overscroll-none utility to prevent scrolling in the target area from triggering scrolling in the parent element, and also prevent "bounce" effects when scrolling past the end of the container:

Scroll to see behavior

Well, let me tell you something, funny boy. Y'know that little stamp, the one that says "New York Public Library"? Well that may not mean anything to you, but that means a lot to me. One whole hell of a lot.

Sure, go ahead, laugh if you want to. I've seen your type before: Flashy, making the scene, flaunting convention. Yeah, I know what you're thinking. What's this guy making such a big stink about old library books? Well, let me give you a hint, junior.

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better?

Use the overscroll-auto utility to make it possible for the user to continue scrolling a parent scroll area when they reach the boundary of the primary scroll area:

Scroll to see behavior

Well, let me tell you something, funny boy. Y'know that little stamp, the one that says "New York Public Library"? Well that may not mean anything to you, but that means a lot to me. One whole hell of a lot.

Sure, go ahead, laugh if you want to. I've seen your type before: Flashy, making the scene, flaunting convention. Yeah, I know what you're thinking. What's this guy making such a big stink about old library books? Well, let me give you a hint, junior.

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better?

Prefix an overscroll-behavior utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (javascript):
```javascript
<div class="overscroll-contain ...">Well, let me tell you something, ...</div>
```

Example 2 (javascript):
```javascript
<div class="overscroll-none ...">Well, let me tell you something, ...</div>
```

Example 3 (javascript):
```javascript
<div class="overscroll-auto ...">Well, let me tell you something, ...</div>
```

Example 4 (unknown):
```unknown
<div class="overscroll-auto md:overscroll-contain ...">  <!-- ... --></div>
```

---

## box-decoration-break

**URL:** https://tailwindcss.com/docs/box-decoration-break

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use the box-decoration-slice and box-decoration-clone utilities to control whether properties like background, border, border-image, box-shadow, clip-path, margin, and padding should be rendered as if the element were one continuous fragment, or distinct blocks:

Prefix a box-decoration-break utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<span class="box-decoration-slice bg-linear-to-r from-indigo-600 to-pink-500 px-2 text-white ...">  Hello<br />World</span><span class="box-decoration-clone bg-linear-to-r from-indigo-600 to-pink-500 px-2 text-white ...">  Hello<br />World</span>
```

Example 2 (unknown):
```unknown
<div class="box-decoration-clone md:box-decoration-slice ...">  <!-- ... --></div>
```

---

## padding

**URL:** https://tailwindcss.com/docs/padding

**Contents:**
- Examples
  - Basic example
  - Adding padding to one side
  - Adding horizontal padding
  - Adding vertical padding
  - Using logical properties
  - Using a custom value
  - Responsive design
- Customizing your theme

Use p-<number> utilities like p-4 and p-8 to control the padding on all sides of an element:

Use pt-<number>, pr-<number>, pb-<number>, and pl-<number> utilities like pt-6 and pr-4 to control the padding on one side of an element:

Use px-<number> utilities like px-4 and px-8 to control the horizontal padding of an element:

Use py-<number> utilities like py-4 and py-8 to control the vertical padding of an element:

Use ps-<number> or pe-<number> utilities like ps-4 and pe-8 to set the padding-inline-start and padding-inline-end logical properties, which map to either the left or right side based on the text direction:

For more control, you can also use the LTR and RTL modifiers to conditionally apply specific styles depending on the current text direction.

Use utilities like p-[<value>],px-[<value>], and pb-[<value>] to set the padding based on a completely custom value:

For CSS variables, you can also use the p-(<custom-property>) syntax:

This is just a shorthand for p-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a padding utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The p-<number>,px-<number>,py-<number>,ps-<number>,pe-<number>,pt-<number>,pr-<number>,pb-<number>, and pl-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="p-8 ...">p-8</div>
```

Example 2 (unknown):
```unknown
<div class="pt-6 ...">pt-6</div><div class="pr-4 ...">pr-4</div><div class="pb-8 ...">pb-8</div><div class="pl-2 ...">pl-2</div>
```

Example 3 (unknown):
```unknown
<div class="px-8 ...">px-8</div>
```

Example 4 (unknown):
```unknown
<div class="py-8 ...">py-8</div>
```

---

## word-break

**URL:** https://tailwindcss.com/docs/word-break

**Contents:**
- Examples
  - Normal
  - Break All
  - Break Keep
  - Responsive design

Use the break-normal utility to only add line breaks at normal word break points:

The longest word in any of the major English language dictionaries is pneumonoultramicroscopicsilicovolcanoconiosis, a word that refers to a lung disease contracted from the inhalation of very fine silica particles, specifically from a volcano; medically, it is the same as silicosis.

Use the break-all utility to add line breaks whenever necessary, without trying to preserve whole words:

The longest word in any of the major English language dictionaries is pneumonoultramicroscopicsilicovolcanoconiosis, a word that refers to a lung disease contracted from the inhalation of very fine silica particles, specifically from a volcano; medically, it is the same as silicosis.

Use the break-keep utility to prevent line breaks from being applied to Chinese/Japanese/Korean (CJK) text:

抗衡不屈不挠 (kànghéng bùqū bùnáo) 这是一个长词，意思是不畏强暴，奋勇抗争，坚定不移，永不放弃。这个词通常用来描述那些在面对困难和挑战时坚持自己信念的人， 他们克服一切困难，不屈不挠地追求自己的目标。无论遇到多大的挑战，他们都能够坚持到底，不放弃，最终获得胜利。

For non-CJK text the break-keep utility has the same behavior as the break-normal utility.

Prefix a word-break utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="break-normal">The longest word in any of the major...</p>
```

Example 2 (unknown):
```unknown
<p class="break-all">The longest word in any of the major...</p>
```

Example 3 (unknown):
```unknown
<p class="break-keep">抗衡不屈不挠...</p>
```

Example 4 (unknown):
```unknown
<p class="break-normal md:break-all ...">  Lorem ipsum dolor sit amet...</p>
```

---

## place-self

**URL:** https://tailwindcss.com/docs/place-self

**Contents:**
- Examples
  - Auto
  - Start
  - Center
  - End
  - Stretch
  - Responsive design

Use place-self-auto to align an item based on the value of the container's place-items property:

Use place-self-start to align an item to the start on both axes:

Use place-self-center to align an item at the center on both axes:

Use place-self-end to align an item to the end on both axes:

Use place-self-stretch to stretch an item on both axes:

Prefix a place-self utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-cols-3 gap-4 ...">  <div>01</div>  <div class="place-self-auto ...">02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-cols-3 gap-4 ...">  <div>01</div>  <div class="place-self-start ...">02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 3 (unknown):
```unknown
<div class="grid grid-cols-3 gap-4 ...">  <div>01</div>  <div class="place-self-center ...">02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 4 (unknown):
```unknown
<div class="grid grid-cols-3 gap-4 ...">  <div>01</div>  <div class="place-self-end ...">02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

---

## font-weight

**URL:** https://tailwindcss.com/docs/font-weight

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design
- Customizing your theme

Use utilities like font-thin and font-bold to set the font weight of an element:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Use the font-[<value>] syntax to set the font weight based on a completely custom value:

For CSS variables, you can also use the font-(weight:<custom-property>) syntax:

This is just a shorthand for font-[weight:var(<custom-property>)] that adds the var() function for you automatically.

Prefix a font-weight utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --font-weight-* theme variables to customize the font weight utilities in your project:

Now the font-extrablack utility can be used in your markup:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="font-light ...">The quick brown fox ...</p><p class="font-normal ...">The quick brown fox ...</p><p class="font-medium ...">The quick brown fox ...</p><p class="font-semibold ...">The quick brown fox ...</p><p class="font-bold ...">The quick brown fox ...</p>
```

Example 2 (unknown):
```unknown
<p class="font-[1000] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 3 (unknown):
```unknown
<p class="font-(weight:--my-font-weight) ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="font-normal md:font-bold ...">  Lorem ipsum dolor sit amet...</p>
```

---

## list-style-image

**URL:** https://tailwindcss.com/docs/list-style-image

**Contents:**
- Examples
  - Basic example
  - Using a CSS variable
  - Removing a marker image
  - Responsive design

Use the list-image-[<value>] syntax to control the marker image for list items:

Use the list-image-(<custom-property>) syntax to control the marker image for list items using a CSS variable:

This is just a shorthand for list-image-[var(<custom-property>)] that adds the var() function for you automatically.

Use the list-image-none utility to remove an existing marker image from list items:

Prefix a list-style-image utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<ul class="list-image-[url(/img/checkmark.png)]">  <li>5 cups chopped Porcini mushrooms</li>  <!-- ... --></ul>
```

Example 2 (unknown):
```unknown
<ul class="list-image-(--my-list-image)">  <!-- ... --></ul>
```

Example 3 (unknown):
```unknown
<ul class="list-image-none">  <!-- ... --></ul>
```

Example 4 (unknown):
```unknown
<div class="list-image-none md:list-image-[url(/img/checkmark.png)] ...">  <!-- ... --></div>
```

---

## background-attachment

**URL:** https://tailwindcss.com/docs/background-attachment

**Contents:**
- Examples
  - Fixing the background image
  - Scrolling with the container
  - Scrolling with the viewport
  - Responsive design

Use the bg-fixed utility to fix the background image relative to the viewport:

Scroll the content to see the background image fixed in place

Maybe we can live without libraries, people like you and me. Maybe. Sure, we're too old to change the world, but what about that kid, sitting down, opening a book, right now, in a branch at the local library and finding drawings of pee-pees and wee-wees on the Cat in the Hat and the Five Chinese Brothers? Doesn't HE deserve better?

Look. If you think this is about overdue fines and missing books, you'd better think again. This is about that kid's right to read a book without getting his mind warped! Or: maybe that turns you on, Seinfeld; maybe that's how y'get your kicks. You and your good-time buddies.

Use the bg-local utility to scroll the background image with the container and the viewport:

Scroll the content to see the background image scroll with the container

Because the mail never stops. It just keeps coming and coming and coming, there's never a let-up. It's relentless. Every day it piles up more and more and more. And you gotta get it out but the more you get it out the more it keeps coming in. And then the barcode reader breaks and it's Publisher's Clearing House day.

Use the bg-scroll utility to scroll the background image with the viewport, but not with the container:

Scroll the content to see the background image fixed in the container

Because the mail never stops. It just keeps coming and coming and coming, there's never a let-up. It's relentless. Every day it piles up more and more and more. And you gotta get it out but the more you get it out the more it keeps coming in. And then the barcode reader breaks and it's Publisher's Clearing House day.

Prefix a background-attachment utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="bg-[url(/img/mountains.jpg)] bg-fixed ...">  <!-- ... --></div>
```

Example 2 (unknown):
```unknown
<div class="bg-[url(/img/mountains.jpg)] bg-local ...">  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="bg-[url(/img/mountains.jpg)] bg-scroll ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="bg-local md:bg-fixed ...">  <!-- ... --></div>
```

---

## list-style-type

**URL:** https://tailwindcss.com/docs/list-style-type

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design

Use utilities like list-disc and list-decimal to control the style of the markers in a list:

Use the list-[<value>] syntax to set the marker based on a completely custom value:

For CSS variables, you can also use the list-(<custom-property>) syntax:

This is just a shorthand for list-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a list-style-type utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<ul class="list-disc">  <li>Now this is a story all about how, my life got flipped-turned upside down</li>  <!-- ... --></ul><ol class="list-decimal">  <li>Now this is a story all about how, my life got flipped-turned upside down</li>  <!-- ... --></ol><ul class="list-none">  <li>Now this is a story all about how, my life got flipped-turned upside down</li>  <!-- ... --></ul>
```

Example 2 (unknown):
```unknown
<ol class="list-[upper-roman] ...">  <!-- ... --></ol>
```

Example 3 (unknown):
```unknown
<ol class="list-(--my-marker) ...">  <!-- ... --></ol>
```

Example 4 (unknown):
```unknown
<ul class="list-none md:list-disc ...">  <!-- ... --></ul>
```

---

## justify-content

**URL:** https://tailwindcss.com/docs/justify-content

**Contents:**
- Examples
  - Start
  - Center
  - End
  - Space between
  - Space around
  - Space evenly
  - Stretch
  - Normal
  - Responsive design

Use the justify-start utility to justify items against the start of the container's main axis:

Use the justify-center or justify-center-safe utilities to justify items along the center of the container's main axis:

Resize the container to see the alignment behavior

When there is not enough space available, the justify-center-safe utility will align items to the start of the container instead of the center.

Use the justify-end or justify-end-safe utilities to justify items against the end of the container's main axis:

Resize the container to see the alignment behavior

When there is not enough space available, the justify-end-safe utility will align items to the start of the container instead of the end.

Use the justify-between utility to justify items along the container's main axis such that there is an equal amount of space between each item:

Use the justify-around utility to justify items along the container's main axis such that there is an equal amount of space on each side of each item:

Use the justify-evenly utility to justify items along the container's main axis such that there is an equal amount of space around each item, but also accounting for the doubling of space you would normally see between each item when using justify-around:

Use the justify-stretch utility to allow auto-sized content items to fill the available space along the container's main axis:

Use the justify-normal utility to pack content items in their default position as if no justify-content value was set:

Prefix a justify-content utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex justify-start ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex justify-center ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex justify-center-safe ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div></div>
```

Example 4 (unknown):
```unknown
<div class="flex justify-end ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>03</div></div>
```

---

## break-before

**URL:** https://tailwindcss.com/docs/break-before

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use utilities like break-before-column and break-before-page to control how a column or page break should behave before an element:

Prefix a break-before utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (javascript):
```javascript
<div class="columns-2">  <p>Well, let me tell you something, ...</p>  <p class="break-before-column">Sure, go ahead, laugh...</p>  <p>Maybe we can live without...</p>  <p>Look. If you think this is...</p></div>
```

Example 2 (unknown):
```unknown
<div class="break-before-column md:break-before-auto ...">  <!-- ... --></div>
```

---

## text-wrap

**URL:** https://tailwindcss.com/docs/text-wrap

**Contents:**
- Examples
  - Allowing text to wrap
  - Preventing text from wrapping
  - Balanced text wrapping
  - Pretty text wrapping
  - Responsive design

Use the text-wrap utility to wrap overflowing text onto multiple lines at logical points in the text:

New Yorkers are facing the winter chill with less warmth this year as the city's most revered soup stand unexpectedly shutters, following a series of events that have left the community puzzled.

Use the text-nowrap utility to prevent text from wrapping, allowing it to overflow if necessary:

New Yorkers are facing the winter chill with less warmth this year as the city's most revered soup stand unexpectedly shutters, following a series of events that have left the community puzzled.

Use the text-balance utility to distribute the text evenly across each line:

New Yorkers are facing the winter chill with less warmth this year as the city's most revered soup stand unexpectedly shutters, following a series of events that have left the community puzzled.

For performance reasons browsers limit text balancing to blocks that are ~6 lines or less, making it best suited for headings.

Use the text-pretty utility to prefer better text wrapping and layout at the expense of speed. Behavior varies across browsers but often involves approaches like preventing orphans (a single word on its own line) at the end of a text block:

New Yorkers are facing the winter chill with less warmth this year as the city's most revered soup stand unexpectedly shutters, following a series of events that have left the community puzzled.

Prefix a text-wrap utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<article class="text-wrap">  <h3>Beloved Manhattan soup stand closes</h3>  <p>New Yorkers are facing the winter chill...</p></article>
```

Example 2 (unknown):
```unknown
<article class="text-nowrap">  <h3>Beloved Manhattan soup stand closes</h3>  <p>New Yorkers are facing the winter chill...</p></article>
```

Example 3 (unknown):
```unknown
<article>  <h3 class="text-balance">Beloved Manhattan soup stand closes</h3>  <p>New Yorkers are facing the winter chill...</p></article>
```

Example 4 (unknown):
```unknown
<article>  <h3 class="text-pretty">Beloved Manhattan soup stand closes</h3>  <p>New Yorkers are facing the winter chill...</p></article>
```

---

## break-inside

**URL:** https://tailwindcss.com/docs/break-inside

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use utilities like break-inside-column and break-inside-avoid-page to control how a column or page break should behave within an element:

Prefix a break-inside utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (javascript):
```javascript
<div class="columns-2">  <p>Well, let me tell you something, ...</p>  <p class="break-inside-avoid-column">Sure, go ahead, laugh...</p>  <p>Maybe we can live without...</p>  <p>Look. If you think this is...</p></div>
```

Example 2 (unknown):
```unknown
<div class="break-inside-avoid-column md:break-inside-auto ...">  <!-- ... --></div>
```

---

## Adding custom styles

**URL:** https://tailwindcss.com/docs/adding-custom-styles

**Contents:**
- Customizing your theme
- Using arbitrary values
  - Arbitrary properties
  - Arbitrary variants
  - Handling whitespace
  - Resolving ambiguities
- Using custom CSS
  - Adding base styles
  - Adding component classes
  - Using variants

Often the biggest challenge when working with a framework is figuring out what you’re supposed to do when there’s something you need that the framework doesn’t handle for you.

Tailwind has been designed from the ground up to be extensible and customizable, so that no matter what you’re building you never feel like you’re fighting the framework.

This guide covers topics like customizing your design tokens, how to break out of those constraints when necessary, adding your own custom CSS, and extending the framework with plugins.

If you want to change things like your color palette, spacing scale, typography scale, or breakpoints, add your customizations using the @theme directive in your CSS:

Learn more about customizing your theme in the theme variables documentation.

While you can usually build the bulk of a well-crafted design using a constrained set of design tokens, once in a while you need to break out of those constraints to get things pixel-perfect.

When you find yourself really needing something like top: 117px to get a background image in just the right spot, use Tailwind's square bracket notation to generate a class on the fly with any arbitrary value:

This is basically like inline styles, with the major benefit that you can combine it with interactive modifiers like hover and responsive modifiers like lg:

This works for everything in the framework, including things like background colors, font sizes, pseudo-element content, and more:

If you're referencing a CSS variable as an arbitrary value, you can use the custom property syntax:

This is just a shorthand for fill-[var(--my-brand-color)] that adds the var() function for you automatically.

If you ever need to use a CSS property that Tailwind doesn't include a utility for out of the box, you can also use square bracket notation to write completely arbitrary CSS:

This is really like inline styles, but again with the benefit that you can use modifiers:

This can be useful for things like CSS variables as well, especially when they need to change under different conditions:

Arbitrary variants are like arbitrary values but for doing on-the-fly selector modification, like you can with built-in pseudo-class variants like hover:{utility} or responsive variants like md:{utility} but using square bracket notation directly in your HTML.

Learn more in the arbitrary variants documentation.

When an arbitrary value needs to contain a space, use an underscore (_) instead and Tailwind will automatically convert it to a space at build-time:

In situations where underscores are common but spaces are invalid, Tailwind will preserve the underscore instead of converting it to a space, for example in URLs:

In the rare case that you actually need to use an underscore but it's ambiguous because a space is valid as well, escape the underscore with a backslash and Tailwind won't convert it to a space:

If you're using something like JSX where the backslash is stripped from the rendered HTML, use String.raw() so the backslash isn't treated as a JavaScript escape character:

Many utilities in Tailwind share a common namespace but map to different CSS properties. For example text-lg and text-black both share the text- namespace, but one is for font-size and the other is for color.

When using arbitrary values, Tailwind can generally handle this ambiguity automatically based on the value you pass in:

Sometimes it really is ambiguous though, for example when using CSS variables:

In these situations, you can "hint" the underlying type to Tailwind by adding a CSS data type before the value:

While Tailwind is designed to handle the bulk of your styling needs, there is nothing stopping you from just writing plain CSS when you need to:

If you just want to set some defaults for the page (like the text color, background color, or font family), the easiest option is just adding some classes to the html or body elements:

This keeps your base styling decisions in your markup alongside all of your other styles, instead of hiding them in a separate file.

If you want to add your own default base styles for specific HTML elements, use the @layer directive to add those styles to Tailwind's base layer:

Use the components layer for any more complicated classes you want to add to your project that you'd still like to be able to override with utility classes.

Traditionally these would be classes like card, btn, badge — that kind of thing.

By defining component classes in the components layer, you can still use utility classes to override them when necessary:

Using Tailwind you probably don't need these types of classes as often as you think. Read our guide on managing duplication for our recommendations.

The components layer is also a good place to put custom styles for any third-party components you're using:

Use the @variant directive to apply a Tailwind variant within custom CSS:

If you need to apply multiple variants at the same time, use nesting:

In addition to using the utilities that ship with Tailwind, you can also add your own custom utilities. This can be useful when there's a CSS feature you'd like to use in your project that Tailwind doesn't include utilities for out of the box.

Use the @utility directive to add a custom utility to your project:

You can now use this utility in your HTML:

It will also work with variants like hover, focus and lg:

Custom utilities are automatically inserted into the utilities layer along with all of the built-in utilities in the framework.

If your custom utility is more complex than a single class name, use nesting to define the utility:

In addition to registering simple utilities with the @utility directive, you can also register functional utilities that accept an argument:

The special --value() function is used to resolve the utility value.

Use the --value(--theme-key-*) syntax to resolve the utility value against a set of theme keys:

This will match utilities like tab-2, tab-4, and tab-github.

To resolve the value as a bare value, use the --value({type}) syntax, where {type} is the data type you want to validate the bare value as:

This will match utilities like tab-1 and tab-76.

Available bare value data types are: number, integer, ratio, and percentage.

To support literal values, use the --value('literal') syntax (notice the quotes):

This will match utilities like tab-inherit, tab-initial, and tab-unset.

To support arbitrary values, use the --value([{type}]) syntax (notice the square brackets) to tell Tailwind which types are supported as an arbitrary value:

This will match utilities like tab-[1] and tab-[76].

Available arbitrary value data types are: absolute-size, angle, bg-size, color, family-name, generic-name, image, integer, length, line-width, number, percentage, position, ratio, relative-size, url, vector, and *.

All three forms of the --value() function can be used within a rule as multiple declarations, and any declarations that fail to resolve will be omitted in the output:

This makes it possible to treat the value differently in each case if necessary, for example translating a bare integer to a percentage:

The --value() function can also take multiple arguments and resolve them left to right if you don't need to treat the return value differently in different cases:

To support negative values, register separate positive and negative utilities into separate declarations:

Modifiers are handled using the --modifier() function which works exactly like the --value() function but operates on a modifier if present:

If a modifier isn't present, any declaration depending on a modifier is just not included in the output.

To handle fractions, we rely on the CSS ratio data type. If this is used with --value(), it's a signal to Tailwind to treat the value and modifier as a single value:

This will match utilities like aspect-square, aspect-3/4, and aspect-[7/9].

In addition to using the variants that ship with Tailwind, you can also add your own custom variants using the @custom-variant directive:

Now you can use the theme-midnight:<utility> variant in your HTML:

You can create variants using the shorthand syntax when nesting isn't required:

When a custom variant has multiple rules, they can be nested within each other:

**Examples:**

Example 1 (unknown):
```unknown
@theme {  --font-display: "Satoshi", "sans-serif";  --breakpoint-3xl: 120rem;  --color-avocado-100: oklch(0.99 0 0);  --color-avocado-200: oklch(0.98 0.04 113.22);  --color-avocado-300: oklch(0.94 0.11 115.03);  --color-avocado-400: oklch(0.92 0.19 114.08);  --color-avocado-500: oklch(0.84 0.18 117.33);  --color-avocado-600: oklch(0.53 0.12 118.34);  --ease-fluid: cubic-bezier(0.3, 0, 0, 1);  --ease-snappy: cubic-bezier(0.2, 0, 0, 1);  /* ... */}
```

Example 2 (unknown):
```unknown
<div class="top-[117px]">  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="top-[117px] lg:top-[344px]">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="bg-[#bada55] text-[22px] before:content-['Festivus']">  <!-- ... --></div>
```

---

## overflow

**URL:** https://tailwindcss.com/docs/overflow

**Contents:**
- Examples
  - Showing content that overflows
  - Hiding content that overflows
  - Scrolling if needed
  - Scrolling horizontally if needed
  - Scrolling vertically if needed
  - Scrolling horizontally always
  - Scrolling vertically always
  - Scrolling in all directions
  - Responsive design

Use the overflow-visible utility to prevent content within an element from being clipped:

Note that any content that overflows the bounds of the element will then be visible.

Use the overflow-hidden utility to clip any content within an element that overflows the bounds of that element:

Use the overflow-auto utility to add scrollbars to an element in the event that its content overflows the bounds of that element:

Unlike overflow-scroll, which always shows scrollbars, this utility will only show them if scrolling is necessary.

Use the overflow-x-auto utility to allow horizontal scrolling if needed:

Use the overflow-y-auto utility to allow vertical scrolling if needed:

Use the overflow-x-scroll utility to allow horizontal scrolling and always show scrollbars unless always-visible scrollbars are disabled by the operating system:

Use the overflow-y-scroll utility to allow vertical scrolling and always show scrollbars unless always-visible scrollbars are disabled by the operating system:

Use the overflow-scroll utility to add scrollbars to an element:

Scroll vertically and horizontally

Unlike overflow-auto, which only shows scrollbars if they are necessary, this utility always shows them. Note that some operating systems (like macOS) hide unnecessary scrollbars regardless of this setting.

Prefix an overflow utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="overflow-visible ...">  <!-- ... --></div>
```

Example 2 (unknown):
```unknown
<div class="overflow-hidden ...">  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="overflow-auto ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="overflow-x-auto ...">  <!-- ... --></div>
```

---

## top / right / bottom / left

**URL:** https://tailwindcss.com/docs/top-right-bottom-left

**Contents:**
- Examples
  - Basic example
  - Using negative values
  - Using logical properties
  - Using a custom value
  - Responsive design
- Customizing your theme

Use top-<number>, right-<number>, bottom-<number>, left-<number>, and inset-<number> utilities like top-0 and bottom-4 to set the horizontal or vertical position of a positioned element:

To use a negative top/right/bottom/left value, prefix the class name with a dash to convert it to a negative value:

Use start-<number> or end-<number> utilities like start-0 and end-4 to set the inset-inline-start and inset-inline-end logical properties, which map to either the left or right side based on the text direction:

For more control, you can also use the LTR and RTL modifiers to conditionally apply specific styles depending on the current text direction.

Use utilities like inset-[<value>] and top-[<value>] to set the position based on a completely custom value:

For CSS variables, you can also use the inset-(<custom-property>) syntax:

This is just a shorthand for inset-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix inset,inset-x,inset-y,start,end,top,left,bottom, and right utilities with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The inset-<number>,inset-x-<number>,inset-y-<number>,start-<number>,end-<number>,top-<number>,left-<number>,bottom-<number>, and right-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<!-- Pin to top left corner --><div class="relative size-32 ...">  <div class="absolute top-0 left-0 size-16 ...">01</div></div><!-- Span top edge --><div class="relative size-32 ...">  <div class="absolute inset-x-0 top-0 h-16 ...">02</div></div><!-- Pin to top right corner --><div class="relative size-32 ...">  <div class="absolute top-0 right-0 size-16 ...">03</div></div><!-- Span left edge --><div class="relative size-32 ...">  <div class="absolute inset-y-0 left-0 w-16 ...">04</div></div><!-- Fill entire parent --><div class="relative size-32 ...">  <div class="absolute inset-0 ...">05</div></div><!-- Span right edge --><div class="relative size-32 ...">  <div class="absolute inset-y-0 right-0 w-16 ...">06</div></div><!-- Pin to bottom left corner --><div class="relative size-32 ...">  <div class="absolute bottom-0 left-0 size-16 ...">07</div></div><!-- Span bottom edge --><div class="relative size-32 ...">  <div class="absolute inset-x-0 bottom-0 h-16 ...">08</div></div><!-- Pin to bottom right corner --><div class="relative size-32 ...">  <div class="absolute right-0 bottom-0 size-16 ...">09</div></div>
```

Example 2 (unknown):
```unknown
<div class="relative size-32 ...">  <div class="absolute -top-4 -left-4 size-14 ..."></div></div>
```

Example 3 (unknown):
```unknown
<div dir="ltr">  <div class="relative size-32 ...">    <div class="absolute start-0 top-0 size-14 ..."></div>  </div>  <div>    <div dir="rtl">      <div class="relative size-32 ...">        <div class="absolute start-0 top-0 size-14 ..."></div>      </div>      <div></div>    </div>  </div></div>
```

Example 4 (unknown):
```unknown
<div class="inset-[3px] ...">  <!-- ... --></div>
```

---

## white-space

**URL:** https://tailwindcss.com/docs/white-space

**Contents:**
- Examples
  - Normal
  - No Wrap
  - Pre
  - Pre Line
  - Pre Wrap
  - Break Spaces
  - Responsive design

Use the whitespace-normal utility to cause text to wrap normally within an element. Newlines and spaces will be collapsed:

Hey everyone! It’s almost 2022 and we still don’t know if there are aliens living among us, or do we? Maybe the person writing this is an alien. You will never know.

Use the whitespace-nowrap utility to prevent text from wrapping within an element. Newlines and spaces will be collapsed:

Hey everyone! It’s almost 2022 and we still don’t know if there are aliens living among us, or do we? Maybe the person writing this is an alien. You will never know.

Use the whitespace-pre utility to preserve newlines and spaces within an element. Text will not be wrapped:

Hey everyone! It’s almost 2022 and we still don’t know if there are aliens living among us, or do we? Maybe the person writing this is an alien. You will never know.

Use the whitespace-pre-line utility to preserve newlines but not spaces within an element. Text will be wrapped normally:

Hey everyone! It’s almost 2022 and we still don’t know if there are aliens living among us, or do we? Maybe the person writing this is an alien. You will never know.

Use the whitespace-pre-wrap utility to preserve newlines and spaces within an element. Text will be wrapped normally:

Hey everyone! It’s almost 2022 and we still don’t know if there are aliens living among us, or do we? Maybe the person writing this is an alien. You will never know.

Use the whitespace-break-spaces utility to preserve newlines and spaces within an element. White space at the end of lines will not hang, but will wrap to the next line:

Hey everyone! It’s almost 2022 and we still don’t know if there are aliens living among us, or do we? Maybe the person writing this is an alien. You will never know.

Prefix a white-space utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="whitespace-normal">Hey everyone!It's almost 2022       and we still don't know if there             are aliens living among us, or do we? Maybe the person writing this is an alien.You will never know.</p>
```

Example 2 (unknown):
```unknown
<p class="overflow-auto whitespace-nowrap">Hey everyone!It's almost 2022       and we still don't know if there             are aliens living among us, or do we? Maybe the person writing this is an alien.You will never know.</p>
```

Example 3 (unknown):
```unknown
<p class="overflow-auto whitespace-pre">Hey everyone!It's almost 2022       and we still don't know if there             are aliens living among us, or do we? Maybe the person writing this is an alien.You will never know.</p>
```

Example 4 (unknown):
```unknown
<p class="whitespace-pre-line">Hey everyone!It's almost 2022       and we still don't know if there             are aliens living among us, or do we? Maybe the person writing this is an alien.You will never know.</p>
```

---

## max-width

**URL:** https://tailwindcss.com/docs/max-width

**Contents:**
- Examples
  - Basic example
  - Using a percentage
  - Using the container scale
  - Using breakpoints container
  - Using a custom value
  - Responsive design
- Customizing your theme

Use max-w-<number> utilities like max-w-24 and max-w-64 to set an element to a fixed maximum width based on the spacing scale:

Resize the example to see the expected behavior

Use max-w-full or max-w-<fraction> utilities like max-w-1/2 and max-w-2/5 to give an element a percentage-based maximum width:

Resize the example to see the expected behavior

Use utilities like max-w-sm and max-w-xl to set an element to a fixed maximum width based on the container scale:

Resize the example to see the expected behavior

Use the container utility to set the maximum width of an element to match the min-width of the current breakpoint. This is useful if you'd prefer to design for a fixed set of screen sizes instead of trying to accommodate a fully fluid viewport:

Note that unlike containers you might have used in other frameworks, Tailwind's container does not center itself automatically and does not have any built-in horizontal padding. Use mx-auto and the px-<number> utilities to add these:

Use the max-w-[<value>] syntax to set the maximum width based on a completely custom value:

For CSS variables, you can also use the max-w-(<custom-property>) syntax:

This is just a shorthand for max-w-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a max-width utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The max-w-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="w-full max-w-96 ...">max-w-96</div><div class="w-full max-w-80 ...">max-w-80</div><div class="w-full max-w-64 ...">max-w-64</div><div class="w-full max-w-48 ...">max-w-48</div><div class="w-full max-w-40 ...">max-w-40</div><div class="w-full max-w-32 ...">max-w-32</div><div class="w-full max-w-24 ...">max-w-24</div>
```

Example 2 (unknown):
```unknown
<div class="w-full max-w-9/10 ...">max-w-9/10</div><div class="w-full max-w-3/4 ...">max-w-3/4</div><div class="w-full max-w-1/2 ...">max-w-1/2</div><div class="w-full max-w-1/3 ...">max-w-1/3</div>
```

Example 3 (unknown):
```unknown
<div class="max-w-md ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="container">  <!-- ... --></div>
```

---

## width

**URL:** https://tailwindcss.com/docs/width

**Contents:**
- Examples
  - Basic example
  - Using a percentage
  - Using the container scale
  - Matching the viewport
  - Resetting the width
  - Setting both width and height
  - Using a custom value
  - Responsive design
- Customizing your theme

Use w-<number> utilities like w-24 and w-64 to set an element to a fixed width based on the spacing scale:

Use w-full or w-<fraction> utilities like w-1/2 and w-2/5 to give an element a percentage-based width:

Use utilities like w-sm and w-xl to set an element to a fixed width based on the container scale:

Use the w-screen utility to make an element span the entire width of the viewport:

Alternatively, you can match the width of the large, small or dynamic viewports using the w-lvw, w-svw, and w-dvw utilities.

Use the w-auto utility to remove an element's assigned width under a specific condition, like at a particular breakpoint:

Use utilities like size-px, size-4, and size-full to set both the width and height of an element at the same time:

Use the w-[<value>] syntax to set the width based on a completely custom value:

For CSS variables, you can also use the w-(<custom-property>) syntax:

This is just a shorthand for w-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a width utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The w-<number> and size-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="w-96 ...">w-96</div><div class="w-80 ...">w-80</div><div class="w-64 ...">w-64</div><div class="w-48 ...">w-48</div><div class="w-40 ...">w-40</div><div class="w-32 ...">w-32</div><div class="w-24 ...">w-24</div>
```

Example 2 (unknown):
```unknown
<div class="flex ...">  <div class="w-1/2 ...">w-1/2</div>  <div class="w-1/2 ...">w-1/2</div></div><div class="flex ...">  <div class="w-2/5 ...">w-2/5</div>  <div class="w-3/5 ...">w-3/5</div></div><div class="flex ...">  <div class="w-1/3 ...">w-1/3</div>  <div class="w-2/3 ...">w-2/3</div></div><div class="flex ...">  <div class="w-1/4 ...">w-1/4</div>  <div class="w-3/4 ...">w-3/4</div></div><div class="flex ...">  <div class="w-1/5 ...">w-1/5</div>  <div class="w-4/5 ...">w-4/5</div></div><div class="flex ...">  <div class="w-1/6 ...">w-1/6</div>  <div class="w-5/6 ...">w-5/6</div></div><div class="w-full ...">w-full</div>
```

Example 3 (unknown):
```unknown
<div class="w-xl ...">w-xl</div><div class="w-lg ...">w-lg</div><div class="w-md ...">w-md</div><div class="w-sm ...">w-sm</div><div class="w-xs ...">w-xs</div><div class="w-2xs ...">w-2xs</div><div class="w-3xs ...">w-3xs</div>
```

Example 4 (unknown):
```unknown
<div class="w-screen">  <!-- ... --></div>
```

---

## break-after

**URL:** https://tailwindcss.com/docs/break-after

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use utilities like break-after-column and break-after-page to control how a column or page break should behave after an element:

Prefix a break-after utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (javascript):
```javascript
<div class="columns-2">  <p>Well, let me tell you something, ...</p>  <p class="break-after-column">Sure, go ahead, laugh...</p>  <p>Maybe we can live without...</p>  <p>Look. If you think this is...</p></div>
```

Example 2 (unknown):
```unknown
<div class="break-after-column md:break-after-auto ...">  <!-- ... --></div>
```

---

## Preflight

**URL:** https://tailwindcss.com/docs/preflight

**Contents:**
- Overview
  - Margins are removed
  - Border styles are reset
  - Headings are unstyled
  - Lists are unstyled
    - Accessibility considerations
  - Images are block-level
  - Images are constrained
    - Elements with a hidden attribute stay hidden
- Extending Preflight

Built on top of modern-normalize, Preflight is a set of base styles for Tailwind projects that are designed to smooth over cross-browser inconsistencies and make it easier for you to work within the constraints of your design system.

When you import tailwindcss into your project, Preflight is automatically injected into the base layer:

While most of the styles in Preflight are meant to go unnoticed—they simply make things behave more like you'd expect them to—some are more opinionated and can be surprising when you first encounter them.

For a complete reference of all the styles applied by Preflight, see the stylesheet.

Preflight removes all of the default margins from all elements including headings, blockquotes, paragraphs, etc:

This makes it harder to accidentally rely on margin values applied by the user-agent stylesheet that are not part of your spacing scale.

In order to make it easy to add a border by simply adding the border class, Tailwind overrides the default border styles for all elements with the following rules:

Since the border class only sets the border-width property, this reset ensures that adding that class always adds a solid 1px border that uses currentColor.

This can cause some unexpected results when integrating certain third-party libraries, like Google maps for example.

When you run into situations like this, you can work around them by overriding the Preflight styles with your own custom CSS:

All heading elements are completely unstyled by default, and have the same font size and weight as normal text:

The reason for this is two-fold:

You can always add default header styles to your project by adding your own base styles.

Ordered and unordered lists are unstyled by default, with no bullets or numbers:

If you'd like to style a list, you can do so using the list-style-type and list-style-position utilities:

You can always add default list styles to your project by adding your own base styles.

Unstyled lists are not announced as lists by VoiceOver. If your content is truly a list but you would like to keep it unstyled, add a "list" role to the element:

Images and other replaced elements (like svg, video, canvas, and others) are display: block by default:

This helps to avoid unexpected alignment issues that you often run into using the browser default of display: inline.

If you ever need to make one of these elements inline instead of block, simply use the inline utility:

Images and videos are constrained to the parent width in a way that preserves their intrinsic aspect ratio:

This prevents them from overflowing their containers and makes them responsive by default. If you ever need to override this behavior, use the max-w-none utility:

This enforces that elements with a hidden attribute stay invisible unless using hidden="until-found". Remove the hidden attribute if you want an element to be visible to the user.

If you'd like to add your own base styles on top of Preflight, add them to the base CSS layer in your CSS using @layer base:

Learn more in the adding base styles documentation.

If you'd like to completely disable Preflight—perhaps because you're integrating Tailwind into an existing project or you'd prefer to define your own base styles—you can do so by importing only the parts of Tailwind that you need.

By default, this is what @import "tailwindcss"; injects:

To disable Preflight, simply omit its import while keeping everything else:

When importing Tailwind CSS' files individually, features like source(), theme(), and prefix() should go on their respective imports.

For example, source detection affects generated utilities, so source(…) should be added to the utilities.css import:

The same goes for important, which also affects utilities:

Similarly, theme(static) and theme(inline) affect the generated theme variables and should be placed on the theme.css import:

Finally, using a prefix with prefix(tw) affects the utilities and variables, so it should go on both imports:

**Examples:**

Example 1 (unknown):
```unknown
@layer theme, base, components, utilities;@import "tailwindcss/theme.css" layer(theme);@import "tailwindcss/preflight.css" layer(base);@import "tailwindcss/utilities.css" layer(utilities);
```

Example 2 (unknown):
```unknown
*,::after,::before,::backdrop,::file-selector-button {  margin: 0;  padding: 0;}
```

Example 3 (unknown):
```unknown
*,::after,::before,::backdrop,::file-selector-button {  box-sizing: border-box;  border: 0 solid;}
```

Example 4 (unknown):
```unknown
@layer base {  .google-map * {    border-style: none;  }}
```

---

## text-decoration-style

**URL:** https://tailwindcss.com/docs/text-decoration-style

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use utilities like decoration-dotted and decoration-dashed to change the text decoration style of an element:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Prefix a text-decoration-style utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="underline decoration-solid">The quick brown fox...</p><p class="underline decoration-double">The quick brown fox...</p><p class="underline decoration-dotted">The quick brown fox...</p><p class="underline decoration-dashed">The quick brown fox...</p><p class="underline decoration-wavy">The quick brown fox...</p>
```

Example 2 (unknown):
```unknown
<p class="underline md:decoration-dashed ...">  Lorem ipsum dolor sit amet...</p>
```

---

## min-width

**URL:** https://tailwindcss.com/docs/min-width

**Contents:**
- Examples
  - Basic example
  - Using a percentage
  - Using the container scale
  - Using a custom value
  - Responsive design
- Customizing your theme

Use min-w-<number> utilities like min-w-24 and min-w-64 to set an element to a fixed minimum width based on the spacing scale:

Use min-w-full or min-w-<fraction> utilities like min-w-1/2 and min-w-2/5 to give an element a percentage-based minimum width:

Use utilities like min-w-sm and min-w-xl to set an element to a fixed minimum width based on the container scale:

Use the min-w-[<value>] syntax to set the minimum width based on a completely custom value:

For CSS variables, you can also use the min-w-(<custom-property>) syntax:

This is just a shorthand for min-w-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a min-width utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

The min-w-<number> utilities are driven by the --spacing theme variable, which can be customized in your own theme:

Learn more about customizing the spacing scale in the theme variable documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="w-20 ...">  <div class="min-w-80 ...">min-w-80</div>  <div class="min-w-64 ...">min-w-64</div>  <div class="min-w-48 ...">min-w-48</div>  <div class="min-w-40 ...">min-w-40</div>  <div class="min-w-32 ...">min-w-32</div>  <div class="min-w-24 ...">min-w-24</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex ...">  <div class="min-w-3/4 ...">min-w-3/4</div>  <div class="w-full ...">w-full</div></div>
```

Example 3 (unknown):
```unknown
<div class="w-40 ...">  <div class="min-w-lg ...">min-w-lg</div>  <div class="min-w-md ...">min-w-md</div>  <div class="min-w-sm ...">min-w-sm</div>  <div class="min-w-xs ...">min-w-xs</div>  <div class="min-w-2xs ...">min-w-2xs</div>  <div class="min-w-3xs ...">min-w-3xs</div></div>
```

Example 4 (unknown):
```unknown
<div class="min-w-[220px] ...">  <!-- ... --></div>
```

---

## Detecting classes in source files

**URL:** https://tailwindcss.com/docs/detecting-classes-in-source-files

**Contents:**
- Overview
  - How classes are detected
  - Dynamic class names
  - Which files are scanned
- Explicitly registering sources
  - Setting your base path
  - Ignoring specific paths
  - Disabling automatic detection
- Safelisting specific utilities
  - Safelisting variants

Tailwind works by scanning your project for utility classes, then generating all of the necessary CSS based on the classes you've actually used.

This makes sure your CSS is as small as possible, and is also what makes features like arbitrary values possible.

Tailwind treats all of your source files as plain text, and doesn't attempt to actually parse your files as code in any way.

Instead it just looks for any tokens in your file that could be classes based on which characters Tailwind is expecting in class names:

Then it tries to generate the CSS for all of these tokens, throwing away any tokens that don't map to a utility class the framework knows about.

Since Tailwind scans your source files as plain text, it has no way of understanding string concatenation or interpolation in the programming language you're using.

Don't construct class names dynamically

In the example above, the strings text-red-600 and text-green-600 do not exist, so Tailwind will not generate those classes.

Instead, make sure any class names you’re using exist in full:

Always use complete class names

If you're using a component library like React or Vue, this means you shouldn't use props to dynamically construct classes:

Don't use props to build class names dynamically

Instead, map props to complete class names that are statically detectable at build-time:

Always map props to static class names

This has the added benefit of letting you map different prop values to different color shades for example:

As long as you always use complete class names in your code, Tailwind will generate all of your CSS perfectly every time.

Tailwind will scan every file in your project for class names, except in the following cases:

If you need to scan any files that Tailwind is ignoring by default, you can explicitly register those sources.

Use @source to explicitly register source paths relative to the stylesheet:

This is especially useful when you need to scan an external library that is built with Tailwind, since dependencies are usually listed in your .gitignore file and ignored by Tailwind by default.

Tailwind uses the current working directory as its starting point when scanning for class names by default.

To set the base path for source detection explicitly, use the source() function when importing Tailwind in your CSS:

This can be useful when working with monorepos where your build commands run from the root of the monorepo instead of the root of each project.

Use @source not to ignore specific paths, relative to the stylesheet, when scanning for class names:

This is useful when you have large directories in your project that you know don't use Tailwind classes, like legacy components or third-party libraries.

Use source(none) to completely disable automatic source detection if you want to register all of your sources explicitly:

This can be useful in projects that have multiple Tailwind stylesheets where you want to make sure each one only includes the classes each stylesheet needs.

If you need to make sure Tailwind generates certain class names that don’t exist in your content files, use @source inline() to force them to be generated:

You can also use @source inline() to generate classes with variants. For example, to generate the underline class with hover and focus variants, add {hover:,focus:,} to the source input:

The source input is brace expanded, so you can generate multiple classes at once. For example, to generate all the red background colors with hover variants, use a range:

This generates red background colors from 100 to 900 in increments of 100, along with the first and last shades of 50 and 950. It also adds the hover: variant for each of those classes.

Use @source not inline() to prevent specific classes from being generated, even if they are detected in your source files:

This will explicitly exclude the red background utilities, along with their hover and focus variants, from being generated.

**Examples:**

Example 1 (javascript):
```javascript
export function Button({ color, children }) {  const colors = {    black: "bg-black text-white",    blue: "bg-blue-500 text-white",    white: "bg-white text-black",  };  return (    <button className={`${colors[color]} rounded-full px-2 py-1.5 font-sans text-sm/6 font-medium shadow`}>      {children}    </button>  );}
```

Example 2 (unknown):
```unknown
<div class="text-{{ error ? 'red' : 'green' }}-600"></div>
```

Example 3 (unknown):
```unknown
<div class="{{ error ? 'text-red-600' : 'text-green-600' }}"></div>
```

Example 4 (unknown):
```unknown
function Button({ color, children }) {  return <button className={`bg-${color}-600 hover:bg-${color}-500 ...`}>{children}</button>;}
```

---
