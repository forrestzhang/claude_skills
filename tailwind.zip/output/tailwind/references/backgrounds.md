# Tailwind - Backgrounds

**Pages:** 1

---

## background-color

**URL:** https://tailwindcss.com/docs/background-color

**Contents:**
- Examples
  - Basic example
  - Changing the opacity
  - Using a custom value
  - Applying on hover
  - Responsive design
- Customizing your theme

Use utilities like bg-white, bg-indigo-500 and bg-transparent to control the background color of an element:

Use the color opacity modifier to control the opacity of an element's background color:

Use the bg-[<value>] syntax to set the background color based on a completely custom value:

For CSS variables, you can also use the bg-(<custom-property>) syntax:

This is just a shorthand for bg-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a background-color utility with a variant like hover:* to only apply the utility in that state:

Learn more about using variants in the variants documentation.

Prefix a background-color utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --color-* theme variables to customize the color utilities in your project:

Now the bg-regal-blue utility can be used in your markup:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<button class="bg-blue-500 ...">Button A</button><button class="bg-cyan-500 ...">Button B</button><button class="bg-pink-500 ...">Button C</button>
```

Example 2 (unknown):
```unknown
<button class="bg-sky-500/100 ..."></button><button class="bg-sky-500/75 ..."></button><button class="bg-sky-500/50 ..."></button>
```

Example 3 (unknown):
```unknown
<div class="bg-[#50d71e] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="bg-(--my-color) ...">  <!-- ... --></div>
```

---
