# Tailwind - Typography

**Pages:** 3

---

## font-family

**URL:** https://tailwindcss.com/docs/font-family

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design
- Customizing your theme

Use utilities like font-sans and font-mono to set the font family of an element:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Use the font-[<value>] syntax to set the font family based on a completely custom value:

For CSS variables, you can also use the font-(family-name:<custom-property>) syntax:

This is just a shorthand for font-[family-name:var(<custom-property>)] that adds the var() function for you automatically.

Prefix a font-family utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --font-* theme variables to customize the font family utilities in your project:

Now the font-display utility can be used in your markup:

You can also provide default font-feature-settings and font-variation-settings values for a font family:

If needed, use the @font-face at-rule to load custom fonts:

If you're loading a font from a service like Google Fonts, make sure to put the @import at the very top of your CSS file:

Browsers require that @import statements come before any other rules, so URL imports need to be above imports like @import "tailwindcss" which are inlined in the compiled CSS.

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="font-sans ...">The quick brown fox ...</p><p class="font-serif ...">The quick brown fox ...</p><p class="font-mono ...">The quick brown fox ...</p>
```

Example 2 (unknown):
```unknown
<p class="font-[Open_Sans] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 3 (unknown):
```unknown
<p class="font-(family-name:--my-font) ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="font-sans md:font-serif ...">  Lorem ipsum dolor sit amet...</p>
```

---

## text-align

**URL:** https://tailwindcss.com/docs/text-align

**Contents:**
- Examples
  - Left aligning text
  - Right aligning text
  - Centering text
  - Justifying text
  - Responsive design

Use the text-left utility to left align the text of an element:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Use the text-right utility to right align the text of an element:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Use the text-center utility to center the text of an element:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Use the text-justify utility to justify the text of an element:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Prefix a text-align utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="text-left">So I started to walk into the water...</p>
```

Example 2 (unknown):
```unknown
<p class="text-right">So I started to walk into the water...</p>
```

Example 3 (unknown):
```unknown
<p class="text-center">So I started to walk into the water...</p>
```

Example 4 (unknown):
```unknown
<p class="text-justify">So I started to walk into the water...</p>
```

---

## font-size

**URL:** https://tailwindcss.com/docs/font-size

**Contents:**
- Examples
  - Basic example
  - Setting the line-height
  - Using a custom value
  - Responsive design
- Customizing your theme

Use utilities like text-sm and text-lg to set the font size of an element:

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Use utilities like text-sm/6 and text-lg/7 to set the font size and line-height of an element at the same time:

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

Use the text-[<value>] syntax to set the font size based on a completely custom value:

For CSS variables, you can also use the text-(length:<custom-property>) syntax:

This is just a shorthand for text-[length:var(<custom-property>)] that adds the var() function for you automatically.

Prefix a font-size utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --text-* theme variables to customize the font size utilities in your project:

Now the text-tiny utility can be used in your markup:

You can also provide default line-height, letter-spacing, and font-weight values for a font size:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p class="text-sm ...">The quick brown fox ...</p><p class="text-base ...">The quick brown fox ...</p><p class="text-lg ...">The quick brown fox ...</p><p class="text-xl ...">The quick brown fox ...</p><p class="text-2xl ...">The quick brown fox ...</p>
```

Example 2 (unknown):
```unknown
<p class="text-sm/6 ...">So I started to walk into the water...</p><p class="text-sm/7 ...">So I started to walk into the water...</p><p class="text-sm/8 ...">So I started to walk into the water...</p>
```

Example 3 (unknown):
```unknown
<p class="text-[14px] ...">  Lorem ipsum dolor sit amet...</p>
```

Example 4 (unknown):
```unknown
<p class="text-(length:--my-text-size) ...">  Lorem ipsum dolor sit amet...</p>
```

---
