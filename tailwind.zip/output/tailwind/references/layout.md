# Tailwind - Layout

**Pages:** 19

---

## grid-auto-flow

**URL:** https://tailwindcss.com/docs/grid-auto-flow

**Contents:**
- Examples
  - Basic example
  - Responsive design

Use utilities like grid-flow-col and grid-flow-row-dense to control how the auto-placement algorithm works for a grid layout:

Prefix a grid-auto-flow utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-flow-row-dense grid-cols-3 grid-rows-3 ...">  <div class="col-span-2">01</div>  <div class="col-span-2">02</div>  <div>03</div>  <div>04</div>  <div>05</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-flow-col md:grid-flow-row ...">  <!-- ... --></div>
```

---

## flex-wrap

**URL:** https://tailwindcss.com/docs/flex-wrap

**Contents:**
- Examples
  - Don't wrap
  - Wrap normally
  - Wrap reversed
  - Responsive design

Use flex-nowrap to prevent flex items from wrapping, causing inflexible items to overflow the container if necessary:

Use flex-wrap to allow flex items to wrap:

Use flex-wrap-reverse to wrap flex items in the reverse direction:

Prefix a flex-wrap utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex flex-nowrap">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex flex-wrap">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex flex-wrap-reverse">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 4 (unknown):
```unknown
<div class="flex flex-wrap md:flex-wrap-reverse ...">  <!-- ... --></div>
```

---

## flex-basis

**URL:** https://tailwindcss.com/docs/flex-basis

**Contents:**
- Examples
  - Using the spacing scale
  - Using the container scale
  - Using percentages
  - Using a custom value
  - Responsive design
- Customizing your theme

Use basis-<number> utilities like basis-64 and basis-128 to set the initial size of flex items based on the spacing scale:

Use utilities like basis-xs and basis-sm to set the initial size of flex items based on the container scale:

Use basis-<fraction> utilities like basis-1/2 and basis-2/3 to set the initial size of flex items:

Use the basis-[<value>] syntax to set the basis based on a completely custom value:

For CSS variables, you can also use the basis-(<custom-property>) syntax:

This is just a shorthand for basis-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a flex-basis utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

Use the --container-* theme variables to customize the fixed-width basis utilities in your project:

Now the basis-4xs utility can be used in your markup:

The basis-<number> utilities are driven by the --spacing theme variable, which you can also customize:

Learn more about customizing the spacing scale in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex flex-row">  <div class="basis-64">01</div>  <div class="basis-64">02</div>  <div class="basis-128">03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex flex-row">  <div class="basis-3xs">01</div>  <div class="basis-2xs">02</div>  <div class="basis-xs">03</div>  <div class="basis-sm">04</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex flex-row">  <div class="basis-1/3">01</div>  <div class="basis-2/3">02</div></div>
```

Example 4 (unknown):
```unknown
<div class="basis-[30vw] ...">  <!-- ... --></div>
```

---

## flex-shrink

**URL:** https://tailwindcss.com/docs/flex-shrink

**Contents:**
- Examples
  - Allowing flex items to shrink
  - Preventing items from shrinking
  - Using a custom value
  - Responsive design

Use shrink to allow a flex item to shrink if needed:

Use shrink-0 to prevent a flex item from shrinking:

Use the shrink-[<value>] syntax to set the flex shrink factor based on a completely custom value:

For CSS variables, you can also use the shrink-(<custom-property>) syntax:

This is just a shorthand for shrink-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a flex-shrink utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex ...">  <div class="h-14 w-14 flex-none ...">01</div>  <div class="h-14 w-64 shrink ...">02</div>  <div class="h-14 w-14 flex-none ...">03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex ...">  <div class="h-16 flex-1 ...">01</div>  <div class="h-16 w-32 shrink-0 ...">02</div>  <div class="h-16 flex-1 ...">03</div></div>
```

Example 3 (unknown):
```unknown
<div class="shrink-[calc(100vw-var(--sidebar))] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="shrink-(--my-shrink) ...">  <!-- ... --></div>
```

---

## grid-row

**URL:** https://tailwindcss.com/docs/grid-row

**Contents:**
- Examples
  - Spanning rows
  - Starting and ending lines
  - Using a custom value
  - Responsive design

Use row-span-<number> utilities like row-span-2 and row-span-4 to make an element span n rows:

Use row-start-<number> or row-end-<number> utilities like row-start-2 and row-end-3 to make an element start or end at the nth grid line:

These can also be combined with the row-span-<number> utilities to span a specific number of rows.

Use utilities like row-[<value>],row-span-[<value>],row-start-[<value>], and row-end-[<value>] to set the grid row size and location based on a completely custom value:

For CSS variables, you can also use the row-(<custom-property>) syntax:

This is just a shorthand for row-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix grid-row,grid-row-start, and grid-row-end utilities with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-flow-col grid-rows-3 gap-4">  <div class="row-span-3 ...">01</div>  <div class="col-span-2 ...">02</div>  <div class="col-span-2 row-span-2 ...">03</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-flow-col grid-rows-3 gap-4">  <div class="row-span-2 row-start-2 ...">01</div>  <div class="row-span-2 row-end-3 ...">02</div>  <div class="row-start-1 row-end-4 ...">03</div></div>
```

Example 3 (unknown):
```unknown
<div class="row-[span_16_/_span_16] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="row-(--my-rows) ...">  <!-- ... --></div>
```

---

## display

**URL:** https://tailwindcss.com/docs/display

**Contents:**
- Examples
  - Block and Inline
  - Flow Root
  - Flex
  - Inline Flex
  - Grid
  - Inline Grid
  - Contents
  - Table
  - Hidden

Use the inline, inline-block, and block utilities to control the flow of text and elements:

Use the flow-root utility to create a block-level element with its own block formatting context:

Use the flex utility to create a block-level flex container:

Use the inline-flex utility to create an inline flex container that flows with text:

Today I spent most of the day researching ways to take advantage of the fact that bottles can be returned for 10 cents in Michigan, but only 5 cents here. Kramer keeps telling me there is no way to make it work, that he has run the numbers on every possible approach, but I just have to believe there's a way to make it work, there's simply too much opportunity here.

Use the grid utility to create a grid container:

Use the inline-grid utility to create an inline grid container:

Use the contents utility to create a "phantom" container whose children act like direct children of the parent:

Use the table, table-row, table-cell, table-caption, table-column, table-column-group, table-header-group, table-row-group, and table-footer-group utilities to create elements that behave like their respective table elements:

Use the hidden utility to remove an element from the document:

To visually hide an element but keep it in the document, use the visibility property instead.

Use sr-only to hide an element visually without hiding it from screen readers:

Use not-sr-only to undo sr-only, making an element visible to sighted users as well as screen readers:

This can be useful when you want to visually hide something on small screens but show it on larger screens for example.

Prefix a display utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<p>  When controlling the flow of text, using the CSS property <span class="inline">display: inline</span> will cause the  text inside the element to wrap normally.</p><p>  While using the property <span class="inline-block">display: inline-block</span> will wrap the element to prevent the  text inside from extending beyond its parent.</p><p>  Lastly, using the property <span class="block">display: block</span> will put the element on its own line and fill its  parent.</p>
```

Example 2 (javascript):
```javascript
<div class="p-4">  <div class="flow-root ...">    <div class="my-4 ...">Well, let me tell you something, ...</div>  </div>  <div class="flow-root ...">    <div class="my-4 ...">Sure, go ahead, laugh if you want...</div>  </div></div>
```

Example 3 (unknown):
```unknown
<div class="flex items-center">  <img src="path/to/image.jpg" />  <div>    <strong>Andrew Alfred</strong>    <span>Technical advisor</span>  </div></div>
```

Example 4 (unknown):
```unknown
<p>  Today I spent most of the day researching ways to ...  <span class="inline-flex items-baseline">    <img src="/img/kramer.jpg" class="mx-1 size-5 self-center rounded-full" />    <span>Kramer</span>  </span>  keeps telling me there is no way to make it work, that ...</p>
```

---

## flex-direction

**URL:** https://tailwindcss.com/docs/flex-direction

**Contents:**
- Examples
  - Row
  - Row reversed
  - Column
  - Column reversed
  - Responsive design

Use flex-row to position flex items horizontally in the same direction as text:

Use flex-row-reverse to position flex items horizontally in the opposite direction:

Use flex-col to position flex items vertically:

Use flex-col-reverse to position flex items vertically in the opposite direction:

Prefix a flex-direction utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex flex-row ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex flex-row-reverse ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex flex-col ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 4 (unknown):
```unknown
<div class="flex flex-col-reverse ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

---

## justify-self

**URL:** https://tailwindcss.com/docs/justify-self

**Contents:**
- Examples
  - Auto
  - Start
  - Center
  - End
  - Stretch
  - Responsive design

Use the justify-self-auto utility to align an item based on the value of the grid's justify-items property:

Use the justify-self-start utility to align a grid item to the start of its inline axis:

Use the justify-self-center or justify-self-center-safe utilities to align a grid item along the center of its inline axis:

Resize the container to see the alignment behavior

justify-self-center-safe

When there is not enough space available, the justify-self-center-safe utility will align the item to the start of the container instead of the end.

Use the justify-self-end or justify-self-end-safe utilities to align a grid item to the end of its inline axis:

Resize the container to see the alignment behavior

justify-self-end-safe

When there is not enough space available, the justify-self-end-safe utility will align the item to the start of the container instead of the end.

Use the justify-self-stretch utility to stretch a grid item to fill the grid area on its inline axis:

Prefix a justify-self utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid justify-items-stretch ...">  <!-- ... -->  <div class="justify-self-auto ...">02</div>  <!-- ... --></div>
```

Example 2 (unknown):
```unknown
<div class="grid justify-items-stretch ...">  <!-- ... -->  <div class="justify-self-start ...">02</div>  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="grid justify-items-stretch ...">  <!-- ... -->  <div class="justify-self-center ...">02</div>  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="grid justify-items-stretch ...">  <!-- ... -->  <div class="justify-self-center-safe ...">02</div>  <!-- ... --></div>
```

---

## grid-column

**URL:** https://tailwindcss.com/docs/grid-column

**Contents:**
- Examples
  - Spanning columns
  - Starting and ending lines
  - Using a custom value
  - Responsive design

Use col-span-<number> utilities like col-span-2 and col-span-4 to make an element span n columns:

Use col-start-<number> or col-end-<number> utilities like col-start-2 and col-end-3 to make an element start or end at the nth grid line:

These can also be combined with the col-span-<number> utilities to span a specific number of columns.

Use utilities like col-[<value>],col-span-[<value>],col-start-[<value>], and col-end-[<value>] to set the grid column size and location based on a completely custom value:

For CSS variables, you can also use the col-(<custom-property>) syntax:

This is just a shorthand for col-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix grid-column,grid-column-start, and grid-column-end utilities with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-cols-3 gap-4">  <div class="...">01</div>  <div class="...">02</div>  <div class="...">03</div>  <div class="col-span-2 ...">04</div>  <div class="...">05</div>  <div class="...">06</div>  <div class="col-span-2 ...">07</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-cols-6 gap-4">  <div class="col-span-4 col-start-2 ...">01</div>  <div class="col-start-1 col-end-3 ...">02</div>  <div class="col-span-2 col-end-7 ...">03</div>  <div class="col-start-1 col-end-7 ...">04</div></div>
```

Example 3 (unknown):
```unknown
<div class="col-[16_/_span_16] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="col-(--my-columns) ...">  <!-- ... --></div>
```

---

## justify-items

**URL:** https://tailwindcss.com/docs/justify-items

**Contents:**
- Examples
  - Start
  - End
  - Center
  - Stretch
  - Responsive design

Use the justify-items-start utility to justify grid items against the start of their inline axis:

Use the justify-items-end or justify-items-end-safe utilities to justify grid items against the end of their inline axis:

Resize the container to see the alignment behavior

justify-items-end-safe

When there is not enough space available, the justify-items-end-safe utility will align items to the start of the container instead of the end.

Use the justify-items-center or justify-items-center-safe utilities to justify grid items against the end of their inline axis:

Resize the container to see the alignment behavior

justify-items-center-safe

When there is not enough space available, the justify-items-center-safe utility will align items to the start of the container instead of the center.

Use the justify-items-stretch utility to stretch items along their inline axis:

Prefix a justify-items utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid justify-items-start ...">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-flow-col justify-items-end ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 3 (unknown):
```unknown
<div class="grid grid-flow-col justify-items-end-safe ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 4 (unknown):
```unknown
<div class="grid grid-flow-col justify-items-center ...">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

---

## flex

**URL:** https://tailwindcss.com/docs/flex

**Contents:**
- Examples
  - Basic example
  - Initial
  - Auto
  - None
  - Using a custom value
  - Responsive design

Use flex-<number> utilities like flex-1 to allow a flex item to grow and shrink as needed, ignoring its initial size:

Use flex-initial to allow a flex item to shrink but not grow, taking into account its initial size:

Use flex-auto to allow a flex item to grow and shrink, taking into account its initial size:

Use flex-none to prevent a flex item from growing or shrinking:

Use the flex-[<value>] syntax to set the flex shorthand property based on a completely custom value:

For CSS variables, you can also use the flex-(<custom-property>) syntax:

This is just a shorthand for flex-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a flex utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex">  <div class="w-14 flex-none ...">01</div>  <div class="w-64 flex-1 ...">02</div>  <div class="w-32 flex-1 ...">03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex">  <div class="w-14 flex-none ...">01</div>  <div class="w-64 flex-initial ...">02</div>  <div class="w-32 flex-initial ...">03</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex ...">  <div class="w-14 flex-none ...">01</div>  <div class="w-64 flex-auto ...">02</div>  <div class="w-32 flex-auto ...">03</div></div>
```

Example 4 (unknown):
```unknown
<div class="flex ...">  <div class="w-14 flex-none ...">01</div>  <div class="w-32 flex-none ...">02</div>  <div class="flex-1 ...">03</div></div>
```

---

## grid-auto-rows

**URL:** https://tailwindcss.com/docs/grid-auto-rows

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design

Use utilities like auto-rows-min and auto-rows-max to control the size of implicitly-created grid rows:

Use the auto-rows-[<value>] syntax to set the size of implicitly-created grid rows based on a completely custom value:

For CSS variables, you can also use the auto-rows-(<custom-property>) syntax:

This is just a shorthand for auto-rows-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a grid-auto-rows utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-flow-row auto-rows-max">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 2 (unknown):
```unknown
<div class="auto-rows-[minmax(0,2fr)] ...">  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="auto-rows-(--my-auto-rows) ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="grid grid-flow-row auto-rows-max md:auto-rows-min ...">  <!-- ... --></div>
```

---

## grid-auto-columns

**URL:** https://tailwindcss.com/docs/grid-auto-columns

**Contents:**
- Examples
  - Basic example
  - Using a custom value
  - Responsive design

Use utilities like auto-cols-min and auto-cols-max to control the size of implicitly-created grid columns:

Use the auto-cols-[<value>] syntax to set the size of implicitly-created grid columns based on a completely custom value:

For CSS variables, you can also use the auto-cols-(<custom-property>) syntax:

This is just a shorthand for auto-cols-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a grid-auto-columns utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid auto-cols-max grid-flow-col">  <div>01</div>  <div>02</div>  <div>03</div></div>
```

Example 2 (unknown):
```unknown
<div class="auto-cols-[minmax(0,2fr)] ...">  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="auto-cols-(--my-auto-cols) ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="grid grid-flow-col auto-cols-max md:auto-cols-min ...">  <!-- ... --></div>
```

---

## gap

**URL:** https://tailwindcss.com/docs/gap

**Contents:**
- Examples
  - Basic example
  - Changing row and column gaps independently
  - Using a custom value
  - Responsive design

Use gap-<number> utilities like gap-2 and gap-4 to change the gap between both rows and columns in grid and flexbox layouts:

Use gap-x-<number> or gap-y-<number> utilities like gap-x-8 and gap-y-4 to change the gap between columns and rows independently:

Use utilities like gap-[<value>],gap-x-[<value>], and gap-y-[<value>] to set the gap based on a completely custom value:

For CSS variables, you can also use the gap-(<custom-property>) syntax:

This is just a shorthand for gap-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix gap,column-gap, and row-gap utilities with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-cols-2 gap-4">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-cols-3 gap-x-8 gap-y-4">  <div>01</div>  <div>02</div>  <div>03</div>  <div>04</div>  <div>05</div>  <div>06</div></div>
```

Example 3 (unknown):
```unknown
<div class="gap-[10vw] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="gap-(--my-gap) ...">  <!-- ... --></div>
```

---

## flex-grow

**URL:** https://tailwindcss.com/docs/flex-grow

**Contents:**
- Examples
  - Allowing items to grow
  - Growing items based on factor
  - Preventing items from growing
  - Using a custom value
  - Responsive design

Use grow to allow a flex item to grow to fill any available space:

Use grow-<number> utilities like grow-3 to make flex items grow proportionally based on their growth factor, allowing them to fill the available space relative to each other:

Use grow-0 to prevent a flex item from growing:

Use the grow-[<value>] syntax to set the flex grow factor based on a completely custom value:

For CSS variables, you can also use the grow-(<custom-property>) syntax:

This is just a shorthand for grow-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a flex-grow utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex ...">  <div class="size-14 flex-none ...">01</div>  <div class="size-14 grow ...">02</div>  <div class="size-14 flex-none ...">03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex ...">  <div class="size-14 grow-3 ...">01</div>  <div class="size-14 grow-7 ...">02</div>  <div class="size-14 grow-3 ...">03</div></div>
```

Example 3 (unknown):
```unknown
<div class="flex ...">  <div class="size-14 grow ...">01</div>  <div class="size-14 grow-0 ...">02</div>  <div class="size-14 grow ...">03</div></div>
```

Example 4 (unknown):
```unknown
<div class="grow-[25vw] ...">  <!-- ... --></div>
```

---

## grid-template-columns

**URL:** https://tailwindcss.com/docs/grid-template-columns

**Contents:**
- Examples
  - Specifying the grid columns
  - Implementing a subgrid
  - Using a custom value
  - Responsive design

Use grid-cols-<number> utilities like grid-cols-2 and grid-cols-4 to create grids with n equally sized columns:

Use the grid-cols-subgrid utility to adopt the column tracks defined by the item's parent:

Use the grid-cols-[<value>] syntax to set the columns based on a completely custom value:

For CSS variables, you can also use the grid-cols-(<custom-property>) syntax:

This is just a shorthand for grid-cols-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a grid-template-columns utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-cols-4 gap-4">  <div>01</div>  <!-- ... -->  <div>09</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-cols-4 gap-4">  <div>01</div>  <!-- ... -->  <div>05</div>  <div class="col-span-3 grid grid-cols-subgrid gap-4">    <div class="col-start-2">06</div>  </div></div>
```

Example 3 (unknown):
```unknown
<div class="grid-cols-[200px_minmax(900px,_1fr)_100px] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="grid-cols-(--my-grid-cols) ...">  <!-- ... --></div>
```

---

## order

**URL:** https://tailwindcss.com/docs/order

**Contents:**
- Examples
  - Explicitly setting a sort order
  - Ordering items first or last
  - Using negative values
  - Using a custom value
  - Responsive design

Use order-<number> utilities like order-1 and order-3 to render flex and grid items in a different order than they appear in the document:

Use the order-first and order-last utilities to render flex and grid items first or last:

To use a negative order value, prefix the class name with a dash to convert it to a negative value:

Use the order-[<value>] syntax to set the order based on a completely custom value:

For CSS variables, you can also use the order-(<custom-property>) syntax:

This is just a shorthand for order-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix an order utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="flex justify-between ...">  <div class="order-3 ...">01</div>  <div class="order-1 ...">02</div>  <div class="order-2 ...">03</div></div>
```

Example 2 (unknown):
```unknown
<div class="flex justify-between ...">  <div class="order-last ...">01</div>  <div class="...">02</div>  <div class="order-first ...">03</div></div>
```

Example 3 (unknown):
```unknown
<div class="-order-1">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="order-[min(var(--total-items),10)] ...">  <!-- ... --></div>
```

---

## columns

**URL:** https://tailwindcss.com/docs/columns

**Contents:**
- Examples
  - Setting by number
  - Setting by width
  - Setting the column gap
  - Using a custom value
  - Responsive design
- Customizing your theme

Use columns-<number> utilities like columns-3 to set the number of columns that should be created for the content within an element:

The column width will automatically adjust to accommodate the specified number of columns.

Use utilities like columns-xs and columns-sm to set the ideal column width for the content within an element:

Resize the example to see the expected behavior

When setting the column width, the number of columns automatically adjusts to ensure they don't get too narrow.

Use the gap-<width> utilities to specify the width between columns:

Learn more about the gap utilities in the gap documentation.

Use the columns-[<value>] syntax to set the columns based on a completely custom value:

For CSS variables, you can also use the columns-(<custom-property>) syntax:

This is just a shorthand for columns-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a columns utility with a breakpoint variant like sm: to only apply the utility at small screen sizes and above:

Resize the example to see the expected behavior

Learn more about using variants in the variants documentation.

Use the --container-* theme variables to customize the fixed-width column utilities in your project:

Now the columns-4xs utility can be used in your markup:

Learn more about customizing your theme in the theme documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="columns-3 ...">  <img class="aspect-3/2 ..." src="/img/mountains-1.jpg" />  <img class="aspect-square ..." src="/img/mountains-2.jpg" />  <img class="aspect-square ..." src="/img/mountains-3.jpg" />  <!-- ... --></div>
```

Example 2 (unknown):
```unknown
<div class="columns-3xs ...">  <img class="aspect-3/2 ..." src="/img/mountains-1.jpg" />  <img class="aspect-square ..." src="/img/mountains-2.jpg" />  <img class="aspect-square ..." src="/img/mountains-3.jpg" />  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div class="columns-3 gap-8 ...">  <img class="aspect-3/2 ..." src="/img/mountains-1.jpg" />  <img class="aspect-square ..." src="/img/mountains-2.jpg" />  <img class="aspect-square ..." src="/img/mountains-3.jpg" />  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="columns-[30vw] ...">  <!-- ... --></div>
```

---

## grid-template-rows

**URL:** https://tailwindcss.com/docs/grid-template-rows

**Contents:**
- Examples
  - Specifying the grid rows
  - Implementing a subgrid
  - Using a custom value
  - Responsive design

Use grid-rows-<number> utilities like grid-rows-2 and grid-rows-4 to create grids with n equally sized rows:

Use the grid-rows-subgrid utility to adopt the row tracks defined by the item's parent:

Use the grid-rows-[<value>] syntax to set the rows based on a completely custom value:

For CSS variables, you can also use the grid-rows-(<custom-property>) syntax:

This is just a shorthand for grid-rows-[var(<custom-property>)] that adds the var() function for you automatically.

Prefix a grid-template-rows utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:

Learn more about using variants in the variants documentation.

**Examples:**

Example 1 (unknown):
```unknown
<div class="grid grid-flow-col grid-rows-4 gap-4">  <div>01</div>  <!-- ... -->  <div>09</div></div>
```

Example 2 (unknown):
```unknown
<div class="grid grid-flow-col grid-rows-4 gap-4">  <div>01</div>  <!-- ... -->  <div>05</div>  <div class="row-span-3 grid grid-rows-subgrid gap-4">    <div class="row-start-2">06</div>  </div>  <div>07</div>  <!-- ... -->  <div>10</div></div>
```

Example 3 (unknown):
```unknown
<div class="grid-rows-[200px_minmax(900px,1fr)_100px] ...">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
<div class="grid-rows-(--my-grid-rows) ...">  <!-- ... --></div>
```

---
