# Tailwind - Core Concepts

**Pages:** 3

---

## Hover, focus, and other states

**URL:** https://tailwindcss.com/docs/hover-focus-and-other-states

**Contents:**
- Pseudo-classes
  - :hover, :focus, and :active
  - :first, :last, :odd, and :even
  - :required and :disabled
  - :has()
    - Styling based on the descendants of a group
    - Styling based on the descendants of a peer
  - :not()
  - Styling based on parent state
    - Differentiating nested groups

Every utility class in Tailwind can be applied conditionally by adding a variant to the beginning of the class name that describes the condition you want to target.

For example, to apply the bg-sky-700 class on hover, use the hover:bg-sky-700 class:

Hover over this button to see the background color change

When writing CSS the traditional way, a single class name would do different things based on the current state:

Traditionally the same class name applies different styles on hover

In Tailwind, rather than adding the styles for a hover state to an existing class, you add another class to the element that only does something on hover:

In Tailwind, separate classes are used for the default state and the hover state

Notice how hover:bg-sky-700 only defines styles for the :hover state? It does nothing by default, but as soon as you hover over an element with that class, the background color will change to sky-700.

This is what we mean when we say a utility class can be applied conditionally — by using variants you can control exactly how your design behaves in different states, without ever leaving your HTML.

Tailwind includes variants for just about everything you'll ever need, including:

These variants can even be stacked to target more specific situations, for example changing the background color in dark mode, at the medium breakpoint, on hover:

In this guide you'll learn about every variant available in the framework, how to use them with your own custom classes, and even how to create your own.

Style elements on hover, focus, and active using the hover, focus, and active variants:

Try interacting with this button to see the hover, focus, and active states

Tailwind also includes variants for other interactive states like :visited, :focus-within, :focus-visible, and more.

See the pseudo-class reference for a complete list of available pseudo-class variants.

Style an element when it is the first-child or last-child using the first and last variants:

kristen.ramos@example.com

floyd.miles@example.com

courtney.henry@example.com

You can also style an element when it's an odd or even child using the odd and even variants:

Use the nth-* and nth-last-* variants to style children based on their position in the list:

You can pass any number you want to these by default, and use arbitrary values for more complex expressions like nth-[2n+1_of_li].

Tailwind also includes variants for other structural pseudo-classes like :only-child, :first-of-type, :empty, and more.

See the pseudo-class reference for a complete list of available pseudo-class variants.

Style form elements in different states using variants like required, invalid, and disabled:

Try making the email address valid to see the styles change

Using variants for this sort of thing can reduce the amount of conditional logic in your templates, letting you use the same set of classes regardless of what state an input is in and letting the browser apply the right styles for you.

Tailwind also includes variants for other form states like :read-only, :indeterminate, :checked, and more.

See the pseudo-class reference for a complete list of available pseudo-class variants.

Use the has-* variant to style an element based on the state or content of its descendants:

You can use has-* with a pseudo-class, like has-[:focus], to style an element based on the state of its descendants. You can also use element selectors, like has-[img] or has-[a], to style an element based on the content of its descendants.

If you need to style an element based on the descendants of a parent element, you can mark the parent with the group class and use the group-has-* variant to style the target element:

Product Designer at planeteria.tech

Just happy to be here.

A multidisciplinary designer, working at the intersection of art and technology. alex-reed.com

Pushing pixels. Slinging divs.

If you need to style an element based on the descendants of a sibling element, you can mark the sibling with the peer class and use the peer-has-* variant to style the target element:

Use the not- variant to style an element when a condition is not true.

It's particularly powerful when combined with other pseudo-class variants, for example combining not-focus: with hover: to only apply hover styles when an element is not focused:

Try focusing on the button and then hovering over it

You can also combine the not- variant with media query variants like forced-colors or supports to only style an element when something about the user's environment is not true:

When you need to style an element based on the state of some parent element, mark the parent with the group class, and use group-* variants like group-hover to style the target element:

Hover over the card to see both text elements change color

Create a new project from a variety of starting templates.

This pattern works with every pseudo-class variant, for example group-focus, group-active, or even group-odd.

When nesting groups, you can style something based on the state of a specific parent group by giving that parent a unique group name using a group/{name} class, and including that name in variants using classes like group-hover/{name}:

Groups can be named however you like and don’t need to be configured in any way — just name your groups directly in your markup and Tailwind will automatically generate the necessary CSS.

You can create one-off group-* variants on the fly by providing your own selector as an arbitrary value between square brackets:

For more control, you can use the & character to mark where .group should end up in the final selector relative to the selector you are passing in:

The in-* variant works similarly to group except you don't need to add group to the parent element:

The in-* variant responds to state changes in any parent, so if you want more fine-grained control you'll need to use group instead.

When you need to style an element based on the state of a sibling element, mark the sibling with the peer class, and use peer-* variants like peer-invalid to style the target element:

Try making the email address valid to see the warning disappear

Please provide a valid email address.

This makes it possible to do all sorts of neat tricks, like floating labels for example without any JS.

This pattern works with every pseudo-class variant, for example peer-focus, peer-required, and peer-disabled.

It's important to note that the peer marker can only be used on previous siblings because of how the subsequent-sibling combinator works in CSS:

Won't work, only previous siblings can be marked as peers

When using multiple peers, you can style something on the state of a specific peer by giving that peer a unique name using a peer/{name} class, and including that name in variants using classes like peer-checked/{name}:

Peers can be named however you like and don’t need to be configured in any way — just name your peers directly in your markup and Tailwind will automatically generate the necessary CSS.

You can create one-off peer-* variants on the fly by providing your own selector as an arbitrary value between square brackets:

For more control, you can use the & character to mark where .peer should end up in the final selector relative to the selector you are passing in:

Style the ::before and ::after pseudo-elements using the before and after variants:

When using these variants, Tailwind will automatically add content: '' by default so you don't have to specify it unless you want a different value:

It's worth noting that you don't really need ::before and ::after pseudo-elements for most things in Tailwind projects — it's usually simpler to just use a real HTML element.

For example, here's the same design from above but using a <span> instead of the ::before pseudo-element, which is a little easier to read and is actually less code:

Save before and after for situations where it's important that the content of the pseudo-element is not actually in the DOM and can't be selected by the user.

Style the placeholder text of any input or textarea using the placeholder variant:

Style the button in file inputs using the file variant:

Style the counters or bullets in lists using the marker variant:

We've designed the marker variant to be inheritable, so although you can use it directly on an <li> element, you can also use it on a parent to avoid repeating yourself.

Style the active text selection using the selection variant:

Try selecting some of this text with your mouse

So I started to walk into the water. I won't lie to you boys, I was terrified. But I pressed on, and as I made my way past the breakers a strange calm came over me. I don't know if it was divine intervention or the kinship of all living things but I tell you Jerry at that moment, I was a marine biologist.

We've designed the selection variant to be inheritable, so you can add it anywhere in the tree and it will be applied to all descendant elements.

This makes it easy to set the selection color to match your brand across your entire site:

Style the first line in a block of content using the first-line variant, and the first letter using the first-letter variant:

Well, let me tell you something, funny boy. Y'know that little stamp, the one that says "New York Public Library"? Well that may not mean anything to you, but that means a lot to me. One whole hell of a lot.

Sure, go ahead, laugh if you want to. I've seen your type before: Flashy, making the scene, flaunting convention. Yeah, I know what you're thinking. What's this guy making such a big stink about old library books? Well, let me give you a hint, junior.

Style the backdrop of a native <dialog> element using the backdrop variant:

If you're using native <dialog> elements in your project, you may also want to read about styling open/closed states using the open variant.

To style an element at a specific breakpoint, use responsive variants like md and lg.

For example, this will render a 3-column grid on mobile, a 4-column grid on medium-width screens, and a 6-column grid on large-width screens:

To style an element based on the width of a parent element instead of the viewport, use variants like @md and @lg:

Check out the Responsive design documentation for an in-depth look at how these features work.

The prefers-color-scheme media query tells you whether the user prefers a light theme or dark theme, and is usually configured at the operating system level.

Use utilities with no variant to target light mode, and use the dark variant to provide overrides for dark mode:

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

Check out the Dark Mode documentation for an in-depth look at how this feature works.

The prefers-reduced-motion media query tells you if the user has requested that you minimize non-essential motion.

Use the motion-reduce variant to conditionally add styles when the user has requested reduced motion:

Try emulating `prefers-reduced-motion: reduce` in your developer tools to hide the spinner

Tailwind also includes a motion-safe variant that only adds styles when the user has not requested reduced motion. This can be useful when using the motion-reduce helper would mean having to "undo" a lot of styles:

The prefers-contrast media query tells you if the user has requested more or less contrast.

Use the contrast-more variant to conditionally add styles when the user has requested more contrast:

Try emulating `prefers-contrast: more` in your developer tools to see the changes

We need this to steal your identity.

Tailwind also includes a contrast-less variant you can use to conditionally add styles when the user has requested less contrast.

The forced-colors media query indicates if the user is using a forced colors mode. These modes override your site's colors with a user defined palette for text, backgrounds, links and buttons.

Use the forced-colors variant to conditionally add styles when the user has enabled a forced color mode:

Try emulating `forced-colors: active` in your developer tools to see the changes

Use the not-forced-colors variant to apply styles based when the user is not using a forced colors mode:

Tailwind also includes a forced color adjust utilities to opt in and out of forced colors.

Use the inverted-colors variant to conditionally add styles when the user has enabled an inverted color scheme:

The pointer media query tells you whether the user has a primary pointing device, like a mouse, and the accuracy of that pointing device.

Use the pointer-fine variant to target an accurate pointing device, like a mouse or trackpad, or the pointer-coarse variant to target a less accurate pointing device, like a touchscreen, which can be useful for providing larger click targets on touch devices:

Try emulating a touch device in your developer tools to see the changes

While pointeronly targets the primary pointing device, any-pointer is used to target any of the pointing devices that might be available. Use the any-pointer-fine and any-pointer-coarse variants to provide different styles if at least one connected pointing device meets the criteria.

You can use pointer-none and any-pointer-none to target the absence of a pointing device.

Use the portrait and landscape variants to conditionally add styles when the viewport is in a specific orientation:

Use the noscript variant to conditionally add styles based on whether the user has scripting, such as JavaScript, enabled:

Use the print variant to conditionally add styles that only apply when the document is being printed:

Use the supports-[...] variant to style things based on whether a certain feature is supported in the user's browser:

Under the hood the supports-[...] variant generates @supports rules and takes anything you’d use with @supports (...) between the square brackets, like a property/value pair, and even expressions using and and or.

For terseness, if you only need to check if a property is supported (and not a specific value), you can just specify the property name:

Use the not-supports-[...] variant to style things based on whether a certain feature is not supported in the user's browser:

You can configure shortcuts for common @supports rules you're using in your project by creating a new variant in the supports-* namespace:

You can then use these custom supports-* variants in your project:

Use the starting variant to set the appearance of an element when it is first rendered in the DOM, or transitions from display: none to visible:

Use the aria-* variant to conditionally style things based on ARIA attributes.

For example, to apply the bg-sky-700 class when the aria-checked attribute is set to true, use the aria-checked:bg-sky-700 class:

By default we've included variants for the most common boolean ARIA attributes:

You can customize which aria-* variants are available by creating a new variant:

If you need to use a one-off aria variant that doesn’t make sense to include in your project, or for more complex ARIA attributes that take specific values, use square brackets to generate a property on the fly using any arbitrary value:

ARIA state variants can also target parent and sibling elements using the group-aria-* and peer-aria-* variants:

Use the data-* variant to conditionally apply styles based on data attributes.

To check if a data attribute exists (and not a specific value), you can just specify the attribute name:

If you need to check for a specific value you may use an arbitrary value:

Alternatively, you can configure shortcuts for common data attributes you're using in your project by creating a new variant in the data-* namespace:

You can then use these custom data-* variants in your project:

Use the rtl and ltr variants to conditionally add styles in right-to-left and left-to-right modes respectively when building multi-directional layouts:

Director of Operations

Remember, these variants are only useful if you are building a site that needs to support both left-to-right and right-to-left layouts. If you're building a site that only needs to support a single direction, you don't need these variants — just apply the styles that make sense for your content.

Use the open variant to conditionally add styles when a <details> or <dialog> element is in an open state:

Try toggling the disclosure to see the styles change

The mug is round. The jar is round. They should call it Roundtine.

This variant also targets the :popover-open pseudo-class for popovers:

The inert variant lets you style elements marked with the inert attribute:

Get notified when someones posts a comment on a post.

Get notified when someones mentions you.

This is useful for adding visual cues that make it clear that sections of content aren't interactive.

While it's generally preferable to put utility classes directly on child elements, you can use the * variant in situations where you need to style direct children that you don’t have control over:

It's important to note that overriding a style with a utility directly on the child itself won't work since children rules are generated after the regular ones and they have the same specificity:

Won't work, children can't override styles given to them by the parent.

Like *, the ** variant can be used to style children of an element. The main difference is that ** will apply styles to all descendants, not just the direct children. This is especially useful when you combine it with another variant for narrowing the thing you're selecting:

Just like arbitrary values let you use custom values with your utility classes, arbitrary variants let you write custom selector variants directly in your HTML.

Arbitrary variants are just format strings that represent the selector, wrapped in square brackets. For example, this arbitrary variant changes the cursor to grabbing when the element has the is-dragging class:

Arbitrary variants can be stacked with built-in variants or with each other, just like the rest of the variants in Tailwind:

If you need spaces in your selector, you can use an underscore. For example, this arbitrary variant selects all p elements within the element where you've added the class:

You can also use at-rules like @media or @supports in arbitrary variants:

With at-rule custom variants the & placeholder isn't necessary, just like when nesting with a preprocessor.

If you find yourself using the same arbitrary variant multiple times in your project, it might be worth creating a custom variant using the @custom-variant directive:

Now you can use the theme-midnight:<utility> variant in your HTML:

Learn more about adding custom variants in the adding custom variants documentation.

A quick reference table of every single variant included in Tailwind by default.

This is a comprehensive list of examples for all the pseudo-class variants included in Tailwind to complement the pseudo-classes documentation at the beginning of this guide.

Style an element when the user hovers over it with the mouse cursor using the hover variant:

Style an element when it has focus using the focus variant:

Style an element when it or one of its descendants has focus using the focus-within variant:

Style an element when it has been focused using the keyboard using the focus-visible variant:

Style an element when it is being pressed using the active variant:

Style a link when it has already been visited using the visited variant:

Style an element if its ID matches the current URL fragment using the target variant:

Style an element if it's the first child using the first variant:

Style an element if it's the last child using the last variant:

Style an element if it's the only child using the only variant:

Style an element if it's an oddly numbered child using the odd variant:

Style an element if it's an evenly numbered child using the even variant:

Style an element if it's the first child of its type using the first-of-type variant:

Style an element if it's the last child of its type using the last-of-type variant:

Style an element if it's the only child of its type using the only-of-type variant:

Style an element at a specific position using the nth variant:

Style an element at a specific position from the end using the nth-last variant:

Style an element at a specific position, of the same type using the nth-of-type variant:

Style an element at a specific position from the end, of the same type using the nth-last-of-type variant:

Style an element if it has no content using the empty variant:

Style an input when it's disabled using the disabled variant:

Style an input when it's enabled using the enabled variant, most helpful when you only want to apply another style when an element is not disabled:

Style a checkbox or radio button when it's checked using the checked variant:

Style a checkbox or radio button in an indeterminate state using the indeterminate variant:

Style an option, checkbox or radio button that was the default value when the page initially loaded using the default variant:

Style an input when it's optional using the optional variant:

Style an input when it's required using the required variant:

Style an input when it's valid using the valid variant:

Style an input when it's invalid using the invalid variant:

Style an input when it's valid and the user has interacted with it, using the user-valid variant:

Style an input when it's invalid and the user has interacted with it, using the user-invalid variant:

Style an input when its value is within a specified range limit using the in-range variant:

Style an input when its value is outside of a specified range limit using the out-of-range variant:

Style an input when the placeholder is shown using the placeholder-shown variant:

Style the content of a <details> element using the details-content variant:

Style an input when it has been autofilled by the browser using the autofill variant:

Style an input when it is read-only using the read-only variant:

**Examples:**

Example 1 (unknown):
```unknown
<button class="bg-sky-500 hover:bg-sky-700 ...">Save changes</button>
```

Example 2 (unknown):
```unknown
.btn-primary {  background-color: #0ea5e9;}.btn-primary:hover {  background-color: #0369a1;}
```

Example 3 (unknown):
```unknown
.bg-sky-500 {  background-color: #0ea5e9;}.hover\:bg-sky-700:hover {  background-color: #0369a1;}
```

Example 4 (unknown):
```unknown
<button class="dark:md:hover:bg-fuchsia-600 ...">Save changes</button>
```

---

## Dark mode

**URL:** https://tailwindcss.com/docs/dark-mode

**Contents:**
- Overview
- Toggling dark mode manually
  - Using a data attribute
  - With system theme support

Now that dark mode is a first-class feature of many operating systems, it's becoming more and more common to design a dark version of your website to go along with the default design.

To make this as easy as possible, Tailwind includes a dark variant that lets you style your site differently when dark mode is enabled:

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.

By default this uses the prefers-color-scheme CSS media feature, but you can also build sites that support toggling dark mode manually by overriding the dark variant.

If you want your dark theme to be driven by a CSS selector instead of the prefers-color-scheme media query, override the dark variant to use your custom selector:

Now instead of dark:* utilities being applied based on prefers-color-scheme, they will be applied whenever the dark class is present earlier in the HTML tree:

How you add the dark class to the html element is up to you, but a common approach is to use a bit of JavaScript that updates the class attribute and syncs that preference to somewhere like localStorage.

To use a data attribute instead of a class to activate dark mode, just override the dark variant with an attribute selector instead:

Now dark mode utilities will be applied whenever the data-theme attribute is set to dark somewhere up the tree:

To build three-way theme toggles that support light mode, dark mode, and your system theme, use a custom dark mode selector and the window.matchMedia() API to detect the system theme and update the html element when needed.

Here's a simple example of how you can support light mode, dark mode, as well as respecting the operating system preference:

Again you can manage this however you like, even storing the preference server-side in a database and rendering the class on the server — it's totally up to you.

**Examples:**

Example 1 (unknown):
```unknown
<div class="bg-white dark:bg-gray-800 rounded-lg px-6 py-8 ring shadow-xl ring-gray-900/5">  <div>    <span class="inline-flex items-center justify-center rounded-md bg-indigo-500 p-2 shadow-lg">      <svg class="h-6 w-6 stroke-white" ...>        <!-- ... -->      </svg>    </span>  </div>  <h3 class="text-gray-900 dark:text-white mt-5 text-base font-medium tracking-tight ">Writes upside-down</h3>  <p class="text-gray-500 dark:text-gray-400 mt-2 text-sm ">    The Zero Gravity Pen can be used to write in any orientation, including upside-down. It even works in outer space.  </p></div>
```

Example 2 (unknown):
```unknown
@import "tailwindcss";@custom-variant dark (&:where(.dark, .dark *));
```

Example 3 (unknown):
```unknown
<html class="dark">  <body>    <div class="bg-white dark:bg-black">      <!-- ... -->    </div>  </body></html>
```

Example 4 (unknown):
```unknown
@import "tailwindcss";@custom-variant dark (&:where([data-theme=dark], [data-theme=dark] *));
```

---

## Responsive design

**URL:** https://tailwindcss.com/docs/responsive-design

**Contents:**
- Overview
- Working mobile-first
  - Targeting mobile screens
  - Targeting a breakpoint range
  - Targeting a single breakpoint
- Using custom breakpoints
  - Customizing your theme
  - Removing default breakpoints
  - Using arbitrary values
- Container queries

Every utility class in Tailwind can be applied conditionally at different breakpoints, which makes it a piece of cake to build complex responsive interfaces without ever leaving your HTML.

First, make sure you've added the viewport meta tag to the <head> of your document:

Then to add a utility but only have it take effect at a certain breakpoint, all you need to do is prefix the utility with the breakpoint name, followed by the : character:

There are five breakpoints by default, inspired by common device resolutions:

This works for every utility class in the framework, which means you can change literally anything at a given breakpoint — even things like letter spacing or cursor styles.

Here's a simple example of a marketing page component that uses a stacked layout on small screens, and a side-by-side layout on larger screens:

Here's how the example above works:

We've only used one breakpoint in this example, but you could easily customize this component at other sizes using the sm, lg, xl, or 2xl responsive prefixes as well.

Tailwind uses a mobile-first breakpoint system, similar to what you might be used to in other frameworks like Bootstrap.

What this means is that unprefixed utilities (like uppercase) take effect on all screen sizes, while prefixed utilities (like md:uppercase) only take effect at the specified breakpoint and above.

Where this approach surprises people most often is that to style something for mobile, you need to use the unprefixed version of a utility, not the sm: prefixed version. Don't think of sm: as meaning "on small screens", think of it as "at the small breakpoint".

Don't use sm: to target mobile devices

Use unprefixed utilities to target mobile, and override them at larger breakpoints

For this reason, it's often a good idea to implement the mobile layout for a design first, then layer on any changes that make sense for sm screens, followed by md screens, etc.

By default, styles applied by rules like md:flex will apply at that breakpoint and stay applied at larger breakpoints.

If you'd like to apply a utility only when a specific breakpoint range is active, stack a responsive variant like md with a max-* variant to limit that style to a specific range:

Tailwind generates a corresponding max-* variant for each breakpoint, so out of the box the following variants are available:

To target a single breakpoint, target the range for that breakpoint by stacking a responsive variant like md with the max-* variant for the next breakpoint:

Read about targeting breakpoint ranges to learn more.

Use the --breakpoint-* theme variables to customize your breakpoints:

This updates the 2xl breakpoint to use 100rem instead of the default 96rem, and creates new xs and 3xl breakpoints that can be used in your markup:

Note that it's important to always use the same unit for defining your breakpoints or the generated utilities may be sorted in an unexpected order, causing breakpoint classes to override each other in unexpected ways.

Tailwind uses rem for the default breakpoints, so if you are adding additional breakpoints to the defaults, make sure you use rem as well.

Learn more about customizing your theme in the theme documentation.

To remove a default breakpoint, reset its value to the initial keyword:

You can also reset all of the default breakpoints using --breakpoint-*: initial, then define all of your breakpoints from scratch:

Learn more removing default theme values in the theme documentation.

If you need to use a one-off breakpoint that doesn’t make sense to include in your theme, use the min or max variants to generate a custom breakpoint on the fly using any arbitrary value.

Learn more about arbitrary value support in the arbitrary values documentation.

Container queries are a modern CSS feature that let you style something based on the size of a parent element instead of the size of the entire viewport. They let you build components that are a lot more portable and reusable because they can change based on the actual space available for that component.

Use the @container class to mark an element as a container, then use variants like @sm and @md to style child elements based on the size of the container:

Just like breakpoint variants, container queries are mobile-first in Tailwind CSS and apply at the target container size and up.

Use variants like @max-sm and @max-md to apply a style below a specific container size:

Stack a regular container query variant with a max-width container query variant to target a specific range:

For complex designs that use multiple nested containers, you can name containers using @container/{name} and target specific containers with variants like @sm/{name} and @md/{name}:

This makes it possible to style something based on the size of a distant container, rather than just the nearest container.

Use the --container-* theme variables to customize your container sizes:

This adds a new 8xl container query variant that can be used in your markup:

Learn more about customizing your theme in the theme documentation.

Use variants like @min-[475px] and @max-[960px] for one-off container query sizes you don't want to add to your theme:

Use container query length units like cqw as arbitrary values in other utility classes to reference the container size:

By default, Tailwind includes container sizes ranging from 16rem (256px) to 80rem (1280px):

**Examples:**

Example 1 (unknown):
```unknown
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
```

Example 2 (unknown):
```unknown
<!-- Width of 16 by default, 32 on medium screens, and 48 on large screens --><img class="w-16 md:w-32 lg:w-48" src="..." />
```

Example 3 (unknown):
```unknown
<div class="mx-auto max-w-md overflow-hidden rounded-xl bg-white shadow-md md:max-w-2xl">  <div class="md:flex">    <div class="md:shrink-0">      <img        class="h-48 w-full object-cover md:h-full md:w-48"        src="/img/building.jpg"        alt="Modern building architecture"      />    </div>    <div class="p-8">      <div class="text-sm font-semibold tracking-wide text-indigo-500 uppercase">Company retreats</div>      <a href="#" class="mt-1 block text-lg leading-tight font-medium text-black hover:underline">        Incredible accommodation for your team      </a>      <p class="mt-2 text-gray-500">        Looking to take your team away on a retreat to enjoy awesome food and take in some sunshine? We have a list of        places to do just that.      </p>    </div>  </div></div>
```

Example 4 (unknown):
```unknown
<!-- This will only center text on screens 640px and wider, not on small screens --><div class="sm:text-center"></div>
```

---
