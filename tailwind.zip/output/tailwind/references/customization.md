# Tailwind - Customization

**Pages:** 1

---

## Theme variables

**URL:** https://tailwindcss.com/docs/theme

**Contents:**
- Overview
  - What are theme variables?
    - Why @theme instead of :root?
  - Relationship to utility classes
    - Relationship to variants
  - Theme variable namespaces
  - Default theme variables
- Customizing your theme
  - Extending the default theme
  - Overriding the default theme

Tailwind is a framework for building custom designs, and different designs need different typography, colors, shadows, breakpoints, and more.

These low-level design decisions are often called design tokens, and in Tailwind projects you store those values in theme variables.

Theme variables are special CSS variables defined using the @theme directive that influence which utility classes exist in your project.

For example, you can add a new color to your project by defining a theme variable like --color-mint-500:

Now you can use utility classes like bg-mint-500, text-mint-500, or fill-mint-500 in your HTML:

Tailwind also generates regular CSS variables for your theme variables so you can reference your design tokens in arbitrary values or inline styles:

Learn more about how theme variables map to different utility classes in the theme variable namespaces documentation.

Theme variables aren't just CSS variables — they also instruct Tailwind to create new utility classes that you can use in your HTML.

Since they do more than regular CSS variables, Tailwind uses special syntax so that defining theme variables is always explicit. Theme variables are also required to be defined top-level and not nested under other selectors or media queries, and using a special syntax makes it possible to enforce that.

Defining regular CSS variables with :root can still be useful in Tailwind projects when you want to define a variable that isn't meant to be connected to a utility class. Use @theme when you want a design token to map directly to a utility class, and use :root for defining regular CSS variables that shouldn't have corresponding utility classes.

Some utility classes in Tailwind like flex and object-cover are static, and are always the same from project to project. But many others are driven by theme variables, and only exist because of the theme variables you've defined.

For example, theme variables defined in the --font-* namespace determine all of the font-family utilities that exist in a project:

The font-sans, font-serif, and font-mono utilities only exist by default because Tailwind's default theme defines the --font-sans, --font-serif, and --font-mono theme variables.

If another theme variable like --font-poppins were defined, a font-poppins utility class would become available to go with it:

You can name your theme variables whatever you want within these namespaces, and a corresponding utility with the same name will become available to use in your HTML.

Some theme variables are used to define variants rather than utilities. For example theme variables in the --breakpoint-* namespace determine which responsive breakpoint variants exist in your project:

Now you can use the 3xl:* variant to only trigger a utility when the viewport is 120rem or wider:

Learn more about how theme variables map to different utility classes and variants in the theme variable namespaces documentation.

Theme variables are defined in namespaces and each namespace corresponds to one or more utility class or variant APIs.

Defining new theme variables in these namespaces will make new corresponding utilities and variants available in your project:

For a list of all of the default theme variables, see the default theme variable reference.

When you import tailwindcss at the top of your CSS file, it includes a set of default theme variables to get you started.

Here's what you're actually importing when you import tailwindcss:

That theme.css file includes the default color palette, type scale, shadows, fonts, and more:

This is why utilities like bg-red-200, font-serif, and shadow-sm exist out of the box — they're driven by the default theme, not hardcoded into the framework like flex-col or pointer-events-none.

For a list of all of the default theme variables, see the default theme variable reference.

The default theme variables are very general purpose and suitable for building dramatically different designs, but they are still just a starting point. It's very common to customize things like the color palette, fonts, and shadows to build exactly the design you have in mind.

Use @theme to define new theme variables and extend the default theme:

This makes a new font-script utility class available that you can use in your HTML, just like the default font-sans or font-mono utilities:

Learn more about how theme variables map to different utility classes and variants in the theme variable namespaces documentation.

Override a default theme variable value by redefining it within @theme:

Now the sm:* variant will trigger at 30rem instead of the default 40rem viewport size:

To completely override an entire namespace in the default theme, set the entire namespace to initial using the special asterisk syntax:

When you do this, all of the default utilities that use that namespace (like bg-red-500) will be removed, and only your custom values (like bg-midnight) will be available.

Learn more about how theme variables map to different utility classes and variants in the theme variable namespaces documentation.

To completely disable the default theme and use only custom values, set the global theme variable namespace to initial:

Now none of the default utility classes that are driven by theme variables will be available, and you'll only be able to use utility classes matching your custom theme variables like font-body and text-dusk.

Define the @keyframes rules for your --animate-* theme variables within @theme to include them in your generated CSS:

If you want your custom @keyframes rules to always be included even when not adding an --animate-* theme variable, define them outside of @theme instead.

When defining theme variables that reference other variables, use the inline option:

Using the inline option, the utility class will use the theme variable value instead of referencing the actual theme variable:

Without using inline, your utility classes might resolve to unexpected values because of how variables are resolved in CSS.

For example, this text will fall back to sans-serif instead of using Inter like you might expect:

This happens because var(--font-sans) is resolved where --font-sans is defined (on #parent), and --font-inter has no value there since it's not defined until deeper in the tree (on #child).

By default only used CSS variables will be generated in the final CSS output. If you want to always generate all CSS variables, you can use the static theme option:

Since theme variables are defined in CSS, sharing them across projects is just a matter of throwing them into their own CSS file that you can import in each project:

Then you can use @import to include your theme variables in other projects:

You can put shared theme variables like this in their own package in monorepo setups or even publish them to NPM and import them just like any other third-party CSS files.

All of your theme variables are turned into regular CSS variables when you compile your CSS:

This makes it easy to reference all of your design tokens in any of your custom CSS or inline styles.

Use your theme variables to get access to your design tokens when you're writing custom CSS that needs to use the same values:

This is often useful when styling HTML you don't control, like Markdown content coming from a database or API and rendered to HTML.

Using theme variables in arbitrary values can be useful, especially in combination with the calc() function.

In the above example, we're subtracting 1px from the --radius-xl value on a nested inset element to make sure it has a concentric border radius.

Most of the time when you need to reference your theme variables in JS you can just use the CSS variables directly, just like any other CSS value.

For example, the popular Motion library for React lets you animate to and from CSS variable values:

If you need access to a resolved CSS variable value in JS, you can use getComputedStyle to get the value of a theme variable on the document root:

For reference, here's a complete list of the theme variables included by default when you import Tailwind CSS into your project:

**Examples:**

Example 1 (unknown):
```unknown
@import "tailwindcss";@theme {  --color-mint-500: oklch(0.72 0.11 178);}
```

Example 2 (unknown):
```unknown
<div class="bg-mint-500">  <!-- ... --></div>
```

Example 3 (unknown):
```unknown
<div style="background-color: var(--color-mint-500)">  <!-- ... --></div>
```

Example 4 (unknown):
```unknown
@theme {  --font-sans: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";  --font-serif: ui-serif, Georgia, Cambria, "Times New Roman", Times, serif;  --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;  /* ... */}
```

---
