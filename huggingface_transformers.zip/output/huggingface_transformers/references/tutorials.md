# Huggingface_Transformers - Tutorials

**Pages:** 1

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/notebooks

**Contents:**
- Transformers
- 🤗 Transformers Notebooks
- Hugging Face’s notebooks 🤗
  - Documentation notebooks
  - PyTorch Examples
    - Natural Language Processing
    - Computer Vision
    - Audio
    - Biological Sequences
    - Other modalities

Transformers documentation

🤗 Transformers Notebooks

and get access to the augmented documentation experience

You can find here a list of the official notebooks provided by Hugging Face.

Also, we would like to list here interesting content created by the community. If you wrote some notebook(s) leveraging 🤗 Transformers and would like to be listed here, please open a Pull Request so it can be included under the Community notebooks.

You can open any page of the documentation as a notebook in Colab (there is a button directly on said pages) but they are also listed here if you need them:

🤗 Optimum is an extension of 🤗 Transformers, providing a set of performance optimization tools enabling maximum efficiency to train and run models on targeted hardwares.

More notebooks developed by the community are available here.

---
