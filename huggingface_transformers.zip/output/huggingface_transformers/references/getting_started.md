# Huggingface_Transformers - Getting Started

**Pages:** 4

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/quicktour

**Contents:**
- Transformers
- Quickstart
- Set up
- Pretrained models
- Pipeline
- Trainer
- Next steps

Transformers documentation

and get access to the augmented documentation experience

Transformers is designed to be fast and easy to use so that everyone can start learning or building with transformer models.

The number of user-facing abstractions is limited to only three classes for instantiating a model, and two APIs for inference or training. This quickstart introduces you to Transformers’ key features and shows you how to:

To start, we recommend creating a Hugging Face account. An account lets you host and access version controlled models, datasets, and Spaces on the Hugging Face Hub, a collaborative platform for discovery and building.

Create a User Access Token and log in to your account.

Paste your User Access Token into notebook_login when prompted to log in.

Then install an up-to-date version of Transformers and some additional libraries from the Hugging Face ecosystem for accessing datasets and vision models, evaluating training, and optimizing training for large models.

Each pretrained model inherits from three base classes.

We recommend using the AutoClass API to load models and preprocessors because it automatically infers the appropriate architecture for each task and machine learning framework based on the name or path to the pretrained weights and configuration file.

Use from_pretrained() to load the weights and configuration file from the Hub into the model and preprocessor class.

When you load a model, configure the following parameters to ensure the model is optimally loaded.

Tokenize the text and return PyTorch tensors with the tokenizer. Move the model to an accelerator if it’s available to accelerate inference.

The model is now ready for inference or training.

For inference, pass the tokenized inputs to generate() to generate text. Decode the token ids back into text with batch_decode().

Skip ahead to the Trainer section to learn how to fine-tune a model.

The Pipeline class is the most convenient way to inference with a pretrained model. It supports many tasks such as text generation, image segmentation, automatic speech recognition, document question answering, and more.

Refer to the Pipeline API reference for a complete list of available tasks.

Create a Pipeline object and select a task. By default, Pipeline downloads and caches a default pretrained model for a given task. Pass the model name to the model parameter to choose a specific model.

Use infer_device() to automatically detect an available accelerator for inference.

Prompt Pipeline with some initial text to generate more text.

Trainer is a complete training and evaluation loop for PyTorch models. It abstracts away a lot of the boilerplate usually involved in manually writing a training loop, so you can start training faster and focus on training design choices. You only need a model, dataset, a preprocessor, and a data collator to build batches of data from the dataset.

Use the TrainingArguments class to customize the training process. It provides many options for training, evaluation, and more. Experiment with training hyperparameters and features like batch size, learning rate, mixed precision, torch.compile, and more to meet your training needs. You could also use the default training parameters to quickly produce a baseline.

Load a model, tokenizer, and dataset for training.

Create a function to tokenize the text and convert it into PyTorch tensors. Apply this function to the whole dataset with the map method.

Load a data collator to create batches of data and pass the tokenizer to it.

Next, set up TrainingArguments with the training features and hyperparameters.

Finally, pass all these separate components to Trainer and call train() to start.

Share your model and tokenizer to the Hub with push_to_hub().

Congratulations, you just trained your first model with Transformers!

Now that you have a better understanding of Transformers and what it offers, it’s time to keep exploring and learning what interests you the most.

**Examples:**

Example 1 (unknown):
```unknown
device_map="auto"
```

Example 2 (unknown):
```unknown
dtype="auto"
```

Example 3 (unknown):
```unknown
torch.float32
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/installation

**Contents:**
- Transformers
- Installation
- Virtual environment
- Python
  - Source install
  - Editable install
- conda
- Set up
  - Cache directory
  - Offline mode

Transformers documentation

and get access to the augmented documentation experience

Transformers works with PyTorch. It has been tested on Python 3.9+ and PyTorch 2.2+.

uv is an extremely fast Rust-based Python package and project manager and requires a virtual environment by default to manage different projects and avoids compatibility issues between dependencies.

It can be used as a drop-in replacement for pip, but if you prefer to use pip, remove uv from the commands below.

Refer to the uv installation docs to install uv.

Create a virtual environment to install Transformers in.

Install Transformers with the following command.

uv is a fast Rust-based Python package and project manager.

For GPU acceleration, install the appropriate CUDA drivers for PyTorch.

Run the command below to check if your system detects an NVIDIA GPU.

To install a CPU-only version of Transformers, run the following command.

Test whether the install was successful with the following command. It should return a label and score for the provided text.

Installing from source installs the latest version rather than the stable version of the library. It ensures you have the most up-to-date changes in Transformers and it’s useful for experimenting with the latest features or fixing a bug that hasn’t been officially released in the stable version yet.

The downside is that the latest version may not always be stable. If you encounter any problems, please open a GitHub Issue so we can fix it as soon as possible.

Install from source with the following command.

Check if the install was successful with the command below. It should return a label and score for the provided text.

An editable install is useful if you’re developing locally with Transformers. It links your local copy of Transformers to the Transformers repository instead of copying the files. The files are added to Python’s import path.

You must keep the local Transformers folder to keep using it.

Update your local version of Transformers with the latest changes in the main repository with the following command.

conda is a language-agnostic package manager. Install Transformers from the conda-forge channel in your newly created virtual environment.

After installation, you can configure the Transformers cache location or set up the library for offline usage.

When you load a pretrained model with from_pretrained(), the model is downloaded from the Hub and locally cached.

Every time you load a model, it checks whether the cached model is up-to-date. If it’s the same, then the local model is loaded. If it’s not the same, the newer model is downloaded and cached.

The default directory given by the shell environment variable TRANSFORMERS_CACHE is ~/.cache/huggingface/hub. On Windows, the default directory is C:\Users\username\.cache\huggingface\hub.

Cache a model in a different directory by changing the path in the following shell environment variables (listed by priority).

Older versions of Transformers uses the shell environment variables PYTORCH_TRANSFORMERS_CACHE or PYTORCH_PRETRAINED_BERT_CACHE. You should keep these unless you specify the newer shell environment variable TRANSFORMERS_CACHE.

To use Transformers in an offline or firewalled environment requires the downloaded and cached files ahead of time. Download a model repository from the Hub with the snapshot_download method.

Refer to the Download files from the Hub guide for more options for downloading files from the Hub. You can download files from specific revisions, download from the CLI, and even filter which files to download from a repository.

Set the environment variable HF_HUB_OFFLINE=1 to prevent HTTP calls to the Hub when loading a model.

Another option for only loading cached files is to set local_files_only=True in from_pretrained().

**Examples:**

Example 1 (unknown):
```unknown
TRANSFORMERS_CACHE
```

Example 2 (unknown):
```unknown
~/.cache/huggingface/hub
```

Example 3 (unknown):
```unknown
C:\Users\username\.cache\huggingface\hub
```

Example 4 (unknown):
```unknown
TRANSFORMERS_CACHE
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/quicktour

**Contents:**
- Transformers
- Quickstart
- Set up
- Pretrained models
- Pipeline
- Trainer
- Next steps

Transformers documentation

and get access to the augmented documentation experience

Transformers is designed to be fast and easy to use so that everyone can start learning or building with transformer models.

The number of user-facing abstractions is limited to only three classes for instantiating a model, and two APIs for inference or training. This quickstart introduces you to Transformers’ key features and shows you how to:

To start, we recommend creating a Hugging Face account. An account lets you host and access version controlled models, datasets, and Spaces on the Hugging Face Hub, a collaborative platform for discovery and building.

Create a User Access Token and log in to your account.

Paste your User Access Token into notebook_login when prompted to log in.

Then install an up-to-date version of Transformers and some additional libraries from the Hugging Face ecosystem for accessing datasets and vision models, evaluating training, and optimizing training for large models.

Each pretrained model inherits from three base classes.

We recommend using the AutoClass API to load models and preprocessors because it automatically infers the appropriate architecture for each task and machine learning framework based on the name or path to the pretrained weights and configuration file.

Use from_pretrained() to load the weights and configuration file from the Hub into the model and preprocessor class.

When you load a model, configure the following parameters to ensure the model is optimally loaded.

Tokenize the text and return PyTorch tensors with the tokenizer. Move the model to an accelerator if it’s available to accelerate inference.

The model is now ready for inference or training.

For inference, pass the tokenized inputs to generate() to generate text. Decode the token ids back into text with batch_decode().

Skip ahead to the Trainer section to learn how to fine-tune a model.

The Pipeline class is the most convenient way to inference with a pretrained model. It supports many tasks such as text generation, image segmentation, automatic speech recognition, document question answering, and more.

Refer to the Pipeline API reference for a complete list of available tasks.

Create a Pipeline object and select a task. By default, Pipeline downloads and caches a default pretrained model for a given task. Pass the model name to the model parameter to choose a specific model.

Use infer_device() to automatically detect an available accelerator for inference.

Prompt Pipeline with some initial text to generate more text.

Trainer is a complete training and evaluation loop for PyTorch models. It abstracts away a lot of the boilerplate usually involved in manually writing a training loop, so you can start training faster and focus on training design choices. You only need a model, dataset, a preprocessor, and a data collator to build batches of data from the dataset.

Use the TrainingArguments class to customize the training process. It provides many options for training, evaluation, and more. Experiment with training hyperparameters and features like batch size, learning rate, mixed precision, torch.compile, and more to meet your training needs. You could also use the default training parameters to quickly produce a baseline.

Load a model, tokenizer, and dataset for training.

Create a function to tokenize the text and convert it into PyTorch tensors. Apply this function to the whole dataset with the map method.

Load a data collator to create batches of data and pass the tokenizer to it.

Next, set up TrainingArguments with the training features and hyperparameters.

Finally, pass all these separate components to Trainer and call train() to start.

Share your model and tokenizer to the Hub with push_to_hub().

Congratulations, you just trained your first model with Transformers!

Now that you have a better understanding of Transformers and what it offers, it’s time to keep exploring and learning what interests you the most.

**Examples:**

Example 1 (unknown):
```unknown
device_map="auto"
```

Example 2 (unknown):
```unknown
dtype="auto"
```

Example 3 (unknown):
```unknown
torch.float32
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/installation

**Contents:**
- Transformers
- Installation
- Virtual environment
- Python
  - Source install
  - Editable install
- conda
- Set up
  - Cache directory
  - Offline mode

Transformers documentation

and get access to the augmented documentation experience

Transformers works with PyTorch. It has been tested on Python 3.9+ and PyTorch 2.2+.

uv is an extremely fast Rust-based Python package and project manager and requires a virtual environment by default to manage different projects and avoids compatibility issues between dependencies.

It can be used as a drop-in replacement for pip, but if you prefer to use pip, remove uv from the commands below.

Refer to the uv installation docs to install uv.

Create a virtual environment to install Transformers in.

Install Transformers with the following command.

uv is a fast Rust-based Python package and project manager.

For GPU acceleration, install the appropriate CUDA drivers for PyTorch.

Run the command below to check if your system detects an NVIDIA GPU.

To install a CPU-only version of Transformers, run the following command.

Test whether the install was successful with the following command. It should return a label and score for the provided text.

Installing from source installs the latest version rather than the stable version of the library. It ensures you have the most up-to-date changes in Transformers and it’s useful for experimenting with the latest features or fixing a bug that hasn’t been officially released in the stable version yet.

The downside is that the latest version may not always be stable. If you encounter any problems, please open a GitHub Issue so we can fix it as soon as possible.

Install from source with the following command.

Check if the install was successful with the command below. It should return a label and score for the provided text.

An editable install is useful if you’re developing locally with Transformers. It links your local copy of Transformers to the Transformers repository instead of copying the files. The files are added to Python’s import path.

You must keep the local Transformers folder to keep using it.

Update your local version of Transformers with the latest changes in the main repository with the following command.

conda is a language-agnostic package manager. Install Transformers from the conda-forge channel in your newly created virtual environment.

After installation, you can configure the Transformers cache location or set up the library for offline usage.

When you load a pretrained model with from_pretrained(), the model is downloaded from the Hub and locally cached.

Every time you load a model, it checks whether the cached model is up-to-date. If it’s the same, then the local model is loaded. If it’s not the same, the newer model is downloaded and cached.

The default directory given by the shell environment variable TRANSFORMERS_CACHE is ~/.cache/huggingface/hub. On Windows, the default directory is C:\Users\username\.cache\huggingface\hub.

Cache a model in a different directory by changing the path in the following shell environment variables (listed by priority).

Older versions of Transformers uses the shell environment variables PYTORCH_TRANSFORMERS_CACHE or PYTORCH_PRETRAINED_BERT_CACHE. You should keep these unless you specify the newer shell environment variable TRANSFORMERS_CACHE.

To use Transformers in an offline or firewalled environment requires the downloaded and cached files ahead of time. Download a model repository from the Hub with the snapshot_download method.

Refer to the Download files from the Hub guide for more options for downloading files from the Hub. You can download files from specific revisions, download from the CLI, and even filter which files to download from a repository.

Set the environment variable HF_HUB_OFFLINE=1 to prevent HTTP calls to the Hub when loading a model.

Another option for only loading cached files is to set local_files_only=True in from_pretrained().

**Examples:**

Example 1 (unknown):
```unknown
TRANSFORMERS_CACHE
```

Example 2 (unknown):
```unknown
~/.cache/huggingface/hub
```

Example 3 (unknown):
```unknown
C:\Users\username\.cache\huggingface\hub
```

Example 4 (unknown):
```unknown
TRANSFORMERS_CACHE
```

---
