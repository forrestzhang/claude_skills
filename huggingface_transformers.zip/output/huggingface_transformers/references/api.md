# Huggingface_Transformers - Api

**Pages:** 54

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/processors

**Contents:**
- Transformers
- Processors
- Multi-modal processors
  - class transformers.ProcessorMixin
    - apply_chat_template
    - batch_decode
    - check_argument_for_proper_class
    - decode
    - from_args_and_dict
    - from_pretrained

Transformers documentation

and get access to the augmented documentation experience

Processors can mean two different things in the Transformers library:

Any multi-modal model will require an object to encode or decode the data that groups several modalities (among text, vision and audio). This is handled by objects called processors, which group together two or more processing objects such as tokenizers (for the text modality), image processors (for vision) and feature extractors (for audio).

Those processors inherit from the following base class that implements the saving and loading functionality:

This is a mixin used to provide saving/loading functionality for all processor classes.

( conversation: typing.Union[list[dict[str, str]], list[list[dict[str, str]]]] chat_template: typing.Optional[str] = None **kwargs: typing_extensions.Unpack[transformers.processing_utils.AllKwargsForChatTemplate] )

Similar to the apply_chat_template method on tokenizers, this method applies a Jinja template to input conversations to turn them into a single tokenizable string.

The input is expected to be in the following format, where each message content is a list consisting of text and optionally image or video inputs. One can also provide an image, video, URL or local path which will be used to form pixel_values when return_dict=True. If not provided, one will get only the formatted text, optionally tokenized text.

conversation = [ { “role”: “user”, “content”: [ {“type”: “image”, “url”: “https://www.ilankelman.org/stopsigns/australia.jpg”}, {“type”: “text”, “text”: “Please describe this image in detail.”}, ], }, ]

This method forwards all its arguments to PreTrainedTokenizer’s batch_decode(). Please refer to the docstring of this method for more information.

( argument_name argument )

Checks the passed argument’s class against the expected transformers class. In case of an unexpected mismatch between expected and actual class, an error is raise. Otherwise, the proper retrieved class is returned.

This method forwards all its arguments to PreTrainedTokenizer’s decode(). Please refer to the docstring of this method for more information.

( args processor_dict: dict **kwargs ) → ~processing_utils.ProcessingMixin

~processing_utils.ProcessingMixin

The processor object instantiated from those parameters.

The processor object instantiated from those parameters.

Instantiates a type of ~processing_utils.ProcessingMixin from a Python dictionary of parameters.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a processor associated with a pretrained model.

This class method is simply calling the feature extractor from_pretrained(), image processor ImageProcessingMixin and the tokenizer ~tokenization_utils_base.PreTrainedTokenizer.from_pretrained methods. Please refer to the docstrings of the methods above for more information.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] **kwargs ) → tuple[Dict, Dict]

The dictionary(ies) that will be used to instantiate the processor object.

The dictionary(ies) that will be used to instantiate the processor object.

From a pretrained_model_name_or_path, resolve to a dictionary of parameters, to be used for instantiating a processor of type ~processing_utils.ProcessingMixin using from_args_and_dict.

( generated_outputs skip_special_tokens = True **kwargs ) → list[str]

Post-process the output of a vlm to decode the text.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the processor files to the 🤗 Model Hub.

( auto_class = 'AutoProcessor' )

Register this class with a given auto class. This should only be used for custom feature extractors as the ones in the library are already mapped with AutoProcessor.

( save_directory push_to_hub: bool = False legacy_serialization: bool = True **kwargs )

Saves the attributes of this processor (feature extractor, tokenizer…) in the specified directory so that it can be reloaded using the from_pretrained() method.

This class method is simply calling save_pretrained() and save_pretrained(). Please refer to the docstrings of the methods above for more information.

( legacy_serialization = True ) → dict[str, Any]

Dictionary of all the attributes that make up this processor instance.

Dictionary of all the attributes that make up this processor instance.

Serializes this instance to a Python dictionary.

( json_file_path: typing.Union[str, os.PathLike] legacy_serialization = True )

Save this instance to a JSON file.

( legacy_serialization = True ) → str

String containing all the attributes that make up this feature_extractor instance in JSON format.

String containing all the attributes that make up this feature_extractor instance in JSON format.

Serializes this instance to a JSON string.

All processors follow the same architecture which is that of the DataProcessor. The processor returns a list of InputExample. These InputExample can be converted to InputFeatures in order to be fed to the model.

Base class for data converters for sequence classification data sets.

Gets a collection of InputExample for the dev set.

Gets an example from a dict with tensorflow tensors.

Gets the list of labels for this data set.

Gets a collection of InputExample for the test set.

Gets a collection of InputExample for the train set.

Some tensorflow_datasets datasets are not formatted the same way the GLUE datasets are. This method converts examples to the correct format.

( guid: str text_a: str text_b: typing.Optional[str] = None label: typing.Optional[str] = None )

A single training/test example for simple sequence classification.

Serializes this instance to a JSON string.

( input_ids: list attention_mask: typing.Optional[list[int]] = None token_type_ids: typing.Optional[list[int]] = None label: typing.Union[int, float, NoneType] = None )

A single set of features of data. Property names are the same names as the corresponding inputs to a model.

Serializes this instance to a JSON string.

General Language Understanding Evaluation (GLUE) is a benchmark that evaluates the performance of models across a diverse set of existing NLU tasks. It was released together with the paper GLUE: A multi-task benchmark and analysis platform for natural language understanding

This library hosts a total of 10 processors for the following tasks: MRPC, MNLI, MNLI (mismatched), CoLA, SST2, STSB, QQP, QNLI, RTE and WNLI.

Those processors are:

Additionally, the following method can be used to load values from a data file and convert them to a list of InputExample.

( examples: typing.Union[list[transformers.data.processors.utils.InputExample], ForwardRef('tf.data.Dataset')] tokenizer: PreTrainedTokenizer max_length: typing.Optional[int] = None task = None label_list = None output_mode = None )

Loads a data file into a list of InputFeatures

The Cross-Lingual NLI Corpus (XNLI) is a benchmark that evaluates the quality of cross-lingual text representations. XNLI is crowd-sourced dataset based on MultiNLI: pairs of text are labeled with textual entailment annotations for 15 different languages (including both high-resource language such as English and low-resource languages such as Swahili).

It was released together with the paper XNLI: Evaluating Cross-lingual Sentence Representations

This library hosts the processor to load the XNLI data:

Please note that since the gold labels are available on the test set, evaluation is performed on the test set.

An example using these processors is given in the run_xnli.py script.

The Stanford Question Answering Dataset (SQuAD) is a benchmark that evaluates the performance of models on question answering. Two versions are available, v1.1 and v2.0. The first version (v1.1) was released together with the paper SQuAD: 100,000+ Questions for Machine Comprehension of Text. The second version (v2.0) was released alongside the paper Know What You Don’t Know: Unanswerable Questions for SQuAD.

This library hosts a processor for each of the two versions:

Those processors are:

They both inherit from the abstract class ~data.processors.utils.SquadProcessor

Processor for the SQuAD data set. overridden by SquadV1Processor and SquadV2Processor, used by the version 1.1 and version 2.0 of SQuAD, respectively.

( data_dir filename = None )

Returns the evaluation example from the data directory.

( dataset evaluate = False )

Creates a list of SquadExample using a TFDS dataset.

( data_dir filename = None )

Returns the training examples from the data directory.

Additionally, the following method can be used to convert SQuAD examples into ~data.processors.utils.SquadFeatures that can be used as model inputs.

( examples tokenizer max_seq_length doc_stride max_query_length is_training padding_strategy = 'max_length' return_dataset = False threads = 1 tqdm_enabled = True )

Converts a list of examples into a list of features that can be directly given as input to a model. It is model-dependant and takes advantage of many of the tokenizer’s features to create the model’s inputs.

These processors as well as the aforementioned method can be used with files containing the data as well as with the tensorflow_datasets package. Examples are given below.

Here is an example using the processors as well as the conversion method using data files:

Using tensorflow_datasets is as easy as using a data file:

Another example using these processors is given in the run_squad.py script.

**Examples:**

Example 1 (unknown):
```unknown
Union[list[Dict, [str, str]], list[list[dict[str, str]]]]
```

Example 2 (unknown):
```unknown
Optional[str]
```

Example 3 (unknown):
```unknown
apply_chat_template
```

Example 4 (unknown):
```unknown
pixel_values
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/philosophy

**Contents:**
- Transformers
- Philosophy
- Main concepts

Transformers documentation

and get access to the augmented documentation experience

🤗 Transformers is an opinionated library built for:

The library was designed with two strong goals in mind:

Expose the models’ internals as consistently as possible:

Incorporate a subjective selection of promising tools for fine-tuning and investigating these models:

The library is built around three types of classes for each model:

All these classes can be instantiated from pretrained instances, saved locally, and shared on the Hub with three methods:

**Examples:**

Example 1 (unknown):
```unknown
from_pretrained()
```

Example 2 (unknown):
```unknown
from_pretrained()
```

Example 3 (unknown):
```unknown
save_pretrained()
```

Example 4 (unknown):
```unknown
from_pretrained()
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/callback

**Contents:**
- Transformers
- Callbacks
- Available Callbacks
  - class transformers.integrations.CometCallback
    - setup
  - class transformers.DefaultFlowCallback
  - class transformers.PrinterCallback
  - class transformers.ProgressCallback
  - class transformers.EarlyStoppingCallback
  - class transformers.integrations.TensorBoardCallback

Transformers documentation

and get access to the augmented documentation experience

Callbacks are objects that can customize the behavior of the training loop in the PyTorch Trainer that can inspect the training loop state (for progress reporting, logging on TensorBoard or other ML platforms…) and take decisions (like early stopping).

Callbacks are “read only” pieces of code, apart from the TrainerControl object they return, they cannot change anything in the training loop. For customizations that require changes in the training loop, you should subclass Trainer and override the methods you need (see trainer for examples).

By default, TrainingArguments.report_to is set to "all", so a Trainer will use the following callbacks.

If a package is installed but you don’t wish to use the accompanying integration, you can change TrainingArguments.report_to to a list of just those integrations you want to use (e.g. ["azure_ml", "wandb"]).

The main class that implements callbacks is TrainerCallback. It gets the TrainingArguments used to instantiate the Trainer, can access that Trainer’s internal state via TrainerState, and can take some actions on the training loop via TrainerControl.

Here is the list of the available TrainerCallback in the library:

A TrainerCallback that sends the logs to Comet ML.

Setup the optional Comet integration.

For a number of configurable items in the environment, see here.

A TrainerCallback that handles the default flow of the training loop for logs, evaluation and checkpoints.

A bare TrainerCallback that just prints the logs.

( max_str_len: int = 100 )

A TrainerCallback that displays the progress of training or evaluation. You can modify max_str_len to control how long strings are truncated when logging.

( early_stopping_patience: int = 1 early_stopping_threshold: typing.Optional[float] = 0.0 )

A TrainerCallback that handles early stopping.

This callback depends on TrainingArguments argument load_best_model_at_end functionality to set best_metric in TrainerState. Note that if the TrainingArguments argument save_steps differs from eval_steps, the early stopping will not occur until the next save step.

A TrainerCallback that sends the logs to TensorBoard.

A TrainerCallback that logs metrics to Trackio.

It records training metrics, model (and PEFT) configuration, and GPU memory usage. If nvidia-ml-py is installed, GPU power consumption is also tracked.

( args state model **kwargs )

Setup the optional Trackio integration.

To customize the setup you can also set the arguments project, trackio_space_id and hub_private_repo in TrainingArguments. Please refer to the docstring of for more details.

A TrainerCallback that logs metrics, media, model checkpoints to Weight and Biases.

( args state model **kwargs )

Setup the optional Weights & Biases (wandb) integration.

One can subclass and override this method to customize the setup if needed. Find more information here. You can also override the following environment variables:

WANDB_LOG_MODEL (str, optional, defaults to "false"): Whether to log model and checkpoints during training. Can be "end", "checkpoint" or "false". If set to "end", the model will be uploaded at the end of training. If set to "checkpoint", the checkpoint will be uploaded every args.save_steps . If set to "false", the model will not be uploaded. Use along with load_best_model_at_end() to upload best model.

Setting WANDB_LOG_MODEL as bool will be deprecated in version 5 of 🤗 Transformers.

WANDB_WATCH (str, optional defaults to "false"): Can be "gradients", "all", "parameters", or "false". Set to "all" to log gradients and parameters.

WANDB_PROJECT (str, optional, defaults to "huggingface"): Set this to a custom string to store results in a different project.

WANDB_DISABLED (bool, optional, defaults to False): Whether to disable wandb entirely. Set WANDB_DISABLED=true to disable.

A TrainerCallback that sends the logs to MLflow. Can be disabled by setting environment variable DISABLE_MLFLOW_INTEGRATION = TRUE.

Setup the optional MLflow integration.

( azureml_run = None )

A TrainerCallback that sends the logs to AzureML.

A TrainerCallback that tracks the CO2 emission of training.

( api_token: typing.Optional[str] = None project: typing.Optional[str] = None name: typing.Optional[str] = None base_namespace: str = 'finetuning' run = None log_parameters: bool = True log_checkpoints: typing.Optional[str] = None **neptune_run_kwargs )

TrainerCallback that sends the logs to Neptune.

For instructions and examples, see the Transformers integration guide in the Neptune documentation.

A TrainerCallback that sends the logs to ClearML.

A TrainerCallback that logs to DagsHub. Extends MLflowCallback

Setup the DagsHub’s Logging integration.

( save_log_history: bool = True sync_checkpoints: bool = True )

A TrainerCallback that sends the logs to Flyte. NOTE: This callback only works within a Flyte task.

( live: typing.Optional[typing.Any] = None log_model: typing.Union[typing.Literal['all'], bool, NoneType] = None **kwargs )

A TrainerCallback that sends the logs to DVCLive.

Use the environment variables below in setup to configure the integration. To customize this callback beyond those environment variables, see here.

Setup the optional DVCLive integration. To customize this callback beyond the environment variables below, see here.

A TrainerCallback that logs metrics, media, model checkpoints to SwanLab.

( args state model **kwargs )

Setup the optional SwanLab (swanlab) integration.

One can subclass and override this method to customize the setup if needed. Find more information here.

You can also override the following environment variables. Find more information about environment variables here

SWANLAB_API_KEY (str, optional, defaults to None): Cloud API Key. During login, this environment variable is checked first. If it doesn’t exist, the system checks if the user is already logged in. If not, the login process is initiated.

SWANLAB_PROJECT (str, optional, defaults to None): Set this to a custom string to store results in a different project. If not specified, the name of the current running directory is used.

SWANLAB_LOG_DIR (str, optional, defaults to swanlog): This environment variable specifies the storage path for log files when running in local mode. By default, logs are saved in a folder named swanlog under the working directory.

SWANLAB_MODE (Literal["local", "cloud", "disabled"], optional, defaults to cloud): SwanLab’s parsing mode, which involves callbacks registered by the operator. Currently, there are three modes: local, cloud, and disabled. Note: Case-sensitive. Find more information here

SWANLAB_LOG_MODEL (str, optional, defaults to None): SwanLab does not currently support the save mode functionality.This feature will be available in a future release

SWANLAB_WEB_HOST (str, optional, defaults to None): Web address for the SwanLab cloud environment for private version (its free)

SWANLAB_API_HOST (str, optional, defaults to None): API address for the SwanLab cloud environment for private version (its free)

Those are only accessible in the event on_evaluate.

Those are only accessible in the event on_log.

A class for objects that will inspect the state of the training loop at some events and take some decisions. At each of those events the following arguments are available:

The control object is the only one that can be changed by the callback, in which case the event that changes it should return the modified version.

The argument args, state and control are positionals for all events, all the others are grouped in kwargs. You can unpack the ones you need in the signature of the event using them. As an example, see the code of the simple PrinterCallback.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the beginning of an epoch.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of an epoch.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after an evaluation phase.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of the initialization of the Trainer.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after logging the last logs.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after the optimizer step but before gradients are zeroed out. Useful for monitoring gradients.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called before the optimizer step but after gradient clipping. Useful for monitoring gradients.

( args: TrainingArguments state: TrainerState control: TrainerControl metrics **kwargs )

Event called after a successful prediction.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after a prediction step.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after a checkpoint save.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the beginning of a training step. If using gradient accumulation, one training step might take several inputs.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of a training step. If using gradient accumulation, one training step might take several inputs.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of an substep during gradient accumulation.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the beginning of training.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of training.

Here is an example of how to register a custom callback with the PyTorch Trainer:

Another way to register a callback is to call trainer.add_callback() as follows:

( epoch: typing.Optional[float] = None global_step: int = 0 max_steps: int = 0 logging_steps: int = 500 eval_steps: int = 500 save_steps: int = 500 train_batch_size: typing.Optional[int] = None num_train_epochs: int = 0 num_input_tokens_seen: int = 0 total_flos: float = 0 log_history: list = None best_metric: typing.Optional[float] = None best_global_step: typing.Optional[int] = None best_model_checkpoint: typing.Optional[str] = None is_local_process_zero: bool = True is_world_process_zero: bool = True is_hyper_param_search: bool = False trial_name: typing.Optional[str] = None trial_params: typing.Optional[dict[str, typing.Union[str, float, int, bool]]] = None stateful_callbacks: typing.Optional[list['TrainerCallback']] = None )

A class containing the Trainer inner state that will be saved along the model and optimizer when checkpointing and passed to the TrainerCallback.

In all this class, one step is to be understood as one update step. When using gradient accumulation, one update step may require several forward and backward passes: if you use gradient_accumulation_steps=n, then one update step requires going through n batches.

Calculates and stores the absolute value for logging, eval, and save steps based on if it was a proportion or not.

( trainer max_steps num_train_epochs trial )

Stores the initial training references needed in self

Create an instance from the content of json_path.

Save the content of this instance in JSON format inside json_path.

( should_training_stop: bool = False should_epoch_stop: bool = False should_save: bool = False should_evaluate: bool = False should_log: bool = False )

If True, this variable will not be set back to False. The training will just stop.

If True, this variable will be set back to False at the beginning of the next epoch.

If True, this variable will be set back to False at the beginning of the next step.

If True, this variable will be set back to False at the beginning of the next step.

If True, this variable will be set back to False at the beginning of the next step.

A class that handles the Trainer control flow. This class is used by the TrainerCallback to activate some switches in the training loop.

**Examples:**

Example 1 (unknown):
```unknown
TrainingArguments.report_to
```

Example 2 (unknown):
```unknown
TrainingArguments.report_to
```

Example 3 (unknown):
```unknown
["azure_ml", "wandb"]
```

Example 4 (unknown):
```unknown
get_or_create
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/data_collator

**Contents:**
- Transformers
- Data Collator
- Default data collator
    - transformers.default_data_collator
- DefaultDataCollator
  - class transformers.DefaultDataCollator
- DataCollatorWithPadding
  - class transformers.DataCollatorWithPadding
- DataCollatorForTokenClassification
  - class transformers.DataCollatorForTokenClassification

Transformers documentation

and get access to the augmented documentation experience

Data collators are objects that will form a batch by using a list of dataset elements as input. These elements are of the same type as the elements of train_dataset or eval_dataset.

To be able to build batches, data collators may apply some processing (like padding). Some of them (like DataCollatorForLanguageModeling) also apply some random data augmentation (like random masking) on the formed batch.

Examples of use can be found in the example scripts or example notebooks.

( features: list return_tensors = 'pt' )

Very simple data collator that simply collates batches of dict-like objects and performs special handling for potential keys named:

Does not do any additional preprocessing: property names of the input object will be used as corresponding inputs to the model. See glue and ner for example of how it’s useful.

( return_tensors: str = 'pt' )

Very simple data collator that simply collates batches of dict-like objects and performs special handling for potential keys named:

Does not do any additional preprocessing: property names of the input object will be used as corresponding inputs to the model. See glue and ner for example of how it’s useful.

This is an object (like other data collators) rather than a pure function like default_data_collator. This can be helpful if you need to set a return_tensors value at initialization.

( tokenizer: PreTrainedTokenizerBase padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None return_tensors: str = 'pt' )

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.0 (Volta).

Data collator that will dynamically pad the inputs received.

( tokenizer: PreTrainedTokenizerBase padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None label_pad_token_id: int = -100 return_tensors: str = 'pt' )

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.0 (Volta).

Data collator that will dynamically pad the inputs received, as well as the labels.

( tokenizer: PreTrainedTokenizerBase model: typing.Optional[typing.Any] = None padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None label_pad_token_id: int = -100 return_tensors: str = 'pt' )

This is useful when using label_smoothing to avoid calculating loss twice.

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.0 (Volta).

Data collator that will dynamically pad the inputs received, as well as the labels.

( tokenizer: PreTrainedTokenizerBase mlm: bool = True whole_word_mask: bool = False mlm_probability: typing.Optional[float] = 0.15 mask_replace_prob: float = 0.8 random_replace_prob: float = 0.1 pad_to_multiple_of: typing.Optional[int] = None tf_experimental_compile: bool = False return_tensors: str = 'pt' seed: typing.Optional[int] = None )

Data collator used for language modeling. Inputs are dynamically padded to the maximum length of a batch if they are not all of the same length.

For best performance, this data collator should be used with a dataset having items that are dictionaries or BatchEncoding, with the "special_tokens_mask" key, as returned by a PreTrainedTokenizer or a PreTrainedTokenizerFast with the argument return_special_tokens_mask=True.

All masked tokens replaced by [MASK]:

No [MASK] replacement, only random tokens:

Balanced replacement:

Note: The sum of mask_replace_prob and random_replace_prob must not exceed 1. If their sum is less than 1, the remaining proportion will consist of masked tokens left unchanged.

( inputs: typing.Any special_tokens_mask: typing.Optional[typing.Any] = None offset_mapping: typing.Optional[typing.Any] = None )

Prepare masked tokens inputs/labels for masked language modeling.

( inputs: typing.Any special_tokens_mask: typing.Optional[typing.Any] = None offset_mapping: typing.Optional[typing.Any] = None )

Prepare masked tokens inputs/labels for masked language modeling.

Data collator used for language modeling that masks entire words.

This collator relies on details of the implementation of subword tokenization by BertTokenizer, specifically that subword tokens are prefixed with ##. For tokenizers that do not adhere to this scheme, this collator will produce an output that is roughly equivalent to .DataCollatorForLanguageModeling.

( inputs: typing.Any mask_labels: typing.Any )

Prepare masked tokens inputs/labels for masked language modeling: 80% MASK, 10% random, 10% original. Set ‘mask_labels’ means we use whole word mask (wwm), we directly mask idxs according to it’s ref.

( inputs: typing.Any mask_labels: typing.Any )

Prepare masked tokens inputs/labels for masked language modeling: 80% MASK, 10% random, 10% original. Set ‘mask_labels’ means we use whole word mask (wwm), we directly mask idxs according to it’s ref.

( tokenizer: PreTrainedTokenizerBase plm_probability: float = 0.16666666666666666 max_span_length: int = 5 return_tensors: str = 'pt' )

Data collator used for permutation language modeling.

( inputs: typing.Any )

The masked tokens to be predicted for a particular sequence are determined by the following algorithm:

( inputs: typing.Any )

The masked tokens to be predicted for a particular sequence are determined by the following algorithm:

( *args return_position_ids = True separator_id = -100 return_flash_attn_kwargs = False return_seq_idx = False **kwargs )

Data collator used for padding free approach. Does the following:

Using DataCollatorWithFlattening will flatten the entire mini batch into single long sequence. Make sure your attention computation is able to handle it!

( tokenizer: PreTrainedTokenizerBase padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None return_tensors: str = 'pt' )

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta).

Data collator that dynamically pads a batch of nested examples for multiple choice, so that all choices of all examples have the same length.

**Examples:**

Example 1 (unknown):
```unknown
train_dataset
```

Example 2 (unknown):
```unknown
eval_dataset
```

Example 3 (unknown):
```unknown
'max_length'
```

Example 4 (unknown):
```unknown
'do_not_pad'
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/optimizer_schedules

**Contents:**
- Transformers
- Optimization
- AdaFactor
  - class transformers.Adafactor
    - step
- Schedules
  - SchedulerType
  - class transformers.SchedulerType
  - get_scheduler
    - transformers.get_scheduler

Transformers documentation

and get access to the augmented documentation experience

The .optimization module provides:

( params lr = None eps = (1e-30, 0.001) clip_threshold = 1.0 decay_rate = -0.8 beta1 = None weight_decay = 0.0 scale_parameter = True relative_step = True warmup_init = False )

AdaFactor pytorch implementation can be used as a drop in replacement for Adam original fairseq code: https://github.com/pytorch/fairseq/blob/master/fairseq/optim/adafactor.py

Paper: Adafactor: Adaptive Learning Rates with Sublinear Memory Cost https://huggingface.co/papers/1804.04235 Note that this optimizer internally adjusts the learning rate depending on the scale_parameter, relative_step and warmup_init options. To use a manual (external) learning rate schedule you should set scale_parameter=False and relative_step=False.

This implementation handles low-precision (FP16, bfloat) values, but we have not thoroughly tested.

Recommended T5 finetuning settings (https://discuss.huggingface.co/t/t5-finetuning-tips/684/3):

Training without LR warmup or clip_threshold is not recommended.

Disable relative updates

Use scale_parameter=False

Additional optimizer operations like gradient clipping should not be used alongside Adafactor

Others reported the following combination to work well:

When using lr=None with Trainer you will most likely need to use AdafactorSchedule

scheduler as following:

Performs a single optimization step

( value names = None module = None qualname = None type = None start = 1 )

Scheduler names for the parameter lr_scheduler_type in TrainingArguments. By default, it uses “linear”. Internally, this retrieves get_linear_schedule_with_warmup scheduler from Trainer. Scheduler types:

( name: typing.Union[str, transformers.trainer_utils.SchedulerType] optimizer: Optimizer num_warmup_steps: typing.Optional[int] = None num_training_steps: typing.Optional[int] = None scheduler_specific_kwargs: typing.Optional[dict] = None )

Unified API to get any scheduler from its name.

( optimizer: Optimizer last_epoch: int = -1 )

Create a schedule with a constant learning rate, using the learning rate set in optimizer.

( optimizer: Optimizer num_warmup_steps: int last_epoch: int = -1 )

Create a schedule with a constant learning rate preceded by a warmup period during which the learning rate increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: float = 0.5 last_epoch: int = -1 )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to 0, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: int = 1 last_epoch: int = -1 )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to 0, with several hard restarts, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: float = 0.5 last_epoch: int = -1 min_lr: typing.Optional[float] = None min_lr_rate: typing.Optional[float] = None )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to min_lr, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: float = 0.5 last_epoch: int = -1 min_lr: typing.Optional[float] = None min_lr_rate: typing.Optional[float] = None warmup_lr_rate: typing.Optional[float] = None )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to min_lr, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer num_warmup_steps num_training_steps last_epoch = -1 )

Create a schedule with a learning rate that decreases linearly from the initial lr set in the optimizer to 0, after a warmup period during which it increases linearly from 0 to the initial lr set in the optimizer.

( optimizer num_warmup_steps num_training_steps lr_end = 1e-07 power = 1.0 last_epoch = -1 )

Create a schedule with a learning rate that decreases as a polynomial decay from the initial lr set in the optimizer to end lr defined by lr_end, after a warmup period during which it increases linearly from 0 to the initial lr set in the optimizer.

Note: power defaults to 1.0 as in the fairseq implementation, which in turn is based on the original BERT implementation at https://github.com/google-research/bert/blob/f39e881b169b9d53bea03d2d341b31707a6c052b/optimization.py#L37

( optimizer: Optimizer num_warmup_steps: int timescale: typing.Optional[int] = None last_epoch: int = -1 )

Create a schedule with an inverse square-root learning rate, from the initial lr set in the optimizer, after a warmup period which increases lr linearly from 0 to the initial lr set in the optimizer.

( optimizer: Optimizer **kwargs )

Create a schedule with a constant learning rate that decreases when a metric has stopped improving.

( optimizer: Optimizer num_warmup_steps: int num_decay_steps: int num_training_steps: typing.Optional[int] = None num_stable_steps: typing.Optional[int] = None warmup_type: str = 'linear' decay_type: str = 'cosine' min_lr_ratio: float = 0 num_cycles: float = 0.5 last_epoch: int = -1 )

Create a schedule with a learning rate that has three stages:

**Examples:**

Example 1 (unknown):
```unknown
.optimization
```

Example 2 (unknown):
```unknown
_LRSchedule
```

Example 3 (unknown):
```unknown
Iterable[nn.parameter.Parameter]
```

Example 4 (unknown):
```unknown
tuple[float, float]
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/onnx

**Contents:**
- Transformers
- Exporting 🤗 Transformers models to ONNX
- ONNX Configurations
  - OnnxConfig
  - class transformers.onnx.OnnxConfig
    - flatten_output_collection_property
    - from_model_config
    - generate_dummy_inputs
    - generate_dummy_inputs_onnxruntime
    - use_external_data_format

Transformers documentation

Exporting 🤗 Transformers models to ONNX

and get access to the augmented documentation experience

🤗 Transformers provides a transformers.onnx package that enables you to convert model checkpoints to an ONNX graph by leveraging configuration objects.

See the guide on exporting 🤗 Transformers models for more details.

We provide three abstract classes that you should inherit from, depending on the type of model architecture you wish to export:

( config: PretrainedConfig task: str = 'default' patching_specs: typing.Optional[list[transformers.onnx.config.PatchingSpec]] = None )

Base class for ONNX exportable model describing metadata on how to export the model through the ONNX format.

( name: str field: Iterable ) → (dict[str, Any])

Outputs with flattened structure and key mapping this new structure.

Outputs with flattened structure and key mapping this new structure.

Flatten any potential nested structure expanding the name of the field with the index of the element within the structure.

( config: PretrainedConfig task: str = 'default' )

Instantiate a OnnxConfig for a specific model

( preprocessor: typing.Union[ForwardRef('PreTrainedTokenizerBase'), ForwardRef('FeatureExtractionMixin'), ForwardRef('ImageProcessingMixin')] batch_size: int = -1 seq_length: int = -1 num_choices: int = -1 is_pair: bool = False framework: typing.Optional[transformers.utils.generic.TensorType] = None num_channels: int = 3 image_width: int = 40 image_height: int = 40 sampling_rate: int = 22050 time_duration: float = 5.0 frequency: int = 220 tokenizer: typing.Optional[ForwardRef('PreTrainedTokenizerBase')] = None )

Generate inputs to provide to the ONNX exporter for the specific framework

( reference_model_inputs: Mapping ) → Mapping[str, Tensor]

The mapping holding the kwargs to provide to the model’s forward function

The mapping holding the kwargs to provide to the model’s forward function

Generate inputs for ONNX Runtime using the reference model inputs. Override this to run inference with seq2seq models which have the encoder and decoder exported as separate ONNX files.

( num_parameters: int )

Flag indicating if the model requires using external data format

( config: PretrainedConfig task: str = 'default' patching_specs: typing.Optional[list[transformers.onnx.config.PatchingSpec]] = None use_past: bool = False )

( inputs_or_outputs: Mapping direction: str inverted_values_shape: bool = False )

Fill the input_or_outputs mapping with past_key_values dynamic axes considering.

( config: PretrainedConfig task: str = 'default' )

Instantiate a OnnxConfig with use_past attribute set to True

( config: PretrainedConfig task: str = 'default' patching_specs: typing.Optional[list[transformers.onnx.config.PatchingSpec]] = None use_past: bool = False )

Each ONNX configuration is associated with a set of features that enable you to export models for different types of topologies or tasks.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] feature: str = 'default' )

Check whether or not the model has the requested features.

( model: str framework: typing.Optional[str] = None )

Determines the framework to use for the export.

The priority is in the following order:

( model_type: str feature: str ) → OnnxConfig

config for the combination

config for the combination

Gets the OnnxConfig for a model_type and feature combination.

( feature: str framework: str = 'pt' )

Attempts to retrieve an AutoModel class from a feature name.

( feature: str model: str framework: typing.Optional[str] = None cache_dir: typing.Optional[str] = None )

Attempts to retrieve a model from a model’s name and the feature to be enabled.

( model_type: str model_name: typing.Optional[str] = None )

Tries to retrieve the feature -> OnnxConfig constructor map from the model type.

**Examples:**

Example 1 (unknown):
```unknown
transformers.onnx
```

Example 2 (unknown):
```unknown
Mapping[str, Tensor]
```

Example 3 (unknown):
```unknown
Mapping[str, Tensor]
```

Example 4 (unknown):
```unknown
Mapping[str, Tensor]
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/video_processor

**Contents:**
- Transformers
- Video Processor
  - Usage Example
    - Sampling behavior
- BaseVideoProcessor
  - class transformers.BaseVideoProcessor
    - convert_to_rgb
    - fetch_videos
    - from_dict
    - from_json_file

Transformers documentation

and get access to the augmented documentation experience

A Video Processor is a utility responsible for preparing input features for video models, as well as handling the post-processing of their outputs. It provides transformations such as resizing, normalization, and conversion into PyTorch. Along ith transformations the VideoProcessor class handles video decoding from local paths or URLs (requires torchcodec) and frame sampling according to model-specific strategies.

The video processor extends the functionality of image processors by allowing Vision Large Language Models (VLMs) to handle videos with a distinct set of arguments compared to images. It serves as the bridge between raw video data and the model, ensuring that input features are optimized for the VLM.

When adding a new VLM or updating an existing one to enable distinct video preprocessing, saving and reloading the processor configuration will store the video related arguments in a dedicated file named video_preprocessing_config.json. Don’t worry if you haven’t updated your VLM, the processor will try to load video related configurations from a file named preprocessing_config.json.

Here’s an example of how to load a video processor with llava-hf/llava-onevision-qwen2-0.5b-ov-hf model:

Currently, if using base image processor for videos, it processes video data by treating each frame as an individual image and applying transformations frame-by-frame. While functional, this approach is not highly efficient. Using AutoVideoProcessor allows us to take advantage of fast video processors, leveraging the torchvision library. Fast processors handle the whole batch of videos at once, without iterating over each video or frame. These updates introduce GPU acceleration and significantly enhance processing speed, especially for tasks requiring high throughput.

Fast video processors are available for all models and are loaded by default when an AutoVideoProcessor is initialized. When using a fast video processor, you can also set the device argument to specify the device on which the processing should be done. By default, the processing is done on the same device as the inputs if the inputs are tensors, or on the CPU otherwise. For even more speed improvement, we can compile the processor when using ‘cuda’ as device.

The video processor can also sample video frames using the technique best suited for the given model. Sampling behavior is controlled with the do_sample_frames argument and can be configured through model-specific parameters such as num_frames or fps (the rate at which the video will be sampled). If the input video is given as a local path or URL (str), the processor will decode it automatically. To obtain metadata about the decoded video, such as sampled frame indices, original dimensions, duration, and fps, pass return_metadata=True to the processor.

Specifying num_frames does not guarantee the output will contain exactly that number of frames. Depending on the model, the sampler may enforce minimum or maximum frame limits.

The default decoder is torchcodec, which must be installed.

If you pass an already decoded video array but still want to enable model-specific frame sampling, it is strongly recommended to provide video_metadata. This allows the sampler to know the original video’s duration and FPS. You can pass metadata as a VideoMetadata object or as a plain dict.

( **kwargs: typing_extensions.Unpack[transformers.processing_utils.VideosKwargs] )

Constructs a base VideoProcessor.

( video: torch.Tensor ) → torch.Tensor

Converts a video to RGB format.

( video_url_or_urls: typing.Union[str, list[str], list[list[str]]] sample_indices_fn = None )

Convert a single or a list of urls into the corresponding np.array objects.

If a single url is passed, the return value will be a single object. If a list is passed a list of objects is returned.

( video_processor_dict: dict **kwargs ) → ~video_processing_utils.VideoProcessorBase

~video_processing_utils.VideoProcessorBase

The video processor object instantiated from those parameters.

The video processor object instantiated from those parameters.

Instantiates a type of ~video_processing_utils.VideoProcessorBase from a Python dictionary of parameters.

( json_file: typing.Union[str, os.PathLike] ) → A video processor of type ~video_processing_utils.VideoProcessorBase

A video processor of type ~video_processing_utils.VideoProcessorBase

The video_processor object instantiated from that JSON file.

The video_processor object instantiated from that JSON file.

Instantiates a video processor of type ~video_processing_utils.VideoProcessorBase from the path to a JSON file of parameters.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a type of ~video_processing_utils.VideoProcessorBase from an video processor.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] **kwargs ) → tuple[Dict, Dict]

The dictionary(ies) that will be used to instantiate the video processor object.

The dictionary(ies) that will be used to instantiate the video processor object.

From a pretrained_model_name_or_path, resolve to a dictionary of parameters, to be used for instantiating a video processor of type ~video_processing_utils.VideoProcessorBase using from_dict.

( videos: typing.Union[list['PIL.Image.Image'], numpy.ndarray, ForwardRef('torch.Tensor'), list[numpy.ndarray], list['torch.Tensor'], list[list['PIL.Image.Image']], list[list[numpy.ndarray]], list[list['torch.Tensor']], transformers.video_utils.URL, list[transformers.video_utils.URL], list[list[transformers.video_utils.URL]], transformers.video_utils.Path, list[transformers.video_utils.Path], list[list[transformers.video_utils.Path]]] **kwargs: typing_extensions.Unpack[transformers.processing_utils.VideosKwargs] )

( auto_class = 'AutoVideoProcessor' )

Register this class with a given auto class. This should only be used for custom video processors as the ones in the library are already mapped with AutoVideoProcessor .

This API is experimental and may have some slight breaking changes in the next releases.

( metadata: VideoMetadata num_frames: typing.Optional[int] = None fps: typing.Union[int, float, NoneType] = None **kwargs ) → np.ndarray

Indices to sample video frames.

Indices to sample video frames.

Default sampling function which uniformly samples the desired number of frames between 0 and total number of frames. If fps is passed along with metadata, fps frames per second are sampled uniformty. Arguments num_frames and fps are mutually exclusive.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save an video processor object to the directory save_directory, so that it can be re-loaded using the ~video_processing_utils.VideoProcessorBase.from_pretrained class method.

Dictionary of all the attributes that make up this video processor instance.

Dictionary of all the attributes that make up this video processor instance.

Serializes this instance to a Python dictionary.

**Examples:**

Example 1 (unknown):
```unknown
VideoProcessor
```

Example 2 (unknown):
```unknown
video_preprocessing_config.json
```

Example 3 (unknown):
```unknown
preprocessing_config.json
```

Example 4 (unknown):
```unknown
llava-hf/llava-onevision-qwen2-0.5b-ov-hf
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/deepspeed

**Contents:**
- Transformers
- DeepSpeed
- HfDeepSpeedConfig
  - class transformers.integrations.HfDeepSpeedConfig

Transformers documentation

and get access to the augmented documentation experience

DeepSpeed, powered by Zero Redundancy Optimizer (ZeRO), is an optimization library for training and fitting very large models onto a GPU. It is available in several ZeRO stages, where each stage progressively saves more GPU memory by partitioning the optimizer state, gradients, parameters, and enabling offloading to a CPU or NVMe. DeepSpeed is integrated with the Trainer class and most of the setup is automatically taken care of for you.

However, if you want to use DeepSpeed without the Trainer, Transformers provides a HfDeepSpeedConfig class.

Learn more about using DeepSpeed with Trainer in the DeepSpeed guide.

( config_file_or_dict )

This object contains a DeepSpeed configuration dictionary and can be quickly queried for things like zero stage.

A weakref of this object is stored in the module’s globals to be able to access the config from areas where things like the Trainer object is not available (e.g. from_pretrained and _get_resized_embeddings). Therefore it’s important that this object remains alive while the program is still running.

Trainer uses the HfTrainerDeepSpeedConfig subclass instead. That subclass has logic to sync the configuration with values of TrainingArguments by replacing special placeholder values: "auto". Without this special logic the DeepSpeed configuration is not modified in any way.

**Examples:**

Example 1 (unknown):
```unknown
HfDeepSpeedConfig
```

Example 2 (unknown):
```unknown
Union[str, Dict]
```

Example 3 (unknown):
```unknown
from_pretrained
```

Example 4 (unknown):
```unknown
_get_resized_embeddings
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/peft

**Contents:**
- Transformers
- PEFT
  - class transformers.integrations.PeftAdapterMixin
    - load_adapter
    - add_adapter
    - set_adapter
    - disable_adapters
    - enable_adapters
    - active_adapters
    - get_adapter_state_dict

Transformers documentation

and get access to the augmented documentation experience

The PeftAdapterMixin provides functions from the PEFT library for managing adapters with Transformers. This mixin currently supports LoRA, IA3, and AdaLora. Prefix tuning methods (prompt tuning, prompt learning) aren’t supported because they can’t be injected into a torch module.

A class containing all functions for loading and using adapters weights that are supported in PEFT library. For more details about adapters and injecting them on a transformer-based model, check out the documentation of PEFT library: https://huggingface.co/docs/peft/index

Currently supported PEFT methods are all non-prompt learning methods (LoRA, IA³, etc.). Other PEFT models such as prompt tuning, prompt learning are out of scope as these adapters are not “injectable” into a torch module. For using these methods, please refer to the usage guide of PEFT library.

With this mixin, if the correct PEFT version is installed, it is possible to:

( peft_model_id: typing.Optional[str] = None adapter_name: typing.Optional[str] = None revision: typing.Optional[str] = None token: typing.Optional[str] = None device_map: str = 'auto' max_memory: typing.Optional[str] = None offload_folder: typing.Optional[str] = None offload_index: typing.Optional[int] = None peft_config: typing.Optional[dict[str, typing.Any]] = None adapter_state_dict: typing.Optional[dict[str, 'torch.Tensor']] = None low_cpu_mem_usage: bool = False is_trainable: bool = False adapter_kwargs: typing.Optional[dict[str, typing.Any]] = None )

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

To have Accelerate compute the most optimized device_map automatically, set device_map="auto". For more information about each option see designing a device map.

Load adapter weights from file or remote Hub folder. If you are not familiar with adapters and PEFT methods, we invite you to read more about them on PEFT official documentation: https://huggingface.co/docs/peft

Requires PEFT to be installed as a backend to load the adapter weights.

( adapter_config adapter_name: typing.Optional[str] = None )

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Adds a fresh new adapter to the current model for training purpose. If no adapter name is passed, a default name is assigned to the adapter to follow the convention of PEFT library (in PEFT we use “default” as the default adapter name).

Note that the newly added adapter is not automatically activated. To activate it, use model.set_adapter.

( adapter_name: typing.Union[list[str], str] )

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Sets a specific adapter by forcing the model to use a that adapter and disable the other adapters.

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Disable all adapters that are attached to the model. This leads to inferring with the base model only.

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Enable adapters that are attached to the model.

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Gets the current active adapters of the model. In case of multi-adapter inference (combining multiple adapters for inference) returns the list of all active adapters so that users can deal with them accordingly.

For previous PEFT versions (that does not support multi-adapter inference), module.active_adapter will return a single string.

( adapter_name: typing.Optional[str] = None state_dict: typing.Optional[dict] = None )

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Gets the adapter state dict that should only contain the weights tensors of the specified adapter_name adapter. If no adapter_name is passed, the active adapter is used.

**Examples:**

Example 1 (unknown):
```unknown
revision="refs/pr/<pr_number>"
```

Example 2 (unknown):
```unknown
hf auth login
```

Example 3 (unknown):
```unknown
dict[str, Union[int, str, torch.device]]
```

Example 4 (unknown):
```unknown
torch.device
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/executorch

**Contents:**
- Transformers
- ExecuTorch
- ExecuTorch Integration
  - class transformers.TorchExportableModuleWithStaticCache
    - forward
    - transformers.convert_and_export_with_cache

Transformers documentation

and get access to the augmented documentation experience

ExecuTorch is an end-to-end solution for enabling on-device inference capabilities across mobile and edge devices including wearables, embedded devices and microcontrollers. It is part of the PyTorch ecosystem and supports the deployment of PyTorch models with a focus on portability, productivity, and performance.

ExecuTorch introduces well defined entry points to perform model, device, and/or use-case specific optimizations such as backend delegation, user-defined compiler transformations, memory planning, and more. The first step in preparing a PyTorch model for execution on an edge device using ExecuTorch is to export the model. This is achieved through the use of a PyTorch API called torch.export.

An integration point is being developed to ensure that 🤗 Transformers can be exported using torch.export. The goal of this integration is not only to enable export but also to ensure that the exported artifact can be further lowered and optimized to run efficiently in ExecuTorch, particularly for mobile and edge use cases.

( model: PreTrainedModel batch_size: typing.Optional[int] = None max_cache_len: typing.Optional[int] = None device: typing.Optional[torch.device] = None )

A recipe module designed to make a PreTrainedModel exportable with torch.export, specifically for decoder-only LM to StaticCache. This module ensures that the exported model is compatible with further lowering and execution in ExecuTorch.

Note: This class is specifically designed to support export process using torch.export in a way that ensures the model can be further lowered and run efficiently in ExecuTorch.

( input_ids: typing.Optional[torch.LongTensor] = None inputs_embeds: typing.Optional[torch.Tensor] = None cache_position: typing.Optional[torch.Tensor] = None ) → torch.Tensor

Logits output from the model.

Logits output from the model.

Forward pass of the module, which is compatible with the ExecuTorch runtime.

This forward adapter serves two primary purposes:

Making the Model torch.export-Compatible: The adapter hides unsupported objects, such as the Cache, from the graph inputs and outputs, enabling the model to be exportable using torch.export without encountering issues.

Ensuring Compatibility with ExecuTorch runtime: The adapter matches the model’s forward signature with that in executorch/extension/llm/runner, ensuring that the exported model can be executed in ExecuTorch out-of-the-box.

( model: PreTrainedModel example_input_ids: typing.Optional[torch.Tensor] = None example_cache_position: typing.Optional[torch.Tensor] = None dynamic_shapes: typing.Optional[dict] = None strict: typing.Optional[bool] = None ) → Exported program (torch.export.ExportedProgram)

Exported program (torch.export.ExportedProgram)

The exported program generated via torch.export.

The exported program generated via torch.export.

Convert a PreTrainedModel into an exportable module and export it using torch.export, ensuring the exported model is compatible with ExecuTorch.

**Examples:**

Example 1 (unknown):
```unknown
torch.export
```

Example 2 (unknown):
```unknown
torch.export
```

Example 3 (unknown):
```unknown
PreTrainedModel
```

Example 4 (unknown):
```unknown
torch.export
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/logging

**Contents:**
- Transformers
- Logging
- logging vs warnings
    - transformers.utils.logging.captureWarnings
- Base setters
    - transformers.utils.logging.set_verbosity_error
    - transformers.utils.logging.set_verbosity_warning
    - transformers.utils.logging.set_verbosity_info
    - transformers.utils.logging.set_verbosity_debug
- Other functions

Transformers documentation

and get access to the augmented documentation experience

🤗 Transformers has a centralized logging system, so that you can setup the verbosity of the library easily.

Currently the default verbosity of the library is WARNING.

To change the level of verbosity, just use one of the direct setters. For instance, here is how to change the verbosity to the INFO level.

You can also use the environment variable TRANSFORMERS_VERBOSITY to override the default verbosity. You can set it to one of the following: debug, info, warning, error, critical, fatal. For example:

Additionally, some warnings can be disabled by setting the environment variable TRANSFORMERS_NO_ADVISORY_WARNINGS to a true value, like 1. This will disable any warning that is logged using logger.warning_advice. For example:

Here is an example of how to use the same logger as the library in your own module or script:

All the methods of this logging module are documented below, the main ones are logging.get_verbosity() to get the current level of verbosity in the logger and logging.set_verbosity() to set the verbosity to the level of your choice. In order (from the least verbose to the most verbose), those levels (with their corresponding int values in parenthesis) are:

By default, tqdm progress bars will be displayed during model download. logging.disable_progress_bar() and logging.enable_progress_bar() can be used to suppress or unsuppress this behavior.

Python has two logging systems that are often used in conjunction: logging, which is explained above, and warnings, which allows further classification of warnings in specific buckets, e.g., FutureWarning for a feature or path that has already been deprecated and DeprecationWarning to indicate an upcoming deprecation.

We use both in the transformers library. We leverage and adapt logging’s captureWarnings method to allow management of these warning messages by the verbosity setters above.

What does that mean for developers of the library? We should respect the following heuristics:

See reference of the captureWarnings method below.

Calls the captureWarnings method from the logging library to enable management of the warnings emitted by the warnings library.

Read more about this method here: https://docs.python.org/3/library/logging.html#integration-with-the-warnings-module

All warnings will be logged through the py.warnings logger.

Careful: this method also adds a handler to this logger if it does not already have one, and updates the logging level of that logger to the library’s root logger.

Set the verbosity to the ERROR level.

Set the verbosity to the WARNING level.

Set the verbosity to the INFO level.

Set the verbosity to the DEBUG level.

Return the current level for the 🤗 Transformers’s root logger as an int.

🤗 Transformers has following logging levels:

Set the verbosity level for the 🤗 Transformers’s root logger.

( name: typing.Optional[str] = None )

Return a logger with the specified name.

This function is not supposed to be directly accessed unless you are writing a custom transformers module.

Enable the default handler of the HuggingFace Transformers’s root logger.

Disable the default handler of the HuggingFace Transformers’s root logger.

Enable explicit formatting for every HuggingFace Transformers’s logger. The explicit formatter is as follows:

Resets the formatting for HuggingFace Transformers’s loggers.

All handlers currently bound to the root logger are affected by this method.

Enable tqdm progress bar.

Disable tqdm progress bar.

**Examples:**

Example 1 (unknown):
```unknown
TRANSFORMERS_VERBOSITY
```

Example 2 (unknown):
```unknown
TRANSFORMERS_NO_ADVISORY_WARNINGS
```

Example 3 (unknown):
```unknown
logger.warning_advice
```

Example 4 (unknown):
```unknown
transformers.logging.CRITICAL
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/text_generation

**Contents:**
- Transformers
- Generation
- GenerationConfig
  - class transformers.GenerationConfig
    - from_pretrained
    - from_model_config
    - save_pretrained
    - update
    - validate
    - get_generation_mode

Transformers documentation

and get access to the augmented documentation experience

Each framework has a generate method for text generation implemented in their respective GenerationMixin class:

You can parameterize the generate method with a GenerationConfig class instance. Please refer to this class for the complete list of generation parameters, which control the behavior of the generation method.

To learn how to inspect a model’s generation configuration, what are the defaults, how to change the parameters ad hoc, and how to create and save a customized generation configuration, refer to the text generation strategies guide. The guide also explains how to use related features, like token streaming.

Parameters that control the length of the output

Parameters that control the generation strategy used

Parameters that control the cache

If none is specified, we will use the default cache for the model (which is often DynamicCache). See our cache documentation for further information.

Parameters for manipulation of the model output logits

Parameters that define the output variables of generate

Special tokens that can be used at generation time

Generation parameters exclusive to encoder-decoder models

Generation parameters exclusive to assistant generation

Parameters related to performances and compilation

Class that holds a configuration for a generation task. A generate call supports the following generation methods for text-decoder, text-to-text, speech-to-text, and vision-to-text models:

To learn more about decoding strategies refer to the text generation strategies guide.

A large number of these flags control the logits or the stopping criteria of the generation. Make sure you check the generate-related classes for a full description of the possible manipulations, as well as examples of their usage.

( pretrained_model_name: typing.Union[str, os.PathLike] config_file_name: typing.Union[str, os.PathLike, NoneType] = None cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs ) → GenerationConfig

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

If True, then this functions returns a Tuple(config, unused_kwargs) where unused_kwargs is a dictionary consisting of the key/value pairs whose keys are not configuration attributes: i.e., the part of kwargs which has not been used to update config and is otherwise ignored.

The configuration object instantiated from this pretrained model.

The configuration object instantiated from this pretrained model.

Instantiate a GenerationConfig from a generation configuration file.

( model_config: PretrainedConfig ) → GenerationConfig

The configuration object instantiated from those parameters.

The configuration object instantiated from those parameters.

Instantiates a GenerationConfig from a PretrainedConfig. This function is useful to convert legacy PretrainedConfig objects, which may contain generation parameters, into a stand-alone GenerationConfig.

( save_directory: typing.Union[str, os.PathLike] config_file_name: typing.Union[str, os.PathLike, NoneType] = None push_to_hub: bool = False **kwargs )

Save a generation configuration object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

( **kwargs ) → dict[str, Any]

Dictionary containing all the key-value pairs that were not used to update the instance.

Dictionary containing all the key-value pairs that were not used to update the instance.

Updates attributes of this class instance with attributes from kwargs if they match existing attributes, returning all the unused kwargs.

Validates the values of the attributes of the GenerationConfig instance. Raises exceptions in the presence of parameterization that can be detected as incorrect from the configuration instance alone.

Note that some parameters not validated here are best validated at generate runtime, as they may depend on other inputs and/or the model, such as parameters related to the generation length.

( assistant_model: typing.Optional[ForwardRef('PreTrainedModel')] = None ) → GenerationMode

The generation mode triggered by the instance.

The generation mode triggered by the instance.

Returns the generation mode triggered by the GenerationConfig instance.

A class containing all functions for auto-regressive text generation, to be used as a mixin in model classes. Inheriting from this class causes the model to have special generation-related behavior, such as loading a GenerationConfig at initialization time or ensuring generate-related tests are run in transformers CI.

A model class should inherit from GenerationMixin to enable calling methods like generate, or when it has defined a custom generate method that relies on GenerationMixin, directly or indirectly, which approximately shares the same interface to public methods like generate. Three examples:

The class exposes generate(), which can be used for:

To learn more about decoding strategies refer to the text generation strategies guide.

( inputs: typing.Optional[torch.Tensor] = None generation_config: typing.Optional[transformers.generation.configuration_utils.GenerationConfig] = None logits_processor: typing.Optional[transformers.generation.logits_process.LogitsProcessorList] = None stopping_criteria: typing.Optional[transformers.generation.stopping_criteria.StoppingCriteriaList] = None prefix_allowed_tokens_fn: typing.Optional[typing.Callable[[int, torch.Tensor], list[int]]] = None synced_gpus: typing.Optional[bool] = None assistant_model: typing.Optional[ForwardRef('PreTrainedModel')] = None streamer: typing.Optional[ForwardRef('BaseStreamer')] = None negative_prompt_ids: typing.Optional[torch.Tensor] = None negative_prompt_attention_mask: typing.Optional[torch.Tensor] = None use_model_defaults: typing.Optional[bool] = None custom_generate: typing.Union[str, typing.Callable, NoneType] = None **kwargs ) → ModelOutput or torch.LongTensor

ModelOutput or torch.LongTensor

A ModelOutput (if return_dict_in_generate=True or when config.return_dict_in_generate=True) or a torch.LongTensor. If the model is not an encoder-decoder model (model.config.is_encoder_decoder=False), the possible ModelOutput types are: GenerateDecoderOnlyOutput, GenerateBeamDecoderOnlyOutput If the model is an encoder-decoder model (model.config.is_encoder_decoder=True), the possible ModelOutput types are: GenerateEncoderDecoderOutput, GenerateBeamEncoderDecoderOutput

A ModelOutput (if return_dict_in_generate=True or when config.return_dict_in_generate=True) or a torch.LongTensor.

If the model is not an encoder-decoder model (model.config.is_encoder_decoder=False), the possible ModelOutput types are:

If the model is an encoder-decoder model (model.config.is_encoder_decoder=True), the possible ModelOutput types are:

Generates sequences of token ids for models with a language modeling head.

Most generation-controlling parameters are set in generation_config which, if not passed, will be set to the model’s default generation configuration. You can override any generation_config by passing the corresponding parameters to generate(), e.g. .generate(inputs, num_beams=4, do_sample=True).

For an overview of generation strategies and code examples, check out the following guide.

( sequences: Tensor scores: tuple beam_indices: typing.Optional[torch.Tensor] = None normalize_logits: bool = False ) → torch.Tensor

A torch.Tensor of shape (batch_size*num_return_sequences, sequence_length) containing the transition scores (logits)

A torch.Tensor of shape (batch_size*num_return_sequences, sequence_length) containing the transition scores (logits)

Computes the transition scores of sequences given the generation scores (and beam indices, if beam search was used). This is a convenient method to quickly obtain the scores of the selected tokens at generation time.

**Examples:**

Example 1 (unknown):
```unknown
GenerationMixin
```

Example 2 (unknown):
```unknown
max_new_tokens
```

Example 3 (unknown):
```unknown
max_new_tokens
```

Example 4 (unknown):
```unknown
min_new_tokens
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/callback

**Contents:**
- Transformers
- Callbacks
- Available Callbacks
  - class transformers.integrations.CometCallback
    - setup
  - class transformers.DefaultFlowCallback
  - class transformers.PrinterCallback
  - class transformers.ProgressCallback
  - class transformers.EarlyStoppingCallback
  - class transformers.integrations.TensorBoardCallback

Transformers documentation

and get access to the augmented documentation experience

Callbacks are objects that can customize the behavior of the training loop in the PyTorch Trainer that can inspect the training loop state (for progress reporting, logging on TensorBoard or other ML platforms…) and take decisions (like early stopping).

Callbacks are “read only” pieces of code, apart from the TrainerControl object they return, they cannot change anything in the training loop. For customizations that require changes in the training loop, you should subclass Trainer and override the methods you need (see trainer for examples).

By default, TrainingArguments.report_to is set to "all", so a Trainer will use the following callbacks.

If a package is installed but you don’t wish to use the accompanying integration, you can change TrainingArguments.report_to to a list of just those integrations you want to use (e.g. ["azure_ml", "wandb"]).

The main class that implements callbacks is TrainerCallback. It gets the TrainingArguments used to instantiate the Trainer, can access that Trainer’s internal state via TrainerState, and can take some actions on the training loop via TrainerControl.

Here is the list of the available TrainerCallback in the library:

A TrainerCallback that sends the logs to Comet ML.

Setup the optional Comet integration.

For a number of configurable items in the environment, see here.

A TrainerCallback that handles the default flow of the training loop for logs, evaluation and checkpoints.

A bare TrainerCallback that just prints the logs.

( max_str_len: int = 100 )

A TrainerCallback that displays the progress of training or evaluation. You can modify max_str_len to control how long strings are truncated when logging.

( early_stopping_patience: int = 1 early_stopping_threshold: typing.Optional[float] = 0.0 )

A TrainerCallback that handles early stopping.

This callback depends on TrainingArguments argument load_best_model_at_end functionality to set best_metric in TrainerState. Note that if the TrainingArguments argument save_steps differs from eval_steps, the early stopping will not occur until the next save step.

A TrainerCallback that sends the logs to TensorBoard.

A TrainerCallback that logs metrics to Trackio.

It records training metrics, model (and PEFT) configuration, and GPU memory usage. If nvidia-ml-py is installed, GPU power consumption is also tracked.

( args state model **kwargs )

Setup the optional Trackio integration.

To customize the setup you can also set the arguments project, trackio_space_id and hub_private_repo in TrainingArguments. Please refer to the docstring of for more details.

A TrainerCallback that logs metrics, media, model checkpoints to Weight and Biases.

( args state model **kwargs )

Setup the optional Weights & Biases (wandb) integration.

One can subclass and override this method to customize the setup if needed. Find more information here. You can also override the following environment variables:

WANDB_LOG_MODEL (str, optional, defaults to "false"): Whether to log model and checkpoints during training. Can be "end", "checkpoint" or "false". If set to "end", the model will be uploaded at the end of training. If set to "checkpoint", the checkpoint will be uploaded every args.save_steps . If set to "false", the model will not be uploaded. Use along with load_best_model_at_end() to upload best model.

Setting WANDB_LOG_MODEL as bool will be deprecated in version 5 of 🤗 Transformers.

WANDB_WATCH (str, optional defaults to "false"): Can be "gradients", "all", "parameters", or "false". Set to "all" to log gradients and parameters.

WANDB_PROJECT (str, optional, defaults to "huggingface"): Set this to a custom string to store results in a different project.

WANDB_DISABLED (bool, optional, defaults to False): Whether to disable wandb entirely. Set WANDB_DISABLED=true to disable.

A TrainerCallback that sends the logs to MLflow. Can be disabled by setting environment variable DISABLE_MLFLOW_INTEGRATION = TRUE.

Setup the optional MLflow integration.

( azureml_run = None )

A TrainerCallback that sends the logs to AzureML.

A TrainerCallback that tracks the CO2 emission of training.

( api_token: typing.Optional[str] = None project: typing.Optional[str] = None name: typing.Optional[str] = None base_namespace: str = 'finetuning' run = None log_parameters: bool = True log_checkpoints: typing.Optional[str] = None **neptune_run_kwargs )

TrainerCallback that sends the logs to Neptune.

For instructions and examples, see the Transformers integration guide in the Neptune documentation.

A TrainerCallback that sends the logs to ClearML.

A TrainerCallback that logs to DagsHub. Extends MLflowCallback

Setup the DagsHub’s Logging integration.

( save_log_history: bool = True sync_checkpoints: bool = True )

A TrainerCallback that sends the logs to Flyte. NOTE: This callback only works within a Flyte task.

( live: typing.Optional[typing.Any] = None log_model: typing.Union[typing.Literal['all'], bool, NoneType] = None **kwargs )

A TrainerCallback that sends the logs to DVCLive.

Use the environment variables below in setup to configure the integration. To customize this callback beyond those environment variables, see here.

Setup the optional DVCLive integration. To customize this callback beyond the environment variables below, see here.

A TrainerCallback that logs metrics, media, model checkpoints to SwanLab.

( args state model **kwargs )

Setup the optional SwanLab (swanlab) integration.

One can subclass and override this method to customize the setup if needed. Find more information here.

You can also override the following environment variables. Find more information about environment variables here

SWANLAB_API_KEY (str, optional, defaults to None): Cloud API Key. During login, this environment variable is checked first. If it doesn’t exist, the system checks if the user is already logged in. If not, the login process is initiated.

SWANLAB_PROJECT (str, optional, defaults to None): Set this to a custom string to store results in a different project. If not specified, the name of the current running directory is used.

SWANLAB_LOG_DIR (str, optional, defaults to swanlog): This environment variable specifies the storage path for log files when running in local mode. By default, logs are saved in a folder named swanlog under the working directory.

SWANLAB_MODE (Literal["local", "cloud", "disabled"], optional, defaults to cloud): SwanLab’s parsing mode, which involves callbacks registered by the operator. Currently, there are three modes: local, cloud, and disabled. Note: Case-sensitive. Find more information here

SWANLAB_LOG_MODEL (str, optional, defaults to None): SwanLab does not currently support the save mode functionality.This feature will be available in a future release

SWANLAB_WEB_HOST (str, optional, defaults to None): Web address for the SwanLab cloud environment for private version (its free)

SWANLAB_API_HOST (str, optional, defaults to None): API address for the SwanLab cloud environment for private version (its free)

Those are only accessible in the event on_evaluate.

Those are only accessible in the event on_log.

A class for objects that will inspect the state of the training loop at some events and take some decisions. At each of those events the following arguments are available:

The control object is the only one that can be changed by the callback, in which case the event that changes it should return the modified version.

The argument args, state and control are positionals for all events, all the others are grouped in kwargs. You can unpack the ones you need in the signature of the event using them. As an example, see the code of the simple PrinterCallback.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the beginning of an epoch.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of an epoch.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after an evaluation phase.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of the initialization of the Trainer.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after logging the last logs.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after the optimizer step but before gradients are zeroed out. Useful for monitoring gradients.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called before the optimizer step but after gradient clipping. Useful for monitoring gradients.

( args: TrainingArguments state: TrainerState control: TrainerControl metrics **kwargs )

Event called after a successful prediction.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after a prediction step.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called after a checkpoint save.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the beginning of a training step. If using gradient accumulation, one training step might take several inputs.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of a training step. If using gradient accumulation, one training step might take several inputs.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of an substep during gradient accumulation.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the beginning of training.

( args: TrainingArguments state: TrainerState control: TrainerControl **kwargs )

Event called at the end of training.

Here is an example of how to register a custom callback with the PyTorch Trainer:

Another way to register a callback is to call trainer.add_callback() as follows:

( epoch: typing.Optional[float] = None global_step: int = 0 max_steps: int = 0 logging_steps: int = 500 eval_steps: int = 500 save_steps: int = 500 train_batch_size: typing.Optional[int] = None num_train_epochs: int = 0 num_input_tokens_seen: int = 0 total_flos: float = 0 log_history: list = None best_metric: typing.Optional[float] = None best_global_step: typing.Optional[int] = None best_model_checkpoint: typing.Optional[str] = None is_local_process_zero: bool = True is_world_process_zero: bool = True is_hyper_param_search: bool = False trial_name: typing.Optional[str] = None trial_params: typing.Optional[dict[str, typing.Union[str, float, int, bool]]] = None stateful_callbacks: typing.Optional[list['TrainerCallback']] = None )

A class containing the Trainer inner state that will be saved along the model and optimizer when checkpointing and passed to the TrainerCallback.

In all this class, one step is to be understood as one update step. When using gradient accumulation, one update step may require several forward and backward passes: if you use gradient_accumulation_steps=n, then one update step requires going through n batches.

Calculates and stores the absolute value for logging, eval, and save steps based on if it was a proportion or not.

( trainer max_steps num_train_epochs trial )

Stores the initial training references needed in self

Create an instance from the content of json_path.

Save the content of this instance in JSON format inside json_path.

( should_training_stop: bool = False should_epoch_stop: bool = False should_save: bool = False should_evaluate: bool = False should_log: bool = False )

If True, this variable will not be set back to False. The training will just stop.

If True, this variable will be set back to False at the beginning of the next epoch.

If True, this variable will be set back to False at the beginning of the next step.

If True, this variable will be set back to False at the beginning of the next step.

If True, this variable will be set back to False at the beginning of the next step.

A class that handles the Trainer control flow. This class is used by the TrainerCallback to activate some switches in the training loop.

**Examples:**

Example 1 (unknown):
```unknown
TrainingArguments.report_to
```

Example 2 (unknown):
```unknown
TrainingArguments.report_to
```

Example 3 (unknown):
```unknown
["azure_ml", "wandb"]
```

Example 4 (unknown):
```unknown
get_or_create
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/executorch

**Contents:**
- Transformers
- ExecuTorch
- ExecuTorch Integration
  - class transformers.TorchExportableModuleWithStaticCache
    - forward
    - transformers.convert_and_export_with_cache

Transformers documentation

and get access to the augmented documentation experience

ExecuTorch is an end-to-end solution for enabling on-device inference capabilities across mobile and edge devices including wearables, embedded devices and microcontrollers. It is part of the PyTorch ecosystem and supports the deployment of PyTorch models with a focus on portability, productivity, and performance.

ExecuTorch introduces well defined entry points to perform model, device, and/or use-case specific optimizations such as backend delegation, user-defined compiler transformations, memory planning, and more. The first step in preparing a PyTorch model for execution on an edge device using ExecuTorch is to export the model. This is achieved through the use of a PyTorch API called torch.export.

An integration point is being developed to ensure that 🤗 Transformers can be exported using torch.export. The goal of this integration is not only to enable export but also to ensure that the exported artifact can be further lowered and optimized to run efficiently in ExecuTorch, particularly for mobile and edge use cases.

( model: PreTrainedModel batch_size: typing.Optional[int] = None max_cache_len: typing.Optional[int] = None device: typing.Optional[torch.device] = None )

A recipe module designed to make a PreTrainedModel exportable with torch.export, specifically for decoder-only LM to StaticCache. This module ensures that the exported model is compatible with further lowering and execution in ExecuTorch.

Note: This class is specifically designed to support export process using torch.export in a way that ensures the model can be further lowered and run efficiently in ExecuTorch.

( input_ids: typing.Optional[torch.LongTensor] = None inputs_embeds: typing.Optional[torch.Tensor] = None cache_position: typing.Optional[torch.Tensor] = None ) → torch.Tensor

Logits output from the model.

Logits output from the model.

Forward pass of the module, which is compatible with the ExecuTorch runtime.

This forward adapter serves two primary purposes:

Making the Model torch.export-Compatible: The adapter hides unsupported objects, such as the Cache, from the graph inputs and outputs, enabling the model to be exportable using torch.export without encountering issues.

Ensuring Compatibility with ExecuTorch runtime: The adapter matches the model’s forward signature with that in executorch/extension/llm/runner, ensuring that the exported model can be executed in ExecuTorch out-of-the-box.

( model: PreTrainedModel example_input_ids: typing.Optional[torch.Tensor] = None example_cache_position: typing.Optional[torch.Tensor] = None dynamic_shapes: typing.Optional[dict] = None strict: typing.Optional[bool] = None ) → Exported program (torch.export.ExportedProgram)

Exported program (torch.export.ExportedProgram)

The exported program generated via torch.export.

The exported program generated via torch.export.

Convert a PreTrainedModel into an exportable module and export it using torch.export, ensuring the exported model is compatible with ExecuTorch.

**Examples:**

Example 1 (unknown):
```unknown
torch.export
```

Example 2 (unknown):
```unknown
torch.export
```

Example 3 (unknown):
```unknown
PreTrainedModel
```

Example 4 (unknown):
```unknown
torch.export
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/model_doc/auto

**Contents:**
- Transformers
- Auto Classes
- Extending the Auto Classes
- AutoConfig
  - class transformers.AutoConfig
    - from_pretrained
    - register
- AutoTokenizer
  - class transformers.AutoTokenizer
    - from_pretrained

Transformers documentation

and get access to the augmented documentation experience

In many cases, the architecture you want to use can be guessed from the name or the path of the pretrained model you are supplying to the from_pretrained() method. AutoClasses are here to do this job for you so that you automatically retrieve the relevant model given the name/path to the pretrained weights/config/vocabulary.

Instantiating one of AutoConfig, AutoModel, and AutoTokenizer will directly create a class of the relevant architecture. For instance

will create a model that is an instance of BertModel.

There is one class of AutoModel for each task.

Each of the auto classes has a method to be extended with your custom classes. For instance, if you have defined a custom class of model NewModel, make sure you have a NewModelConfig then you can add those to the auto classes like this:

You will then be able to use the auto classes like you would usually do!

If your NewModelConfig is a subclass of PretrainedConfig, make sure its model_type attribute is set to the same key you use when registering the config (here "new-model").

Likewise, if your NewModel is a subclass of PreTrainedModel, make sure its config_class attribute is set to the same class you use when registering the model (here NewModelConfig).

This is a generic configuration class that will be instantiated as one of the configuration classes of the library when created with the from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path: typing.Union[str, os.PathLike[str]] **kwargs )

If True, then this functions returns a Tuple(config, unused_kwargs) where unused_kwargs is a dictionary consisting of the key/value pairs whose keys are not configuration attributes: i.e., the part of kwargs which has not been used to update config and is otherwise ignored.

Instantiate one of the configuration classes of the library from a pretrained model configuration.

The configuration class to instantiate is selected based on the model_type property of the config object that is loaded, or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

( model_type config exist_ok = False )

Register a new configuration for this class.

This is a generic tokenizer class that will be instantiated as one of the tokenizer classes of the library when created with the AutoTokenizer.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path *inputs **kwargs )

Instantiate one of the tokenizer classes of the library from a pretrained model vocabulary.

The tokenizer class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

( config_class slow_tokenizer_class = None fast_tokenizer_class = None exist_ok = False )

Register a new tokenizer in this mapping.

This is a generic feature extractor class that will be instantiated as one of the feature extractor classes of the library when created with the AutoFeatureExtractor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path **kwargs )

Instantiate one of the feature extractor classes of the library from a pretrained model vocabulary.

The feature extractor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

Passing token=True is required when you want to use a private model.

( config_class feature_extractor_class exist_ok = False )

Register a new feature extractor for this class.

This is a generic image processor class that will be instantiated as one of the image processor classes of the library when created with the AutoImageProcessor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path *inputs **kwargs )

Instantiate one of the image processor classes of the library from a pretrained model vocabulary.

The image processor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

Passing token=True is required when you want to use a private model.

( config_class image_processor_class = None slow_image_processor_class = None fast_image_processor_class = None exist_ok = False )

Register a new image processor for this class.

This is a generic video processor class that will be instantiated as one of the video processor classes of the library when created with the AutoVideoProcessor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path *inputs **kwargs )

Instantiate one of the video processor classes of the library from a pretrained model vocabulary.

The video processor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

Passing token=True is required when you want to use a private model.

( config_class video_processor_class exist_ok = False )

Register a new video processor for this class.

This is a generic processor class that will be instantiated as one of the processor classes of the library when created with the AutoProcessor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path **kwargs )

Instantiate one of the processor classes of the library from a pretrained model vocabulary.

The processor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible):

Passing token=True is required when you want to use a private model.

( config_class processor_class exist_ok = False )

Register a new processor for this class.

The following auto classes are available for instantiating a base model class without a specific head.

This is a generic model class that will be instantiated as one of the base model classes of the library when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the base model classes of the library from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the base model classes of the library from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for instantiating a model with a pretraining head.

This is a generic model class that will be instantiated as one of the model classes of the library (with a pretraining head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a pretraining head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a pretraining head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following natural language processing tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a causal language modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a causal language modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a causal language modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a masked language modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a masked language modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a masked language modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a sequence-to-sequence language modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a sequence-to-sequence language modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a sequence-to-sequence language modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a sequence classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a sequence classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a sequence classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a multiple choice head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a multiple choice head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a multiple choice head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a next sentence prediction head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a next sentence prediction head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a next sentence prediction head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a token classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a token classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a token classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following computer vision tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a depth estimation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a depth estimation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a depth estimation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a image classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a image classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a image classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a video classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a video classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a video classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a masked image modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a masked image modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a masked image modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a object detection head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a object detection head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a object detection head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a image segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a image segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a image segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a semantic segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a semantic segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a semantic segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a instance segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a instance segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a instance segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a universal image segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a universal image segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a universal image segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a zero-shot image classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a zero-shot image classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a zero-shot image classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a zero-shot object detection head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a zero-shot object detection head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a zero-shot object detection head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following audio tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio frame (token) classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio frame (token) classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio frame (token) classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a connectionist temporal classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a connectionist temporal classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a connectionist temporal classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a sequence-to-sequence speech-to-text modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a sequence-to-sequence speech-to-text modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a sequence-to-sequence speech-to-text modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio retrieval via x-vector head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio retrieval via x-vector head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio retrieval via x-vector head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio tokenization through codebooks head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio tokenization through codebooks head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio tokenization through codebooks head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following multimodal tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a table question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a table question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a table question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a document question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a document question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a document question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a visual question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a visual question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a visual question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a image-text-to-text modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a image-text-to-text modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a image-text-to-text modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a time-series prediction head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a time-series prediction head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a time-series prediction head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

**Examples:**

Example 1 (unknown):
```unknown
from_pretrained()
```

Example 2 (unknown):
```unknown
NewModelConfig
```

Example 3 (unknown):
```unknown
NewModelConfig
```

Example 4 (unknown):
```unknown
"new-model"
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/chat_templating

**Contents:**
- Transformers
- Chat templates
- Using apply_chat_template
  - add_generation_prompt
  - continue_final_message
- Model training

Transformers documentation

and get access to the augmented documentation experience

The chat basics guide covers how to store chat histories and generate text from chat models using TextGenerationPipeline.

This guide is intended for more advanced users, and covers the underlying classes and methods, as well as the key concepts for understanding what’s actually going on when you chat with a model.

The critical insight needed to understand chat models is this: All causal LMs, whether chat-trained or not, continue a sequence of tokens. When causal LMs are trained, the training usually begins with “pre-training” on a huge corpus of text, which creates a “base” model. These base models are then often “fine-tuned” for chat, which means training them on data that is formatted as a sequence of messages. The chat is still just a sequence of tokens, though! The list of role and content dictionaries that you pass to a chat model get converted to a token sequence, often with control tokens like <|user|> or <|assistant|> or <|end_of_message|>, which allow the model to see the chat structure. There are many possible chat formats, and different models may use different formats or control tokens, even if they were fine-tuned from the same base model!

Don’t panic, though - you don’t need to memorize every possible chat format in order to use chat models. Chat models come with chat templates, which indicate how they expect chats to be formatted. You can access these with the apply_chat_template method. Let’s see two examples. Both of these models are fine-tuned from the same Mistral-7B base model:

Mistral-7B-Instruct uses [INST] and [/INST] tokens to indicate the start and end of user messages, while Zephyr-7B uses <|user|> and <|assistant|> tokens to indicate speaker roles. This is why chat templates are important - with the wrong control tokens, these models would have drastically worse performance.

The input to apply_chat_template should be structured as a list of dictionaries with role and content keys. The role key specifies the speaker, and the content key contains the message. The common roles are:

apply_chat_template takes this list and returns a formatted sequence. Set tokenize=True if you want to tokenize the sequence.

Pass the tokenized chat to generate() to generate a response.

Some tokenizers add special <bos> and <eos> tokens. Chat templates should already include all the necessary special tokens, and adding additional special tokens is often incorrect or duplicated, hurting model performance. When you format text with apply_chat_template(tokenize=False), make sure you set add_special_tokens=False if you tokenize later to avoid duplicating these tokens. This isn’t an issue if you use apply_chat_template(tokenize=True), which means it’s usually the safer option!

You may have noticed the add_generation_prompt argument in the above examples. This argument adds tokens to the end of the chat that indicate the start of an assistant response. Remember: Beneath all the chat abstractions, chat models are still just language models that continue a sequence of tokens! If you include tokens that tell it that it’s now in an assistant response, it will correctly write a response, but if you don’t include these tokens, the model may get confused and do something strange, like continuing the user’s message instead of replying to it!

Let’s see an example to understand what add_generation_prompt is actually doing. First, let’s format a chat without add_generation_prompt:

Now, let’s format the same chat with add_generation_prompt=True:

When add_generation_prompt=True, <|im_start|>assistant is added at the end to indicate the start of an assistant message. This lets the model know an assistant response is next.

Not all models require generation prompts, and some models, like Llama, don’t have any special tokens before the assistant response. In these cases, add_generation_prompt has no effect.

The continue_final_message parameter controls whether the final message in the chat should be continued or not instead of starting a new one. It removes end of sequence tokens so that the model continues generation from the final message.

This is useful for “prefilling” a model response. In the example below, the model generates text that continues the JSON string rather than starting a new message. It can be very useful for improving the accuracy of instruction following when you know how to start its replies.

You shouldn’t use add_generation_prompt and continue_final_message together. The former adds tokens that start a new message, while the latter removes end of sequence tokens. Using them together returns an error.

TextGenerationPipeline sets add_generation_prompt to True by default to start a new message. However, if the final message in the chat has the assistant role, it assumes the message is a prefill and switches to continue_final_message=True. This is because most models don’t support multiple consecutive assistant messages. To override this behavior, explicitly pass the continue_final_message argument to the pipeline.

Training a model with a chat template is a good way to ensure the template matches the tokens the model was trained on. Apply the chat template as a preprocessing step to your dataset. Set add_generation_prompt=False because the additional tokens to prompt an assistant response aren’t helpful during training.

An example of preprocessing a dataset with a chat template is shown below.

After this step, you can continue following the training recipe for causal language models using the formatted_chat column.

**Examples:**

Example 1 (unknown):
```unknown
<|assistant|>
```

Example 2 (unknown):
```unknown
<|end_of_message|>
```

Example 3 (unknown):
```unknown
apply_chat_template
```

Example 4 (unknown):
```unknown
<|assistant|>
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/text_generation

**Contents:**
- Transformers
- Generation
- GenerationConfig
  - class transformers.GenerationConfig
    - from_pretrained
    - from_model_config
    - save_pretrained
    - update
    - validate
    - get_generation_mode

Transformers documentation

and get access to the augmented documentation experience

Each framework has a generate method for text generation implemented in their respective GenerationMixin class:

You can parameterize the generate method with a GenerationConfig class instance. Please refer to this class for the complete list of generation parameters, which control the behavior of the generation method.

To learn how to inspect a model’s generation configuration, what are the defaults, how to change the parameters ad hoc, and how to create and save a customized generation configuration, refer to the text generation strategies guide. The guide also explains how to use related features, like token streaming.

Parameters that control the length of the output

Parameters that control the generation strategy used

Parameters that control the cache

If none is specified, we will use the default cache for the model (which is often DynamicCache). See our cache documentation for further information.

Parameters for manipulation of the model output logits

Parameters that define the output variables of generate

Special tokens that can be used at generation time

Generation parameters exclusive to encoder-decoder models

Generation parameters exclusive to assistant generation

Parameters related to performances and compilation

Class that holds a configuration for a generation task. A generate call supports the following generation methods for text-decoder, text-to-text, speech-to-text, and vision-to-text models:

To learn more about decoding strategies refer to the text generation strategies guide.

A large number of these flags control the logits or the stopping criteria of the generation. Make sure you check the generate-related classes for a full description of the possible manipulations, as well as examples of their usage.

( pretrained_model_name: typing.Union[str, os.PathLike] config_file_name: typing.Union[str, os.PathLike, NoneType] = None cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs ) → GenerationConfig

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

If True, then this functions returns a Tuple(config, unused_kwargs) where unused_kwargs is a dictionary consisting of the key/value pairs whose keys are not configuration attributes: i.e., the part of kwargs which has not been used to update config and is otherwise ignored.

The configuration object instantiated from this pretrained model.

The configuration object instantiated from this pretrained model.

Instantiate a GenerationConfig from a generation configuration file.

( model_config: PretrainedConfig ) → GenerationConfig

The configuration object instantiated from those parameters.

The configuration object instantiated from those parameters.

Instantiates a GenerationConfig from a PretrainedConfig. This function is useful to convert legacy PretrainedConfig objects, which may contain generation parameters, into a stand-alone GenerationConfig.

( save_directory: typing.Union[str, os.PathLike] config_file_name: typing.Union[str, os.PathLike, NoneType] = None push_to_hub: bool = False **kwargs )

Save a generation configuration object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

( **kwargs ) → dict[str, Any]

Dictionary containing all the key-value pairs that were not used to update the instance.

Dictionary containing all the key-value pairs that were not used to update the instance.

Updates attributes of this class instance with attributes from kwargs if they match existing attributes, returning all the unused kwargs.

Validates the values of the attributes of the GenerationConfig instance. Raises exceptions in the presence of parameterization that can be detected as incorrect from the configuration instance alone.

Note that some parameters not validated here are best validated at generate runtime, as they may depend on other inputs and/or the model, such as parameters related to the generation length.

( assistant_model: typing.Optional[ForwardRef('PreTrainedModel')] = None ) → GenerationMode

The generation mode triggered by the instance.

The generation mode triggered by the instance.

Returns the generation mode triggered by the GenerationConfig instance.

A class containing all functions for auto-regressive text generation, to be used as a mixin in model classes. Inheriting from this class causes the model to have special generation-related behavior, such as loading a GenerationConfig at initialization time or ensuring generate-related tests are run in transformers CI.

A model class should inherit from GenerationMixin to enable calling methods like generate, or when it has defined a custom generate method that relies on GenerationMixin, directly or indirectly, which approximately shares the same interface to public methods like generate. Three examples:

The class exposes generate(), which can be used for:

To learn more about decoding strategies refer to the text generation strategies guide.

( inputs: typing.Optional[torch.Tensor] = None generation_config: typing.Optional[transformers.generation.configuration_utils.GenerationConfig] = None logits_processor: typing.Optional[transformers.generation.logits_process.LogitsProcessorList] = None stopping_criteria: typing.Optional[transformers.generation.stopping_criteria.StoppingCriteriaList] = None prefix_allowed_tokens_fn: typing.Optional[typing.Callable[[int, torch.Tensor], list[int]]] = None synced_gpus: typing.Optional[bool] = None assistant_model: typing.Optional[ForwardRef('PreTrainedModel')] = None streamer: typing.Optional[ForwardRef('BaseStreamer')] = None negative_prompt_ids: typing.Optional[torch.Tensor] = None negative_prompt_attention_mask: typing.Optional[torch.Tensor] = None use_model_defaults: typing.Optional[bool] = None custom_generate: typing.Union[str, typing.Callable, NoneType] = None **kwargs ) → ModelOutput or torch.LongTensor

ModelOutput or torch.LongTensor

A ModelOutput (if return_dict_in_generate=True or when config.return_dict_in_generate=True) or a torch.LongTensor. If the model is not an encoder-decoder model (model.config.is_encoder_decoder=False), the possible ModelOutput types are: GenerateDecoderOnlyOutput, GenerateBeamDecoderOnlyOutput If the model is an encoder-decoder model (model.config.is_encoder_decoder=True), the possible ModelOutput types are: GenerateEncoderDecoderOutput, GenerateBeamEncoderDecoderOutput

A ModelOutput (if return_dict_in_generate=True or when config.return_dict_in_generate=True) or a torch.LongTensor.

If the model is not an encoder-decoder model (model.config.is_encoder_decoder=False), the possible ModelOutput types are:

If the model is an encoder-decoder model (model.config.is_encoder_decoder=True), the possible ModelOutput types are:

Generates sequences of token ids for models with a language modeling head.

Most generation-controlling parameters are set in generation_config which, if not passed, will be set to the model’s default generation configuration. You can override any generation_config by passing the corresponding parameters to generate(), e.g. .generate(inputs, num_beams=4, do_sample=True).

For an overview of generation strategies and code examples, check out the following guide.

( sequences: Tensor scores: tuple beam_indices: typing.Optional[torch.Tensor] = None normalize_logits: bool = False ) → torch.Tensor

A torch.Tensor of shape (batch_size*num_return_sequences, sequence_length) containing the transition scores (logits)

A torch.Tensor of shape (batch_size*num_return_sequences, sequence_length) containing the transition scores (logits)

Computes the transition scores of sequences given the generation scores (and beam indices, if beam search was used). This is a convenient method to quickly obtain the scores of the selected tokens at generation time.

**Examples:**

Example 1 (unknown):
```unknown
GenerationMixin
```

Example 2 (unknown):
```unknown
max_new_tokens
```

Example 3 (unknown):
```unknown
max_new_tokens
```

Example 4 (unknown):
```unknown
min_new_tokens
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/llm_tutorial_optimization

**Contents:**
- Transformers
- Optimizing LLMs for Speed and Memory
- 1. Lower Precision
- 2. Flash Attention
- 3. Architectural Innovations
  - 3.1 Improving positional embeddings of LLMs
  - 3.2 The key-value cache
    - 3.2.1 Multi-round conversation
    - 3.2.2 Multi-Query-Attention (MQA)
    - 3.2.3 Grouped-Query-Attention (GQA)

Transformers documentation

Optimizing LLMs for Speed and Memory

and get access to the augmented documentation experience

Large Language Models (LLMs) such as GPT3/4, Falcon, and Llama are rapidly advancing in their ability to tackle human-centric tasks, establishing themselves as essential tools in modern knowledge-based industries. Deploying these models in real-world tasks remains challenging, however:

The crux of these challenges lies in augmenting the computational and memory capabilities of LLMs, especially when handling expansive input sequences.

In this guide, we will go over the effective techniques for efficient LLM deployment:

Lower Precision: Research has shown that operating at reduced numerical precision, namely 8-bit and 4-bit can achieve computational advantages without a considerable decline in model performance.

Flash Attention: Flash Attention is a variation of the attention algorithm that not only provides a more memory-efficient approach but also realizes increased efficiency due to optimized GPU memory utilization.

Architectural Innovations: Considering that LLMs are always deployed in the same way during inference, namely autoregressive text generation with a long input context, specialized model architectures have been proposed that allow for more efficient inference. The most important advancement in model architectures hereby are Alibi, Rotary embeddings, Multi-Query Attention (MQA) and Grouped-Query-Attention (GQA).

Throughout this guide, we will offer an analysis of auto-regressive generation from a tensor’s perspective. We delve into the pros and cons of adopting lower precision, provide a comprehensive exploration of the latest attention algorithms, and discuss improved LLM architectures. While doing so, we run practical examples showcasing each of the feature improvements.

Memory requirements of LLMs can be best understood by seeing the LLM as a set of weight matrices and vectors and the text inputs as a sequence of vectors. In the following, the definition weights will be used to signify all model weight matrices and vectors.

At the time of writing this guide, LLMs consist of at least a couple billion parameters. Each parameter thereby is made of a decimal number, e.g. 4.5689 which is usually stored in either float32, bfloat16, or float16 format. This allows us to easily compute the memory requirement to load the LLM into memory:

Loading the weights of a model having X billion parameters requires roughly 4 X GB of VRAM in float32 precision*

Nowadays, models are however rarely trained in full float32 precision, but usually in bfloat16 precision or less frequently in float16 precision. Therefore the rule of thumb becomes:

Loading the weights of a model having X billion parameters requires roughly 2 X GB of VRAM in bfloat16/float16 precision*

For shorter text inputs (less than 1024 tokens), the memory requirement for inference is very much dominated by the memory requirement to load the weights. Therefore, for now, let’s assume that the memory requirement for inference is equal to the memory requirement to load the model into the GPU VRAM.

To give some examples of how much VRAM it roughly takes to load a model in bfloat16:

As of writing this document, the largest GPU chip on the market is the A100 & H100 offering 80GB of VRAM. Most of the models listed before require more than 80GB just to be loaded and therefore necessarily require tensor parallelism and/or pipeline parallelism.

🤗 Transformers now supports tensor parallelism for supported models having base_tp_plan in their respective config classes. Learn more about Tensor Parallelism here. Furthermore, if you’re interested in writing models in a tensor-parallelism-friendly way, feel free to have a look at the text-generation-inference library.

Naive pipeline parallelism is supported out of the box. For this, simply load the model with device="auto" which will automatically place the different layers on the available GPUs as explained here. Note, however that while very effective, this naive pipeline parallelism does not tackle the issues of GPU idling. For this more advanced pipeline parallelism is required as explained here.

If you have access to an 8 x 80GB A100 node, you could load BLOOM as follows

By using device_map="auto" the attention layers would be equally distributed over all available GPUs.

In this guide, we will use bigcode/octocoder as it can be run on a single 40 GB A100 GPU device chip. Note that all memory and speed optimizations that we will apply going forward, are equally applicable to models that require model or tensor parallelism.

Since the model is loaded in bfloat16 precision, using our rule of thumb above, we would expect the memory requirement to run inference with bigcode/octocoder to be around 31 GB VRAM. Let’s give it a try.

We first load the model and tokenizer and then pass both to Transformers’ pipeline object.

Nice, we can now directly use the result to convert bytes into Gigabytes.

Let’s call torch.cuda.max_memory_allocated to measure the peak GPU memory allocation.

Close enough to our back-of-the-envelope computation! We can see the number is not exactly correct as going from bytes to kilobytes requires a multiplication of 1024 instead of 1000. Therefore the back-of-the-envelope formula can also be understood as an “at most X GB” computation. Note that if we had tried to run the model in full float32 precision, a whopping 64 GB of VRAM would have been required.

Almost all models are trained in bfloat16 nowadays, there is no reason to run the model in full float32 precision if your GPU supports bfloat16. Float32 won’t give better inference results than the precision that was used to train the model.

If you are unsure in which format the model weights are stored on the Hub, you can always look into the checkpoint’s config under "dtype", e.g. here. It is recommended to set the model to the same precision type as written in the config when loading with from_pretrained(..., dtype=...) except when the original type is float32 in which case one can use both float16 or bfloat16 for inference.

Let’s define a flush(...) function to free all allocated memory so that we can accurately measure the peak allocated GPU memory.

Let’s call it now for the next experiment.

From the Accelerate library, you can also use a device-agnostic utility method called release_memory, which takes various hardware backends like XPU, MLU, NPU, MPS, and more into account.

Now what if your GPU does not have 32 GB of VRAM? It has been found that model weights can be quantized to 8-bit or 4-bits without a significant loss in performance (see Dettmers et al.). Model can be quantized to even 3 or 2 bits with an acceptable loss in performance as shown in the recent GPTQ paper 🤯.

Without going into too many details, quantization schemes aim at reducing the precision of weights while trying to keep the model’s inference results as accurate as possible (a.k.a as close as possible to bfloat16). Note that quantization works especially well for text generation since all we care about is choosing the set of most likely next tokens and don’t really care about the exact values of the next token logit distribution. All that matters is that the next token logit distribution stays roughly the same so that an argmax or topk operation gives the same results.

There are various quantization techniques, which we won’t discuss in detail here, but in general, all quantization techniques work as follows:

In a nutshell, this means that inputs-weight matrix multiplications, withX X X being the inputs,W W W being a weight matrix andY Y Y being the output: Y=X∗W Y = X * W Y=X∗W

are changed to Y=X∗dequantize(W) Y = X * \text{dequantize}(W) Y=X∗dequantize(W)

for every matrix multiplication. Dequantization and re-quantization is performed sequentially for all weight matrices as the inputs run through the network graph.

Therefore, inference time is often not reduced when using quantized weights, but rather increases. Enough theory, let’s give it a try! To quantize the weights with Transformers, you need to make sure that the bitsandbytes library is installed.

We can then load models in 8-bit quantization by simply adding a load_in_8bit=True flag to from_pretrained.

Now, let’s run our example again and measure the memory usage.

Nice, we’re getting the same result as before, so no loss in accuracy! Let’s look at how much memory was used this time.

Significantly less! We’re down to just a bit over 15 GBs and could therefore run this model on consumer GPUs like the 4090. We’re seeing a very nice gain in memory efficiency and more or less no degradation to the model’s output. However, we can also notice a slight slow-down during inference.

We delete the models and flush the memory again.

Let’s see what peak GPU memory consumption 4-bit quantization gives. Quantizing the model to 4-bit can be done with the same API as before - this time by passing load_in_4bit=True instead of load_in_8bit=True.

We’re almost seeing the same output text as before - just the python is missing just before the code snippet. Let’s see how much memory was required.

Just 9.5GB! That’s really not a lot for a >15 billion parameter model.

While we see very little degradation in accuracy for our model here, 4-bit quantization can in practice often lead to different results compared to 8-bit quantization or full bfloat16 inference. It is up to the user to try it out.

Also note that inference here was again a bit slower compared to 8-bit quantization which is due to the more aggressive quantization method used for 4-bit quantization leading toquantize \text{quantize} quantize anddequantize \text{dequantize} dequantize taking longer during inference.

Overall, we saw that running OctoCoder in 8-bit precision reduced the required GPU VRAM from 32G GPU VRAM to only 15GB and running the model in 4-bit precision further reduces the required GPU VRAM to just a bit over 9GB.

4-bit quantization allows the model to be run on GPUs such as RTX3090, V100, and T4 which are quite accessible for most people.

For more information on quantization and to see how one can quantize models to require even less GPU VRAM memory than 4-bit, we recommend looking into the AutoGPTQ implementation.

As a conclusion, it is important to remember that model quantization trades improved memory efficiency against accuracy and in some cases inference time.

If GPU memory is not a constraint for your use case, there is often no need to look into quantization. However many GPUs simply can’t run LLMs without quantization methods and in this case, 4-bit and 8-bit quantization schemes are extremely useful tools.

For more in-detail usage information, we strongly recommend taking a look at the Transformers Quantization Docs. Next, let’s look into how we can improve computational and memory efficiency by using better algorithms and an improved model architecture.

Today’s top-performing LLMs share more or less the same fundamental architecture that consists of feed-forward layers, activation layers, layer normalization layers, and most crucially, self-attention layers.

Self-attention layers are central to Large Language Models (LLMs) in that they enable the model to understand the contextual relationships between input tokens. However, the peak GPU memory consumption for self-attention layers grows quadratically both in compute and memory complexity with number of input tokens (also called sequence length) that we denote in the following byN N N . While this is not really noticeable for shorter input sequences (of up to 1000 input tokens), it becomes a serious problem for longer input sequences (at around 16000 input tokens).

Let’s take a closer look. The formula to compute the outputO \mathbf{O} O of a self-attention layer for an inputX \mathbf{X} X of lengthN N N is: O=Attn(X)=V×Softmax(QKT) with Q=WqX,V=WvX,K=WkX \textbf{O} = \text{Attn}(\mathbf{X}) = \mathbf{V} \times \text{Softmax}(\mathbf{QK}^T) \text{ with } \mathbf{Q} = \mathbf{W}_q \mathbf{X}, \mathbf{V} = \mathbf{W}_v \mathbf{X}, \mathbf{K} = \mathbf{W}_k \mathbf{X} O=Attn(X)=V×Softmax(QKT) with Q=Wq​X,V=Wv​X,K=Wk​X X=(x1,...xN) \mathbf{X} = (\mathbf{x}_1, ... \mathbf{x}_{N}) X=(x1​,...xN​) is thereby the input sequence to the attention layer. The projectionsQ \mathbf{Q} Q andK \mathbf{K} K will each consist ofN N N vectors resulting in theQKT \mathbf{QK}^T QKT being of sizeN2 N^2 N2 .

LLMs usually have multiple attention heads, thus doing multiple self-attention computations in parallel. Assuming, the LLM has 40 attention heads and runs in bfloat16 precision, we can calculate the memory requirement to store theQKT \mathbf{QK^T} QKT matrices to be40∗2∗N2 40 * 2 * N^2 40∗2∗N2 bytes. ForN=1000 N=1000 N=1000 only around 50 MB of VRAM are needed, however, forN=16000 N=16000 N=16000 we would need 19 GB of VRAM, and forN=100,000 N=100,000 N=100,000 we would need almost 1TB just to store theQKT \mathbf{QK}^T QKT matrices.

Long story short, the default self-attention algorithm quickly becomes prohibitively memory-expensive for large input contexts.

As LLMs improve in text comprehension and generation, they are applied to increasingly complex tasks. While models once handled the translation or summarization of a few sentences, they now manage entire pages, demanding the capability to process extensive input lengths.

How can we get rid of the exorbitant memory requirements for large input lengths? We need a new way to compute the self-attention mechanism that gets rid of theQKT QK^T QKT matrix. Tri Dao et al. developed exactly such a new algorithm and called it Flash Attention.

In a nutshell, Flash Attention breaks the V×Softmax(QKT\mathbf{V} \times \text{Softmax}(\mathbf{QK}^TV×Softmax(QKT) computation apart and instead computes smaller chunks of the output by iterating over multiple softmax computation steps: Oi←sija∗Oi+sijb∗Vj×Softmax(QKi,jT) for multiple i,j iterations \textbf{O}_i \leftarrow s^a_{ij} * \textbf{O}_i + s^b_{ij} * \mathbf{V}_{j} \times \text{Softmax}(\mathbf{QK}^T_{i,j}) \text{ for multiple } i, j \text{ iterations} Oi​←sija​∗Oi​+sijb​∗Vj​×Softmax(QKi,jT​) for multiple i,j iterations

withsija s^a_{ij} sija​ andsijb s^b_{ij} sijb​ being some softmax normalization statistics that need to be recomputed for everyi i i andj j j .

Please note that the whole Flash Attention is a bit more complex and is greatly simplified here as going in too much depth is out of scope for this guide. The reader is invited to take a look at the well-written Flash Attention paper for more details.

The main takeaway here is:

By keeping track of softmax normalization statistics and by using some smart mathematics, Flash Attention gives numerical identical outputs compared to the default self-attention layer at a memory cost that only increases linearly withN N N .

Looking at the formula, one would intuitively say that Flash Attention must be much slower compared to the default self-attention formula as more computation needs to be done. Indeed Flash Attention requires more FLOPs compared to normal attention as the softmax normalization statistics have to constantly be recomputed (see paper for more details if interested)

However, Flash Attention is much faster in inference compared to default attention which comes from its ability to significantly reduce the demands on the slower, high-bandwidth memory of the GPU (VRAM), focusing instead on the faster on-chip memory (SRAM).

Essentially, Flash Attention makes sure that all intermediate write and read operations can be done using the fast on-chip SRAM memory instead of having to access the slower VRAM memory to compute the output vectorO \mathbf{O} O .

In practice, there is currently absolutely no reason to not use Flash Attention if available. The algorithm gives mathematically the same outputs, and is both faster and more memory-efficient.

Let’s look at a practical example.

Our OctoCoder model now gets a significantly longer input prompt which includes a so-called system prompt. System prompts are used to steer the LLM into a better assistant that is tailored to the users’ task. In the following, we use a system prompt that will make OctoCoder a better coding assistant.

For demonstration purposes, we duplicate the system prompt by ten so that the input length is long enough to observe Flash Attention’s memory savings. We append the original text prompt "Question: Please write a function in Python that transforms bytes to Giga bytes.\n\nAnswer: Here"

We instantiate our model again in bfloat16 precision.

Let’s now run the model just like before without Flash Attention and measure the peak GPU memory requirement and inference time.

We’re getting the same output as before, however this time, the model repeats the answer multiple times until it’s 60 tokens cut-off. This is not surprising as we’ve repeated the system prompt ten times for demonstration purposes and thus cued the model to repeat itself.

Note that the system prompt should not be repeated ten times in real-world applications - one time is enough!

Let’s measure the peak GPU memory requirement.

As we can see the peak GPU memory requirement is now significantly higher than in the beginning, which is largely due to the longer input sequence. Also the generation takes a little over a minute now.

We call flush() to free GPU memory for our next experiment.

For comparison, let’s run the same function, but enable Flash Attention instead. To do so, we convert the model to BetterTransformer and by doing so enabling PyTorch’s SDPA self-attention which in turn is able to use Flash Attention.

Now we run the exact same code snippet as before and under the hood Transformers will make use of Flash Attention.

We’re getting the exact same result as before, but can observe a very significant speed-up thanks to Flash Attention.

Let’s measure the memory consumption one last time.

And we’re almost back to our original 29GB peak GPU memory from the beginning.

We can observe that we only use roughly 100MB more GPU memory when passing a very long input sequence with Flash Attention compared to passing a short input sequence as done in the beginning.

For more information on how to use Flash Attention, please have a look at this doc page.

So far we have looked into improving computational and memory efficiency by:

Let’s now look into how we can change the architecture of an LLM so that it is most effective and efficient for task that require long text inputs, e.g.:

Note that chat not only requires the LLM to handle long text inputs, but it also necessitates that the LLM is able to efficiently handle the back-and-forth dialogue between user and assistant (such as ChatGPT).

Once trained, the fundamental LLM architecture is difficult to change, so it is important to make considerations about the LLM’s tasks beforehand and accordingly optimize the model’s architecture. There are two important components of the model architecture that quickly become memory and/or performance bottlenecks for large input sequences.

Let’s go over each component in more detail

Self-attention puts each token in relation to each other’s tokens. As an example, theSoftmax(QKT) \text{Softmax}(\mathbf{QK}^T) Softmax(QKT) matrix of the text input sequence “Hello”, “I”, “love”, “you” could look as follows:

Each word token is given a probability mass at which it attends all other word tokens and, therefore is put into relation with all other word tokens. E.g. the word “love” attends to the word “Hello” with 5%, to “I” with 30%, and to itself with 65%.

A LLM based on self-attention, but without position embeddings would have great difficulties in understanding the positions of the text inputs to each other. This is because the probability score computed byQKT \mathbf{QK}^T QKT relates each word token to each other word token inO(1) O(1) O(1) computations regardless of their relative positional distance to each other. Therefore, for the LLM without position embeddings each token appears to have the same distance to all other tokens, e.g. differentiating between “Hello I love you” and “You love I hello” would be very challenging.

For the LLM to understand sentence order, an additional cue is needed and is usually applied in the form of positional encodings (or also called positional embeddings). Positional encodings, encode the position of each token into a numerical presentation that the LLM can leverage to better understand sentence order.

The authors of the Attention Is All You Need paper introduced sinusoidal positional embeddingsP=p1,…,pN \mathbf{P} = \mathbf{p}_1, \ldots, \mathbf{p}_N P=p1​,…,pN​ . where each vectorpi \mathbf{p}_i pi​ is computed as a sinusoidal function of its positioni i i . The positional encodings are then simply added to the input sequence vectorsX^=x^1,…,x^N \mathbf{\hat{X}} = \mathbf{\hat{x}}_1, \ldots, \mathbf{\hat{x}}_N X^=x^1​,…,x^N​ =x1+p1,…,xN+pN \mathbf{x}_1 + \mathbf{p}_1, \ldots, \mathbf{x}_N + \mathbf{p}_N x1​+p1​,…,xN​+pN​ thereby cueing the model to better learn sentence order.

Instead of using fixed position embeddings, others (such as Devlin et al.) used learned positional encodings for which the positional embeddingsP \mathbf{P} P are learned during training.

Sinusoidal and learned position embeddings used to be the predominant methods to encode sentence order into LLMs, but a couple of problems related to these positional encodings were found:

Recently, relative positional embeddings that can tackle the above mentioned problems have become more popular, most notably:

Both RoPE and ALiBi argue that it’s best to cue the LLM about sentence order directly in the self-attention algorithm as it’s there that word tokens are put into relation with each other. More specifically, sentence order should be cued by modifying theQKT \mathbf{QK}^T QKT computation.

Without going into too many details, RoPE notes that positional information can be encoded into query-key pairs, e.g.qi \mathbf{q}_i qi​ andxj \mathbf{x}_j xj​ by rotating each vector by an angleθ∗i \theta * i θ∗i andθ∗j \theta * j θ∗j respectively withi,j i, j i,j describing each vectors sentence position: q^iTx^j=qiTRθ,i−jxj. \mathbf{\hat{q}}_i^T \mathbf{\hat{x}}_j = \mathbf{{q}}_i^T \mathbf{R}_{\theta, i -j} \mathbf{{x}}_j. q^​iT​x^j​=qiT​Rθ,i−j​xj​. Rθ,i−j \mathbf{R}_{\theta, i - j} Rθ,i−j​ thereby represents a rotational matrix.θ \theta θ is not learned during training, but instead set to a pre-defined value that depends on the maximum input sequence length during training.

By doing so, the probability score betweenqi \mathbf{q}_i qi​ andqj \mathbf{q}_j qj​ is only affected ifi≠j i \ne j i=j and solely depends on the relative distancei−j i - j i−j regardless of each vector’s specific positionsi i i andj j j .

RoPE is used in multiple of today’s most important LLMs, such as:

As an alternative, ALiBi proposes a much simpler relative position encoding scheme. The relative distance that input tokens have to each other is added as a negative integer scaled by a pre-defined value m to each query-key entry of theQKT \mathbf{QK}^T QKT matrix right before the softmax computation.

As shown in the ALiBi paper, this simple relative positional encoding allows the model to retain a high performance even at very long text input sequences.

ALiBi is used in multiple of today’s most important LLMs, such as:

Both RoPE and ALiBi position encodings can extrapolate to input lengths not seen during training whereas it has been shown that extrapolation works much better out-of-the-box for ALiBi as compared to RoPE. For ALiBi, one simply increases the values of the lower triangular position matrix to match the length of the input sequence. For RoPE, keeping the sameθ \theta θ that was used during training leads to poor results when passing text inputs much longer than those seen during training, c.f Press et al.. However, the community has found a couple of effective tricks that adaptθ \theta θ, thereby allowing RoPE position embeddings to work well for extrapolated text input sequences (see here).

Both RoPE and ALiBi are relative positional embeddings that are not learned during training, but instead are based on the following intuitions:

In conclusion, LLMs that are intended to be deployed in tasks that require handling large text inputs are better trained with relative positional embeddings, such as RoPE and ALiBi. Also note that even if an LLM with RoPE and ALiBi has been trained only on a fixed length of sayN1=2048 N_1 = 2048 N1​=2048 it can still be used in practice with text inputs much larger thanN1 N_1 N1​, likeN2=8192>N1 N_2 = 8192 > N_1 N2​=8192>N1​ by extrapolating the positional embeddings.

Auto-regressive text generation with LLMs works by iteratively putting in an input sequence, sampling the next token, appending the next token to the input sequence, and continuing to do so until the LLM produces a token that signifies that the generation has finished.

Please have a look at Transformer’s Generate Text Tutorial to get a more visual explanation of how auto-regressive generation works.

Let’s run a quick code snippet to show how auto-regressive works in practice. We will simply take the most likely next token via torch.argmax.

As we can see every time we increase the text input tokens by the just sampled token.

With very few exceptions, LLMs are trained using the causal language modeling objective and therefore mask the upper triangle matrix of the attention score - this is why in the two diagrams above the attention scores are left blank (a.k.a have 0 probability). For a quick recap on causal language modeling you can refer to the Illustrated Self Attention blog.

As a consequence, tokens never depend on previous tokens, more specifically theqi \mathbf{q}_i qi​ vector is never put in relation with any key, values vectorskj,vj \mathbf{k}_j, \mathbf{v}_j kj​,vj​ ifj>i j > i j>i . Insteadqi \mathbf{q}_i qi​ only attends to previous key-value vectorskm<i,vm<i , for m∈{0,…i−1} \mathbf{k}_{m < i}, \mathbf{v}_{m < i} \text{ , for } m \in \{0, \ldots i - 1\} km<i​,vm<i​ , for m∈{0,…i−1}. In order to reduce unnecessary computation, one can therefore cache each layer’s key-value vectors for all previous timesteps.

In the following, we will tell the LLM to make use of the key-value cache by retrieving and forwarding it for each forward pass. In Transformers, we can retrieve the key-value cache by passing the use_cache flag to the forward call and can then pass it with the current token.

As one can see, when using the key-value cache the text input tokens are not increased in length, but remain a single input vector. The length of the key-value cache on the other hand is increased by one at every decoding step.

Making use of the key-value cache means that theQKT \mathbf{QK}^T QKT is essentially reduced toqcKT \mathbf{q}_c\mathbf{K}^T qc​KT withqc \mathbf{q}_c qc​ being the query projection of the currently passed input token which is always just a single vector.

Using the key-value cache has two advantages:

One should always make use of the key-value cache as it leads to identical results and a significant speed-up for longer input sequences. Transformers has the key-value cache enabled by default when making use of the text pipeline or the generate method. We have an entire guide dedicated to caches here.

Note that, despite our advice to use key-value caches, your LLM output may be slightly different when you use them. This is a property of the matrix multiplication kernels themselves — you can read more about it here.

The key-value cache is especially useful for applications such as chat where multiple passes of auto-regressive decoding are required. Let’s look at an example.

In this chat, the LLM runs auto-regressive decoding twice:

Two things should be noted here:

In transformers, a generate call will return past_key_values when return_dict_in_generate=True is passed, in addition to the default use_cache=True. Note that it is not yet available through the pipeline interface.

Great, no additional time is spent recomputing the same key and values for the attention layer! There is however one catch. While the required peak memory for theQKT \mathbf{QK}^T QKT matrix is significantly reduced, holding the key-value cache in memory can become very memory expensive for long input sequences or multi-turn chat. Remember that the key-value cache needs to store the key-value vectors for all previous input vectorsxi, for i∈{1,…,c−1} \mathbf{x}_i \text{, for } i \in \{1, \ldots, c - 1\} xi​, for i∈{1,…,c−1} for all self-attention layers and for all attention heads.

Let’s compute the number of float values that need to be stored in the key-value cache for the LLM bigcode/octocoder that we used before. The number of float values amounts to two times the sequence length times the number of attention heads times the attention head dimension and times the number of layers. Computing this for our LLM at a hypothetical input sequence length of 16000 gives:

Roughly 8 billion float values! Storing 8 billion float values in float16 precision requires around 15 GB of RAM which is circa half as much as the model weights themselves! Researchers have proposed two methods that allow to significantly reduce the memory cost of storing the key-value cache, which are explored in the next subsections.

Multi-Query-Attention was proposed in Noam Shazeer’s Fast Transformer Decoding: One Write-Head is All You Need paper. As the title says, Noam found out that instead of using n_head key-value projections weights, one can use a single head-value projection weight pair that is shared across all attention heads without that the model’s performance significantly degrades.

By using a single head-value projection weight pair, the key value vectorski,vi \mathbf{k}_i, \mathbf{v}_i ki​,vi​ have to be identical across all attention heads which in turn means that we only need to store 1 key-value projection pair in the cache instead of n_head ones.

As most LLMs use between 20 and 100 attention heads, MQA significantly reduces the memory consumption of the key-value cache. For the LLM used in this notebook we could therefore reduce the required memory consumption from 15 GB to less than 400 MB at an input sequence length of 16000.

In addition to memory savings, MQA also leads to improved computational efficiency as explained in the following. In auto-regressive decoding, large key-value vectors need to be reloaded, concatenated with the current key-value vector pair to be then fed into theqcKT \mathbf{q}_c\mathbf{K}^T qc​KT computation at every step. For auto-regressive decoding, the required memory bandwidth for the constant reloading can become a serious time bottleneck. By reducing the size of the key-value vectors less memory needs to be accessed, thus reducing the memory bandwidth bottleneck. For more detail, please have a look at Noam’s paper.

The important part to understand here is that reducing the number of key-value attention heads to 1 only makes sense if a key-value cache is used. The peak memory consumption of the model for a single forward pass without key-value cache stays unchanged as every attention head still has a unique query vector so that each attention head still has a differentQKT \mathbf{QK}^T QKT matrix.

MQA has seen wide adoption by the community and is now used by many of the most popular LLMs:

Also, the checkpoint used in this notebook - bigcode/octocoder - makes use of MQA.

Grouped-Query-Attention, as proposed by Ainslie et al. from Google, found that using MQA can often lead to quality degradation compared to using vanilla multi-key-value head projections. The paper argues that more model performance can be kept by less drastically reducing the number of query head projection weights. Instead of using just a single key-value projection weight, n < n_head key-value projection weights should be used. By choosing n to a significantly smaller value than n_head, such as 2,4 or 8 almost all of the memory and speed gains from MQA can be kept while sacrificing less model capacity and thus arguably less performance.

Moreover, the authors of GQA found out that existing model checkpoints can be uptrained to have a GQA architecture with as little as 5% of the original pre-training compute. While 5% of the original pre-training compute can still be a massive amount, GQA uptraining allows existing checkpoints to be useful for longer input sequences.

GQA was only recently proposed which is why there is less adoption at the time of writing this notebook. The most notable application of GQA is Llama-v2.

As a conclusion, it is strongly recommended to make use of either GQA or MQA if the LLM is deployed with auto-regressive decoding and is required to handle large input sequences as is the case for example for chat.

The research community is constantly coming up with new, nifty ways to speed up inference time for ever-larger LLMs. As an example, one such promising research direction is speculative decoding where “easy tokens” are generated by smaller, faster language models and only “hard tokens” are generated by the LLM itself. Going into more detail is out of the scope of this notebook, but can be read upon in this nice blog post.

The reason massive LLMs such as GPT3/4, Llama-2-70b, Claude, PaLM can run so quickly in chat-interfaces such as Hugging Face Chat or ChatGPT is to a big part thanks to the above-mentioned improvements in precision, algorithms, and architecture. Going forward, accelerators such as GPUs, TPUs, etc… will only get faster and allow for more memory, but one should nevertheless always make sure to use the best available algorithms and architectures to get the most bang for your buck 🤗

**Examples:**

Example 1 (unknown):
```unknown
base_tp_plan
```

Example 2 (unknown):
```unknown
device="auto"
```

Example 3 (unknown):
```unknown
device_map="auto"
```

Example 4 (unknown):
```unknown
bigcode/octocoder
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/data_collator

**Contents:**
- Transformers
- Data Collator
- Default data collator
    - transformers.default_data_collator
- DefaultDataCollator
  - class transformers.DefaultDataCollator
- DataCollatorWithPadding
  - class transformers.DataCollatorWithPadding
- DataCollatorForTokenClassification
  - class transformers.DataCollatorForTokenClassification

Transformers documentation

and get access to the augmented documentation experience

Data collators are objects that will form a batch by using a list of dataset elements as input. These elements are of the same type as the elements of train_dataset or eval_dataset.

To be able to build batches, data collators may apply some processing (like padding). Some of them (like DataCollatorForLanguageModeling) also apply some random data augmentation (like random masking) on the formed batch.

Examples of use can be found in the example scripts or example notebooks.

( features: list return_tensors = 'pt' )

Very simple data collator that simply collates batches of dict-like objects and performs special handling for potential keys named:

Does not do any additional preprocessing: property names of the input object will be used as corresponding inputs to the model. See glue and ner for example of how it’s useful.

( return_tensors: str = 'pt' )

Very simple data collator that simply collates batches of dict-like objects and performs special handling for potential keys named:

Does not do any additional preprocessing: property names of the input object will be used as corresponding inputs to the model. See glue and ner for example of how it’s useful.

This is an object (like other data collators) rather than a pure function like default_data_collator. This can be helpful if you need to set a return_tensors value at initialization.

( tokenizer: PreTrainedTokenizerBase padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None return_tensors: str = 'pt' )

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.0 (Volta).

Data collator that will dynamically pad the inputs received.

( tokenizer: PreTrainedTokenizerBase padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None label_pad_token_id: int = -100 return_tensors: str = 'pt' )

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.0 (Volta).

Data collator that will dynamically pad the inputs received, as well as the labels.

( tokenizer: PreTrainedTokenizerBase model: typing.Optional[typing.Any] = None padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None label_pad_token_id: int = -100 return_tensors: str = 'pt' )

This is useful when using label_smoothing to avoid calculating loss twice.

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.0 (Volta).

Data collator that will dynamically pad the inputs received, as well as the labels.

( tokenizer: PreTrainedTokenizerBase mlm: bool = True whole_word_mask: bool = False mlm_probability: typing.Optional[float] = 0.15 mask_replace_prob: float = 0.8 random_replace_prob: float = 0.1 pad_to_multiple_of: typing.Optional[int] = None tf_experimental_compile: bool = False return_tensors: str = 'pt' seed: typing.Optional[int] = None )

Data collator used for language modeling. Inputs are dynamically padded to the maximum length of a batch if they are not all of the same length.

For best performance, this data collator should be used with a dataset having items that are dictionaries or BatchEncoding, with the "special_tokens_mask" key, as returned by a PreTrainedTokenizer or a PreTrainedTokenizerFast with the argument return_special_tokens_mask=True.

All masked tokens replaced by [MASK]:

No [MASK] replacement, only random tokens:

Balanced replacement:

Note: The sum of mask_replace_prob and random_replace_prob must not exceed 1. If their sum is less than 1, the remaining proportion will consist of masked tokens left unchanged.

( inputs: typing.Any special_tokens_mask: typing.Optional[typing.Any] = None offset_mapping: typing.Optional[typing.Any] = None )

Prepare masked tokens inputs/labels for masked language modeling.

( inputs: typing.Any special_tokens_mask: typing.Optional[typing.Any] = None offset_mapping: typing.Optional[typing.Any] = None )

Prepare masked tokens inputs/labels for masked language modeling.

Data collator used for language modeling that masks entire words.

This collator relies on details of the implementation of subword tokenization by BertTokenizer, specifically that subword tokens are prefixed with ##. For tokenizers that do not adhere to this scheme, this collator will produce an output that is roughly equivalent to .DataCollatorForLanguageModeling.

( inputs: typing.Any mask_labels: typing.Any )

Prepare masked tokens inputs/labels for masked language modeling: 80% MASK, 10% random, 10% original. Set ‘mask_labels’ means we use whole word mask (wwm), we directly mask idxs according to it’s ref.

( inputs: typing.Any mask_labels: typing.Any )

Prepare masked tokens inputs/labels for masked language modeling: 80% MASK, 10% random, 10% original. Set ‘mask_labels’ means we use whole word mask (wwm), we directly mask idxs according to it’s ref.

( tokenizer: PreTrainedTokenizerBase plm_probability: float = 0.16666666666666666 max_span_length: int = 5 return_tensors: str = 'pt' )

Data collator used for permutation language modeling.

( inputs: typing.Any )

The masked tokens to be predicted for a particular sequence are determined by the following algorithm:

( inputs: typing.Any )

The masked tokens to be predicted for a particular sequence are determined by the following algorithm:

( *args return_position_ids = True separator_id = -100 return_flash_attn_kwargs = False return_seq_idx = False **kwargs )

Data collator used for padding free approach. Does the following:

Using DataCollatorWithFlattening will flatten the entire mini batch into single long sequence. Make sure your attention computation is able to handle it!

( tokenizer: PreTrainedTokenizerBase padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None return_tensors: str = 'pt' )

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta).

Data collator that dynamically pads a batch of nested examples for multiple choice, so that all choices of all examples have the same length.

**Examples:**

Example 1 (unknown):
```unknown
train_dataset
```

Example 2 (unknown):
```unknown
eval_dataset
```

Example 3 (unknown):
```unknown
'max_length'
```

Example 4 (unknown):
```unknown
'do_not_pad'
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/image_processor

**Contents:**
- Transformers
- Image Processor
- ImageProcessingMixin
  - class transformers.ImageProcessingMixin
    - from_pretrained
    - save_pretrained
- BatchFeature
  - class transformers.BatchFeature
    - convert_to_tensors
    - to

Transformers documentation

and get access to the augmented documentation experience

An image processor is in charge of loading images (optionally), preparing input features for vision models and post processing their outputs. This includes transformations such as resizing, normalization, and conversion to PyTorch and Numpy tensors. It may also include model specific post-processing such as converting logits to segmentation masks. Fast image processors are available for a few models and more will be added in the future. They are based on the torchvision library and provide a significant speed-up, especially when processing on GPU. They have the same API as the base image processors and can be used as drop-in replacements. To use a fast image processor, you need to install the torchvision library, and set the use_fast argument to True when instantiating the image processor:

Note that use_fast will be set to True by default in a future release.

When using a fast image processor, you can also set the device argument to specify the device on which the processing should be done. By default, the processing is done on the same device as the inputs if the inputs are tensors, or on the CPU otherwise.

Here are some speed comparisons between the base and fast image processors for the DETR and RT-DETR models, and how they impact overall inference time:

These benchmarks were run on an AWS EC2 g5.2xlarge instance, utilizing an NVIDIA A10G Tensor Core GPU.

This is an image processor mixin used to provide saving/loading functionality for sequential and image feature extractors.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a type of ImageProcessingMixin from an image processor.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save an image processor object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

( data: typing.Optional[dict[str, typing.Any]] = None tensor_type: typing.Union[NoneType, str, transformers.utils.generic.TensorType] = None )

Holds the output of the pad() and feature extractor specific __call__ methods.

This class is derived from a python dictionary and can be used as a dictionary.

( tensor_type: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None )

Convert the inner content to tensors.

( *args **kwargs ) → BatchFeature

The same instance after modification.

The same instance after modification.

Send all values to device by calling v.to(*args, **kwargs) (PyTorch only). This should support casting in different dtypes and sending the BatchFeature to a different device.

( image: ndarray size: dict data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None input_data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None **kwargs )

Center crop an image to (size["height"], size["width"]). If the input size is smaller than crop_size along any edge, the image is padded with 0’s and then center cropped.

( image: ndarray mean: typing.Union[float, collections.abc.Iterable[float]] std: typing.Union[float, collections.abc.Iterable[float]] data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None input_data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None **kwargs ) → np.ndarray

The normalized image.

The normalized image.

Normalize an image. image = (image - image_mean) / image_std.

( image: ndarray scale: float data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None input_data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None **kwargs ) → np.ndarray

Rescale an image by a scale factor. image = image * scale.

( **kwargs: typing_extensions.Unpack[transformers.image_processing_utils_fast.DefaultFastImageProcessorKwargs] )

( image: torch.Tensor size: SizeDict **kwargs ) → torch.Tensor

The center cropped image.

The center cropped image.

Note: override torchvision’s center_crop to have the same behavior as the slow processor. Center crop an image to (size["height"], size["width"]). If the input size is smaller than crop_size along any edge, the image is padded with 0’s and then center cropped.

( image: torch.Tensor new_size: tuple interpolation: typing.Optional[ForwardRef('F.InterpolationMode')] = None antialias: bool = True )

A wrapper around F.resize so that it is compatible with torch.compile when the image is a uint8 tensor.

( image: typing.Union[ForwardRef('PIL.Image.Image'), numpy.ndarray, ForwardRef('torch.Tensor'), list['PIL.Image.Image'], list[numpy.ndarray], list['torch.Tensor']] ) → ImageInput

Converts an image to RGB format. Only converts if the image is of type PIL.Image.Image, otherwise returns the image as is.

Filter out the unused kwargs from the kwargs dictionary.

( image: torch.Tensor mean: typing.Union[float, collections.abc.Iterable[float]] std: typing.Union[float, collections.abc.Iterable[float]] **kwargs ) → torch.Tensor

The normalized image.

The normalized image.

Normalize an image. image = (image - image_mean) / image_std.

( images: torch.Tensor pad_size: SizeDict = None fill_value: typing.Optional[int] = 0 padding_mode: typing.Optional[str] = 'constant' return_mask: bool = False disable_grouping: typing.Optional[bool] = False **kwargs ) → torch.Tensor

Pads images to (pad_size["height"], pad_size["width"]) or to the largest size in the batch.

( images: typing.Union[ForwardRef('PIL.Image.Image'), numpy.ndarray, ForwardRef('torch.Tensor'), list['PIL.Image.Image'], list[numpy.ndarray], list['torch.Tensor']] *args **kwargs: typing_extensions.Unpack[transformers.image_processing_utils_fast.DefaultFastImageProcessorKwargs] ) → <class 'transformers.image_processing_base.BatchFeature'>

<class 'transformers.image_processing_base.BatchFeature'>

data (dict) — Dictionary of lists/arrays/tensors returned by the call method (‘pixel_values’, etc.). tensor_type (Union[None, str, TensorType], optional) — You can give a tensor_type here to convert the lists of integers in PyTorch/TensorFlow/Numpy Tensors at initialization.

( image: torch.Tensor scale: float **kwargs ) → torch.Tensor

Rescale an image by a scale factor. image = image * scale.

( images: torch.Tensor do_rescale: bool rescale_factor: float do_normalize: bool image_mean: typing.Union[float, list[float]] image_std: typing.Union[float, list[float]] )

Rescale and normalize images.

( image: torch.Tensor size: SizeDict interpolation: typing.Optional[ForwardRef('F.InterpolationMode')] = None antialias: bool = True **kwargs ) → torch.Tensor

Resize an image to (size["height"], size["width"]).

**Examples:**

Example 1 (unknown):
```unknown
torchvision
```

Example 2 (unknown):
```unknown
os.PathLike
```

Example 3 (unknown):
```unknown
./my_model_directory/
```

Example 4 (unknown):
```unknown
./my_model_directory/preprocessor_config.json
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/configuration

**Contents:**
- Transformers
- Configuration
- PretrainedConfig
  - class transformers.PretrainedConfig
    - push_to_hub
    - dict_dtype_to_str
    - from_dict
    - from_json_file
    - from_pretrained
    - from_text_audio_configs

Transformers documentation

and get access to the augmented documentation experience

The base class PretrainedConfig implements the common methods for loading/saving a configuration either from a local file or directory, or from a pretrained model configuration provided by the library (downloaded from HuggingFace’s AWS S3 repository).

Each derived config class implements model specific attributes. Common attributes present in all config classes are: hidden_size, num_attention_heads, and num_hidden_layers. Text models further implement: vocab_size.

( output_hidden_states: bool = False output_attentions: bool = False return_dict: bool = True torchscript: bool = False dtype: typing.Union[str, ForwardRef('torch.dtype'), NoneType] = None pruned_heads: typing.Optional[dict[int, list[int]]] = None tie_word_embeddings: bool = True chunk_size_feed_forward: int = 0 is_encoder_decoder: bool = False is_decoder: bool = False cross_attention_hidden_size: typing.Optional[int] = None add_cross_attention: bool = False tie_encoder_decoder: bool = False architectures: typing.Optional[list[str]] = None finetuning_task: typing.Optional[str] = None id2label: typing.Optional[dict[int, str]] = None label2id: typing.Optional[dict[str, int]] = None num_labels: typing.Optional[int] = None task_specific_params: typing.Optional[dict[str, typing.Any]] = None problem_type: typing.Optional[str] = None tokenizer_class: typing.Optional[str] = None prefix: typing.Optional[str] = None bos_token_id: typing.Optional[int] = None pad_token_id: typing.Optional[int] = None eos_token_id: typing.Optional[int] = None sep_token_id: typing.Optional[int] = None decoder_start_token_id: typing.Optional[int] = None **kwargs )

For instance {1: [0, 2], 2: [2, 3]} will prune heads 0 and 2 on layer 1 and heads 2 and 3 on layer 2.

Parameters for fine-tuning tasks

Parameters linked to the tokenizer

PyTorch specific parameters

Base class for all configuration classes. Handles a few parameters common to all models’ configurations as well as methods for loading/downloading/saving configurations.

A configuration file can be loaded and saved to disk. Loading the configuration file and using this file to initialize a model does not load the model weights. It only affects the model’s configuration.

Class attributes (overridden by derived classes):

Common attributes (present in all subclasses):

Setting parameters for sequence generation in the model config is deprecated. For backward compatibility, loading some of them will still be possible, but attempting to overwrite them will throw an exception — you should set them in a [~transformers.GenerationConfig]. Check the documentation of [~transformers.GenerationConfig] for more information about the individual parameters.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the configuration file to the 🤗 Model Hub.

Checks whether the passed dictionary and its nested dicts have a dtype key and if it’s not None, converts torch.dtype to a string of just the type. For example, torch.float32 get converted into “float32” string, which can then be stored in the json format.

( config_dict: dict **kwargs ) → PretrainedConfig

The configuration object instantiated from those parameters.

The configuration object instantiated from those parameters.

Instantiates a PretrainedConfig from a Python dictionary of parameters.

( json_file: typing.Union[str, os.PathLike] ) → PretrainedConfig

The configuration object instantiated from that JSON file.

The configuration object instantiated from that JSON file.

Instantiates a PretrainedConfig from the path to a JSON file of parameters.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[bool, str, NoneType] = None revision: str = 'main' **kwargs ) → PretrainedConfig

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

If True, then this functions returns a Tuple(config, unused_kwargs) where unused_kwargs is a dictionary consisting of the key/value pairs whose keys are not configuration attributes: i.e., the part of kwargs which has not been used to update config and is otherwise ignored.

The configuration object instantiated from this pretrained model.

The configuration object instantiated from this pretrained model.

Instantiate a PretrainedConfig (or a derived class) from a pretrained model configuration.

( text_config audio_config **kwargs ) → PreTrainedConfig

An instance of a configuration object

An instance of a configuration object

Instantiate a model config (or a derived class) from text model configuration and audio model configuration.

( text_config vision_config **kwargs ) → PreTrainedConfig

An instance of a configuration object

An instance of a configuration object

Instantiate a model config (or a derived class) from text model configuration and vision model configuration.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] **kwargs ) → tuple[Dict, Dict]

The dictionary(ies) that will be used to instantiate the configuration object.

The dictionary(ies) that will be used to instantiate the configuration object.

From a pretrained_model_name_or_path, resolve to a dictionary of parameters, to be used for instantiating a PretrainedConfig using from_dict.

( decoder = None encoder = None )

Returns the text config related to the text input (encoder) or text output (decoder) of the model. The decoder and encoder input arguments can be used to specify which end of the model we are interested in, which is useful on models that have both text input and output modalities.

There are three possible outcomes of using this method:

( auto_class = 'AutoConfig' )

Register this class with a given auto class. This should only be used for custom configurations as the ones in the library are already mapped with AutoConfig.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save a configuration object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

Dictionary of all the attributes that make up this configuration instance.

Dictionary of all the attributes that make up this configuration instance.

Serializes this instance to a Python dictionary.

Dictionary of all the attributes that make up this configuration instance.

Dictionary of all the attributes that make up this configuration instance.

Removes all attributes from the configuration that correspond to the default config attributes for better readability, while always retaining the config attribute from the class. Serializes to a Python dictionary.

( json_file_path: typing.Union[str, os.PathLike] use_diff: bool = True )

Save this instance to a JSON file.

( use_diff: bool = True ) → str

String containing all the attributes that make up this configuration instance in JSON format.

String containing all the attributes that make up this configuration instance in JSON format.

Serializes this instance to a JSON string.

( config_dict: dict )

Updates attributes of this class with attributes from config_dict.

Updates attributes of this class with attributes from update_str.

The expected format is ints, floats and strings as is, and for booleans use true or false. For example: “n_embd=10,resid_pdrop=0.2,scale_attn_weights=false,summary_type=cls_index”

The keys to change have to already exist in the config object.

**Examples:**

Example 1 (unknown):
```unknown
hidden_size
```

Example 2 (unknown):
```unknown
num_attention_heads
```

Example 3 (unknown):
```unknown
num_hidden_layers
```

Example 4 (unknown):
```unknown
TFPreTrainedModel.from_pretrained()
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/models_timeline

**Contents:**
- Transformers
- Models Timeline

Transformers documentation

and get access to the augmented documentation experience

The Models Timeline is an interactive chart of how architectures in Transformers have changed over time. You can scroll through models in order, spanning text, vision, audio, video, and multimodal use cases.

Use the filters to narrow models by modality or task. Set custom date ranges to focus on models added during specific periods. Click a model card to see its capabilities, supported tasks, and documentation.

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/training

**Contents:**
- Transformers
- Fine-tuning
- Trainer
- Resources

Transformers documentation

and get access to the augmented documentation experience

Fine-tuning adapts a pretrained model to a specific task with a smaller specialized dataset. This approach requires far less data and compute compared to training a model from scratch, which makes it a more accessible option for many users.

Transformers provides the Trainer API, which offers a comprehensive set of training features, for fine-tuning any of the models on the Hub.

Learn how to fine-tune models for other tasks in our Task Recipes section in Resources!

This guide will show you how to fine-tune a model with Trainer to classify Yelp reviews.

Log in to your Hugging Face account with your user token to ensure you can access gated models and share your models on the Hub.

Start by loading the Yelp Reviews dataset and preprocess (tokenize, pad, and truncate) it for training. Use map to preprocess the entire dataset in one step.

Fine-tune on a smaller subset of the full dataset to reduce the time it takes. The results won’t be as good compared to fine-tuning on the full dataset, but it is useful to make sure everything works as expected first before committing to training on the full dataset.

Trainer is an optimized training loop for Transformers models, making it easy to start training right away without manually writing your own training code. Pick and choose from a wide range of training features in TrainingArguments such as gradient accumulation, mixed precision, and options for reporting and logging training metrics.

Load a model and provide the number of expected labels (you can find this information on the Yelp Review dataset card).

The message above is a reminder that the models pretrained head is discarded and replaced with a randomly initialized classification head. The randomly initialized head needs to be fine-tuned on your specific task to output meaningful predictions.

With the model loaded, set up your training hyperparameters in TrainingArguments. Hyperparameters are variables that control the training process - such as the learning rate, batch size, number of epochs - which in turn impacts model performance. Selecting the correct hyperparameters is important and you should experiment with them to find the best configuration for your task.

For this guide, you can use the default hyperparameters which provide a good baseline to begin with. The only settings to configure in this guide are where to save the checkpoint, how to evaluate model performance during training, and pushing the model to the Hub.

Trainer requires a function to compute and report your metric. For a classification task, you’ll use evaluate.load to load the accuracy function from the Evaluate library. Gather the predictions and labels in compute to calculate the accuracy.

Set up TrainingArguments with where to save the model and when to compute accuracy during training. The example below sets it to "epoch", which reports the accuracy at the end of each epoch. Add push_to_hub=True to upload the model to the Hub after training.

Create a Trainer instance and pass it the model, training arguments, training and test datasets, and evaluation function. Call train() to start training.

Finally, use push_to_hub() to upload your model and tokenizer to the Hub.

Refer to the Transformers examples for more detailed training scripts on various tasks. You can also check out the notebooks for interactive examples.

**Examples:**

Example 1 (unknown):
```unknown
push_to_hub=True
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/logging

**Contents:**
- Transformers
- Logging
- logging vs warnings
    - transformers.utils.logging.captureWarnings
- Base setters
    - transformers.utils.logging.set_verbosity_error
    - transformers.utils.logging.set_verbosity_warning
    - transformers.utils.logging.set_verbosity_info
    - transformers.utils.logging.set_verbosity_debug
- Other functions

Transformers documentation

and get access to the augmented documentation experience

🤗 Transformers has a centralized logging system, so that you can setup the verbosity of the library easily.

Currently the default verbosity of the library is WARNING.

To change the level of verbosity, just use one of the direct setters. For instance, here is how to change the verbosity to the INFO level.

You can also use the environment variable TRANSFORMERS_VERBOSITY to override the default verbosity. You can set it to one of the following: debug, info, warning, error, critical, fatal. For example:

Additionally, some warnings can be disabled by setting the environment variable TRANSFORMERS_NO_ADVISORY_WARNINGS to a true value, like 1. This will disable any warning that is logged using logger.warning_advice. For example:

Here is an example of how to use the same logger as the library in your own module or script:

All the methods of this logging module are documented below, the main ones are logging.get_verbosity() to get the current level of verbosity in the logger and logging.set_verbosity() to set the verbosity to the level of your choice. In order (from the least verbose to the most verbose), those levels (with their corresponding int values in parenthesis) are:

By default, tqdm progress bars will be displayed during model download. logging.disable_progress_bar() and logging.enable_progress_bar() can be used to suppress or unsuppress this behavior.

Python has two logging systems that are often used in conjunction: logging, which is explained above, and warnings, which allows further classification of warnings in specific buckets, e.g., FutureWarning for a feature or path that has already been deprecated and DeprecationWarning to indicate an upcoming deprecation.

We use both in the transformers library. We leverage and adapt logging’s captureWarnings method to allow management of these warning messages by the verbosity setters above.

What does that mean for developers of the library? We should respect the following heuristics:

See reference of the captureWarnings method below.

Calls the captureWarnings method from the logging library to enable management of the warnings emitted by the warnings library.

Read more about this method here: https://docs.python.org/3/library/logging.html#integration-with-the-warnings-module

All warnings will be logged through the py.warnings logger.

Careful: this method also adds a handler to this logger if it does not already have one, and updates the logging level of that logger to the library’s root logger.

Set the verbosity to the ERROR level.

Set the verbosity to the WARNING level.

Set the verbosity to the INFO level.

Set the verbosity to the DEBUG level.

Return the current level for the 🤗 Transformers’s root logger as an int.

🤗 Transformers has following logging levels:

Set the verbosity level for the 🤗 Transformers’s root logger.

( name: typing.Optional[str] = None )

Return a logger with the specified name.

This function is not supposed to be directly accessed unless you are writing a custom transformers module.

Enable the default handler of the HuggingFace Transformers’s root logger.

Disable the default handler of the HuggingFace Transformers’s root logger.

Enable explicit formatting for every HuggingFace Transformers’s logger. The explicit formatter is as follows:

Resets the formatting for HuggingFace Transformers’s loggers.

All handlers currently bound to the root logger are affected by this method.

Enable tqdm progress bar.

Disable tqdm progress bar.

**Examples:**

Example 1 (unknown):
```unknown
TRANSFORMERS_VERBOSITY
```

Example 2 (unknown):
```unknown
TRANSFORMERS_NO_ADVISORY_WARNINGS
```

Example 3 (unknown):
```unknown
logger.warning_advice
```

Example 4 (unknown):
```unknown
transformers.logging.CRITICAL
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/model

**Contents:**
- Transformers
- Models
- PreTrainedModel
  - class transformers.PreTrainedModel
    - push_to_hub
    - add_model_tags
    - can_generate
    - dequantize
    - disable_input_require_grads
    - enable_input_require_grads

Transformers documentation

and get access to the augmented documentation experience

The base class PreTrainedModel implements the common methods for loading/saving a model either from a local file or directory, or from a pretrained model configuration provided by the library (downloaded from HuggingFace’s Hub).

PreTrainedModel also implements a few methods which are common among all the models to:

The other methods that are common to each model are defined in ModuleUtilsMixin and GenerationMixin.

( config: PretrainedConfig *inputs **kwargs )

Base class for all models.

PreTrainedModel takes care of storing the configuration of the models and handles methods for loading, downloading and saving models as well as a few methods common to all models to:

Class attributes (overridden by derived classes):

config_class (PretrainedConfig) — A subclass of PretrainedConfig to use as configuration class for this model architecture.

load_tf_weights (Callable) — A python method for loading a TensorFlow checkpoint in a PyTorch model, taking as arguments:

base_model_prefix (str) — A string indicating the attribute associated to the base model in derived classes of the same architecture adding modules on top of the base model.

is_parallelizable (bool) — A flag indicating whether this model supports model parallelization.

main_input_name (str) — The name of the principal input to the model (often input_ids for NLP models, pixel_values for vision models and input_values for speech models).

can_record_outputs (dict):

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the model file to the 🤗 Model Hub.

( tags: typing.Union[list[str], str] )

Add custom tags into the model that gets pushed to the Hugging Face Hub. Will not overwrite existing tags in the model.

Whether this model can generate sequences with .generate().

Whether this model can generate sequences with .generate().

Returns whether this model can generate sequences with .generate() from the GenerationMixin.

Under the hood, on classes where this function returns True, some generation-specific changes are triggered: for instance, the model instance will have a populated generation_config attribute.

Potentially dequantize the model in case it has been quantized by a quantization method that support dequantization.

Removes the _require_grads_hook.

Enables the gradients for the input embeddings. This is useful for fine-tuning adapter weights while keeping the model weights fixed.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike, NoneType] *model_args config: typing.Union[transformers.configuration_utils.PretrainedConfig, str, os.PathLike, NoneType] = None cache_dir: typing.Union[str, os.PathLike, NoneType] = None ignore_mismatched_sizes: bool = False force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' use_safetensors: typing.Optional[bool] = None weights_only: bool = True **kwargs )

Configuration for the model to use instead of an automatically loaded configuration. Configuration can be automatically loaded when:

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

Accept HF kernel references in the form:

Examples that match: “org/model” “org/model@main” “org/model:custom_kernel” “org/model@v1.2.3:custom_kernel”

Parameters for big model inference

torch.float16 or torch.bfloat16 or torch.float: load in a specified dtype, ignoring the model’s config.dtype if one exists. If not specified

"auto" - A dtype or torch_dtype entry in the config.json file of the model will be attempted to be used. If this entry isn’t found then next check the dtype of the first weight in the checkpoint that’s of a floating point type and use that as dtype. This will load the model using the dtype it was saved in at the end of the training. It can’t be used as an indicator of how the model was trained. Since it could be trained in one of half precision dtypes, but saved in fp32.

A string that is a valid torch.dtype. E.g. “float32” loads the model in torch.float32, “float16” loads in torch.float16 etc.

For some models the dtype they were trained in is unknown - you may try to check the model’s paper or reach out to the authors and ask them to add this information to the model’s card and to insert the dtype or torch_dtype entry in config.json on the hub.

To have Accelerate compute the most optimized device_map automatically, set device_map="auto". For more information about each option see designing a device map.

Instantiate a pretrained pytorch model from a pre-trained model configuration.

The model is set in evaluation mode by default using model.eval() (Dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train().

The warning Weights from XXX not initialized from pretrained model means that the weights of XXX do not come pretrained with the rest of the model. It is up to you to train those weights with a downstream fine-tuning task.

The warning Weights from XXX not used in YYY means that the layer XXX is not used by YYY, therefore those weights are discarded.

Activate the special “offline-mode” to use this method in a firewalled environment.

( compile_config: typing.Optional[transformers.generation.configuration_utils.CompileConfig] )

Return a torch.compile‘d version of self.__call__. This is useful to dynamically choose between non-compiled/compiled forward during inference, especially to switch between prefill (where we don’t want to use compiled version to avoid recomputing the graph with new shapes) and iterative decoding (where we want the speed-ups of compiled version with static shapes).

Best-effort lookup of the decoder module.

Order of attempts (covers ~85 % of current usages):

( return_buffers = True )

Get the memory footprint of a model. This will return the memory footprint of the current model in bytes. Useful to benchmark the memory footprint of the current model and design some tests. Solution inspired from the PyTorch discussions: https://discuss.pytorch.org/t/gpu-memory-that-model-uses/56822/2

Return the parameter or buffer given by target if it exists, otherwise throw an error. This combines get_parameter() and get_buffer() in a single handy function. If the target is an _extra_state attribute, it will return the extra state provided by the module. Note that it only work if target is a leaf of the model.

Deactivates gradient checkpointing for the current model.

Note that in other frameworks this feature can be referred to as “activation checkpointing” or “checkpoint activations”.

( gradient_checkpointing_kwargs = None )

Activates gradient checkpointing for the current model.

Note that in other frameworks this feature can be referred to as “activation checkpointing” or “checkpoint activations”.

We pass the __call__ method of the modules instead of forward because __call__ attaches all the hooks of the module. https://discuss.pytorch.org/t/any-different-between-model-input-and-model-forward-input/3690/2

If needed prunes and maybe initializes weights. If using a custom PreTrainedModel, you need to implement any initialization logic in _init_weights.

This is equivalent to calling self.apply(self._initialize_weights), but correctly handles composite models. This function dynamically dispatches the correct init_weights function to the modules as we advance in the module graph along the recursion. It can handle an arbitrary number of sub-models. Without it, every composite model would have to recurse a second time on all sub-models explicitly in the outer-most _init_weights, which is extremely error prone and inefficient.

Note that the torch.no_grad() decorator is very important as well, as most of our _init_weights do not use torch.nn.init functions (which are all nograd by default), but simply do in-place ops such as `module.weight.data.zero()`.

A method executed at the end of each Transformer model initialization, to execute code that needs the model’s modules properly initialized (such as weight initialization).

This is also used when the user is running distributed code. We add hooks to the modules here, according to the model’s tp_plan!

( heads_to_prune: dict )

Prunes heads of the base model.

( auto_class = 'AutoModel' )

Register this class with a given auto class. This should only be used for custom models as the ones in the library are already mapped with an auto class.

( new_num_tokens: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None mean_resizing: bool = True ) → torch.nn.Embedding

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta), or on TPUs which benefit from having sequence lengths be a multiple of 128. For more details about this, or help on choosing the correct value for resizing, refer to this guide: https://docs.nvidia.com/deeplearning/performance/dl-performance-matrix-multiplication/index.html#requirements-tc

Setting mean_resizing to True is useful when increasing the size of the embeddings of causal language models, where the generated tokens’ probabilities won’t be affected by the added embeddings because initializing the new embeddings with the old embeddings’ mean will reduce the kl-divergence between the next token probability before and after adding the new embeddings. Refer to this article for more information: https://nlp.stanford.edu/~johnhew/vocab-expansion.html

Pointer to the input tokens Embeddings Module of the model.

Pointer to the input tokens Embeddings Module of the model.

Resizes input token embeddings matrix of the model if new_num_tokens != config.vocab_size.

Takes care of tying weights embeddings afterwards if the model class has a tie_weights() method.

( ) → PreTrainedModel

The model converted back to the original modeling.

The model converted back to the original modeling.

Reverts the transformation from to_bettertransformer() so that the original modeling is used, for example in order to save the model.

( save_directory: typing.Union[str, os.PathLike] is_main_process: bool = True state_dict: typing.Optional[dict] = None save_function: typing.Callable = <function save at 0x7f6429f34550> push_to_hub: bool = False max_shard_size: typing.Union[int, str] = '5GB' safe_serialization: bool = True variant: typing.Optional[str] = None token: typing.Union[str, bool, NoneType] = None save_peft_format: bool = True **kwargs )

If a single weight of the model is bigger than max_shard_size, it will be in its own checkpoint shard which will be bigger than max_shard_size.

Save a model and its configuration file to a directory, so that it can be re-loaded using the from_pretrained() class method.

( attn_implementation: typing.Union[str, dict] )

Set the requested attn_implementation for this model.

Symmetric setter. Mirrors the lookup logic used in get_decoder.

If set in the config, tie the weights between the input embeddings and the output embeddings, and the encoder and decoder.

If the torchscript flag is set in the configuration, can’t handle parameter sharing so we are cloning the weights instead.

Recursively (for all submodels) tie all the weights of the model.

( ) → PreTrainedModel

The model converted to BetterTransformer.

The model converted to BetterTransformer.

Converts the model to use PyTorch’s native attention implementation, integrated to Transformers through Optimum library. Only a subset of all Transformers models are supported.

PyTorch’s attention fastpath allows to speed up inference through kernel fusions and the use of nested tensors. Detailed benchmarks can be found in this blog post.

( input_ids attention_mask )

Shows a one-time warning if the input_ids appear to contain padding and no attention mask was given.

Custom models should also include a _supports_assign_param_buffer, which determines if superfast init can apply on the particular model. Signs that your model needs this are if test_save_and_load_from_pretrained fails. If so, set this to False.

A few utilities for torch.nn.Modules, to be used as a mixin.

Add a memory hook before and after each sub-module forward pass to record increase in memory consumption.

Increase in memory consumption is stored in a mem_rss_diff attribute for each module and can be reset to zero with model.reset_memory_hooks_state().

( input_dict: dict ) → int

The total number of tokens.

The total number of tokens.

Helper function to estimate the total number of tokens from the model inputs.

( input_dict: dict exclude_embeddings: bool = True ) → int

The number of floating-point operations.

The number of floating-point operations.

Get number of (optionally, non-embeddings) floating-point operations for the forward and backward passes of a batch with this transformer model. Default approximation neglects the quadratic dependency on the number of tokens (valid if 12 * d_model << sequence_length) as laid out in this paper section 2.1. Should be overridden for transformers with parameter re-use e.g. Albert or Universal Transformers, or if doing long-range modeling with very high sequence lengths.

( attention_mask: Tensor input_shape: tuple device: typing.Optional[torch.device] = None dtype: typing.Optional[torch.dtype] = None )

Makes broadcastable attention and causal masks so that future and masked tokens are ignored.

( head_mask: typing.Optional[torch.Tensor] num_hidden_layers: int is_attention_chunked: bool = False )

Prepare the head mask if needed.

( encoder_attention_mask: Tensor ) → torch.Tensor

The inverted attention mask.

The inverted attention mask.

Invert an attention mask (e.g., switches 0. and 1.).

( only_trainable: bool = False exclude_embeddings: bool = False ) → int

The number of parameters.

The number of parameters.

Get number of (optionally, trainable or non-embeddings) parameters in the module.

Reset the mem_rss_diff attribute of each module (see add_memory_hooks()).

A Mixin containing the functionality to push a model or tokenizer to the hub.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the {object_files} to the 🤗 Model Hub.

( model folder strict = True prefer_safe = True ) → NamedTuple

A named tuple with missing_keys and unexpected_keys fields missing_keys is a list of str containing the missing keys unexpected_keys is a list of str containing the unexpected keys

A named tuple with missing_keys and unexpected_keys fields

This is the same as torch.nn.Module.load_state_dict but for a sharded checkpoint.

This load is performed efficiently: each checkpoint shard is loaded one by one in RAM and deleted after being loaded in the model.

**Examples:**

Example 1 (unknown):
```unknown
PreTrainedConfig
```

Example 2 (unknown):
```unknown
pixel_values
```

Example 3 (unknown):
```unknown
input_values
```

Example 4 (unknown):
```unknown
"Upload model"
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/trainer

**Contents:**
- Transformers
- Trainer
- Trainer
  - class transformers.Trainer
    - add_callback
    - autocast_smart_context_manager
    - compute_loss
    - compute_loss_context_manager
    - create_model_card
    - create_optimizer

Transformers documentation

and get access to the augmented documentation experience

The Trainer class provides an API for feature-complete training in PyTorch, and it supports distributed training on multiple GPUs/TPUs, mixed precision for NVIDIA GPUs, AMD GPUs, and torch.amp for PyTorch. Trainer goes hand-in-hand with the TrainingArguments class, which offers a wide range of options to customize how a model is trained. Together, these two classes provide a complete training API.

Seq2SeqTrainer and Seq2SeqTrainingArguments inherit from the Trainer and TrainingArguments classes and they’re adapted for training models for sequence-to-sequence tasks such as summarization or translation.

The Trainer class is optimized for 🤗 Transformers models and can have surprising behaviors when used with other models. When using it with your own model, make sure:

( model: typing.Union[transformers.modeling_utils.PreTrainedModel, torch.nn.modules.module.Module, NoneType] = None args: typing.Optional[transformers.training_args.TrainingArguments] = None data_collator: typing.Optional[typing.Callable[[list[typing.Any]], dict[str, typing.Any]]] = None train_dataset: typing.Union[torch.utils.data.dataset.Dataset, torch.utils.data.dataset.IterableDataset, ForwardRef('datasets.Dataset'), NoneType] = None eval_dataset: typing.Union[torch.utils.data.dataset.Dataset, dict[str, torch.utils.data.dataset.Dataset], ForwardRef('datasets.Dataset'), NoneType] = None processing_class: typing.Union[transformers.tokenization_utils_base.PreTrainedTokenizerBase, transformers.image_processing_utils.BaseImageProcessor, transformers.feature_extraction_utils.FeatureExtractionMixin, transformers.processing_utils.ProcessorMixin, NoneType] = None model_init: typing.Optional[typing.Callable[..., transformers.modeling_utils.PreTrainedModel]] = None compute_loss_func: typing.Optional[typing.Callable] = None compute_metrics: typing.Optional[typing.Callable[[transformers.trainer_utils.EvalPrediction], dict]] = None callbacks: typing.Optional[list[transformers.trainer_callback.TrainerCallback]] = None optimizers: tuple = (None, None) optimizer_cls_and_kwargs: typing.Optional[tuple[type[torch.optim.optimizer.Optimizer], dict[str, typing.Any]]] = None preprocess_logits_for_metrics: typing.Optional[typing.Callable[[torch.Tensor, torch.Tensor], torch.Tensor]] = None )

Trainer is optimized to work with the PreTrainedModel provided by the library. You can still use your own models defined as torch.nn.Module as long as they work the same way as the 🤗 Transformers models.

Note that if it’s a torch.utils.data.IterableDataset with some randomization and you are training in a distributed fashion, your iterable dataset should either use a internal attribute generator that is a torch.Generator for the randomization that must be identical on all processes (and the Trainer will manually set the seed of this generator at each epoch) or have a set_epoch() method that internally sets the seed of the RNGs used.

The function may have zero argument, or a single one containing the optuna/Ray Tune/SigOpt trial object, to be able to choose different architectures according to hyper parameters (such as layer count, sizes of inner layers, dropout probabilities etc).

If you want to remove one of the default callbacks used, use the Trainer.remove_callback() method.

Unlike optimizers, this argument avoids the need to place model parameters on the correct devices before initializing the Trainer.

Note that the labels (second parameter) will be None if the dataset does not have them.

Trainer is a simple but feature-complete training and eval loop for PyTorch, optimized for 🤗 Transformers.

Important attributes:

Add a callback to the current list of TrainerCallback.

( cache_enabled: typing.Optional[bool] = True )

A helper wrapper that creates an appropriate context manager for autocast while feeding it the desired arguments, depending on the situation.

( model: Module inputs: dict return_outputs: bool = False num_items_in_batch: typing.Optional[torch.Tensor] = None )

How the loss is computed by Trainer. By default, all models return the loss in the first element.

Subclass and override for custom behavior. If you are not using num_items_in_batch when computing your loss, make sure to overwrite self.model_accepts_loss_kwargs to False. Otherwise, the loss calculating might be slightly inaccurate when performing gradient accumulation.

A helper wrapper to group together context managers.

( language: typing.Optional[str] = None license: typing.Optional[str] = None tags: typing.Union[str, list[str], NoneType] = None model_name: typing.Optional[str] = None finetuned_from: typing.Optional[str] = None tasks: typing.Union[str, list[str], NoneType] = None dataset_tags: typing.Union[str, list[str], NoneType] = None dataset: typing.Union[str, list[str], NoneType] = None dataset_args: typing.Union[str, list[str], NoneType] = None )

Creates a draft of a model card using the information available to the Trainer.

We provide a reasonable default that works well. If you want to use something else, you can pass a tuple in the Trainer’s init through optimizers, or subclass and override this method in a subclass.

( num_training_steps: int )

Setup the optimizer and the learning rate scheduler.

We provide a reasonable default that works well. If you want to use something else, you can pass a tuple in the Trainer’s init through optimizers, or subclass and override this method (or create_optimizer and/or create_scheduler) in a subclass.

( num_training_steps: int optimizer: Optimizer = None )

Setup the scheduler. The optimizer of the trainer must have been set up either before this method is called or passed as an argument.

( eval_dataset: typing.Union[torch.utils.data.dataset.Dataset, dict[str, torch.utils.data.dataset.Dataset], NoneType] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' )

If you pass a dictionary with names of datasets as keys and datasets as values, evaluate will run separate evaluations on each dataset. This can be useful to monitor how training affects other datasets or simply to get a more fine-grained evaluation. When used with load_best_model_at_end, make sure metric_for_best_model references exactly one of the datasets. If you, for example, pass in {"data1": data1, "data2": data2} for two datasets data1 and data2, you could specify metric_for_best_model="eval_data1_loss" for using the loss on data1 and metric_for_best_model="eval_data2_loss" for the loss on data2.

Run evaluation and returns metrics.

The calling script will be responsible for providing a method to compute metrics, as they are task-dependent (pass it to the init compute_metrics argument).

You can also subclass and override this method to inject custom behavior.

( dataloader: DataLoader description: str prediction_loss_only: typing.Optional[bool] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' )

Prediction/evaluation loop, shared by Trainer.evaluate() and Trainer.predict().

Works both with or without labels.

( inputs: dict ) → int

The number of floating-point operations.

The number of floating-point operations.

For models that inherit from PreTrainedModel, uses that method to compute the number of floating point operations for every backward + forward pass. If using another model, either implement such a method in the model or subclass and override this method.

( epoch_iterator: Iterator num_batches: int device: device )

Collects a specified number of batches from the epoch iterator and optionally counts the number of items in the batches to properly scale the loss.

Get all parameter names that weight decay will be applied to.

This function filters out parameters in two ways:

( eval_dataset: typing.Union[str, torch.utils.data.dataset.Dataset, NoneType] = None )

Returns the evaluation ~torch.utils.data.DataLoader.

Subclass and override this method if you want to inject some custom behavior.

Returns the learning rate of each parameter from self.optimizer.

Get the number of trainable parameters.

( args: TrainingArguments model: typing.Optional[transformers.modeling_utils.PreTrainedModel] = None )

Returns the optimizer class and optimizer parameters based on the training arguments.

( param: typing.Union[str, torch.nn.parameter.Parameter, NoneType] = None )

Returns optimizer group for a parameter if given, else returns all optimizer groups for params.

( test_dataset: Dataset )

Returns the test ~torch.utils.data.DataLoader.

Subclass and override this method if you want to inject some custom behavior.

Calculates total batch size (micro_batch grad_accum dp_world_size).

Note: Only considers DP and TP (dp_world_size = world_size // tp_size).

Get the tensor parallel size from either the model or DeepSpeed config.

Returns the training ~torch.utils.data.DataLoader.

Will use no sampler if train_dataset does not implement __len__, a random sampler (adapted to distributed training if necessary) otherwise.

Subclass and override this method if you want to inject some custom behavior.

( hp_space: typing.Optional[typing.Callable[[ForwardRef('optuna.Trial')], dict[str, float]]] = None compute_objective: typing.Optional[typing.Callable[[dict[str, float]], float]] = None n_trials: int = 20 direction: typing.Union[str, list[str]] = 'minimize' backend: typing.Union[ForwardRef('str'), transformers.trainer_utils.HPSearchBackend, NoneType] = None hp_name: typing.Optional[typing.Callable[[ForwardRef('optuna.Trial')], str]] = None **kwargs ) → [trainer_utils.BestRun or list[trainer_utils.BestRun]]

[trainer_utils.BestRun or list[trainer_utils.BestRun]]

All the information about the best run or best runs for multi-objective optimization. Experiment summary can be found in run_summary attribute for Ray backend.

All the information about the best run or best runs for multi-objective optimization. Experiment summary can be found in run_summary attribute for Ray backend.

Launch an hyperparameter search using optuna or Ray Tune or SigOpt. The optimized quantity is determined by compute_objective, which defaults to a function returning the evaluation loss when no metric is provided, the sum of all metrics otherwise.

To use this method, you need to have provided a model_init when initializing your Trainer: we need to reinitialize the model at each new run. This is incompatible with the optimizers argument, so you need to subclass Trainer and override the method create_optimizer_and_scheduler() for custom optimizer/scheduler.

( token: typing.Optional[str] = None )

Initializes a git repo in self.args.hub_model_id.

Whether or not this process is the local (e.g., on one machine if training in a distributed fashion on several machines) main process.

Whether or not this process is the global main process (when training in a distributed fashion on several machines, this is only going to be True for one process).

( logs: dict start_time: typing.Optional[float] = None )

Log logs on the various objects watching training.

Subclass and override this method to inject custom behavior.

Log metrics in a specially formatted way.

Under distributed environment this is done only for a process with rank 0.

Notes on memory reports:

In order to get memory usage report you need to install psutil. You can do that with pip install psutil.

Now when this method is run, you will see a report that will include:

Understanding the reports:

The reporting happens only for process of rank 0 and gpu 0 (if there is a gpu). Typically this is enough since the main process does the bulk of work, but it could be not quite so if model parallel is used and then other GPUs may use a different amount of gpu memory. This is also not the same under DataParallel where gpu0 may require much more memory than the rest since it stores the gradient and optimizer states for all participating GPUs. Perhaps in the future these reports will evolve to measure those too.

The CPU RAM metric measures RSS (Resident Set Size) includes both the memory which is unique to the process and the memory shared with other processes. It is important to note that it does not include swapped out memory, so the reports could be imprecise.

The CPU peak memory is measured using a sampling thread. Due to python’s GIL it may miss some of the peak memory if that thread didn’t get a chance to run when the highest memory was used. Therefore this report can be less than reality. Using tracemalloc would have reported the exact peak memory, but it doesn’t report memory allocations outside of python. So if some C++ CUDA extension allocated its own memory it won’t be reported. And therefore it was dropped in favor of the memory sampling approach, which reads the current process memory usage.

The GPU allocated and peak memory reporting is done with torch.cuda.memory_allocated() and torch.cuda.max_memory_allocated(). This metric reports only “deltas” for pytorch-specific allocations, as torch.cuda memory management system doesn’t track any memory allocated outside of pytorch. For example, the very first cuda call typically loads CUDA kernels, which may take from 0.5 to 2GB of GPU memory.

Note that this tracker doesn’t account for memory allocations outside of Trainer’s __init__, train, evaluate and predict calls.

Because evaluation calls may happen during train, we can’t handle nested invocations because torch.cuda.max_memory_allocated is a single counter, so if it gets reset by a nested eval call, train’s tracker will report incorrect info. If this pytorch issue gets resolved it will be possible to change this class to be re-entrant. Until then we will only track the outer level of train, evaluate and predict methods. Which means that if eval is called during train, it’s the latter that will account for its memory usage and that of the former.

This also means that if any other tool that is used along the Trainer calls torch.cuda.reset_peak_memory_stats, the gpu peak memory stats could be invalid. And the Trainer will disrupt the normal behavior of any such tools that rely on calling torch.cuda.reset_peak_memory_stats themselves.

For best performance you may want to consider turning the memory profiling off for production runs.

( metrics: dict ) → metrics (dict[str, float])

metrics (dict[str, float])

The reformatted metrics

The reformatted metrics

Reformat Trainer metrics values to a human-readable format.

( dataloader: DataLoader )

Helper to get number of samples in a ~torch.utils.data.DataLoader by accessing its dataset. When dataloader.dataset does not exist or has no length, estimates as best it can

( train_dl: DataLoader max_steps: typing.Optional[int] = None )

Helper to get number of tokens in a ~torch.utils.data.DataLoader by enumerating dataloader.

( callback ) → TrainerCallback

The callback removed, if found.

The callback removed, if found.

Remove a callback from the current list of TrainerCallback and returns it.

If the callback is not found, returns None (and no error is raised).

( test_dataset: Dataset ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'test' )

Run prediction and returns predictions and potential metrics.

Depending on the dataset and your use case, your test dataset may contain labels. In that case, this method will also return metrics, like in evaluate().

If your predictions or labels have different sequence length (for instance because you’re doing dynamic padding in a token classification task) the predictions will be padded (on the right) to allow for concatenation into one array. The padding index is -100.

Returns: NamedTuple A namedtuple with the following keys:

( dataloader: DataLoader description: str prediction_loss_only: typing.Optional[bool] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' )

Prediction/evaluation loop, shared by Trainer.evaluate() and Trainer.predict().

Works both with or without labels.

( model: Module inputs: dict prediction_loss_only: bool ignore_keys: typing.Optional[list[str]] = None ) → tuple[Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor]]

The dictionary will be unpacked before being fed to the model. Most models expect the targets under the argument labels. Check your model’s documentation for all accepted arguments.

tuple[Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor]]

A tuple with the loss, logits and labels (each being optional).

A tuple with the loss, logits and labels (each being optional).

Perform an evaluation step on model using inputs.

Subclass and override to inject custom behavior.

( auto_find_batch_size = False )

Sets values in the deepspeed plugin based on the Trainer args

( commit_message: typing.Optional[str] = 'End of training' blocking: bool = True token: typing.Optional[str] = None revision: typing.Optional[str] = None **kwargs )

Upload self.model and self.processing_class to the 🤗 model hub on the repo self.args.hub_model_id.

Remove a callback from the current list of TrainerCallback.

( split metrics combined = True )

Save metrics into a json file for that split, e.g. train_results.json.

Under distributed environment this is done only for a process with rank 0.

To understand the metrics please read the docstring of log_metrics(). The only difference is that raw unformatted numbers are saved in the current method.

( output_dir: typing.Optional[str] = None _internal_call: bool = False )

Will save the model, so you can reload it using from_pretrained().

Will only save from the main process.

Saves the Trainer state, since Trainer.save_model saves only the tokenizer with the model.

Under distributed environment this is done only for a process with rank 0.

( args: TrainingArguments dataloader: DataLoader total_train_batch_size: int )

Calculates and returns the following values:

( resume_from_checkpoint: typing.Union[bool, str, NoneType] = None trial: typing.Union[ForwardRef('optuna.Trial'), dict[str, typing.Any], NoneType] = None ignore_keys_for_eval: typing.Optional[list[str]] = None **kwargs: typing.Any )

Main training entry point.

( model: Module inputs: dict num_items_in_batch: typing.Optional[torch.Tensor] = None ) → torch.Tensor

The dictionary will be unpacked before being fed to the model. Most models expect the targets under the argument labels. Check your model’s documentation for all accepted arguments.

The tensor with training loss on this batch.

The tensor with training loss on this batch.

Perform a training step on a batch of inputs.

Subclass and override to inject custom behavior.

( model: typing.Union[ForwardRef('PreTrainedModel'), torch.nn.modules.module.Module, NoneType] = None args: typing.Optional[ForwardRef('TrainingArguments')] = None data_collator: typing.Optional[ForwardRef('DataCollator')] = None train_dataset: typing.Union[torch.utils.data.dataset.Dataset, ForwardRef('IterableDataset'), ForwardRef('datasets.Dataset'), NoneType] = None eval_dataset: typing.Union[torch.utils.data.dataset.Dataset, dict[str, torch.utils.data.dataset.Dataset], NoneType] = None processing_class: typing.Union[ForwardRef('PreTrainedTokenizerBase'), ForwardRef('BaseImageProcessor'), ForwardRef('FeatureExtractionMixin'), ForwardRef('ProcessorMixin'), NoneType] = None model_init: typing.Optional[typing.Callable[[], ForwardRef('PreTrainedModel')]] = None compute_loss_func: typing.Optional[typing.Callable] = None compute_metrics: typing.Optional[typing.Callable[[ForwardRef('EvalPrediction')], dict]] = None callbacks: typing.Optional[list['TrainerCallback']] = None optimizers: tuple = (None, None) preprocess_logits_for_metrics: typing.Optional[typing.Callable[[torch.Tensor, torch.Tensor], torch.Tensor]] = None )

( eval_dataset: typing.Optional[torch.utils.data.dataset.Dataset] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' **gen_kwargs )

Run evaluation and returns metrics.

The calling script will be responsible for providing a method to compute metrics, as they are task-dependent (pass it to the init compute_metrics argument).

You can also subclass and override this method to inject custom behavior.

( test_dataset: Dataset ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'test' **gen_kwargs )

Run prediction and returns predictions and potential metrics.

Depending on the dataset and your use case, your test dataset may contain labels. In that case, this method will also return metrics, like in evaluate().

If your predictions or labels have different sequence lengths (for instance because you’re doing dynamic padding in a token classification task) the predictions will be padded (on the right) to allow for concatenation into one array. The padding index is -100.

Returns: NamedTuple A namedtuple with the following keys:

( output_dir: typing.Optional[str] = None overwrite_output_dir: bool = False do_train: bool = False do_eval: bool = False do_predict: bool = False eval_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'no' prediction_loss_only: bool = False per_device_train_batch_size: int = 8 per_device_eval_batch_size: int = 8 per_gpu_train_batch_size: typing.Optional[int] = None per_gpu_eval_batch_size: typing.Optional[int] = None gradient_accumulation_steps: int = 1 eval_accumulation_steps: typing.Optional[int] = None eval_delay: float = 0 torch_empty_cache_steps: typing.Optional[int] = None learning_rate: float = 5e-05 weight_decay: float = 0.0 adam_beta1: float = 0.9 adam_beta2: float = 0.999 adam_epsilon: float = 1e-08 max_grad_norm: float = 1.0 num_train_epochs: float = 3.0 max_steps: int = -1 lr_scheduler_type: typing.Union[transformers.trainer_utils.SchedulerType, str] = 'linear' lr_scheduler_kwargs: typing.Union[dict[str, typing.Any], str] = <factory> warmup_ratio: float = 0.0 warmup_steps: int = 0 log_level: str = 'passive' log_level_replica: str = 'warning' log_on_each_node: bool = True logging_dir: typing.Optional[str] = None logging_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'steps' logging_first_step: bool = False logging_steps: float = 500 logging_nan_inf_filter: bool = True save_strategy: typing.Union[transformers.trainer_utils.SaveStrategy, str] = 'steps' save_steps: float = 500 save_total_limit: typing.Optional[int] = None save_safetensors: bool = True save_on_each_node: bool = False save_only_model: bool = False restore_callback_states_from_checkpoint: bool = False no_cuda: bool = False use_cpu: bool = False use_mps_device: bool = False seed: int = 42 data_seed: typing.Optional[int] = None jit_mode_eval: bool = False bf16: bool = False fp16: bool = False fp16_opt_level: str = 'O1' half_precision_backend: str = 'auto' bf16_full_eval: bool = False fp16_full_eval: bool = False tf32: typing.Optional[bool] = None local_rank: int = -1 ddp_backend: typing.Optional[str] = None tpu_num_cores: typing.Optional[int] = None tpu_metrics_debug: bool = False debug: typing.Union[str, list[transformers.debug_utils.DebugOption]] = '' dataloader_drop_last: bool = False eval_steps: typing.Optional[float] = None dataloader_num_workers: int = 0 dataloader_prefetch_factor: typing.Optional[int] = None past_index: int = -1 run_name: typing.Optional[str] = None disable_tqdm: typing.Optional[bool] = None remove_unused_columns: bool = True label_names: typing.Optional[list[str]] = None load_best_model_at_end: bool = False metric_for_best_model: typing.Optional[str] = None greater_is_better: typing.Optional[bool] = None ignore_data_skip: bool = False fsdp: typing.Union[list[transformers.trainer_utils.FSDPOption], str, NoneType] = None fsdp_min_num_params: int = 0 fsdp_config: typing.Union[dict[str, typing.Any], str, NoneType] = None fsdp_transformer_layer_cls_to_wrap: typing.Optional[str] = None accelerator_config: typing.Union[dict, str, NoneType] = None parallelism_config: typing.Optional[accelerate.parallelism_config.ParallelismConfig] = None deepspeed: typing.Union[dict, str, NoneType] = None label_smoothing_factor: float = 0.0 optim: typing.Union[transformers.training_args.OptimizerNames, str] = 'adamw_torch_fused' optim_args: typing.Optional[str] = None adafactor: bool = False group_by_length: bool = False length_column_name: str = 'length' report_to: typing.Union[NoneType, str, list[str]] = None project: str = 'huggingface' trackio_space_id: typing.Optional[str] = 'trackio' ddp_find_unused_parameters: typing.Optional[bool] = None ddp_bucket_cap_mb: typing.Optional[int] = None ddp_broadcast_buffers: typing.Optional[bool] = None dataloader_pin_memory: bool = True dataloader_persistent_workers: bool = False skip_memory_metrics: bool = True use_legacy_prediction_loop: bool = False push_to_hub: bool = False resume_from_checkpoint: typing.Optional[str] = None hub_model_id: typing.Optional[str] = None hub_strategy: typing.Union[transformers.trainer_utils.HubStrategy, str] = 'every_save' hub_token: typing.Optional[str] = None hub_private_repo: typing.Optional[bool] = None hub_always_push: bool = False hub_revision: typing.Optional[str] = None gradient_checkpointing: bool = False gradient_checkpointing_kwargs: typing.Union[dict[str, typing.Any], str, NoneType] = None include_inputs_for_metrics: bool = False include_for_metrics: list = <factory> eval_do_concat_batches: bool = True fp16_backend: str = 'auto' push_to_hub_model_id: typing.Optional[str] = None push_to_hub_organization: typing.Optional[str] = None push_to_hub_token: typing.Optional[str] = None mp_parameters: str = '' auto_find_batch_size: bool = False full_determinism: bool = False torchdynamo: typing.Optional[str] = None ray_scope: typing.Optional[str] = 'last' ddp_timeout: int = 1800 torch_compile: bool = False torch_compile_backend: typing.Optional[str] = None torch_compile_mode: typing.Optional[str] = None include_tokens_per_second: bool = False include_num_input_tokens_seen: typing.Union[str, bool] = False neftune_noise_alpha: typing.Optional[float] = None optim_target_modules: typing.Union[NoneType, str, list[str]] = None batch_eval_metrics: bool = False eval_on_start: bool = False use_liger_kernel: bool = False liger_kernel_config: typing.Optional[dict[str, bool]] = None eval_use_gather_object: bool = False average_tokens_across_devices: bool = True )

When using gradient accumulation, one step is counted as one step with backward pass. Therefore, logging, evaluation, save will be conducted every gradient_accumulation_steps * xxx_step training examples.

This can help avoid CUDA out-of-memory errors by lowering peak VRAM usage at a cost of about 10% slower performance.

logging_nan_inf_filter only influences the logging of loss values, it does not change the behavior the gradient is computed or applied to the model.

If "epoch" or "steps" is chosen, saving will also be performed at the very end of training, always.

This should not be activated when the different nodes use the same storage as the files will be saved with the same names for each node.

Will eventually default to the list of argument names accepted by the model that contain the word “label”, except if the model used is one of the XxxForQuestionAnswering in which case it will also include the ["start_positions", "end_positions"] keys.

You should only specify label_names if you’re using custom label names or if your model’s forward consumes multiple label tensors (e.g., extractive QA).

When set to True, the parameters save_strategy needs to be the same as eval_strategy, and in the case it is “steps”, save_steps must be a round multiple of eval_steps.

If not specified, this will default to "loss" when either load_best_model_at_end == True or lr_scheduler_type == SchedulerType.REDUCE_ON_PLATEAU (to use the evaluation loss).

If you set this value, greater_is_better will default to True unless the name ends with “loss”. Don’t forget to set it to False if your metric is better when lower.

A list of options along the following:

A List of config and its options:

min_num_params (int, optional, defaults to 0): FSDP’s minimum number of parameters for Default Auto Wrapping. (useful only when fsdp field is passed).

transformer_layer_cls_to_wrap (list[str], optional): List of transformer layer class names (case-sensitive) to wrap, e.g, BertLayer, GPTJBlock, T5Block … (useful only when fsdp flag is passed).

backward_prefetch (str, optional) FSDP’s backward prefetch mode. Controls when to prefetch next set of parameters (useful only when fsdp field is passed).

A list of options along the following:

forward_prefetch (bool, optional, defaults to False) FSDP’s forward prefetch mode (useful only when fsdp field is passed). If "True", then FSDP explicitly prefetches the next upcoming all-gather while executing in the forward pass.

limit_all_gathers (bool, optional, defaults to False) FSDP’s limit_all_gathers (useful only when fsdp field is passed). If "True", FSDP explicitly synchronizes the CPU thread to prevent too many in-flight all-gathers.

use_orig_params (bool, optional, defaults to True) If "True", allows non-uniform requires_grad during init, which means support for interspersed frozen and trainable parameters. Useful in cases such as parameter-efficient fine-tuning. Please refer this [blog](https://dev-discuss.pytorch.org/t/rethinking-pytorch-fully-sharded-data-parallel-fsdp-from-first-principles/1019

sync_module_states (bool, optional, defaults to True) If "True", each individually wrapped FSDP unit will broadcast module parameters from rank 0 to ensure they are the same across all ranks after initialization

cpu_ram_efficient_loading (bool, optional, defaults to False) If "True", only the first process loads the pretrained model checkpoint while all other processes have empty weights. When this setting as "True", sync_module_states also must to be "True", otherwise all the processes except the main process would have random weights leading to unexpected behaviour during training.

activation_checkpointing (bool, optional, defaults to False): If "True", activation checkpointing is a technique to reduce memory usage by clearing activations of certain layers and recomputing them during a backward pass. Effectively, this trades extra computation time for reduced memory usage.

xla (bool, optional, defaults to False): Whether to use PyTorch/XLA Fully Sharded Data Parallel Training. This is an experimental feature and its API may evolve in the future.

xla_fsdp_settings (dict, optional) The value is a dictionary which stores the XLA FSDP wrapping parameters.

For a complete list of options, please see here.

xla_fsdp_grad_ckpt (bool, optional, defaults to False): Will use gradient checkpointing over each nested XLA FSDP wrapped layer. This setting can only be used when the xla flag is set to true, and an auto wrapping policy is specified through fsdp_min_num_params or fsdp_transformer_layer_cls_to_wrap.

A list of config and its options:

Possible options are:

The options should be separated by whitespaces.

If output_dir exists, it needs to be a local clone of the repository to which the Trainer will be pushed.

Will default to the name of output_dir.

This will use the best defaults for the torch.compile API. You can customize the defaults with the argument torch_compile_backend and torch_compile_mode but we don’t guarantee any of them will work as the support is progressively rolled in in PyTorch.

This flag and the whole compile API is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

This will iterate over the entire training dataloader once beforehand, and will slow down the entire process.

May be slower in distributed training as gather operations must be called.

TrainingArguments is the subset of the arguments we use in our example scripts which relate to the training loop itself.

Using HfArgumentParser we can turn this class into argparse arguments that can be specified on the command line.

Returns the log level to be used depending on whether this process is the main process of node 0, main process of node non-0, or a non-main process.

For the main process the log level defaults to the logging level set (logging.WARNING if you didn’t do anything) unless overridden by log_level argument.

For the replica processes the log level defaults to logging.WARNING unless overridden by log_level_replica argument.

The choice between the main and replica process settings is made according to the return value of should_log.

( num_training_steps: int )

Get number of steps used for a linear warmup.

( local = True desc = 'work' )

A context manager for torch distributed environment where on needs to do something on the main process, while blocking replicas, and when it’s finished releasing the replicas.

One such use is for datasets’s map feature which to be efficient should be run once on the main process, which upon completion saves a cached version of results and which then automatically gets loaded by the replicas.

( train_batch_size: int = 8 eval_batch_size: int = 8 drop_last: bool = False num_workers: int = 0 pin_memory: bool = True persistent_workers: bool = False prefetch_factor: typing.Optional[int] = None auto_find_batch_size: bool = False ignore_data_skip: bool = False sampler_seed: typing.Optional[int] = None )

A method that regroups all arguments linked to the dataloaders creation.

( strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'no' steps: int = 500 batch_size: int = 8 accumulation_steps: typing.Optional[int] = None delay: typing.Optional[float] = None loss_only: bool = False jit_mode: bool = False )

Setting a strategy different from "no" will set self.do_eval to True.

A method that regroups all arguments linked to evaluation.

( strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'steps' steps: int = 500 report_to: typing.Union[str, list[str]] = 'none' level: str = 'passive' first_step: bool = False nan_inf_filter: bool = False on_each_node: bool = False replica_level: str = 'passive' )

nan_inf_filter only influences the logging of loss values, it does not change the behavior the gradient is computed or applied to the model.

A method that regroups all arguments linked to logging.

( name: typing.Union[str, transformers.trainer_utils.SchedulerType] = 'linear' num_epochs: float = 3.0 max_steps: int = -1 warmup_ratio: float = 0 warmup_steps: int = 0 )

A method that regroups all arguments linked to the learning rate scheduler and its hyperparameters.

( name: typing.Union[str, transformers.training_args.OptimizerNames] = 'adamw_torch' learning_rate: float = 5e-05 weight_decay: float = 0 beta1: float = 0.9 beta2: float = 0.999 epsilon: float = 1e-08 args: typing.Optional[str] = None )

A method that regroups all arguments linked to the optimizer and its hyperparameters.

( model_id: str strategy: typing.Union[str, transformers.trainer_utils.HubStrategy] = 'every_save' token: typing.Optional[str] = None private_repo: typing.Optional[bool] = None always_push: bool = False revision: typing.Optional[str] = None )

A method that regroups all arguments linked to synchronizing checkpoints with the Hub.

Calling this method will set self.push_to_hub to True, which means the output_dir will begin a git directory synced with the repo (determined by model_id) and the content will be pushed each time a save is triggered (depending on your self.save_strategy). Calling save_model() will also trigger a push.

( strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'steps' steps: int = 500 total_limit: typing.Optional[int] = None on_each_node: bool = False )

This should not be activated when the different nodes use the same storage as the files will be saved with the same names for each node.

A method that regroups all arguments linked to checkpoint saving.

( batch_size: int = 8 loss_only: bool = False jit_mode: bool = False )

A method that regroups all basic arguments linked to testing on a held-out dataset.

Calling this method will automatically set self.do_predict to True.

( learning_rate: float = 5e-05 batch_size: int = 8 weight_decay: float = 0 num_epochs: float = 3 max_steps: int = -1 gradient_accumulation_steps: int = 1 seed: int = 42 gradient_checkpointing: bool = False )

When using gradient accumulation, one step is counted as one step with backward pass. Therefore, logging, evaluation, save will be conducted every gradient_accumulation_steps * xxx_step training examples.

A method that regroups all basic arguments linked to the training.

Calling this method will automatically set self.do_train to True.

Serializes this instance while replace Enum by their values (for JSON serialization support). It obfuscates the token values by removing their value.

Serializes this instance to a JSON string.

Sanitized serialization to use with TensorBoard’s hparams

( output_dir: typing.Optional[str] = None overwrite_output_dir: bool = False do_train: bool = False do_eval: bool = False do_predict: bool = False eval_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'no' prediction_loss_only: bool = False per_device_train_batch_size: int = 8 per_device_eval_batch_size: int = 8 per_gpu_train_batch_size: typing.Optional[int] = None per_gpu_eval_batch_size: typing.Optional[int] = None gradient_accumulation_steps: int = 1 eval_accumulation_steps: typing.Optional[int] = None eval_delay: float = 0 torch_empty_cache_steps: typing.Optional[int] = None learning_rate: float = 5e-05 weight_decay: float = 0.0 adam_beta1: float = 0.9 adam_beta2: float = 0.999 adam_epsilon: float = 1e-08 max_grad_norm: float = 1.0 num_train_epochs: float = 3.0 max_steps: int = -1 lr_scheduler_type: typing.Union[transformers.trainer_utils.SchedulerType, str] = 'linear' lr_scheduler_kwargs: typing.Union[dict[str, typing.Any], str] = <factory> warmup_ratio: float = 0.0 warmup_steps: int = 0 log_level: str = 'passive' log_level_replica: str = 'warning' log_on_each_node: bool = True logging_dir: typing.Optional[str] = None logging_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'steps' logging_first_step: bool = False logging_steps: float = 500 logging_nan_inf_filter: bool = True save_strategy: typing.Union[transformers.trainer_utils.SaveStrategy, str] = 'steps' save_steps: float = 500 save_total_limit: typing.Optional[int] = None save_safetensors: bool = True save_on_each_node: bool = False save_only_model: bool = False restore_callback_states_from_checkpoint: bool = False no_cuda: bool = False use_cpu: bool = False use_mps_device: bool = False seed: int = 42 data_seed: typing.Optional[int] = None jit_mode_eval: bool = False bf16: bool = False fp16: bool = False fp16_opt_level: str = 'O1' half_precision_backend: str = 'auto' bf16_full_eval: bool = False fp16_full_eval: bool = False tf32: typing.Optional[bool] = None local_rank: int = -1 ddp_backend: typing.Optional[str] = None tpu_num_cores: typing.Optional[int] = None tpu_metrics_debug: bool = False debug: typing.Union[str, list[transformers.debug_utils.DebugOption]] = '' dataloader_drop_last: bool = False eval_steps: typing.Optional[float] = None dataloader_num_workers: int = 0 dataloader_prefetch_factor: typing.Optional[int] = None past_index: int = -1 run_name: typing.Optional[str] = None disable_tqdm: typing.Optional[bool] = None remove_unused_columns: bool = True label_names: typing.Optional[list[str]] = None load_best_model_at_end: bool = False metric_for_best_model: typing.Optional[str] = None greater_is_better: typing.Optional[bool] = None ignore_data_skip: bool = False fsdp: typing.Union[list[transformers.trainer_utils.FSDPOption], str, NoneType] = None fsdp_min_num_params: int = 0 fsdp_config: typing.Union[dict[str, typing.Any], str, NoneType] = None fsdp_transformer_layer_cls_to_wrap: typing.Optional[str] = None accelerator_config: typing.Union[dict, str, NoneType] = None parallelism_config: typing.Optional[accelerate.parallelism_config.ParallelismConfig] = None deepspeed: typing.Union[dict, str, NoneType] = None label_smoothing_factor: float = 0.0 optim: typing.Union[transformers.training_args.OptimizerNames, str] = 'adamw_torch_fused' optim_args: typing.Optional[str] = None adafactor: bool = False group_by_length: bool = False length_column_name: str = 'length' report_to: typing.Union[NoneType, str, list[str]] = None project: str = 'huggingface' trackio_space_id: typing.Optional[str] = 'trackio' ddp_find_unused_parameters: typing.Optional[bool] = None ddp_bucket_cap_mb: typing.Optional[int] = None ddp_broadcast_buffers: typing.Optional[bool] = None dataloader_pin_memory: bool = True dataloader_persistent_workers: bool = False skip_memory_metrics: bool = True use_legacy_prediction_loop: bool = False push_to_hub: bool = False resume_from_checkpoint: typing.Optional[str] = None hub_model_id: typing.Optional[str] = None hub_strategy: typing.Union[transformers.trainer_utils.HubStrategy, str] = 'every_save' hub_token: typing.Optional[str] = None hub_private_repo: typing.Optional[bool] = None hub_always_push: bool = False hub_revision: typing.Optional[str] = None gradient_checkpointing: bool = False gradient_checkpointing_kwargs: typing.Union[dict[str, typing.Any], str, NoneType] = None include_inputs_for_metrics: bool = False include_for_metrics: list = <factory> eval_do_concat_batches: bool = True fp16_backend: str = 'auto' push_to_hub_model_id: typing.Optional[str] = None push_to_hub_organization: typing.Optional[str] = None push_to_hub_token: typing.Optional[str] = None mp_parameters: str = '' auto_find_batch_size: bool = False full_determinism: bool = False torchdynamo: typing.Optional[str] = None ray_scope: typing.Optional[str] = 'last' ddp_timeout: int = 1800 torch_compile: bool = False torch_compile_backend: typing.Optional[str] = None torch_compile_mode: typing.Optional[str] = None include_tokens_per_second: bool = False include_num_input_tokens_seen: typing.Union[str, bool] = False neftune_noise_alpha: typing.Optional[float] = None optim_target_modules: typing.Union[NoneType, str, list[str]] = None batch_eval_metrics: bool = False eval_on_start: bool = False use_liger_kernel: bool = False liger_kernel_config: typing.Optional[dict[str, bool]] = None eval_use_gather_object: bool = False average_tokens_across_devices: bool = True sortish_sampler: bool = False predict_with_generate: bool = False generation_max_length: typing.Optional[int] = None generation_num_beams: typing.Optional[int] = None generation_config: typing.Union[str, pathlib.Path, transformers.generation.configuration_utils.GenerationConfig, NoneType] = None )

When using gradient accumulation, one step is counted as one step with backward pass. Therefore, logging, evaluation, save will be conducted every gradient_accumulation_steps * xxx_step training examples.

This can help avoid CUDA out-of-memory errors by lowering peak VRAM usage at a cost of about 10% slower performance.

logging_nan_inf_filter only influences the logging of loss values, it does not change the behavior the gradient is computed or applied to the model.

If "epoch" or "steps" is chosen, saving will also be performed at the very end of training, always.

This should not be activated when the different nodes use the same storage as the files will be saved with the same names for each node.

Will eventually default to the list of argument names accepted by the model that contain the word “label”, except if the model used is one of the XxxForQuestionAnswering in which case it will also include the ["start_positions", "end_positions"] keys.

You should only specify label_names if you’re using custom label names or if your model’s forward consumes multiple label tensors (e.g., extractive QA).

When set to True, the parameters save_strategy needs to be the same as eval_strategy, and in the case it is “steps”, save_steps must be a round multiple of eval_steps.

If not specified, this will default to "loss" when either load_best_model_at_end == True or lr_scheduler_type == SchedulerType.REDUCE_ON_PLATEAU (to use the evaluation loss).

If you set this value, greater_is_better will default to True unless the name ends with “loss”. Don’t forget to set it to False if your metric is better when lower.

A list of options along the following:

A List of config and its options:

min_num_params (int, optional, defaults to 0): FSDP’s minimum number of parameters for Default Auto Wrapping. (useful only when fsdp field is passed).

transformer_layer_cls_to_wrap (list[str], optional): List of transformer layer class names (case-sensitive) to wrap, e.g, BertLayer, GPTJBlock, T5Block … (useful only when fsdp flag is passed).

backward_prefetch (str, optional) FSDP’s backward prefetch mode. Controls when to prefetch next set of parameters (useful only when fsdp field is passed).

A list of options along the following:

forward_prefetch (bool, optional, defaults to False) FSDP’s forward prefetch mode (useful only when fsdp field is passed). If "True", then FSDP explicitly prefetches the next upcoming all-gather while executing in the forward pass.

limit_all_gathers (bool, optional, defaults to False) FSDP’s limit_all_gathers (useful only when fsdp field is passed). If "True", FSDP explicitly synchronizes the CPU thread to prevent too many in-flight all-gathers.

use_orig_params (bool, optional, defaults to True) If "True", allows non-uniform requires_grad during init, which means support for interspersed frozen and trainable parameters. Useful in cases such as parameter-efficient fine-tuning. Please refer this [blog](https://dev-discuss.pytorch.org/t/rethinking-pytorch-fully-sharded-data-parallel-fsdp-from-first-principles/1019

sync_module_states (bool, optional, defaults to True) If "True", each individually wrapped FSDP unit will broadcast module parameters from rank 0 to ensure they are the same across all ranks after initialization

cpu_ram_efficient_loading (bool, optional, defaults to False) If "True", only the first process loads the pretrained model checkpoint while all other processes have empty weights. When this setting as "True", sync_module_states also must to be "True", otherwise all the processes except the main process would have random weights leading to unexpected behaviour during training.

activation_checkpointing (bool, optional, defaults to False): If "True", activation checkpointing is a technique to reduce memory usage by clearing activations of certain layers and recomputing them during a backward pass. Effectively, this trades extra computation time for reduced memory usage.

xla (bool, optional, defaults to False): Whether to use PyTorch/XLA Fully Sharded Data Parallel Training. This is an experimental feature and its API may evolve in the future.

xla_fsdp_settings (dict, optional) The value is a dictionary which stores the XLA FSDP wrapping parameters.

For a complete list of options, please see here.

xla_fsdp_grad_ckpt (bool, optional, defaults to False): Will use gradient checkpointing over each nested XLA FSDP wrapped layer. This setting can only be used when the xla flag is set to true, and an auto wrapping policy is specified through fsdp_min_num_params or fsdp_transformer_layer_cls_to_wrap.

A list of config and its options:

Possible options are:

The options should be separated by whitespaces.

If output_dir exists, it needs to be a local clone of the repository to which the Trainer will be pushed.

Will default to the name of output_dir.

This will use the best defaults for the torch.compile API. You can customize the defaults with the argument torch_compile_backend and torch_compile_mode but we don’t guarantee any of them will work as the support is progressively rolled in in PyTorch.

This flag and the whole compile API is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

This will iterate over the entire training dataloader once beforehand, and will slow down the entire process.

May be slower in distributed training as gather operations must be called.

TrainingArguments is the subset of the arguments we use in our example scripts which relate to the training loop itself.

Using HfArgumentParser we can turn this class into argparse arguments that can be specified on the command line.

Serializes this instance while replace Enum by their values and GenerationConfig by dictionaries (for JSON serialization support). It obfuscates the token values by removing their value.

**Examples:**

Example 1 (unknown):
```unknown
label_names
```

Example 2 (unknown):
```unknown
torch.nn.Module
```

Example 3 (unknown):
```unknown
torch.nn.Module
```

Example 4 (unknown):
```unknown
DataCollator
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/keras_callbacks

**Contents:**
- Transformers
- Keras callbacks
- KerasMetricCallback
  - class transformers.KerasMetricCallback
- PushToHubCallback
  - class transformers.PushToHubCallback

Transformers documentation

and get access to the augmented documentation experience

When training a Transformers model with Keras, there are some library-specific callbacks available to automate common tasks:

( metric_fn: typing.Callable eval_dataset: typing.Union[tensorflow.python.data.ops.dataset_ops.DatasetV2, numpy.ndarray, tensorflow.python.framework.tensor.Tensor, tuple, dict] output_cols: typing.Optional[list[str]] = None label_cols: typing.Optional[list[str]] = None batch_size: typing.Optional[int] = None predict_with_generate: bool = False use_xla_generation: bool = False generate_kwargs: typing.Optional[dict] = None )

Callback to compute metrics at the end of every epoch. Unlike normal Keras metrics, these do not need to be compilable by TF. It is particularly useful for common NLP metrics like BLEU and ROUGE that require string operations or generation loops that cannot be compiled. Predictions (or generations) will be computed on the eval_dataset before being passed to the metric_fn in np.ndarray format. The metric_fn should compute metrics and return a dict mapping metric names to metric values.

We provide an example of a suitable metric_fn that computes ROUGE scores for a summarization model below. Note that this example skips some post-processing for readability and simplicity, and should probably not be used as-is!

The above function will return a dict containing values which will be logged like any other Keras metric:

( output_dir: typing.Union[str, pathlib.Path] save_strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'epoch' save_steps: typing.Optional[int] = None tokenizer: typing.Optional[transformers.tokenization_utils_base.PreTrainedTokenizerBase] = None hub_model_id: typing.Optional[str] = None hub_token: typing.Optional[str] = None checkpoint: bool = False **model_card_args )

Will default to the name of output_dir.

Callback that will save and push the model to the Hub regularly. By default, it pushes once per epoch, but this can be changed with the save_strategy argument. Pushed models can be accessed like any other model on the hub, such as with the from_pretrained method.

**Examples:**

Example 1 (unknown):
```unknown
predictions
```

Example 2 (unknown):
```unknown
tf.data.Dataset
```

Example 3 (unknown):
```unknown
tf.data.Dataset
```

Example 4 (unknown):
```unknown
model.generate()
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/model

**Contents:**
- Transformers
- Models
- PreTrainedModel
  - class transformers.PreTrainedModel
    - push_to_hub
    - add_model_tags
    - can_generate
    - dequantize
    - disable_input_require_grads
    - enable_input_require_grads

Transformers documentation

and get access to the augmented documentation experience

The base class PreTrainedModel implements the common methods for loading/saving a model either from a local file or directory, or from a pretrained model configuration provided by the library (downloaded from HuggingFace’s Hub).

PreTrainedModel also implements a few methods which are common among all the models to:

The other methods that are common to each model are defined in ModuleUtilsMixin and GenerationMixin.

( config: PretrainedConfig *inputs **kwargs )

Base class for all models.

PreTrainedModel takes care of storing the configuration of the models and handles methods for loading, downloading and saving models as well as a few methods common to all models to:

Class attributes (overridden by derived classes):

config_class (PretrainedConfig) — A subclass of PretrainedConfig to use as configuration class for this model architecture.

load_tf_weights (Callable) — A python method for loading a TensorFlow checkpoint in a PyTorch model, taking as arguments:

base_model_prefix (str) — A string indicating the attribute associated to the base model in derived classes of the same architecture adding modules on top of the base model.

is_parallelizable (bool) — A flag indicating whether this model supports model parallelization.

main_input_name (str) — The name of the principal input to the model (often input_ids for NLP models, pixel_values for vision models and input_values for speech models).

can_record_outputs (dict):

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the model file to the 🤗 Model Hub.

( tags: typing.Union[list[str], str] )

Add custom tags into the model that gets pushed to the Hugging Face Hub. Will not overwrite existing tags in the model.

Whether this model can generate sequences with .generate().

Whether this model can generate sequences with .generate().

Returns whether this model can generate sequences with .generate() from the GenerationMixin.

Under the hood, on classes where this function returns True, some generation-specific changes are triggered: for instance, the model instance will have a populated generation_config attribute.

Potentially dequantize the model in case it has been quantized by a quantization method that support dequantization.

Removes the _require_grads_hook.

Enables the gradients for the input embeddings. This is useful for fine-tuning adapter weights while keeping the model weights fixed.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike, NoneType] *model_args config: typing.Union[transformers.configuration_utils.PretrainedConfig, str, os.PathLike, NoneType] = None cache_dir: typing.Union[str, os.PathLike, NoneType] = None ignore_mismatched_sizes: bool = False force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' use_safetensors: typing.Optional[bool] = None weights_only: bool = True **kwargs )

Configuration for the model to use instead of an automatically loaded configuration. Configuration can be automatically loaded when:

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

Accept HF kernel references in the form:

Examples that match: “org/model” “org/model@main” “org/model:custom_kernel” “org/model@v1.2.3:custom_kernel”

Parameters for big model inference

torch.float16 or torch.bfloat16 or torch.float: load in a specified dtype, ignoring the model’s config.dtype if one exists. If not specified

"auto" - A dtype or torch_dtype entry in the config.json file of the model will be attempted to be used. If this entry isn’t found then next check the dtype of the first weight in the checkpoint that’s of a floating point type and use that as dtype. This will load the model using the dtype it was saved in at the end of the training. It can’t be used as an indicator of how the model was trained. Since it could be trained in one of half precision dtypes, but saved in fp32.

A string that is a valid torch.dtype. E.g. “float32” loads the model in torch.float32, “float16” loads in torch.float16 etc.

For some models the dtype they were trained in is unknown - you may try to check the model’s paper or reach out to the authors and ask them to add this information to the model’s card and to insert the dtype or torch_dtype entry in config.json on the hub.

To have Accelerate compute the most optimized device_map automatically, set device_map="auto". For more information about each option see designing a device map.

Instantiate a pretrained pytorch model from a pre-trained model configuration.

The model is set in evaluation mode by default using model.eval() (Dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train().

The warning Weights from XXX not initialized from pretrained model means that the weights of XXX do not come pretrained with the rest of the model. It is up to you to train those weights with a downstream fine-tuning task.

The warning Weights from XXX not used in YYY means that the layer XXX is not used by YYY, therefore those weights are discarded.

Activate the special “offline-mode” to use this method in a firewalled environment.

( compile_config: typing.Optional[transformers.generation.configuration_utils.CompileConfig] )

Return a torch.compile‘d version of self.__call__. This is useful to dynamically choose between non-compiled/compiled forward during inference, especially to switch between prefill (where we don’t want to use compiled version to avoid recomputing the graph with new shapes) and iterative decoding (where we want the speed-ups of compiled version with static shapes).

Best-effort lookup of the decoder module.

Order of attempts (covers ~85 % of current usages):

( return_buffers = True )

Get the memory footprint of a model. This will return the memory footprint of the current model in bytes. Useful to benchmark the memory footprint of the current model and design some tests. Solution inspired from the PyTorch discussions: https://discuss.pytorch.org/t/gpu-memory-that-model-uses/56822/2

Return the parameter or buffer given by target if it exists, otherwise throw an error. This combines get_parameter() and get_buffer() in a single handy function. If the target is an _extra_state attribute, it will return the extra state provided by the module. Note that it only work if target is a leaf of the model.

Deactivates gradient checkpointing for the current model.

Note that in other frameworks this feature can be referred to as “activation checkpointing” or “checkpoint activations”.

( gradient_checkpointing_kwargs = None )

Activates gradient checkpointing for the current model.

Note that in other frameworks this feature can be referred to as “activation checkpointing” or “checkpoint activations”.

We pass the __call__ method of the modules instead of forward because __call__ attaches all the hooks of the module. https://discuss.pytorch.org/t/any-different-between-model-input-and-model-forward-input/3690/2

If needed prunes and maybe initializes weights. If using a custom PreTrainedModel, you need to implement any initialization logic in _init_weights.

This is equivalent to calling self.apply(self._initialize_weights), but correctly handles composite models. This function dynamically dispatches the correct init_weights function to the modules as we advance in the module graph along the recursion. It can handle an arbitrary number of sub-models. Without it, every composite model would have to recurse a second time on all sub-models explicitly in the outer-most _init_weights, which is extremely error prone and inefficient.

Note that the torch.no_grad() decorator is very important as well, as most of our _init_weights do not use torch.nn.init functions (which are all nograd by default), but simply do in-place ops such as `module.weight.data.zero()`.

A method executed at the end of each Transformer model initialization, to execute code that needs the model’s modules properly initialized (such as weight initialization).

This is also used when the user is running distributed code. We add hooks to the modules here, according to the model’s tp_plan!

( heads_to_prune: dict )

Prunes heads of the base model.

( auto_class = 'AutoModel' )

Register this class with a given auto class. This should only be used for custom models as the ones in the library are already mapped with an auto class.

( new_num_tokens: typing.Optional[int] = None pad_to_multiple_of: typing.Optional[int] = None mean_resizing: bool = True ) → torch.nn.Embedding

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta), or on TPUs which benefit from having sequence lengths be a multiple of 128. For more details about this, or help on choosing the correct value for resizing, refer to this guide: https://docs.nvidia.com/deeplearning/performance/dl-performance-matrix-multiplication/index.html#requirements-tc

Setting mean_resizing to True is useful when increasing the size of the embeddings of causal language models, where the generated tokens’ probabilities won’t be affected by the added embeddings because initializing the new embeddings with the old embeddings’ mean will reduce the kl-divergence between the next token probability before and after adding the new embeddings. Refer to this article for more information: https://nlp.stanford.edu/~johnhew/vocab-expansion.html

Pointer to the input tokens Embeddings Module of the model.

Pointer to the input tokens Embeddings Module of the model.

Resizes input token embeddings matrix of the model if new_num_tokens != config.vocab_size.

Takes care of tying weights embeddings afterwards if the model class has a tie_weights() method.

( ) → PreTrainedModel

The model converted back to the original modeling.

The model converted back to the original modeling.

Reverts the transformation from to_bettertransformer() so that the original modeling is used, for example in order to save the model.

( save_directory: typing.Union[str, os.PathLike] is_main_process: bool = True state_dict: typing.Optional[dict] = None save_function: typing.Callable = <function save at 0x7f6429f34550> push_to_hub: bool = False max_shard_size: typing.Union[int, str] = '5GB' safe_serialization: bool = True variant: typing.Optional[str] = None token: typing.Union[str, bool, NoneType] = None save_peft_format: bool = True **kwargs )

If a single weight of the model is bigger than max_shard_size, it will be in its own checkpoint shard which will be bigger than max_shard_size.

Save a model and its configuration file to a directory, so that it can be re-loaded using the from_pretrained() class method.

( attn_implementation: typing.Union[str, dict] )

Set the requested attn_implementation for this model.

Symmetric setter. Mirrors the lookup logic used in get_decoder.

If set in the config, tie the weights between the input embeddings and the output embeddings, and the encoder and decoder.

If the torchscript flag is set in the configuration, can’t handle parameter sharing so we are cloning the weights instead.

Recursively (for all submodels) tie all the weights of the model.

( ) → PreTrainedModel

The model converted to BetterTransformer.

The model converted to BetterTransformer.

Converts the model to use PyTorch’s native attention implementation, integrated to Transformers through Optimum library. Only a subset of all Transformers models are supported.

PyTorch’s attention fastpath allows to speed up inference through kernel fusions and the use of nested tensors. Detailed benchmarks can be found in this blog post.

( input_ids attention_mask )

Shows a one-time warning if the input_ids appear to contain padding and no attention mask was given.

Custom models should also include a _supports_assign_param_buffer, which determines if superfast init can apply on the particular model. Signs that your model needs this are if test_save_and_load_from_pretrained fails. If so, set this to False.

A few utilities for torch.nn.Modules, to be used as a mixin.

Add a memory hook before and after each sub-module forward pass to record increase in memory consumption.

Increase in memory consumption is stored in a mem_rss_diff attribute for each module and can be reset to zero with model.reset_memory_hooks_state().

( input_dict: dict ) → int

The total number of tokens.

The total number of tokens.

Helper function to estimate the total number of tokens from the model inputs.

( input_dict: dict exclude_embeddings: bool = True ) → int

The number of floating-point operations.

The number of floating-point operations.

Get number of (optionally, non-embeddings) floating-point operations for the forward and backward passes of a batch with this transformer model. Default approximation neglects the quadratic dependency on the number of tokens (valid if 12 * d_model << sequence_length) as laid out in this paper section 2.1. Should be overridden for transformers with parameter re-use e.g. Albert or Universal Transformers, or if doing long-range modeling with very high sequence lengths.

( attention_mask: Tensor input_shape: tuple device: typing.Optional[torch.device] = None dtype: typing.Optional[torch.dtype] = None )

Makes broadcastable attention and causal masks so that future and masked tokens are ignored.

( head_mask: typing.Optional[torch.Tensor] num_hidden_layers: int is_attention_chunked: bool = False )

Prepare the head mask if needed.

( encoder_attention_mask: Tensor ) → torch.Tensor

The inverted attention mask.

The inverted attention mask.

Invert an attention mask (e.g., switches 0. and 1.).

( only_trainable: bool = False exclude_embeddings: bool = False ) → int

The number of parameters.

The number of parameters.

Get number of (optionally, trainable or non-embeddings) parameters in the module.

Reset the mem_rss_diff attribute of each module (see add_memory_hooks()).

A Mixin containing the functionality to push a model or tokenizer to the hub.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the {object_files} to the 🤗 Model Hub.

( model folder strict = True prefer_safe = True ) → NamedTuple

A named tuple with missing_keys and unexpected_keys fields missing_keys is a list of str containing the missing keys unexpected_keys is a list of str containing the unexpected keys

A named tuple with missing_keys and unexpected_keys fields

This is the same as torch.nn.Module.load_state_dict but for a sharded checkpoint.

This load is performed efficiently: each checkpoint shard is loaded one by one in RAM and deleted after being loaded in the model.

**Examples:**

Example 1 (unknown):
```unknown
PreTrainedConfig
```

Example 2 (unknown):
```unknown
pixel_values
```

Example 3 (unknown):
```unknown
input_values
```

Example 4 (unknown):
```unknown
"Upload model"
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/quantization

**Contents:**
- Transformers
- Quantization
- QuantoConfig
  - class transformers.QuantoConfig
    - post_init
- AqlmConfig
  - class transformers.AqlmConfig
    - post_init
- VptqConfig
  - class transformers.VptqConfig

Transformers documentation

and get access to the augmented documentation experience

Quantization techniques reduce memory and computational costs by representing weights and activations with lower-precision data types like 8-bit integers (int8). This enables loading larger models you normally wouldn’t be able to fit into memory, and speeding up inference. Transformers supports the AWQ and GPTQ quantization algorithms and it supports 8-bit and 4-bit quantization with bitsandbytes.

Quantization techniques that aren’t supported in Transformers can be added with the HfQuantizer class.

Learn how to quantize models in the Quantization guide.

( weights = 'int8' activations = None modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using quanto.

Safety checker that arguments are correct

( in_group_size: int = 8 out_group_size: int = 1 num_codebooks: int = 1 nbits_per_codebook: int = 16 linear_weights_not_to_quantize: typing.Optional[list[str]] = None **kwargs )

This is a wrapper class about aqlm parameters.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( enable_proxy_error: bool = False config_for_layers: dict = {} shared_layer_config: dict = {} modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about vptq parameters.

Safety checker that arguments are correct

( bits: int = 4 group_size: int = 128 zero_point: bool = True version: AWQLinearVersion = <AWQLinearVersion.GEMM: 'gemm'> backend: AwqBackendPackingMethod = <AwqBackendPackingMethod.AUTOAWQ: 'autoawq'> do_fuse: typing.Optional[bool] = None fuse_max_seq_len: typing.Optional[int] = None modules_to_fuse: typing.Optional[dict] = None modules_to_not_convert: typing.Optional[list] = None exllama_config: typing.Optional[dict[str, int]] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using auto-awq library awq quantization relying on auto_awq backend.

Safety checker that arguments are correct

( weights: str = 'int8' modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using eetq.

Safety checker that arguments are correct

( bits: int tokenizer: typing.Any = None dataset: typing.Union[list[str], str, NoneType] = None group_size: int = 128 damp_percent: float = 0.1 desc_act: bool = False sym: bool = True true_sequential: bool = True checkpoint_format: str = 'gptq' meta: typing.Optional[dict[str, typing.Any]] = None backend: typing.Optional[str] = None use_cuda_fp16: bool = False model_seqlen: typing.Optional[int] = None block_name_to_quantize: typing.Optional[str] = None module_name_preceding_first_block: typing.Optional[list[str]] = None batch_size: int = 1 pad_token_id: typing.Optional[int] = None use_exllama: typing.Optional[bool] = None max_input_length: typing.Optional[int] = None exllama_config: typing.Optional[dict[str, typing.Any]] = None cache_block_outputs: bool = True modules_in_block_to_quantize: typing.Optional[list[list[str]]] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using optimum api for gptq quantization relying on auto_gptq backend.

Get compatible class with optimum gptq config dict

Safety checker that arguments are correct

Get compatible dict for optimum gptq config

( load_in_8bit = False load_in_4bit = False llm_int8_threshold = 6.0 llm_int8_skip_modules = None llm_int8_enable_fp32_cpu_offload = False llm_int8_has_fp16_weight = False bnb_4bit_compute_dtype = None bnb_4bit_quant_type = 'fp4' bnb_4bit_use_double_quant = False bnb_4bit_quant_storage = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using bitsandbytes.

This replaces load_in_8bit or load_in_4bittherefore both options are mutually exclusive.

Currently only supports LLM.int8(), FP4, and NF4 quantization. If more methods are added to bitsandbytes, then more arguments will be added to this class.

Returns True if the model is quantizable, False otherwise.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

This method returns the quantization method used for the model. If the model is not quantizable, it returns None.

Dictionary of all the attributes that make up this configuration instance,

Dictionary of all the attributes that make up this configuration instance,

Removes all attributes from config which correspond to the default config attributes for better readability and serializes to a Python dictionary.

( quantization_config: QuantizationConfigMixin **kwargs )

Abstract class of the HuggingFace quantizer. Supports for now quantizing HF transformers models for inference and/or quantization. This class is used only for transformers.PreTrainedModel.from_pretrained and cannot be easily used outside the scope of that method yet.

Attributes quantization_config (transformers.utils.quantization_config.QuantizationConfigMixin): The quantization config that defines the quantization parameters of your model that you want to quantize. modules_to_not_convert (list[str], optional): The list of module names to not convert when quantizing the model. required_packages (list[str], optional): The list of required pip packages to install prior to using the quantizer requires_calibration (bool): Whether the quantization method requires to calibrate the model before using it. requires_parameters_quantization (bool): Whether the quantization method requires to create a new Parameter. For example, for bitsandbytes, it is required to create a new xxxParameter in order to properly quantize the model.

adjust max_memory argument for infer_auto_device_map() if extra memory is needed for quantization

( dtype: torch.dtype )

Override this method if you want to adjust the target_dtype variable used in from_pretrained to compute the device_map in case the device_map is a str. E.g. for bitsandbytes we force-set target_dtype to torch.int8 and for 4-bit we pass a custom enum accelerate.CustomDtype.int4.

DEPRECATED -> remove in v5

Take needed components from state_dict (those from which param_needs_quantization is True) and create quantized param. It usually also load the new param directly in the model. Note: only applicable if requires_parameters_quantization == True.

Potentially dequantize the model to retrieve the original model, with some loss in accuracy / performance. Note not all quantization schemes support this.

The factor to be used in caching_allocator_warmup to get the number of bytes to pre-allocate to warm up accelerator. A factor of 2 means we allocate all bytes in the empty model (since we allocate in fp16), a factor of 4 means we allocate half the memory of the weights residing in the empty model, etc…

Override this method if you want to adjust the param_name.

( model dtype: torch.dtype )

returns dtypes for modules that are not quantized - used for the computation of the device_map in case one passes a str as a device_map. The method will use the modules_to_not_convert that is modified in _process_model_before_weight_loading.

( model safe_serialization = False )

Get state dict and metadata. Useful when we need to modify a bit the state dict due to quantization

( model: PreTrainedModel param_name: str **kwargs )

Check whether a given param needs quantization as defined by create_quantized_param.

( model: PreTrainedModel **kwargs )

Post-process the model post weights loading. Make sure to override the abstract method _process_model_after_weight_loading.

( model: PreTrainedModel **kwargs )

Setting model attributes and/or converting model before weights loading. At this point the model should be initialized on the meta device so you can freely manipulate the skeleton of the model in order to replace modules in-place. Make sure to override the abstract method _process_model_before_weight_loading.

Remove the quantization config from the model.

( device_map: typing.Optional[dict[str, typing.Any]] )

Override this method if you want to pass a override the existing device map with a new one. E.g. for bitsandbytes, since accelerate is a hard requirement, if no device_map is passed, the device_map is set to `“auto”“

( dtype: torch.dtype )

Some quantization methods require to explicitly set the dtype of the model to a target dtype. You need to override this method in case you want to make sure that behavior is preserved

updates the tp plan for the scales

( model expected_keys: list loaded_keys: list )

Override this method if you want to adjust the update_expected_keys.

( model missing_keys: list prefix: str )

Override this method if you want to adjust the missing_keys.

( state_dict metadata )

Update state dict with metadata. Default behaviour returns state_dict

( dtype: torch.dtype )

Deprecared in favor of update_dtype!

updates the tp plan for the scales

This method is used to potentially check for potential conflicts with arguments that are passed in from_pretrained. You need to define it for all future quantizers that are integrated with transformers. If no explicit check are needed, simply return nothing.

( bits: int = 4 p: int = 2 modules_to_not_convert: typing.Optional[list[str]] = None hadamard_size: int = 512 group_size: int = 256 tune_metadata: typing.Optional[dict[str, typing.Any]] = None **kwargs )

HiggsConfig is a configuration class for quantization using the HIGGS method.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( nbits: int = 4 group_size: int = 64 view_as_float: bool = False axis: typing.Optional[int] = None dynamic_config: typing.Optional[dict] = None skip_modules: list = ['lm_head'] **kwargs )

This is wrapper around hqq’s BaseQuantizeConfig.

Override from_dict, used in AutoQuantizationConfig.from_dict in quantizers/auto.py

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

Dictionary of all the attributes that make up this configuration instance,

Dictionary of all the attributes that make up this configuration instance,

Removes all attributes from config which correspond to the default config attributes for better readability and serializes to a Python dictionary.

( modules_to_not_convert: typing.Optional[list] = None dequantize: bool = False **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using mxfp4 quantization.

( activation_scale_ub: float = 1200.0 modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using fbgemm fp8 quantization.

( config_groups: typing.Optional[dict[str, typing.Union[ForwardRef('QuantizationScheme'), list[str]]]] = None format: str = 'dense' quantization_status: QuantizationStatus = 'initialized' kv_cache_scheme: typing.Optional[ForwardRef('QuantizationArgs')] = None global_compression_ratio: typing.Optional[float] = None ignore: typing.Optional[list[str]] = None sparsity_config: typing.Optional[dict[str, typing.Any]] = None quant_method: str = 'compressed-tensors' run_compressed: bool = True **kwargs )

This is a wrapper class that handles compressed-tensors quantization config options. It is a wrapper around compressed_tensors.QuantizationConfig

( config_dict return_unused_kwargs = False **kwargs ) → QuantizationConfigMixin

QuantizationConfigMixin

The configuration object instantiated from those parameters.

The configuration object instantiated from those parameters.

Instantiates a CompressedTensorsConfig from a Python dictionary of parameters. Optionally unwraps any args from the nested quantization_config

Quantization config to be added to config.json

Serializes this instance to a Python dictionary. Returns: dict[str, Any]: Dictionary of all the attributes that make up this configuration instance.

Dictionary of all the attributes that make up this configuration instance,

Dictionary of all the attributes that make up this configuration instance,

Removes all attributes from config which correspond to the default config attributes for better readability and serializes to a Python dictionary.

( quant_type: typing.Union[str, ForwardRef('AOBaseConfig')] modules_to_not_convert: typing.Optional[list] = None include_input_output_embeddings: bool = False untie_embedding_weights: bool = False **kwargs )

( config_dict return_unused_kwargs = False **kwargs )

Create configuration from a dictionary.

Create the appropriate quantization method based on configuration.

Validate configuration and set defaults.

Convert configuration to a dictionary.

( modules_to_not_convert: typing.Optional[list] = None linear_class: str = 'bitlinear' quantization_mode: str = 'offline' use_rms_norm: bool = False rms_norm_eps: typing.Optional[float] = 1e-06 **kwargs )

Configuration class for applying BitNet quantization.

Safety checker that arguments are correct

( bits: int = 3 beta1: int = 16 beta2: int = 16 shapes: typing.Optional[dict[str, int]] = None modules_to_not_convert: typing.Optional[list[str]] = None **kwargs )

This is a wrapper class about spqr parameters. Refer to the original publication for more details.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( activation_scheme: str = 'dynamic' weight_block_size: tuple = (128, 128) modules_to_not_convert: typing.Optional[list] = None **kwargs )

FineGrainedFP8Config is a configuration class for fine-grained FP8 quantization used mainly for deepseek models.

Safety checker that arguments are correct

( forward_dtype: str = 'nvfp4' forward_method: str = 'abs_max' backward_dtype: str = 'bf16' store_master_weights: bool = False hadamard_group_size: typing.Optional[int] = None pseudoquantization: bool = False transform_init: str = 'hadamard' modules_to_not_convert: typing.Optional[list[str]] = None **kwargs )

FPQuantConfig is a configuration class for quantization using the FPQuant method.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( bits: int = 4 group_size: int = 128 sym: bool = True backend: str = 'auto' **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded AutoRound quantization.

Safety checker that arguments are correct.

**Examples:**

Example 1 (unknown):
```unknown
HfQuantizer
```

Example 2 (unknown):
```unknown
Optional[list[str]]
```

Example 3 (unknown):
```unknown
dict[str, Any]
```

Example 4 (unknown):
```unknown
dict[str, Any]
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/onnx

**Contents:**
- Transformers
- Exporting 🤗 Transformers models to ONNX
- ONNX Configurations
  - OnnxConfig
  - class transformers.onnx.OnnxConfig
    - flatten_output_collection_property
    - from_model_config
    - generate_dummy_inputs
    - generate_dummy_inputs_onnxruntime
    - use_external_data_format

Transformers documentation

Exporting 🤗 Transformers models to ONNX

and get access to the augmented documentation experience

🤗 Transformers provides a transformers.onnx package that enables you to convert model checkpoints to an ONNX graph by leveraging configuration objects.

See the guide on exporting 🤗 Transformers models for more details.

We provide three abstract classes that you should inherit from, depending on the type of model architecture you wish to export:

( config: PretrainedConfig task: str = 'default' patching_specs: typing.Optional[list[transformers.onnx.config.PatchingSpec]] = None )

Base class for ONNX exportable model describing metadata on how to export the model through the ONNX format.

( name: str field: Iterable ) → (dict[str, Any])

Outputs with flattened structure and key mapping this new structure.

Outputs with flattened structure and key mapping this new structure.

Flatten any potential nested structure expanding the name of the field with the index of the element within the structure.

( config: PretrainedConfig task: str = 'default' )

Instantiate a OnnxConfig for a specific model

( preprocessor: typing.Union[ForwardRef('PreTrainedTokenizerBase'), ForwardRef('FeatureExtractionMixin'), ForwardRef('ImageProcessingMixin')] batch_size: int = -1 seq_length: int = -1 num_choices: int = -1 is_pair: bool = False framework: typing.Optional[transformers.utils.generic.TensorType] = None num_channels: int = 3 image_width: int = 40 image_height: int = 40 sampling_rate: int = 22050 time_duration: float = 5.0 frequency: int = 220 tokenizer: typing.Optional[ForwardRef('PreTrainedTokenizerBase')] = None )

Generate inputs to provide to the ONNX exporter for the specific framework

( reference_model_inputs: Mapping ) → Mapping[str, Tensor]

The mapping holding the kwargs to provide to the model’s forward function

The mapping holding the kwargs to provide to the model’s forward function

Generate inputs for ONNX Runtime using the reference model inputs. Override this to run inference with seq2seq models which have the encoder and decoder exported as separate ONNX files.

( num_parameters: int )

Flag indicating if the model requires using external data format

( config: PretrainedConfig task: str = 'default' patching_specs: typing.Optional[list[transformers.onnx.config.PatchingSpec]] = None use_past: bool = False )

( inputs_or_outputs: Mapping direction: str inverted_values_shape: bool = False )

Fill the input_or_outputs mapping with past_key_values dynamic axes considering.

( config: PretrainedConfig task: str = 'default' )

Instantiate a OnnxConfig with use_past attribute set to True

( config: PretrainedConfig task: str = 'default' patching_specs: typing.Optional[list[transformers.onnx.config.PatchingSpec]] = None use_past: bool = False )

Each ONNX configuration is associated with a set of features that enable you to export models for different types of topologies or tasks.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] feature: str = 'default' )

Check whether or not the model has the requested features.

( model: str framework: typing.Optional[str] = None )

Determines the framework to use for the export.

The priority is in the following order:

( model_type: str feature: str ) → OnnxConfig

config for the combination

config for the combination

Gets the OnnxConfig for a model_type and feature combination.

( feature: str framework: str = 'pt' )

Attempts to retrieve an AutoModel class from a feature name.

( feature: str model: str framework: typing.Optional[str] = None cache_dir: typing.Optional[str] = None )

Attempts to retrieve a model from a model’s name and the feature to be enabled.

( model_type: str model_name: typing.Optional[str] = None )

Tries to retrieve the feature -> OnnxConfig constructor map from the model type.

**Examples:**

Example 1 (unknown):
```unknown
transformers.onnx
```

Example 2 (unknown):
```unknown
Mapping[str, Tensor]
```

Example 3 (unknown):
```unknown
Mapping[str, Tensor]
```

Example 4 (unknown):
```unknown
Mapping[str, Tensor]
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/deepspeed

**Contents:**
- Transformers
- DeepSpeed
- HfDeepSpeedConfig
  - class transformers.integrations.HfDeepSpeedConfig

Transformers documentation

and get access to the augmented documentation experience

DeepSpeed, powered by Zero Redundancy Optimizer (ZeRO), is an optimization library for training and fitting very large models onto a GPU. It is available in several ZeRO stages, where each stage progressively saves more GPU memory by partitioning the optimizer state, gradients, parameters, and enabling offloading to a CPU or NVMe. DeepSpeed is integrated with the Trainer class and most of the setup is automatically taken care of for you.

However, if you want to use DeepSpeed without the Trainer, Transformers provides a HfDeepSpeedConfig class.

Learn more about using DeepSpeed with Trainer in the DeepSpeed guide.

( config_file_or_dict )

This object contains a DeepSpeed configuration dictionary and can be quickly queried for things like zero stage.

A weakref of this object is stored in the module’s globals to be able to access the config from areas where things like the Trainer object is not available (e.g. from_pretrained and _get_resized_embeddings). Therefore it’s important that this object remains alive while the program is still running.

Trainer uses the HfTrainerDeepSpeedConfig subclass instead. That subclass has logic to sync the configuration with values of TrainingArguments by replacing special placeholder values: "auto". Without this special logic the DeepSpeed configuration is not modified in any way.

**Examples:**

Example 1 (unknown):
```unknown
HfDeepSpeedConfig
```

Example 2 (unknown):
```unknown
Union[str, Dict]
```

Example 3 (unknown):
```unknown
from_pretrained
```

Example 4 (unknown):
```unknown
_get_resized_embeddings
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/tokenizer

**Contents:**
- Transformers
- Tokenizer
- Multimodal Tokenizer
- PreTrainedTokenizer
  - class transformers.PreTrainedTokenizer
    - __call__
    - add_tokens
    - add_special_tokens
    - apply_chat_template
    - batch_decode

Transformers documentation

and get access to the augmented documentation experience

A tokenizer is in charge of preparing the inputs for a model. The library contains tokenizers for all the models. Most of the tokenizers are available in two flavors: a full python implementation and a “Fast” implementation based on the Rust library 🤗 Tokenizers. The “Fast” implementations allows:

The base classes PreTrainedTokenizer and PreTrainedTokenizerFast implement the common methods for encoding string inputs in model inputs (see below) and instantiating/saving python and “Fast” tokenizers either from a local file or directory or from a pretrained tokenizer provided by the library (downloaded from HuggingFace’s AWS S3 repository). They both rely on PreTrainedTokenizerBase that contains the common methods, and SpecialTokensMixin.

PreTrainedTokenizer and PreTrainedTokenizerFast thus implement the main methods for using all the tokenizers:

BatchEncoding holds the output of the PreTrainedTokenizerBase’s encoding methods (__call__, encode_plus and batch_encode_plus) and is derived from a Python dictionary. When the tokenizer is a pure python tokenizer, this class behaves just like a standard python dictionary and holds the various model inputs computed by these methods (input_ids, attention_mask…). When the tokenizer is a “Fast” tokenizer (i.e., backed by HuggingFace tokenizers library), this class provides in addition several advanced alignment methods which can be used to map between the original string (character and words) and the token space (e.g., getting the index of the token comprising a given character or the span of characters corresponding to a given token).

Apart from that each tokenizer can be a “multimodal” tokenizer which means that the tokenizer will hold all relevant special tokens as part of tokenizer attributes for easier access. For example, if the tokenizer is loaded from a vision-language model like LLaVA, you will be able to access tokenizer.image_token_id to obtain the special image token used as a placeholder.

To enable extra special tokens for any type of tokenizer, you have to add the following lines and save the tokenizer. Extra special tokens do not have to be modality related and can ne anything that the model often needs access to. In the below code, tokenizer at output_dir will have direct access to three more special tokens.

Base class for all slow tokenizers.

Inherits from PreTrainedTokenizerBase.

Handle all the shared methods for tokenization and special tokens as well as methods downloading/caching/loading pretrained tokenizers as well as adding tokens to the vocabulary.

This class also contain the added tokens in a unified way on top of all tokenizers so we don’t have to handle the specific vocabulary augmentation methods of the various underlying dictionary structures (BPE, sentencepiece…).

Class attributes (overridden by derived classes)

( text: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair: typing.Union[str, list[str], list[list[str]], NoneType] = None text_target: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair_target: typing.Union[str, list[str], list[list[str]], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 is_split_into_words: bool = False pad_to_multiple_of: typing.Optional[int] = None padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_token_type_ids: typing.Optional[bool] = None return_attention_mask: typing.Optional[bool] = None return_overflowing_tokens: bool = False return_special_tokens_mask: bool = False return_offsets_mapping: bool = False return_length: bool = False verbose: bool = True **kwargs ) → BatchEncoding

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

What are token type IDs?

What are attention masks?

This is only available on fast tokenizers inheriting from PreTrainedTokenizerFast, if using Python’s tokenizer, this method will raise NotImplementedError.

A BatchEncoding with the following fields: input_ids — List of token ids to be fed to a model. What are input IDs? token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names). What are token type IDs? attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names). What are attention masks? overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True). num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True). special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True). length — The length of the inputs (when return_length=True)

A BatchEncoding with the following fields:

input_ids — List of token ids to be fed to a model.

token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names).

What are token type IDs?

attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names).

What are attention masks?

overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True).

num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True).

special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True).

length — The length of the inputs (when return_length=True)

Main method to tokenize and prepare for the model one or several sequence(s) or one or several pair(s) of sequences.

( new_tokens: typing.Union[str, tokenizers.AddedToken, collections.abc.Sequence[typing.Union[str, tokenizers.AddedToken]]] special_tokens: bool = False ) → int

See details for tokenizers.AddedToken in HuggingFace tokenizers library.

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a list of new tokens to the tokenizer class. If the new tokens are not in the vocabulary, they are added to it with indices starting from length of the current vocabulary and will be isolated before the tokenization algorithm is applied. Added tokens and tokens from the vocabulary of the tokenization algorithm are therefore not treated in the same way.

Note, when adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

( special_tokens_dict: dict replace_additional_special_tokens = True ) → int

Tokens are only added if they are not already in the vocabulary (tested by checking if the tokenizer assign the index of the unk_token to them).

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a dictionary of special tokens (eos, pad, cls, etc.) to the encoder and link them to class attributes. If special tokens are NOT in the vocabulary, they are added to it (indexed starting from the last index of the current vocabulary).

When adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

Using add_special_tokens will ensure your special tokens can be used in several ways:

When possible, special tokens are already registered for provided pretrained models (for instance BertTokenizer cls_token is already registered to be '[CLS]' and XLM’s one is also registered to be '</s>').

( conversation: typing.Union[list[dict[str, str]], list[list[dict[str, str]]]] tools: typing.Optional[list[typing.Union[dict, typing.Callable]]] = None documents: typing.Optional[list[dict[str, str]]] = None chat_template: typing.Optional[str] = None add_generation_prompt: bool = False continue_final_message: bool = False tokenize: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: bool = False max_length: typing.Optional[int] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_dict: bool = False return_assistant_tokens_mask: bool = False tokenizer_kwargs: typing.Optional[dict[str, typing.Any]] = None **kwargs ) → Union[list[int], Dict]

Union[list[int], Dict]

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

Converts a list of dictionaries with "role" and "content" keys to a list of token ids. This method is intended for use with chat models, and will read the tokenizer’s chat_template attribute to determine the format and control tokens to use when converting.

( sequences: typing.Union[list[int], list[list[int]], ForwardRef('np.ndarray'), ForwardRef('torch.Tensor'), ForwardRef('tf.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → list[str]

The list of decoded sentences.

The list of decoded sentences.

Convert a list of lists of token ids into a list of strings by calling decode.

( token_ids: typing.Union[int, list[int], numpy.ndarray, ForwardRef('torch.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → str

The decoded sentence.

The decoded sentence.

Converts a sequence of ids in a string, using the tokenizer and vocabulary with options to remove special tokens and clean up tokenization spaces.

Similar to doing self.convert_tokens_to_string(self.convert_ids_to_tokens(token_ids)).

( text: typing.Union[str, list[str], list[int]] text_pair: typing.Union[str, list[str], list[int], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None **kwargs ) → list[int], torch.Tensor, tf.Tensor or np.ndarray

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

list[int], torch.Tensor, tf.Tensor or np.ndarray

The tokenized ids of the text.

The tokenized ids of the text.

Converts a string to a sequence of ids (integer), using the tokenizer and vocabulary.

Same as doing self.convert_tokens_to_ids(self.tokenize(text)).

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the tokenizer files to the 🤗 Model Hub.

( ids: typing.Union[int, list[int]] skip_special_tokens: bool = False ) → str or list[str]

The decoded token(s).

The decoded token(s).

Converts a single index or a sequence of indices in a token or a sequence of tokens, using the vocabulary and added tokens.

( tokens: typing.Union[str, list[str]] ) → int or list[int]

The token id or list of token ids.

The token id or list of token ids.

Converts a token string (or a sequence of tokens) in a single integer id (or a sequence of ids), using the vocabulary.

Returns the added tokens in the vocabulary as a dictionary of token to index. Results might be different from the fast call because for now we always add the tokens even if they are already in the vocabulary. This is something we should change.

( pair: bool = False ) → int

Number of special tokens added to sequences.

Number of special tokens added to sequences.

Returns the number of added tokens when encoding a sequence with special tokens.

This encodes a dummy input and checks the number of added tokens, and is therefore not efficient. Do not put this inside your training loop.

( text: str is_split_into_words: bool = False **kwargs ) → tuple[str, dict[str, Any]]

tuple[str, dict[str, Any]]

The prepared text and the unused kwargs.

The prepared text and the unused kwargs.

Performs any necessary transformations before tokenization.

This method should pop the arguments from kwargs and return the remaining kwargs as well. We test the kwargs at the end of the encoding process to be sure all the arguments have been used.

( text: str **kwargs ) → list[str]

Converts a string into a sequence of tokens, using the tokenizer.

Split in words for word-based vocabulary or sub-words for sub-word-based vocabularies (BPE/SentencePieces/WordPieces). Takes care of added tokens.

The PreTrainedTokenizerFast depend on the tokenizers library. The tokenizers obtained from the 🤗 tokenizers library can be loaded very simply into 🤗 transformers. Take a look at the Using tokenizers from 🤗 tokenizers page to understand how this is done.

Base class for all fast tokenizers (wrapping HuggingFace tokenizers library).

Inherits from PreTrainedTokenizerBase.

Handles all the shared methods for tokenization and special tokens, as well as methods for downloading/caching/loading pretrained tokenizers, as well as adding tokens to the vocabulary.

This class also contains the added tokens in a unified way on top of all tokenizers so we don’t have to handle the specific vocabulary augmentation methods of the various underlying dictionary structures (BPE, sentencepiece…).

Class attributes (overridden by derived classes)

( text: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair: typing.Union[str, list[str], list[list[str]], NoneType] = None text_target: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair_target: typing.Union[str, list[str], list[list[str]], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 is_split_into_words: bool = False pad_to_multiple_of: typing.Optional[int] = None padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_token_type_ids: typing.Optional[bool] = None return_attention_mask: typing.Optional[bool] = None return_overflowing_tokens: bool = False return_special_tokens_mask: bool = False return_offsets_mapping: bool = False return_length: bool = False verbose: bool = True **kwargs ) → BatchEncoding

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

What are token type IDs?

What are attention masks?

This is only available on fast tokenizers inheriting from PreTrainedTokenizerFast, if using Python’s tokenizer, this method will raise NotImplementedError.

A BatchEncoding with the following fields: input_ids — List of token ids to be fed to a model. What are input IDs? token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names). What are token type IDs? attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names). What are attention masks? overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True). num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True). special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True). length — The length of the inputs (when return_length=True)

A BatchEncoding with the following fields:

input_ids — List of token ids to be fed to a model.

token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names).

What are token type IDs?

attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names).

What are attention masks?

overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True).

num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True).

special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True).

length — The length of the inputs (when return_length=True)

Main method to tokenize and prepare for the model one or several sequence(s) or one or several pair(s) of sequences.

( new_tokens: typing.Union[str, tokenizers.AddedToken, collections.abc.Sequence[typing.Union[str, tokenizers.AddedToken]]] special_tokens: bool = False ) → int

See details for tokenizers.AddedToken in HuggingFace tokenizers library.

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a list of new tokens to the tokenizer class. If the new tokens are not in the vocabulary, they are added to it with indices starting from length of the current vocabulary and will be isolated before the tokenization algorithm is applied. Added tokens and tokens from the vocabulary of the tokenization algorithm are therefore not treated in the same way.

Note, when adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

( special_tokens_dict: dict replace_additional_special_tokens = True ) → int

Tokens are only added if they are not already in the vocabulary (tested by checking if the tokenizer assign the index of the unk_token to them).

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a dictionary of special tokens (eos, pad, cls, etc.) to the encoder and link them to class attributes. If special tokens are NOT in the vocabulary, they are added to it (indexed starting from the last index of the current vocabulary).

When adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

Using add_special_tokens will ensure your special tokens can be used in several ways:

When possible, special tokens are already registered for provided pretrained models (for instance BertTokenizer cls_token is already registered to be '[CLS]' and XLM’s one is also registered to be '</s>').

( conversation: typing.Union[list[dict[str, str]], list[list[dict[str, str]]]] tools: typing.Optional[list[typing.Union[dict, typing.Callable]]] = None documents: typing.Optional[list[dict[str, str]]] = None chat_template: typing.Optional[str] = None add_generation_prompt: bool = False continue_final_message: bool = False tokenize: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: bool = False max_length: typing.Optional[int] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_dict: bool = False return_assistant_tokens_mask: bool = False tokenizer_kwargs: typing.Optional[dict[str, typing.Any]] = None **kwargs ) → Union[list[int], Dict]

Union[list[int], Dict]

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

Converts a list of dictionaries with "role" and "content" keys to a list of token ids. This method is intended for use with chat models, and will read the tokenizer’s chat_template attribute to determine the format and control tokens to use when converting.

( sequences: typing.Union[list[int], list[list[int]], ForwardRef('np.ndarray'), ForwardRef('torch.Tensor'), ForwardRef('tf.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → list[str]

The list of decoded sentences.

The list of decoded sentences.

Convert a list of lists of token ids into a list of strings by calling decode.

( token_ids: typing.Union[int, list[int], numpy.ndarray, ForwardRef('torch.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → str

The decoded sentence.

The decoded sentence.

Converts a sequence of ids in a string, using the tokenizer and vocabulary with options to remove special tokens and clean up tokenization spaces.

Similar to doing self.convert_tokens_to_string(self.convert_ids_to_tokens(token_ids)).

( text: typing.Union[str, list[str], list[int]] text_pair: typing.Union[str, list[str], list[int], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None **kwargs ) → list[int], torch.Tensor, tf.Tensor or np.ndarray

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

list[int], torch.Tensor, tf.Tensor or np.ndarray

The tokenized ids of the text.

The tokenized ids of the text.

Converts a string to a sequence of ids (integer), using the tokenizer and vocabulary.

Same as doing self.convert_tokens_to_ids(self.tokenize(text)).

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the tokenizer files to the 🤗 Model Hub.

( ids: typing.Union[int, list[int]] skip_special_tokens: bool = False ) → str or list[str]

The decoded token(s).

The decoded token(s).

Converts a single index or a sequence of indices in a token or a sequence of tokens, using the vocabulary and added tokens.

( tokens: typing.Union[str, collections.abc.Iterable[str]] ) → int or list[int]

The token id or list of token ids.

The token id or list of token ids.

Converts a token string (or a sequence of tokens) in a single integer id (or a Iterable of ids), using the vocabulary.

Returns the added tokens in the vocabulary as a dictionary of token to index.

( pair: bool = False ) → int

Number of special tokens added to sequences.

Number of special tokens added to sequences.

Returns the number of added tokens when encoding a sequence with special tokens.

This encodes a dummy input and checks the number of added tokens, and is therefore not efficient. Do not put this inside your training loop.

( padding_strategy: PaddingStrategy truncation_strategy: TruncationStrategy max_length: int stride: int pad_to_multiple_of: typing.Optional[int] padding_side: typing.Optional[str] )

Define the truncation and the padding strategies for fast tokenizers (provided by HuggingFace tokenizers library) and restore the tokenizer settings afterwards.

The provided tokenizer has no padding / truncation strategy before the managed section. If your tokenizer set a padding / truncation strategy before, then it will be reset to no padding / truncation when exiting the managed section.

( text_iterator vocab_size length = None new_special_tokens = None special_tokens_map = None **kwargs ) → PreTrainedTokenizerFast

PreTrainedTokenizerFast

A new tokenizer of the same type as the original one, trained on text_iterator.

A new tokenizer of the same type as the original one, trained on text_iterator.

Trains a tokenizer on a new corpus with the same defaults (in terms of special tokens or tokenization pipeline) as the current one.

( data: typing.Optional[dict[str, typing.Any]] = None encoding: typing.Union[tokenizers.Encoding, collections.abc.Sequence[tokenizers.Encoding], NoneType] = None tensor_type: typing.Union[NoneType, str, transformers.utils.generic.TensorType] = None prepend_batch_axis: bool = False n_sequences: typing.Optional[int] = None )

Holds the output of the call(), encode_plus() and batch_encode_plus() methods (tokens, attention_masks, etc).

This class is derived from a python dictionary and can be used as a dictionary. In addition, this class exposes utility methods to map from word/character space to token space.

( batch_or_char_index: int char_index: typing.Optional[int] = None sequence_index: int = 0 ) → int

Index of the token, or None if the char index refers to a whitespace only token and whitespace is trimmed with trim_offsets=True.

Index of the token, or None if the char index refers to a whitespace only token and whitespace is trimmed with trim_offsets=True.

Get the index of the token in the encoded output comprising a character in the original string for a sequence of the batch.

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e. words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_or_char_index: int char_index: typing.Optional[int] = None sequence_index: int = 0 ) → int or list[int]

Index or indices of the associated encoded token(s).

Index or indices of the associated encoded token(s).

Get the word in the original string corresponding to a character in the original string of a sequence of the batch.

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e. words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( tensor_type: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None prepend_batch_axis: bool = False )

Convert the inner content to tensors.

( batch_index: int = 0 ) → list[Optional[int]]

A list indicating the sequence id corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding sequence.

A list indicating the sequence id corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding sequence.

Return a list mapping the tokens to the id of their original sentences:

( device: typing.Union[str, ForwardRef('torch.device')] non_blocking: bool = False ) → BatchEncoding

The same instance after modification.

The same instance after modification.

Send all values to device by calling v.to(device, non_blocking=non_blocking) (PyTorch only).

( batch_or_token_index: int token_index: typing.Optional[int] = None ) → CharSpan

Span of characters in the original string, or None, if the token (e.g. , ) doesn’t correspond to any chars in the origin string.

Span of characters in the original string, or None, if the token (e.g. , ) doesn’t correspond to any chars in the origin string.

Get the character span corresponding to an encoded token in a sequence of the batch.

Character spans are returned as a CharSpan with:

( batch_or_token_index: int token_index: typing.Optional[int] = None ) → int

Index of the word in the input sequence.

Index of the word in the input sequence.

Get the index of the sequence represented by the given token. In the general use case, this method returns 0 for a single sequence or the first sequence of a pair, and 1 for the second sequence of a pair

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e., words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_or_token_index: int token_index: typing.Optional[int] = None ) → int

Index of the word in the input sequence.

Index of the word in the input sequence.

Get the index of the word corresponding (i.e. comprising) to an encoded token in a sequence of the batch.

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e., words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_index: int = 0 ) → list[str]

The list of tokens at that index.

The list of tokens at that index.

Return the list of tokens (sub-parts of the input strings after word/subword splitting and before conversion to integer indices) at a given batch index (only works for the output of a fast tokenizer).

( batch_index: int = 0 ) → list[Optional[int]]

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

Return a list mapping the tokens to their actual word in the initial sentence for a fast tokenizer.

( batch_or_word_index: int word_index: typing.Optional[int] = None sequence_index: int = 0 ) → CharSpan or list[CharSpan]

CharSpan or list[CharSpan]

Span(s) of the associated character or characters in the string. CharSpan are NamedTuple with: start: index of the first character associated to the token in the original string end: index of the character following the last character associated to the token in the original string

Span(s) of the associated character or characters in the string. CharSpan are NamedTuple with:

Get the character span in the original string corresponding to given word in a sequence of the batch.

Character spans are returned as a CharSpan NamedTuple with:

( batch_or_word_index: int word_index: typing.Optional[int] = None sequence_index: int = 0 ) → (TokenSpan, optional)

(TokenSpan, optional)

Span of tokens in the encoded sequence. Returns None if no tokens correspond to the word. This can happen especially when the token is a special token that has been used to format the tokenization. For example when we add a class token at the very beginning of the tokenization.

Span of tokens in the encoded sequence. Returns None if no tokens correspond to the word. This can happen especially when the token is a special token that has been used to format the tokenization. For example when we add a class token at the very beginning of the tokenization.

Get the encoded token span corresponding to a word in a sequence of the batch.

Token spans are returned as a TokenSpan with:

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e. words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_index: int = 0 ) → list[Optional[int]]

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

Return a list mapping the tokens to their actual word in the initial sentence for a fast tokenizer.

**Examples:**

Example 1 (unknown):
```unknown
encode_plus
```

Example 2 (unknown):
```unknown
batch_encode_plus
```

Example 3 (unknown):
```unknown
attention_mask
```

Example 4 (unknown):
```unknown
tokenizer.image_token_id
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/configuration

**Contents:**
- Transformers
- Configuration
- PretrainedConfig
  - class transformers.PretrainedConfig
    - push_to_hub
    - dict_dtype_to_str
    - from_dict
    - from_json_file
    - from_pretrained
    - from_text_audio_configs

Transformers documentation

and get access to the augmented documentation experience

The base class PretrainedConfig implements the common methods for loading/saving a configuration either from a local file or directory, or from a pretrained model configuration provided by the library (downloaded from HuggingFace’s AWS S3 repository).

Each derived config class implements model specific attributes. Common attributes present in all config classes are: hidden_size, num_attention_heads, and num_hidden_layers. Text models further implement: vocab_size.

( output_hidden_states: bool = False output_attentions: bool = False return_dict: bool = True torchscript: bool = False dtype: typing.Union[str, ForwardRef('torch.dtype'), NoneType] = None pruned_heads: typing.Optional[dict[int, list[int]]] = None tie_word_embeddings: bool = True chunk_size_feed_forward: int = 0 is_encoder_decoder: bool = False is_decoder: bool = False cross_attention_hidden_size: typing.Optional[int] = None add_cross_attention: bool = False tie_encoder_decoder: bool = False architectures: typing.Optional[list[str]] = None finetuning_task: typing.Optional[str] = None id2label: typing.Optional[dict[int, str]] = None label2id: typing.Optional[dict[str, int]] = None num_labels: typing.Optional[int] = None task_specific_params: typing.Optional[dict[str, typing.Any]] = None problem_type: typing.Optional[str] = None tokenizer_class: typing.Optional[str] = None prefix: typing.Optional[str] = None bos_token_id: typing.Optional[int] = None pad_token_id: typing.Optional[int] = None eos_token_id: typing.Optional[int] = None sep_token_id: typing.Optional[int] = None decoder_start_token_id: typing.Optional[int] = None **kwargs )

For instance {1: [0, 2], 2: [2, 3]} will prune heads 0 and 2 on layer 1 and heads 2 and 3 on layer 2.

Parameters for fine-tuning tasks

Parameters linked to the tokenizer

PyTorch specific parameters

Base class for all configuration classes. Handles a few parameters common to all models’ configurations as well as methods for loading/downloading/saving configurations.

A configuration file can be loaded and saved to disk. Loading the configuration file and using this file to initialize a model does not load the model weights. It only affects the model’s configuration.

Class attributes (overridden by derived classes):

Common attributes (present in all subclasses):

Setting parameters for sequence generation in the model config is deprecated. For backward compatibility, loading some of them will still be possible, but attempting to overwrite them will throw an exception — you should set them in a [~transformers.GenerationConfig]. Check the documentation of [~transformers.GenerationConfig] for more information about the individual parameters.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the configuration file to the 🤗 Model Hub.

Checks whether the passed dictionary and its nested dicts have a dtype key and if it’s not None, converts torch.dtype to a string of just the type. For example, torch.float32 get converted into “float32” string, which can then be stored in the json format.

( config_dict: dict **kwargs ) → PretrainedConfig

The configuration object instantiated from those parameters.

The configuration object instantiated from those parameters.

Instantiates a PretrainedConfig from a Python dictionary of parameters.

( json_file: typing.Union[str, os.PathLike] ) → PretrainedConfig

The configuration object instantiated from that JSON file.

The configuration object instantiated from that JSON file.

Instantiates a PretrainedConfig from the path to a JSON file of parameters.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[bool, str, NoneType] = None revision: str = 'main' **kwargs ) → PretrainedConfig

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

If True, then this functions returns a Tuple(config, unused_kwargs) where unused_kwargs is a dictionary consisting of the key/value pairs whose keys are not configuration attributes: i.e., the part of kwargs which has not been used to update config and is otherwise ignored.

The configuration object instantiated from this pretrained model.

The configuration object instantiated from this pretrained model.

Instantiate a PretrainedConfig (or a derived class) from a pretrained model configuration.

( text_config audio_config **kwargs ) → PreTrainedConfig

An instance of a configuration object

An instance of a configuration object

Instantiate a model config (or a derived class) from text model configuration and audio model configuration.

( text_config vision_config **kwargs ) → PreTrainedConfig

An instance of a configuration object

An instance of a configuration object

Instantiate a model config (or a derived class) from text model configuration and vision model configuration.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] **kwargs ) → tuple[Dict, Dict]

The dictionary(ies) that will be used to instantiate the configuration object.

The dictionary(ies) that will be used to instantiate the configuration object.

From a pretrained_model_name_or_path, resolve to a dictionary of parameters, to be used for instantiating a PretrainedConfig using from_dict.

( decoder = None encoder = None )

Returns the text config related to the text input (encoder) or text output (decoder) of the model. The decoder and encoder input arguments can be used to specify which end of the model we are interested in, which is useful on models that have both text input and output modalities.

There are three possible outcomes of using this method:

( auto_class = 'AutoConfig' )

Register this class with a given auto class. This should only be used for custom configurations as the ones in the library are already mapped with AutoConfig.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save a configuration object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

Dictionary of all the attributes that make up this configuration instance.

Dictionary of all the attributes that make up this configuration instance.

Serializes this instance to a Python dictionary.

Dictionary of all the attributes that make up this configuration instance.

Dictionary of all the attributes that make up this configuration instance.

Removes all attributes from the configuration that correspond to the default config attributes for better readability, while always retaining the config attribute from the class. Serializes to a Python dictionary.

( json_file_path: typing.Union[str, os.PathLike] use_diff: bool = True )

Save this instance to a JSON file.

( use_diff: bool = True ) → str

String containing all the attributes that make up this configuration instance in JSON format.

String containing all the attributes that make up this configuration instance in JSON format.

Serializes this instance to a JSON string.

( config_dict: dict )

Updates attributes of this class with attributes from config_dict.

Updates attributes of this class with attributes from update_str.

The expected format is ints, floats and strings as is, and for booleans use true or false. For example: “n_embd=10,resid_pdrop=0.2,scale_attn_weights=false,summary_type=cls_index”

The keys to change have to already exist in the config object.

**Examples:**

Example 1 (unknown):
```unknown
hidden_size
```

Example 2 (unknown):
```unknown
num_attention_heads
```

Example 3 (unknown):
```unknown
num_hidden_layers
```

Example 4 (unknown):
```unknown
TFPreTrainedModel.from_pretrained()
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/llm_tutorial

**Contents:**
- Transformers
- Text generation
- Default generate
- Generation configuration
  - Saving
- Common Options
- Pitfalls
  - Output length
  - Decoding strategy
  - Padding side

Transformers documentation

and get access to the augmented documentation experience

Text generation is the most popular application for large language models (LLMs). A LLM is trained to generate the next word (token) given some initial text (prompt) along with its own generated outputs up to a predefined length or when it reaches an end-of-sequence (EOS) token.

In Transformers, the generate() API handles text generation, and it is available for all models with generative capabilities. This guide will show you the basics of text generation with generate() and some common pitfalls to avoid.

You can also chat with a model directly from the command line. (reference)

Before you begin, it’s helpful to install bitsandbytes to quantize really large models to reduce their memory usage.

Bitsandbytes supports multiple backends in addition to CUDA-based GPUs. Refer to the multi-backend installation guide to learn more.

Load a LLM with from_pretrained() and add the following two parameters to reduce the memory requirements.

Tokenize your input, and set the padding_side() parameter to "left" because a LLM is not trained to continue generation from padding tokens. The tokenizer returns the input ids and attention mask.

Process more than one prompt at a time by passing a list of strings to the tokenizer. Batch the inputs to improve throughput at a small cost to latency and memory.

Pass the inputs to generate() to generate tokens, and batch_decode() the generated tokens back to text.

All generation settings are contained in GenerationConfig. In the example above, the generation settings are derived from the generation_config.json file of mistralai/Mistral-7B-v0.1. A default decoding strategy is used when no configuration is saved with a model.

Inspect the configuration through the generation_config attribute. It only shows values that are different from the default configuration, in this case, the bos_token_id and eos_token_id.

You can customize generate() by overriding the parameters and values in GenerationConfig. See this section below for commonly adjusted parameters.

generate() can also be extended with external libraries or custom code:

Refer to the Generation strategies guide to learn more about search, sampling, and decoding strategies.

Create an instance of GenerationConfig and specify the decoding parameters you want.

Use save_pretrained() to save a specific generation configuration and set the push_to_hub parameter to True to upload it to the Hub.

Leave the config_file_name parameter empty. This parameter should be used when storing multiple generation configurations in a single directory. It gives you a way to specify which generation configuration to load. You can create different configurations for different generative tasks (creative text generation with sampling, summarization with beam search) for use with a single model.

generate() is a powerful tool that can be heavily customized. This can be daunting for a new users. This section contains a list of popular generation options that you can define in most text generation tools in Transformers: generate(), GenerationConfig, pipelines, the chat CLI, …

The section below covers some common issues you may encounter during text generation and how to solve them.

generate() returns up to 20 tokens by default unless otherwise specified in a models GenerationConfig. It is highly recommended to manually set the number of generated tokens with the max_new_tokens parameter to control the output length. Decoder-only models returns the initial prompt along with the generated tokens.

The default decoding strategy in generate() is greedy search, which selects the next most likely token, unless otherwise specified in a models GenerationConfig. While this decoding strategy works well for input-grounded tasks (transcription, translation), it is not optimal for more creative use cases (story writing, chat applications).

For example, enable a multinomial sampling strategy to generate more diverse outputs. Refer to the Generation strategy guide for more decoding strategies.

Inputs need to be padded if they don’t have the same length. But LLMs aren’t trained to continue generation from padding tokens, which means the padding_side() parameter needs to be set to the left of the input.

Some models and tasks expect a certain input prompt format, and if the format is incorrect, the model returns a suboptimal output. You can learn more about prompting in the prompt engineering guide.

For example, a chat model expects the input as a chat template. Your prompt should include a role and content to indicate who is participating in the conversation. If you try to pass your prompt as a single string, the model doesn’t always return the expected output.

Take a look below for some more specific and specialized text generation libraries.

**Examples:**

Example 1 (unknown):
```unknown
device_map="auto"
```

Example 2 (unknown):
```unknown
quantization_config
```

Example 3 (unknown):
```unknown
padding_side()
```

Example 4 (unknown):
```unknown
generation_config.json
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/peft

**Contents:**
- Transformers
- PEFT
  - class transformers.integrations.PeftAdapterMixin
    - load_adapter
    - add_adapter
    - set_adapter
    - disable_adapters
    - enable_adapters
    - active_adapters
    - get_adapter_state_dict

Transformers documentation

and get access to the augmented documentation experience

The PeftAdapterMixin provides functions from the PEFT library for managing adapters with Transformers. This mixin currently supports LoRA, IA3, and AdaLora. Prefix tuning methods (prompt tuning, prompt learning) aren’t supported because they can’t be injected into a torch module.

A class containing all functions for loading and using adapters weights that are supported in PEFT library. For more details about adapters and injecting them on a transformer-based model, check out the documentation of PEFT library: https://huggingface.co/docs/peft/index

Currently supported PEFT methods are all non-prompt learning methods (LoRA, IA³, etc.). Other PEFT models such as prompt tuning, prompt learning are out of scope as these adapters are not “injectable” into a torch module. For using these methods, please refer to the usage guide of PEFT library.

With this mixin, if the correct PEFT version is installed, it is possible to:

( peft_model_id: typing.Optional[str] = None adapter_name: typing.Optional[str] = None revision: typing.Optional[str] = None token: typing.Optional[str] = None device_map: str = 'auto' max_memory: typing.Optional[str] = None offload_folder: typing.Optional[str] = None offload_index: typing.Optional[int] = None peft_config: typing.Optional[dict[str, typing.Any]] = None adapter_state_dict: typing.Optional[dict[str, 'torch.Tensor']] = None low_cpu_mem_usage: bool = False is_trainable: bool = False adapter_kwargs: typing.Optional[dict[str, typing.Any]] = None )

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

To have Accelerate compute the most optimized device_map automatically, set device_map="auto". For more information about each option see designing a device map.

Load adapter weights from file or remote Hub folder. If you are not familiar with adapters and PEFT methods, we invite you to read more about them on PEFT official documentation: https://huggingface.co/docs/peft

Requires PEFT to be installed as a backend to load the adapter weights.

( adapter_config adapter_name: typing.Optional[str] = None )

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Adds a fresh new adapter to the current model for training purpose. If no adapter name is passed, a default name is assigned to the adapter to follow the convention of PEFT library (in PEFT we use “default” as the default adapter name).

Note that the newly added adapter is not automatically activated. To activate it, use model.set_adapter.

( adapter_name: typing.Union[list[str], str] )

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Sets a specific adapter by forcing the model to use a that adapter and disable the other adapters.

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Disable all adapters that are attached to the model. This leads to inferring with the base model only.

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Enable adapters that are attached to the model.

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Gets the current active adapters of the model. In case of multi-adapter inference (combining multiple adapters for inference) returns the list of all active adapters so that users can deal with them accordingly.

For previous PEFT versions (that does not support multi-adapter inference), module.active_adapter will return a single string.

( adapter_name: typing.Optional[str] = None state_dict: typing.Optional[dict] = None )

If you are not familiar with adapters and PEFT methods, we invite you to read more about them on the PEFT official documentation: https://huggingface.co/docs/peft

Gets the adapter state dict that should only contain the weights tensors of the specified adapter_name adapter. If no adapter_name is passed, the active adapter is used.

**Examples:**

Example 1 (unknown):
```unknown
revision="refs/pr/<pr_number>"
```

Example 2 (unknown):
```unknown
hf auth login
```

Example 3 (unknown):
```unknown
dict[str, Union[int, str, torch.device]]
```

Example 4 (unknown):
```unknown
torch.device
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/keras_callbacks

**Contents:**
- Transformers
- Keras callbacks
- KerasMetricCallback
  - class transformers.KerasMetricCallback
- PushToHubCallback
  - class transformers.PushToHubCallback

Transformers documentation

and get access to the augmented documentation experience

When training a Transformers model with Keras, there are some library-specific callbacks available to automate common tasks:

( metric_fn: typing.Callable eval_dataset: typing.Union[tensorflow.python.data.ops.dataset_ops.DatasetV2, numpy.ndarray, tensorflow.python.framework.tensor.Tensor, tuple, dict] output_cols: typing.Optional[list[str]] = None label_cols: typing.Optional[list[str]] = None batch_size: typing.Optional[int] = None predict_with_generate: bool = False use_xla_generation: bool = False generate_kwargs: typing.Optional[dict] = None )

Callback to compute metrics at the end of every epoch. Unlike normal Keras metrics, these do not need to be compilable by TF. It is particularly useful for common NLP metrics like BLEU and ROUGE that require string operations or generation loops that cannot be compiled. Predictions (or generations) will be computed on the eval_dataset before being passed to the metric_fn in np.ndarray format. The metric_fn should compute metrics and return a dict mapping metric names to metric values.

We provide an example of a suitable metric_fn that computes ROUGE scores for a summarization model below. Note that this example skips some post-processing for readability and simplicity, and should probably not be used as-is!

The above function will return a dict containing values which will be logged like any other Keras metric:

( output_dir: typing.Union[str, pathlib.Path] save_strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'epoch' save_steps: typing.Optional[int] = None tokenizer: typing.Optional[transformers.tokenization_utils_base.PreTrainedTokenizerBase] = None hub_model_id: typing.Optional[str] = None hub_token: typing.Optional[str] = None checkpoint: bool = False **model_card_args )

Will default to the name of output_dir.

Callback that will save and push the model to the Hub regularly. By default, it pushes once per epoch, but this can be changed with the save_strategy argument. Pushed models can be accessed like any other model on the hub, such as with the from_pretrained method.

**Examples:**

Example 1 (unknown):
```unknown
predictions
```

Example 2 (unknown):
```unknown
tf.data.Dataset
```

Example 3 (unknown):
```unknown
tf.data.Dataset
```

Example 4 (unknown):
```unknown
model.generate()
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/output

**Contents:**
- Transformers
- Model outputs
- ModelOutput
  - class transformers.utils.ModelOutput
    - to_tuple
- BaseModelOutput
  - class transformers.modeling_outputs.BaseModelOutput
- BaseModelOutputWithPooling
  - class transformers.modeling_outputs.BaseModelOutputWithPooling
- BaseModelOutputWithCrossAttentions

Transformers documentation

and get access to the augmented documentation experience

All models have outputs that are instances of subclasses of ModelOutput. Those are data structures containing all the information returned by the model, but that can also be used as tuples or dictionaries.

Let’s see how this looks in an example:

The outputs object is a SequenceClassifierOutput, as we can see in the documentation of that class below, it means it has an optional loss, a logits, an optional hidden_states and an optional attentions attribute. Here we have the loss since we passed along labels, but we don’t have hidden_states and attentions because we didn’t pass output_hidden_states=True or output_attentions=True.

When passing output_hidden_states=True you may expect the outputs.hidden_states[-1] to match outputs.last_hidden_state exactly. However, this is not always the case. Some models apply normalization or subsequent process to the last hidden state when it’s returned.

You can access each attribute as you would usually do, and if that attribute has not been returned by the model, you will get None. Here for instance outputs.loss is the loss computed by the model, and outputs.attentions is None.

When considering our outputs object as tuple, it only considers the attributes that don’t have None values. Here for instance, it has two elements, loss then logits, so

will return the tuple (outputs.loss, outputs.logits) for instance.

When considering our outputs object as dictionary, it only considers the attributes that don’t have None values. Here for instance, it has two keys that are loss and logits.

We document here the generic model outputs that are used by more than one model type. Specific output types are documented on their corresponding model page.

Base class for all model outputs as dataclass. Has a __getitem__ that allows indexing by integer or slice (like a tuple) or strings (like a dictionary) that will ignore the None attributes. Otherwise behaves like a regular python dictionary.

You can’t unpack a ModelOutput directly. Use the to_tuple() method to convert it to a tuple before.

Convert self to a tuple containing all the attributes/keys that are not None.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model’s outputs, with potential hidden states and attentions.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None pooler_output: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model’s outputs that also contains a pooling of the last hidden states.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Base class for model’s outputs, with potential hidden states and attentions.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None pooler_output: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if config.is_encoder_decoder=True in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Base class for model’s outputs that also contains a pooling of the last hidden states.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if config.is_encoder_decoder=True in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model’s outputs that may also contain a past key/values (to speed up sequential decoding).

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if config.is_encoder_decoder=True in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Base class for model’s outputs that may also contain a past key/values (to speed up sequential decoding).

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model encoder’s outputs that also contains : pre-computed hidden states that can speed up sequential decoding.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for causal language model (or autoregressive) outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Cross attentions weights after the attention softmax, used to compute the weighted average in the cross-attention heads.

Contains pre-computed hidden-states (key and values in the attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Base class for causal language model (or autoregressive) outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for causal language model (or autoregressive) outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for masked language models outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for sequence-to-sequence language models outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of models predicting if two sentences are consecutive or not.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of sentence classification models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of sequence-to-sequence sentence classification models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Classification scores (before SoftMax).

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of multiple choice models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of token classification models.

( loss: typing.Optional[torch.FloatTensor] = None start_logits: typing.Optional[torch.FloatTensor] = None end_logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of question answering models.

( loss: typing.Optional[torch.FloatTensor] = None start_logits: typing.Optional[torch.FloatTensor] = None end_logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of sequence-to-sequence question answering models.

( loss: typing.Optional[torch.FloatTensor] = None spectrogram: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for sequence-to-sequence spectrogram outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

The logits returned do not necessarily have the same size as the pixel_values passed as inputs. This is to avoid doing two interpolations and lose some quality when a user needs to resize the logits to the original image size as post-processing. You should always check your logits shape and resize as needed.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of semantic segmentation models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of image classification models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Base class for outputs of image classification models.

( loss: typing.Optional[torch.FloatTensor] = None predicted_depth: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of depth estimation models.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None extract_features: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for models that have been trained with the Wav2Vec2 loss objective.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None embeddings: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Output type of Wav2Vec2ForXVector.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None loc: typing.Optional[torch.FloatTensor] = None scale: typing.Optional[torch.FloatTensor] = None static_features: typing.Optional[torch.FloatTensor] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for time series model’s encoder outputs that also contains pre-computed hidden states that can speed up sequential decoding.

( loss: typing.Optional[torch.FloatTensor] = None params: typing.Optional[tuple[torch.FloatTensor, ...]] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None loc: typing.Optional[torch.FloatTensor] = None scale: typing.Optional[torch.FloatTensor] = None static_features: typing.Optional[torch.FloatTensor] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for time series model’s decoder outputs that also contain the loss as well as the parameters of the chosen distribution.

( sequences: typing.Optional[torch.FloatTensor] = None )

Base class for time series model’s predictions outputs that contains the sampled values from the chosen distribution.

**Examples:**

Example 1 (unknown):
```unknown
hidden_states
```

Example 2 (unknown):
```unknown
hidden_states
```

Example 3 (unknown):
```unknown
output_hidden_states=True
```

Example 4 (unknown):
```unknown
output_attentions=True
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/trainer

**Contents:**
- Transformers
- Trainer
- Trainer
  - class transformers.Trainer
    - add_callback
    - autocast_smart_context_manager
    - compute_loss
    - compute_loss_context_manager
    - create_model_card
    - create_optimizer

Transformers documentation

and get access to the augmented documentation experience

The Trainer class provides an API for feature-complete training in PyTorch, and it supports distributed training on multiple GPUs/TPUs, mixed precision for NVIDIA GPUs, AMD GPUs, and torch.amp for PyTorch. Trainer goes hand-in-hand with the TrainingArguments class, which offers a wide range of options to customize how a model is trained. Together, these two classes provide a complete training API.

Seq2SeqTrainer and Seq2SeqTrainingArguments inherit from the Trainer and TrainingArguments classes and they’re adapted for training models for sequence-to-sequence tasks such as summarization or translation.

The Trainer class is optimized for 🤗 Transformers models and can have surprising behaviors when used with other models. When using it with your own model, make sure:

( model: typing.Union[transformers.modeling_utils.PreTrainedModel, torch.nn.modules.module.Module, NoneType] = None args: typing.Optional[transformers.training_args.TrainingArguments] = None data_collator: typing.Optional[typing.Callable[[list[typing.Any]], dict[str, typing.Any]]] = None train_dataset: typing.Union[torch.utils.data.dataset.Dataset, torch.utils.data.dataset.IterableDataset, ForwardRef('datasets.Dataset'), NoneType] = None eval_dataset: typing.Union[torch.utils.data.dataset.Dataset, dict[str, torch.utils.data.dataset.Dataset], ForwardRef('datasets.Dataset'), NoneType] = None processing_class: typing.Union[transformers.tokenization_utils_base.PreTrainedTokenizerBase, transformers.image_processing_utils.BaseImageProcessor, transformers.feature_extraction_utils.FeatureExtractionMixin, transformers.processing_utils.ProcessorMixin, NoneType] = None model_init: typing.Optional[typing.Callable[..., transformers.modeling_utils.PreTrainedModel]] = None compute_loss_func: typing.Optional[typing.Callable] = None compute_metrics: typing.Optional[typing.Callable[[transformers.trainer_utils.EvalPrediction], dict]] = None callbacks: typing.Optional[list[transformers.trainer_callback.TrainerCallback]] = None optimizers: tuple = (None, None) optimizer_cls_and_kwargs: typing.Optional[tuple[type[torch.optim.optimizer.Optimizer], dict[str, typing.Any]]] = None preprocess_logits_for_metrics: typing.Optional[typing.Callable[[torch.Tensor, torch.Tensor], torch.Tensor]] = None )

Trainer is optimized to work with the PreTrainedModel provided by the library. You can still use your own models defined as torch.nn.Module as long as they work the same way as the 🤗 Transformers models.

Note that if it’s a torch.utils.data.IterableDataset with some randomization and you are training in a distributed fashion, your iterable dataset should either use a internal attribute generator that is a torch.Generator for the randomization that must be identical on all processes (and the Trainer will manually set the seed of this generator at each epoch) or have a set_epoch() method that internally sets the seed of the RNGs used.

The function may have zero argument, or a single one containing the optuna/Ray Tune/SigOpt trial object, to be able to choose different architectures according to hyper parameters (such as layer count, sizes of inner layers, dropout probabilities etc).

If you want to remove one of the default callbacks used, use the Trainer.remove_callback() method.

Unlike optimizers, this argument avoids the need to place model parameters on the correct devices before initializing the Trainer.

Note that the labels (second parameter) will be None if the dataset does not have them.

Trainer is a simple but feature-complete training and eval loop for PyTorch, optimized for 🤗 Transformers.

Important attributes:

Add a callback to the current list of TrainerCallback.

( cache_enabled: typing.Optional[bool] = True )

A helper wrapper that creates an appropriate context manager for autocast while feeding it the desired arguments, depending on the situation.

( model: Module inputs: dict return_outputs: bool = False num_items_in_batch: typing.Optional[torch.Tensor] = None )

How the loss is computed by Trainer. By default, all models return the loss in the first element.

Subclass and override for custom behavior. If you are not using num_items_in_batch when computing your loss, make sure to overwrite self.model_accepts_loss_kwargs to False. Otherwise, the loss calculating might be slightly inaccurate when performing gradient accumulation.

A helper wrapper to group together context managers.

( language: typing.Optional[str] = None license: typing.Optional[str] = None tags: typing.Union[str, list[str], NoneType] = None model_name: typing.Optional[str] = None finetuned_from: typing.Optional[str] = None tasks: typing.Union[str, list[str], NoneType] = None dataset_tags: typing.Union[str, list[str], NoneType] = None dataset: typing.Union[str, list[str], NoneType] = None dataset_args: typing.Union[str, list[str], NoneType] = None )

Creates a draft of a model card using the information available to the Trainer.

We provide a reasonable default that works well. If you want to use something else, you can pass a tuple in the Trainer’s init through optimizers, or subclass and override this method in a subclass.

( num_training_steps: int )

Setup the optimizer and the learning rate scheduler.

We provide a reasonable default that works well. If you want to use something else, you can pass a tuple in the Trainer’s init through optimizers, or subclass and override this method (or create_optimizer and/or create_scheduler) in a subclass.

( num_training_steps: int optimizer: Optimizer = None )

Setup the scheduler. The optimizer of the trainer must have been set up either before this method is called or passed as an argument.

( eval_dataset: typing.Union[torch.utils.data.dataset.Dataset, dict[str, torch.utils.data.dataset.Dataset], NoneType] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' )

If you pass a dictionary with names of datasets as keys and datasets as values, evaluate will run separate evaluations on each dataset. This can be useful to monitor how training affects other datasets or simply to get a more fine-grained evaluation. When used with load_best_model_at_end, make sure metric_for_best_model references exactly one of the datasets. If you, for example, pass in {"data1": data1, "data2": data2} for two datasets data1 and data2, you could specify metric_for_best_model="eval_data1_loss" for using the loss on data1 and metric_for_best_model="eval_data2_loss" for the loss on data2.

Run evaluation and returns metrics.

The calling script will be responsible for providing a method to compute metrics, as they are task-dependent (pass it to the init compute_metrics argument).

You can also subclass and override this method to inject custom behavior.

( dataloader: DataLoader description: str prediction_loss_only: typing.Optional[bool] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' )

Prediction/evaluation loop, shared by Trainer.evaluate() and Trainer.predict().

Works both with or without labels.

( inputs: dict ) → int

The number of floating-point operations.

The number of floating-point operations.

For models that inherit from PreTrainedModel, uses that method to compute the number of floating point operations for every backward + forward pass. If using another model, either implement such a method in the model or subclass and override this method.

( epoch_iterator: Iterator num_batches: int device: device )

Collects a specified number of batches from the epoch iterator and optionally counts the number of items in the batches to properly scale the loss.

Get all parameter names that weight decay will be applied to.

This function filters out parameters in two ways:

( eval_dataset: typing.Union[str, torch.utils.data.dataset.Dataset, NoneType] = None )

Returns the evaluation ~torch.utils.data.DataLoader.

Subclass and override this method if you want to inject some custom behavior.

Returns the learning rate of each parameter from self.optimizer.

Get the number of trainable parameters.

( args: TrainingArguments model: typing.Optional[transformers.modeling_utils.PreTrainedModel] = None )

Returns the optimizer class and optimizer parameters based on the training arguments.

( param: typing.Union[str, torch.nn.parameter.Parameter, NoneType] = None )

Returns optimizer group for a parameter if given, else returns all optimizer groups for params.

( test_dataset: Dataset )

Returns the test ~torch.utils.data.DataLoader.

Subclass and override this method if you want to inject some custom behavior.

Calculates total batch size (micro_batch grad_accum dp_world_size).

Note: Only considers DP and TP (dp_world_size = world_size // tp_size).

Get the tensor parallel size from either the model or DeepSpeed config.

Returns the training ~torch.utils.data.DataLoader.

Will use no sampler if train_dataset does not implement __len__, a random sampler (adapted to distributed training if necessary) otherwise.

Subclass and override this method if you want to inject some custom behavior.

( hp_space: typing.Optional[typing.Callable[[ForwardRef('optuna.Trial')], dict[str, float]]] = None compute_objective: typing.Optional[typing.Callable[[dict[str, float]], float]] = None n_trials: int = 20 direction: typing.Union[str, list[str]] = 'minimize' backend: typing.Union[ForwardRef('str'), transformers.trainer_utils.HPSearchBackend, NoneType] = None hp_name: typing.Optional[typing.Callable[[ForwardRef('optuna.Trial')], str]] = None **kwargs ) → [trainer_utils.BestRun or list[trainer_utils.BestRun]]

[trainer_utils.BestRun or list[trainer_utils.BestRun]]

All the information about the best run or best runs for multi-objective optimization. Experiment summary can be found in run_summary attribute for Ray backend.

All the information about the best run or best runs for multi-objective optimization. Experiment summary can be found in run_summary attribute for Ray backend.

Launch an hyperparameter search using optuna or Ray Tune or SigOpt. The optimized quantity is determined by compute_objective, which defaults to a function returning the evaluation loss when no metric is provided, the sum of all metrics otherwise.

To use this method, you need to have provided a model_init when initializing your Trainer: we need to reinitialize the model at each new run. This is incompatible with the optimizers argument, so you need to subclass Trainer and override the method create_optimizer_and_scheduler() for custom optimizer/scheduler.

( token: typing.Optional[str] = None )

Initializes a git repo in self.args.hub_model_id.

Whether or not this process is the local (e.g., on one machine if training in a distributed fashion on several machines) main process.

Whether or not this process is the global main process (when training in a distributed fashion on several machines, this is only going to be True for one process).

( logs: dict start_time: typing.Optional[float] = None )

Log logs on the various objects watching training.

Subclass and override this method to inject custom behavior.

Log metrics in a specially formatted way.

Under distributed environment this is done only for a process with rank 0.

Notes on memory reports:

In order to get memory usage report you need to install psutil. You can do that with pip install psutil.

Now when this method is run, you will see a report that will include:

Understanding the reports:

The reporting happens only for process of rank 0 and gpu 0 (if there is a gpu). Typically this is enough since the main process does the bulk of work, but it could be not quite so if model parallel is used and then other GPUs may use a different amount of gpu memory. This is also not the same under DataParallel where gpu0 may require much more memory than the rest since it stores the gradient and optimizer states for all participating GPUs. Perhaps in the future these reports will evolve to measure those too.

The CPU RAM metric measures RSS (Resident Set Size) includes both the memory which is unique to the process and the memory shared with other processes. It is important to note that it does not include swapped out memory, so the reports could be imprecise.

The CPU peak memory is measured using a sampling thread. Due to python’s GIL it may miss some of the peak memory if that thread didn’t get a chance to run when the highest memory was used. Therefore this report can be less than reality. Using tracemalloc would have reported the exact peak memory, but it doesn’t report memory allocations outside of python. So if some C++ CUDA extension allocated its own memory it won’t be reported. And therefore it was dropped in favor of the memory sampling approach, which reads the current process memory usage.

The GPU allocated and peak memory reporting is done with torch.cuda.memory_allocated() and torch.cuda.max_memory_allocated(). This metric reports only “deltas” for pytorch-specific allocations, as torch.cuda memory management system doesn’t track any memory allocated outside of pytorch. For example, the very first cuda call typically loads CUDA kernels, which may take from 0.5 to 2GB of GPU memory.

Note that this tracker doesn’t account for memory allocations outside of Trainer’s __init__, train, evaluate and predict calls.

Because evaluation calls may happen during train, we can’t handle nested invocations because torch.cuda.max_memory_allocated is a single counter, so if it gets reset by a nested eval call, train’s tracker will report incorrect info. If this pytorch issue gets resolved it will be possible to change this class to be re-entrant. Until then we will only track the outer level of train, evaluate and predict methods. Which means that if eval is called during train, it’s the latter that will account for its memory usage and that of the former.

This also means that if any other tool that is used along the Trainer calls torch.cuda.reset_peak_memory_stats, the gpu peak memory stats could be invalid. And the Trainer will disrupt the normal behavior of any such tools that rely on calling torch.cuda.reset_peak_memory_stats themselves.

For best performance you may want to consider turning the memory profiling off for production runs.

( metrics: dict ) → metrics (dict[str, float])

metrics (dict[str, float])

The reformatted metrics

The reformatted metrics

Reformat Trainer metrics values to a human-readable format.

( dataloader: DataLoader )

Helper to get number of samples in a ~torch.utils.data.DataLoader by accessing its dataset. When dataloader.dataset does not exist or has no length, estimates as best it can

( train_dl: DataLoader max_steps: typing.Optional[int] = None )

Helper to get number of tokens in a ~torch.utils.data.DataLoader by enumerating dataloader.

( callback ) → TrainerCallback

The callback removed, if found.

The callback removed, if found.

Remove a callback from the current list of TrainerCallback and returns it.

If the callback is not found, returns None (and no error is raised).

( test_dataset: Dataset ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'test' )

Run prediction and returns predictions and potential metrics.

Depending on the dataset and your use case, your test dataset may contain labels. In that case, this method will also return metrics, like in evaluate().

If your predictions or labels have different sequence length (for instance because you’re doing dynamic padding in a token classification task) the predictions will be padded (on the right) to allow for concatenation into one array. The padding index is -100.

Returns: NamedTuple A namedtuple with the following keys:

( dataloader: DataLoader description: str prediction_loss_only: typing.Optional[bool] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' )

Prediction/evaluation loop, shared by Trainer.evaluate() and Trainer.predict().

Works both with or without labels.

( model: Module inputs: dict prediction_loss_only: bool ignore_keys: typing.Optional[list[str]] = None ) → tuple[Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor]]

The dictionary will be unpacked before being fed to the model. Most models expect the targets under the argument labels. Check your model’s documentation for all accepted arguments.

tuple[Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor]]

A tuple with the loss, logits and labels (each being optional).

A tuple with the loss, logits and labels (each being optional).

Perform an evaluation step on model using inputs.

Subclass and override to inject custom behavior.

( auto_find_batch_size = False )

Sets values in the deepspeed plugin based on the Trainer args

( commit_message: typing.Optional[str] = 'End of training' blocking: bool = True token: typing.Optional[str] = None revision: typing.Optional[str] = None **kwargs )

Upload self.model and self.processing_class to the 🤗 model hub on the repo self.args.hub_model_id.

Remove a callback from the current list of TrainerCallback.

( split metrics combined = True )

Save metrics into a json file for that split, e.g. train_results.json.

Under distributed environment this is done only for a process with rank 0.

To understand the metrics please read the docstring of log_metrics(). The only difference is that raw unformatted numbers are saved in the current method.

( output_dir: typing.Optional[str] = None _internal_call: bool = False )

Will save the model, so you can reload it using from_pretrained().

Will only save from the main process.

Saves the Trainer state, since Trainer.save_model saves only the tokenizer with the model.

Under distributed environment this is done only for a process with rank 0.

( args: TrainingArguments dataloader: DataLoader total_train_batch_size: int )

Calculates and returns the following values:

( resume_from_checkpoint: typing.Union[bool, str, NoneType] = None trial: typing.Union[ForwardRef('optuna.Trial'), dict[str, typing.Any], NoneType] = None ignore_keys_for_eval: typing.Optional[list[str]] = None **kwargs: typing.Any )

Main training entry point.

( model: Module inputs: dict num_items_in_batch: typing.Optional[torch.Tensor] = None ) → torch.Tensor

The dictionary will be unpacked before being fed to the model. Most models expect the targets under the argument labels. Check your model’s documentation for all accepted arguments.

The tensor with training loss on this batch.

The tensor with training loss on this batch.

Perform a training step on a batch of inputs.

Subclass and override to inject custom behavior.

( model: typing.Union[ForwardRef('PreTrainedModel'), torch.nn.modules.module.Module, NoneType] = None args: typing.Optional[ForwardRef('TrainingArguments')] = None data_collator: typing.Optional[ForwardRef('DataCollator')] = None train_dataset: typing.Union[torch.utils.data.dataset.Dataset, ForwardRef('IterableDataset'), ForwardRef('datasets.Dataset'), NoneType] = None eval_dataset: typing.Union[torch.utils.data.dataset.Dataset, dict[str, torch.utils.data.dataset.Dataset], NoneType] = None processing_class: typing.Union[ForwardRef('PreTrainedTokenizerBase'), ForwardRef('BaseImageProcessor'), ForwardRef('FeatureExtractionMixin'), ForwardRef('ProcessorMixin'), NoneType] = None model_init: typing.Optional[typing.Callable[[], ForwardRef('PreTrainedModel')]] = None compute_loss_func: typing.Optional[typing.Callable] = None compute_metrics: typing.Optional[typing.Callable[[ForwardRef('EvalPrediction')], dict]] = None callbacks: typing.Optional[list['TrainerCallback']] = None optimizers: tuple = (None, None) preprocess_logits_for_metrics: typing.Optional[typing.Callable[[torch.Tensor, torch.Tensor], torch.Tensor]] = None )

( eval_dataset: typing.Optional[torch.utils.data.dataset.Dataset] = None ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'eval' **gen_kwargs )

Run evaluation and returns metrics.

The calling script will be responsible for providing a method to compute metrics, as they are task-dependent (pass it to the init compute_metrics argument).

You can also subclass and override this method to inject custom behavior.

( test_dataset: Dataset ignore_keys: typing.Optional[list[str]] = None metric_key_prefix: str = 'test' **gen_kwargs )

Run prediction and returns predictions and potential metrics.

Depending on the dataset and your use case, your test dataset may contain labels. In that case, this method will also return metrics, like in evaluate().

If your predictions or labels have different sequence lengths (for instance because you’re doing dynamic padding in a token classification task) the predictions will be padded (on the right) to allow for concatenation into one array. The padding index is -100.

Returns: NamedTuple A namedtuple with the following keys:

( output_dir: typing.Optional[str] = None overwrite_output_dir: bool = False do_train: bool = False do_eval: bool = False do_predict: bool = False eval_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'no' prediction_loss_only: bool = False per_device_train_batch_size: int = 8 per_device_eval_batch_size: int = 8 per_gpu_train_batch_size: typing.Optional[int] = None per_gpu_eval_batch_size: typing.Optional[int] = None gradient_accumulation_steps: int = 1 eval_accumulation_steps: typing.Optional[int] = None eval_delay: float = 0 torch_empty_cache_steps: typing.Optional[int] = None learning_rate: float = 5e-05 weight_decay: float = 0.0 adam_beta1: float = 0.9 adam_beta2: float = 0.999 adam_epsilon: float = 1e-08 max_grad_norm: float = 1.0 num_train_epochs: float = 3.0 max_steps: int = -1 lr_scheduler_type: typing.Union[transformers.trainer_utils.SchedulerType, str] = 'linear' lr_scheduler_kwargs: typing.Union[dict[str, typing.Any], str] = <factory> warmup_ratio: float = 0.0 warmup_steps: int = 0 log_level: str = 'passive' log_level_replica: str = 'warning' log_on_each_node: bool = True logging_dir: typing.Optional[str] = None logging_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'steps' logging_first_step: bool = False logging_steps: float = 500 logging_nan_inf_filter: bool = True save_strategy: typing.Union[transformers.trainer_utils.SaveStrategy, str] = 'steps' save_steps: float = 500 save_total_limit: typing.Optional[int] = None save_safetensors: bool = True save_on_each_node: bool = False save_only_model: bool = False restore_callback_states_from_checkpoint: bool = False no_cuda: bool = False use_cpu: bool = False use_mps_device: bool = False seed: int = 42 data_seed: typing.Optional[int] = None jit_mode_eval: bool = False bf16: bool = False fp16: bool = False fp16_opt_level: str = 'O1' half_precision_backend: str = 'auto' bf16_full_eval: bool = False fp16_full_eval: bool = False tf32: typing.Optional[bool] = None local_rank: int = -1 ddp_backend: typing.Optional[str] = None tpu_num_cores: typing.Optional[int] = None tpu_metrics_debug: bool = False debug: typing.Union[str, list[transformers.debug_utils.DebugOption]] = '' dataloader_drop_last: bool = False eval_steps: typing.Optional[float] = None dataloader_num_workers: int = 0 dataloader_prefetch_factor: typing.Optional[int] = None past_index: int = -1 run_name: typing.Optional[str] = None disable_tqdm: typing.Optional[bool] = None remove_unused_columns: bool = True label_names: typing.Optional[list[str]] = None load_best_model_at_end: bool = False metric_for_best_model: typing.Optional[str] = None greater_is_better: typing.Optional[bool] = None ignore_data_skip: bool = False fsdp: typing.Union[list[transformers.trainer_utils.FSDPOption], str, NoneType] = None fsdp_min_num_params: int = 0 fsdp_config: typing.Union[dict[str, typing.Any], str, NoneType] = None fsdp_transformer_layer_cls_to_wrap: typing.Optional[str] = None accelerator_config: typing.Union[dict, str, NoneType] = None parallelism_config: typing.Optional[accelerate.parallelism_config.ParallelismConfig] = None deepspeed: typing.Union[dict, str, NoneType] = None label_smoothing_factor: float = 0.0 optim: typing.Union[transformers.training_args.OptimizerNames, str] = 'adamw_torch_fused' optim_args: typing.Optional[str] = None adafactor: bool = False group_by_length: bool = False length_column_name: str = 'length' report_to: typing.Union[NoneType, str, list[str]] = None project: str = 'huggingface' trackio_space_id: typing.Optional[str] = 'trackio' ddp_find_unused_parameters: typing.Optional[bool] = None ddp_bucket_cap_mb: typing.Optional[int] = None ddp_broadcast_buffers: typing.Optional[bool] = None dataloader_pin_memory: bool = True dataloader_persistent_workers: bool = False skip_memory_metrics: bool = True use_legacy_prediction_loop: bool = False push_to_hub: bool = False resume_from_checkpoint: typing.Optional[str] = None hub_model_id: typing.Optional[str] = None hub_strategy: typing.Union[transformers.trainer_utils.HubStrategy, str] = 'every_save' hub_token: typing.Optional[str] = None hub_private_repo: typing.Optional[bool] = None hub_always_push: bool = False hub_revision: typing.Optional[str] = None gradient_checkpointing: bool = False gradient_checkpointing_kwargs: typing.Union[dict[str, typing.Any], str, NoneType] = None include_inputs_for_metrics: bool = False include_for_metrics: list = <factory> eval_do_concat_batches: bool = True fp16_backend: str = 'auto' push_to_hub_model_id: typing.Optional[str] = None push_to_hub_organization: typing.Optional[str] = None push_to_hub_token: typing.Optional[str] = None mp_parameters: str = '' auto_find_batch_size: bool = False full_determinism: bool = False torchdynamo: typing.Optional[str] = None ray_scope: typing.Optional[str] = 'last' ddp_timeout: int = 1800 torch_compile: bool = False torch_compile_backend: typing.Optional[str] = None torch_compile_mode: typing.Optional[str] = None include_tokens_per_second: bool = False include_num_input_tokens_seen: typing.Union[str, bool] = False neftune_noise_alpha: typing.Optional[float] = None optim_target_modules: typing.Union[NoneType, str, list[str]] = None batch_eval_metrics: bool = False eval_on_start: bool = False use_liger_kernel: bool = False liger_kernel_config: typing.Optional[dict[str, bool]] = None eval_use_gather_object: bool = False average_tokens_across_devices: bool = True )

When using gradient accumulation, one step is counted as one step with backward pass. Therefore, logging, evaluation, save will be conducted every gradient_accumulation_steps * xxx_step training examples.

This can help avoid CUDA out-of-memory errors by lowering peak VRAM usage at a cost of about 10% slower performance.

logging_nan_inf_filter only influences the logging of loss values, it does not change the behavior the gradient is computed or applied to the model.

If "epoch" or "steps" is chosen, saving will also be performed at the very end of training, always.

This should not be activated when the different nodes use the same storage as the files will be saved with the same names for each node.

Will eventually default to the list of argument names accepted by the model that contain the word “label”, except if the model used is one of the XxxForQuestionAnswering in which case it will also include the ["start_positions", "end_positions"] keys.

You should only specify label_names if you’re using custom label names or if your model’s forward consumes multiple label tensors (e.g., extractive QA).

When set to True, the parameters save_strategy needs to be the same as eval_strategy, and in the case it is “steps”, save_steps must be a round multiple of eval_steps.

If not specified, this will default to "loss" when either load_best_model_at_end == True or lr_scheduler_type == SchedulerType.REDUCE_ON_PLATEAU (to use the evaluation loss).

If you set this value, greater_is_better will default to True unless the name ends with “loss”. Don’t forget to set it to False if your metric is better when lower.

A list of options along the following:

A List of config and its options:

min_num_params (int, optional, defaults to 0): FSDP’s minimum number of parameters for Default Auto Wrapping. (useful only when fsdp field is passed).

transformer_layer_cls_to_wrap (list[str], optional): List of transformer layer class names (case-sensitive) to wrap, e.g, BertLayer, GPTJBlock, T5Block … (useful only when fsdp flag is passed).

backward_prefetch (str, optional) FSDP’s backward prefetch mode. Controls when to prefetch next set of parameters (useful only when fsdp field is passed).

A list of options along the following:

forward_prefetch (bool, optional, defaults to False) FSDP’s forward prefetch mode (useful only when fsdp field is passed). If "True", then FSDP explicitly prefetches the next upcoming all-gather while executing in the forward pass.

limit_all_gathers (bool, optional, defaults to False) FSDP’s limit_all_gathers (useful only when fsdp field is passed). If "True", FSDP explicitly synchronizes the CPU thread to prevent too many in-flight all-gathers.

use_orig_params (bool, optional, defaults to True) If "True", allows non-uniform requires_grad during init, which means support for interspersed frozen and trainable parameters. Useful in cases such as parameter-efficient fine-tuning. Please refer this [blog](https://dev-discuss.pytorch.org/t/rethinking-pytorch-fully-sharded-data-parallel-fsdp-from-first-principles/1019

sync_module_states (bool, optional, defaults to True) If "True", each individually wrapped FSDP unit will broadcast module parameters from rank 0 to ensure they are the same across all ranks after initialization

cpu_ram_efficient_loading (bool, optional, defaults to False) If "True", only the first process loads the pretrained model checkpoint while all other processes have empty weights. When this setting as "True", sync_module_states also must to be "True", otherwise all the processes except the main process would have random weights leading to unexpected behaviour during training.

activation_checkpointing (bool, optional, defaults to False): If "True", activation checkpointing is a technique to reduce memory usage by clearing activations of certain layers and recomputing them during a backward pass. Effectively, this trades extra computation time for reduced memory usage.

xla (bool, optional, defaults to False): Whether to use PyTorch/XLA Fully Sharded Data Parallel Training. This is an experimental feature and its API may evolve in the future.

xla_fsdp_settings (dict, optional) The value is a dictionary which stores the XLA FSDP wrapping parameters.

For a complete list of options, please see here.

xla_fsdp_grad_ckpt (bool, optional, defaults to False): Will use gradient checkpointing over each nested XLA FSDP wrapped layer. This setting can only be used when the xla flag is set to true, and an auto wrapping policy is specified through fsdp_min_num_params or fsdp_transformer_layer_cls_to_wrap.

A list of config and its options:

Possible options are:

The options should be separated by whitespaces.

If output_dir exists, it needs to be a local clone of the repository to which the Trainer will be pushed.

Will default to the name of output_dir.

This will use the best defaults for the torch.compile API. You can customize the defaults with the argument torch_compile_backend and torch_compile_mode but we don’t guarantee any of them will work as the support is progressively rolled in in PyTorch.

This flag and the whole compile API is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

This will iterate over the entire training dataloader once beforehand, and will slow down the entire process.

May be slower in distributed training as gather operations must be called.

TrainingArguments is the subset of the arguments we use in our example scripts which relate to the training loop itself.

Using HfArgumentParser we can turn this class into argparse arguments that can be specified on the command line.

Returns the log level to be used depending on whether this process is the main process of node 0, main process of node non-0, or a non-main process.

For the main process the log level defaults to the logging level set (logging.WARNING if you didn’t do anything) unless overridden by log_level argument.

For the replica processes the log level defaults to logging.WARNING unless overridden by log_level_replica argument.

The choice between the main and replica process settings is made according to the return value of should_log.

( num_training_steps: int )

Get number of steps used for a linear warmup.

( local = True desc = 'work' )

A context manager for torch distributed environment where on needs to do something on the main process, while blocking replicas, and when it’s finished releasing the replicas.

One such use is for datasets’s map feature which to be efficient should be run once on the main process, which upon completion saves a cached version of results and which then automatically gets loaded by the replicas.

( train_batch_size: int = 8 eval_batch_size: int = 8 drop_last: bool = False num_workers: int = 0 pin_memory: bool = True persistent_workers: bool = False prefetch_factor: typing.Optional[int] = None auto_find_batch_size: bool = False ignore_data_skip: bool = False sampler_seed: typing.Optional[int] = None )

A method that regroups all arguments linked to the dataloaders creation.

( strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'no' steps: int = 500 batch_size: int = 8 accumulation_steps: typing.Optional[int] = None delay: typing.Optional[float] = None loss_only: bool = False jit_mode: bool = False )

Setting a strategy different from "no" will set self.do_eval to True.

A method that regroups all arguments linked to evaluation.

( strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'steps' steps: int = 500 report_to: typing.Union[str, list[str]] = 'none' level: str = 'passive' first_step: bool = False nan_inf_filter: bool = False on_each_node: bool = False replica_level: str = 'passive' )

nan_inf_filter only influences the logging of loss values, it does not change the behavior the gradient is computed or applied to the model.

A method that regroups all arguments linked to logging.

( name: typing.Union[str, transformers.trainer_utils.SchedulerType] = 'linear' num_epochs: float = 3.0 max_steps: int = -1 warmup_ratio: float = 0 warmup_steps: int = 0 )

A method that regroups all arguments linked to the learning rate scheduler and its hyperparameters.

( name: typing.Union[str, transformers.training_args.OptimizerNames] = 'adamw_torch' learning_rate: float = 5e-05 weight_decay: float = 0 beta1: float = 0.9 beta2: float = 0.999 epsilon: float = 1e-08 args: typing.Optional[str] = None )

A method that regroups all arguments linked to the optimizer and its hyperparameters.

( model_id: str strategy: typing.Union[str, transformers.trainer_utils.HubStrategy] = 'every_save' token: typing.Optional[str] = None private_repo: typing.Optional[bool] = None always_push: bool = False revision: typing.Optional[str] = None )

A method that regroups all arguments linked to synchronizing checkpoints with the Hub.

Calling this method will set self.push_to_hub to True, which means the output_dir will begin a git directory synced with the repo (determined by model_id) and the content will be pushed each time a save is triggered (depending on your self.save_strategy). Calling save_model() will also trigger a push.

( strategy: typing.Union[str, transformers.trainer_utils.IntervalStrategy] = 'steps' steps: int = 500 total_limit: typing.Optional[int] = None on_each_node: bool = False )

This should not be activated when the different nodes use the same storage as the files will be saved with the same names for each node.

A method that regroups all arguments linked to checkpoint saving.

( batch_size: int = 8 loss_only: bool = False jit_mode: bool = False )

A method that regroups all basic arguments linked to testing on a held-out dataset.

Calling this method will automatically set self.do_predict to True.

( learning_rate: float = 5e-05 batch_size: int = 8 weight_decay: float = 0 num_epochs: float = 3 max_steps: int = -1 gradient_accumulation_steps: int = 1 seed: int = 42 gradient_checkpointing: bool = False )

When using gradient accumulation, one step is counted as one step with backward pass. Therefore, logging, evaluation, save will be conducted every gradient_accumulation_steps * xxx_step training examples.

A method that regroups all basic arguments linked to the training.

Calling this method will automatically set self.do_train to True.

Serializes this instance while replace Enum by their values (for JSON serialization support). It obfuscates the token values by removing their value.

Serializes this instance to a JSON string.

Sanitized serialization to use with TensorBoard’s hparams

( output_dir: typing.Optional[str] = None overwrite_output_dir: bool = False do_train: bool = False do_eval: bool = False do_predict: bool = False eval_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'no' prediction_loss_only: bool = False per_device_train_batch_size: int = 8 per_device_eval_batch_size: int = 8 per_gpu_train_batch_size: typing.Optional[int] = None per_gpu_eval_batch_size: typing.Optional[int] = None gradient_accumulation_steps: int = 1 eval_accumulation_steps: typing.Optional[int] = None eval_delay: float = 0 torch_empty_cache_steps: typing.Optional[int] = None learning_rate: float = 5e-05 weight_decay: float = 0.0 adam_beta1: float = 0.9 adam_beta2: float = 0.999 adam_epsilon: float = 1e-08 max_grad_norm: float = 1.0 num_train_epochs: float = 3.0 max_steps: int = -1 lr_scheduler_type: typing.Union[transformers.trainer_utils.SchedulerType, str] = 'linear' lr_scheduler_kwargs: typing.Union[dict[str, typing.Any], str] = <factory> warmup_ratio: float = 0.0 warmup_steps: int = 0 log_level: str = 'passive' log_level_replica: str = 'warning' log_on_each_node: bool = True logging_dir: typing.Optional[str] = None logging_strategy: typing.Union[transformers.trainer_utils.IntervalStrategy, str] = 'steps' logging_first_step: bool = False logging_steps: float = 500 logging_nan_inf_filter: bool = True save_strategy: typing.Union[transformers.trainer_utils.SaveStrategy, str] = 'steps' save_steps: float = 500 save_total_limit: typing.Optional[int] = None save_safetensors: bool = True save_on_each_node: bool = False save_only_model: bool = False restore_callback_states_from_checkpoint: bool = False no_cuda: bool = False use_cpu: bool = False use_mps_device: bool = False seed: int = 42 data_seed: typing.Optional[int] = None jit_mode_eval: bool = False bf16: bool = False fp16: bool = False fp16_opt_level: str = 'O1' half_precision_backend: str = 'auto' bf16_full_eval: bool = False fp16_full_eval: bool = False tf32: typing.Optional[bool] = None local_rank: int = -1 ddp_backend: typing.Optional[str] = None tpu_num_cores: typing.Optional[int] = None tpu_metrics_debug: bool = False debug: typing.Union[str, list[transformers.debug_utils.DebugOption]] = '' dataloader_drop_last: bool = False eval_steps: typing.Optional[float] = None dataloader_num_workers: int = 0 dataloader_prefetch_factor: typing.Optional[int] = None past_index: int = -1 run_name: typing.Optional[str] = None disable_tqdm: typing.Optional[bool] = None remove_unused_columns: bool = True label_names: typing.Optional[list[str]] = None load_best_model_at_end: bool = False metric_for_best_model: typing.Optional[str] = None greater_is_better: typing.Optional[bool] = None ignore_data_skip: bool = False fsdp: typing.Union[list[transformers.trainer_utils.FSDPOption], str, NoneType] = None fsdp_min_num_params: int = 0 fsdp_config: typing.Union[dict[str, typing.Any], str, NoneType] = None fsdp_transformer_layer_cls_to_wrap: typing.Optional[str] = None accelerator_config: typing.Union[dict, str, NoneType] = None parallelism_config: typing.Optional[accelerate.parallelism_config.ParallelismConfig] = None deepspeed: typing.Union[dict, str, NoneType] = None label_smoothing_factor: float = 0.0 optim: typing.Union[transformers.training_args.OptimizerNames, str] = 'adamw_torch_fused' optim_args: typing.Optional[str] = None adafactor: bool = False group_by_length: bool = False length_column_name: str = 'length' report_to: typing.Union[NoneType, str, list[str]] = None project: str = 'huggingface' trackio_space_id: typing.Optional[str] = 'trackio' ddp_find_unused_parameters: typing.Optional[bool] = None ddp_bucket_cap_mb: typing.Optional[int] = None ddp_broadcast_buffers: typing.Optional[bool] = None dataloader_pin_memory: bool = True dataloader_persistent_workers: bool = False skip_memory_metrics: bool = True use_legacy_prediction_loop: bool = False push_to_hub: bool = False resume_from_checkpoint: typing.Optional[str] = None hub_model_id: typing.Optional[str] = None hub_strategy: typing.Union[transformers.trainer_utils.HubStrategy, str] = 'every_save' hub_token: typing.Optional[str] = None hub_private_repo: typing.Optional[bool] = None hub_always_push: bool = False hub_revision: typing.Optional[str] = None gradient_checkpointing: bool = False gradient_checkpointing_kwargs: typing.Union[dict[str, typing.Any], str, NoneType] = None include_inputs_for_metrics: bool = False include_for_metrics: list = <factory> eval_do_concat_batches: bool = True fp16_backend: str = 'auto' push_to_hub_model_id: typing.Optional[str] = None push_to_hub_organization: typing.Optional[str] = None push_to_hub_token: typing.Optional[str] = None mp_parameters: str = '' auto_find_batch_size: bool = False full_determinism: bool = False torchdynamo: typing.Optional[str] = None ray_scope: typing.Optional[str] = 'last' ddp_timeout: int = 1800 torch_compile: bool = False torch_compile_backend: typing.Optional[str] = None torch_compile_mode: typing.Optional[str] = None include_tokens_per_second: bool = False include_num_input_tokens_seen: typing.Union[str, bool] = False neftune_noise_alpha: typing.Optional[float] = None optim_target_modules: typing.Union[NoneType, str, list[str]] = None batch_eval_metrics: bool = False eval_on_start: bool = False use_liger_kernel: bool = False liger_kernel_config: typing.Optional[dict[str, bool]] = None eval_use_gather_object: bool = False average_tokens_across_devices: bool = True sortish_sampler: bool = False predict_with_generate: bool = False generation_max_length: typing.Optional[int] = None generation_num_beams: typing.Optional[int] = None generation_config: typing.Union[str, pathlib.Path, transformers.generation.configuration_utils.GenerationConfig, NoneType] = None )

When using gradient accumulation, one step is counted as one step with backward pass. Therefore, logging, evaluation, save will be conducted every gradient_accumulation_steps * xxx_step training examples.

This can help avoid CUDA out-of-memory errors by lowering peak VRAM usage at a cost of about 10% slower performance.

logging_nan_inf_filter only influences the logging of loss values, it does not change the behavior the gradient is computed or applied to the model.

If "epoch" or "steps" is chosen, saving will also be performed at the very end of training, always.

This should not be activated when the different nodes use the same storage as the files will be saved with the same names for each node.

Will eventually default to the list of argument names accepted by the model that contain the word “label”, except if the model used is one of the XxxForQuestionAnswering in which case it will also include the ["start_positions", "end_positions"] keys.

You should only specify label_names if you’re using custom label names or if your model’s forward consumes multiple label tensors (e.g., extractive QA).

When set to True, the parameters save_strategy needs to be the same as eval_strategy, and in the case it is “steps”, save_steps must be a round multiple of eval_steps.

If not specified, this will default to "loss" when either load_best_model_at_end == True or lr_scheduler_type == SchedulerType.REDUCE_ON_PLATEAU (to use the evaluation loss).

If you set this value, greater_is_better will default to True unless the name ends with “loss”. Don’t forget to set it to False if your metric is better when lower.

A list of options along the following:

A List of config and its options:

min_num_params (int, optional, defaults to 0): FSDP’s minimum number of parameters for Default Auto Wrapping. (useful only when fsdp field is passed).

transformer_layer_cls_to_wrap (list[str], optional): List of transformer layer class names (case-sensitive) to wrap, e.g, BertLayer, GPTJBlock, T5Block … (useful only when fsdp flag is passed).

backward_prefetch (str, optional) FSDP’s backward prefetch mode. Controls when to prefetch next set of parameters (useful only when fsdp field is passed).

A list of options along the following:

forward_prefetch (bool, optional, defaults to False) FSDP’s forward prefetch mode (useful only when fsdp field is passed). If "True", then FSDP explicitly prefetches the next upcoming all-gather while executing in the forward pass.

limit_all_gathers (bool, optional, defaults to False) FSDP’s limit_all_gathers (useful only when fsdp field is passed). If "True", FSDP explicitly synchronizes the CPU thread to prevent too many in-flight all-gathers.

use_orig_params (bool, optional, defaults to True) If "True", allows non-uniform requires_grad during init, which means support for interspersed frozen and trainable parameters. Useful in cases such as parameter-efficient fine-tuning. Please refer this [blog](https://dev-discuss.pytorch.org/t/rethinking-pytorch-fully-sharded-data-parallel-fsdp-from-first-principles/1019

sync_module_states (bool, optional, defaults to True) If "True", each individually wrapped FSDP unit will broadcast module parameters from rank 0 to ensure they are the same across all ranks after initialization

cpu_ram_efficient_loading (bool, optional, defaults to False) If "True", only the first process loads the pretrained model checkpoint while all other processes have empty weights. When this setting as "True", sync_module_states also must to be "True", otherwise all the processes except the main process would have random weights leading to unexpected behaviour during training.

activation_checkpointing (bool, optional, defaults to False): If "True", activation checkpointing is a technique to reduce memory usage by clearing activations of certain layers and recomputing them during a backward pass. Effectively, this trades extra computation time for reduced memory usage.

xla (bool, optional, defaults to False): Whether to use PyTorch/XLA Fully Sharded Data Parallel Training. This is an experimental feature and its API may evolve in the future.

xla_fsdp_settings (dict, optional) The value is a dictionary which stores the XLA FSDP wrapping parameters.

For a complete list of options, please see here.

xla_fsdp_grad_ckpt (bool, optional, defaults to False): Will use gradient checkpointing over each nested XLA FSDP wrapped layer. This setting can only be used when the xla flag is set to true, and an auto wrapping policy is specified through fsdp_min_num_params or fsdp_transformer_layer_cls_to_wrap.

A list of config and its options:

Possible options are:

The options should be separated by whitespaces.

If output_dir exists, it needs to be a local clone of the repository to which the Trainer will be pushed.

Will default to the name of output_dir.

This will use the best defaults for the torch.compile API. You can customize the defaults with the argument torch_compile_backend and torch_compile_mode but we don’t guarantee any of them will work as the support is progressively rolled in in PyTorch.

This flag and the whole compile API is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

Refer to the PyTorch doc for possible values and note that they may change across PyTorch versions.

This flag is experimental and subject to change in future releases.

This will iterate over the entire training dataloader once beforehand, and will slow down the entire process.

May be slower in distributed training as gather operations must be called.

TrainingArguments is the subset of the arguments we use in our example scripts which relate to the training loop itself.

Using HfArgumentParser we can turn this class into argparse arguments that can be specified on the command line.

Serializes this instance while replace Enum by their values and GenerationConfig by dictionaries (for JSON serialization support). It obfuscates the token values by removing their value.

**Examples:**

Example 1 (unknown):
```unknown
label_names
```

Example 2 (unknown):
```unknown
torch.nn.Module
```

Example 3 (unknown):
```unknown
torch.nn.Module
```

Example 4 (unknown):
```unknown
DataCollator
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/processors

**Contents:**
- Transformers
- Processors
- Multi-modal processors
  - class transformers.ProcessorMixin
    - apply_chat_template
    - batch_decode
    - check_argument_for_proper_class
    - decode
    - from_args_and_dict
    - from_pretrained

Transformers documentation

and get access to the augmented documentation experience

Processors can mean two different things in the Transformers library:

Any multi-modal model will require an object to encode or decode the data that groups several modalities (among text, vision and audio). This is handled by objects called processors, which group together two or more processing objects such as tokenizers (for the text modality), image processors (for vision) and feature extractors (for audio).

Those processors inherit from the following base class that implements the saving and loading functionality:

This is a mixin used to provide saving/loading functionality for all processor classes.

( conversation: typing.Union[list[dict[str, str]], list[list[dict[str, str]]]] chat_template: typing.Optional[str] = None **kwargs: typing_extensions.Unpack[transformers.processing_utils.AllKwargsForChatTemplate] )

Similar to the apply_chat_template method on tokenizers, this method applies a Jinja template to input conversations to turn them into a single tokenizable string.

The input is expected to be in the following format, where each message content is a list consisting of text and optionally image or video inputs. One can also provide an image, video, URL or local path which will be used to form pixel_values when return_dict=True. If not provided, one will get only the formatted text, optionally tokenized text.

conversation = [ { “role”: “user”, “content”: [ {“type”: “image”, “url”: “https://www.ilankelman.org/stopsigns/australia.jpg”}, {“type”: “text”, “text”: “Please describe this image in detail.”}, ], }, ]

This method forwards all its arguments to PreTrainedTokenizer’s batch_decode(). Please refer to the docstring of this method for more information.

( argument_name argument )

Checks the passed argument’s class against the expected transformers class. In case of an unexpected mismatch between expected and actual class, an error is raise. Otherwise, the proper retrieved class is returned.

This method forwards all its arguments to PreTrainedTokenizer’s decode(). Please refer to the docstring of this method for more information.

( args processor_dict: dict **kwargs ) → ~processing_utils.ProcessingMixin

~processing_utils.ProcessingMixin

The processor object instantiated from those parameters.

The processor object instantiated from those parameters.

Instantiates a type of ~processing_utils.ProcessingMixin from a Python dictionary of parameters.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a processor associated with a pretrained model.

This class method is simply calling the feature extractor from_pretrained(), image processor ImageProcessingMixin and the tokenizer ~tokenization_utils_base.PreTrainedTokenizer.from_pretrained methods. Please refer to the docstrings of the methods above for more information.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] **kwargs ) → tuple[Dict, Dict]

The dictionary(ies) that will be used to instantiate the processor object.

The dictionary(ies) that will be used to instantiate the processor object.

From a pretrained_model_name_or_path, resolve to a dictionary of parameters, to be used for instantiating a processor of type ~processing_utils.ProcessingMixin using from_args_and_dict.

( generated_outputs skip_special_tokens = True **kwargs ) → list[str]

Post-process the output of a vlm to decode the text.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the processor files to the 🤗 Model Hub.

( auto_class = 'AutoProcessor' )

Register this class with a given auto class. This should only be used for custom feature extractors as the ones in the library are already mapped with AutoProcessor.

( save_directory push_to_hub: bool = False legacy_serialization: bool = True **kwargs )

Saves the attributes of this processor (feature extractor, tokenizer…) in the specified directory so that it can be reloaded using the from_pretrained() method.

This class method is simply calling save_pretrained() and save_pretrained(). Please refer to the docstrings of the methods above for more information.

( legacy_serialization = True ) → dict[str, Any]

Dictionary of all the attributes that make up this processor instance.

Dictionary of all the attributes that make up this processor instance.

Serializes this instance to a Python dictionary.

( json_file_path: typing.Union[str, os.PathLike] legacy_serialization = True )

Save this instance to a JSON file.

( legacy_serialization = True ) → str

String containing all the attributes that make up this feature_extractor instance in JSON format.

String containing all the attributes that make up this feature_extractor instance in JSON format.

Serializes this instance to a JSON string.

All processors follow the same architecture which is that of the DataProcessor. The processor returns a list of InputExample. These InputExample can be converted to InputFeatures in order to be fed to the model.

Base class for data converters for sequence classification data sets.

Gets a collection of InputExample for the dev set.

Gets an example from a dict with tensorflow tensors.

Gets the list of labels for this data set.

Gets a collection of InputExample for the test set.

Gets a collection of InputExample for the train set.

Some tensorflow_datasets datasets are not formatted the same way the GLUE datasets are. This method converts examples to the correct format.

( guid: str text_a: str text_b: typing.Optional[str] = None label: typing.Optional[str] = None )

A single training/test example for simple sequence classification.

Serializes this instance to a JSON string.

( input_ids: list attention_mask: typing.Optional[list[int]] = None token_type_ids: typing.Optional[list[int]] = None label: typing.Union[int, float, NoneType] = None )

A single set of features of data. Property names are the same names as the corresponding inputs to a model.

Serializes this instance to a JSON string.

General Language Understanding Evaluation (GLUE) is a benchmark that evaluates the performance of models across a diverse set of existing NLU tasks. It was released together with the paper GLUE: A multi-task benchmark and analysis platform for natural language understanding

This library hosts a total of 10 processors for the following tasks: MRPC, MNLI, MNLI (mismatched), CoLA, SST2, STSB, QQP, QNLI, RTE and WNLI.

Those processors are:

Additionally, the following method can be used to load values from a data file and convert them to a list of InputExample.

( examples: typing.Union[list[transformers.data.processors.utils.InputExample], ForwardRef('tf.data.Dataset')] tokenizer: PreTrainedTokenizer max_length: typing.Optional[int] = None task = None label_list = None output_mode = None )

Loads a data file into a list of InputFeatures

The Cross-Lingual NLI Corpus (XNLI) is a benchmark that evaluates the quality of cross-lingual text representations. XNLI is crowd-sourced dataset based on MultiNLI: pairs of text are labeled with textual entailment annotations for 15 different languages (including both high-resource language such as English and low-resource languages such as Swahili).

It was released together with the paper XNLI: Evaluating Cross-lingual Sentence Representations

This library hosts the processor to load the XNLI data:

Please note that since the gold labels are available on the test set, evaluation is performed on the test set.

An example using these processors is given in the run_xnli.py script.

The Stanford Question Answering Dataset (SQuAD) is a benchmark that evaluates the performance of models on question answering. Two versions are available, v1.1 and v2.0. The first version (v1.1) was released together with the paper SQuAD: 100,000+ Questions for Machine Comprehension of Text. The second version (v2.0) was released alongside the paper Know What You Don’t Know: Unanswerable Questions for SQuAD.

This library hosts a processor for each of the two versions:

Those processors are:

They both inherit from the abstract class ~data.processors.utils.SquadProcessor

Processor for the SQuAD data set. overridden by SquadV1Processor and SquadV2Processor, used by the version 1.1 and version 2.0 of SQuAD, respectively.

( data_dir filename = None )

Returns the evaluation example from the data directory.

( dataset evaluate = False )

Creates a list of SquadExample using a TFDS dataset.

( data_dir filename = None )

Returns the training examples from the data directory.

Additionally, the following method can be used to convert SQuAD examples into ~data.processors.utils.SquadFeatures that can be used as model inputs.

( examples tokenizer max_seq_length doc_stride max_query_length is_training padding_strategy = 'max_length' return_dataset = False threads = 1 tqdm_enabled = True )

Converts a list of examples into a list of features that can be directly given as input to a model. It is model-dependant and takes advantage of many of the tokenizer’s features to create the model’s inputs.

These processors as well as the aforementioned method can be used with files containing the data as well as with the tensorflow_datasets package. Examples are given below.

Here is an example using the processors as well as the conversion method using data files:

Using tensorflow_datasets is as easy as using a data file:

Another example using these processors is given in the run_squad.py script.

**Examples:**

Example 1 (unknown):
```unknown
Union[list[Dict, [str, str]], list[list[dict[str, str]]]]
```

Example 2 (unknown):
```unknown
Optional[str]
```

Example 3 (unknown):
```unknown
apply_chat_template
```

Example 4 (unknown):
```unknown
pixel_values
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/feature_extractor

**Contents:**
- Transformers
- Feature Extractor
- FeatureExtractionMixin
  - class transformers.FeatureExtractionMixin
    - from_pretrained
    - save_pretrained
- SequenceFeatureExtractor
  - class transformers.SequenceFeatureExtractor
    - pad
- BatchFeature

Transformers documentation

and get access to the augmented documentation experience

A feature extractor is in charge of preparing input features for audio or vision models. This includes feature extraction from sequences, e.g., pre-processing audio files to generate Log-Mel Spectrogram features, feature extraction from images, e.g., cropping image files, but also padding, normalization, and conversion to NumPy and PyTorch tensors.

This is a feature extraction mixin used to provide saving/loading functionality for sequential and image feature extractors.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[bool, str, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a type of FeatureExtractionMixin from a feature extractor, e.g. a derived class of SequenceFeatureExtractor.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save a feature_extractor object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

( feature_size: int sampling_rate: int padding_value: float **kwargs )

This is a general feature extraction class for speech recognition.

( processed_features: typing.Union[transformers.feature_extraction_utils.BatchFeature, list[transformers.feature_extraction_utils.BatchFeature], dict[str, transformers.feature_extraction_utils.BatchFeature], dict[str, list[transformers.feature_extraction_utils.BatchFeature]], list[dict[str, transformers.feature_extraction_utils.BatchFeature]]] padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None truncation: bool = False pad_to_multiple_of: typing.Optional[int] = None return_attention_mask: typing.Optional[bool] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None )

Instead of list[float] you can have tensors (numpy arrays, PyTorch tensors or TensorFlow tensors), see the note above for the return type.

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta), or on TPUs which benefit from having sequence lengths be a multiple of 128.

What are attention masks?

Pad input values / input vectors or a batch of input values / input vectors up to predefined length or to the max sequence length in the batch.

Padding side (left/right) padding values are defined at the feature extractor level (with self.padding_side, self.padding_value)

If the processed_features passed are dictionary of numpy arrays, PyTorch tensors or TensorFlow tensors, the result will use the same type unless you provide a different tensor type with return_tensors. In the case of PyTorch tensors, you will lose the specific device of your tensors however.

( data: typing.Optional[dict[str, typing.Any]] = None tensor_type: typing.Union[NoneType, str, transformers.utils.generic.TensorType] = None )

Holds the output of the pad() and feature extractor specific __call__ methods.

This class is derived from a python dictionary and can be used as a dictionary.

( tensor_type: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None )

Convert the inner content to tensors.

( *args **kwargs ) → BatchFeature

The same instance after modification.

The same instance after modification.

Send all values to device by calling v.to(*args, **kwargs) (PyTorch only). This should support casting in different dtypes and sending the BatchFeature to a different device.

Mixin that contain utilities for preparing image features.

( image size ) → new_image

A center cropped PIL.Image.Image or np.ndarray or torch.Tensor of shape: (n_channels, height, width).

A center cropped PIL.Image.Image or np.ndarray or torch.Tensor of shape: (n_channels, height, width).

Crops image to the given size using a center crop. Note that if the image is too small to be cropped to the size given, it will be padded (so the returned result has the size asked).

Converts PIL.Image.Image to RGB format.

Expands 2-dimensional image to 3 dimensions.

Flips the channel order of image from RGB to BGR, or vice versa. Note that this will trigger a conversion of image to a NumPy array if it’s a PIL Image.

( image mean std rescale = False )

Normalizes image with mean and std. Note that this will trigger a conversion of image to a NumPy array if it’s a PIL Image.

( image: ndarray scale: typing.Union[float, int] )

Rescale a numpy image by scale amount

( image size resample = None default_to_square = True max_size = None ) → image

If size is an int and default_to_square is True, then image will be resized to (size, size). If size is an int and default_to_square is False, then smaller edge of the image will be matched to this number. i.e, if height > width, then image will be rescaled to (size * height / width, size).

A resized PIL.Image.Image.

A resized PIL.Image.Image.

Resizes image. Enforces conversion of input to PIL.Image.

( image angle resample = None expand = 0 center = None translate = None fillcolor = None ) → image

A rotated PIL.Image.Image.

A rotated PIL.Image.Image.

Returns a rotated copy of image. This method returns a copy of image, rotated the given number of degrees counter clockwise around its centre.

( image rescale = None channel_first = True )

Converts image to a numpy array. Optionally rescales it and puts the channel dimension as the first dimension.

( image rescale = None )

Converts image to a PIL Image. Optionally rescales it and puts the channel dimension back as the last axis if needed.

**Examples:**

Example 1 (unknown):
```unknown
os.PathLike
```

Example 2 (unknown):
```unknown
./my_model_directory/
```

Example 3 (unknown):
```unknown
./my_model_directory/preprocessor_config.json
```

Example 4 (unknown):
```unknown
os.PathLike
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/tokenizer

**Contents:**
- Transformers
- Tokenizer
- Multimodal Tokenizer
- PreTrainedTokenizer
  - class transformers.PreTrainedTokenizer
    - __call__
    - add_tokens
    - add_special_tokens
    - apply_chat_template
    - batch_decode

Transformers documentation

and get access to the augmented documentation experience

A tokenizer is in charge of preparing the inputs for a model. The library contains tokenizers for all the models. Most of the tokenizers are available in two flavors: a full python implementation and a “Fast” implementation based on the Rust library 🤗 Tokenizers. The “Fast” implementations allows:

The base classes PreTrainedTokenizer and PreTrainedTokenizerFast implement the common methods for encoding string inputs in model inputs (see below) and instantiating/saving python and “Fast” tokenizers either from a local file or directory or from a pretrained tokenizer provided by the library (downloaded from HuggingFace’s AWS S3 repository). They both rely on PreTrainedTokenizerBase that contains the common methods, and SpecialTokensMixin.

PreTrainedTokenizer and PreTrainedTokenizerFast thus implement the main methods for using all the tokenizers:

BatchEncoding holds the output of the PreTrainedTokenizerBase’s encoding methods (__call__, encode_plus and batch_encode_plus) and is derived from a Python dictionary. When the tokenizer is a pure python tokenizer, this class behaves just like a standard python dictionary and holds the various model inputs computed by these methods (input_ids, attention_mask…). When the tokenizer is a “Fast” tokenizer (i.e., backed by HuggingFace tokenizers library), this class provides in addition several advanced alignment methods which can be used to map between the original string (character and words) and the token space (e.g., getting the index of the token comprising a given character or the span of characters corresponding to a given token).

Apart from that each tokenizer can be a “multimodal” tokenizer which means that the tokenizer will hold all relevant special tokens as part of tokenizer attributes for easier access. For example, if the tokenizer is loaded from a vision-language model like LLaVA, you will be able to access tokenizer.image_token_id to obtain the special image token used as a placeholder.

To enable extra special tokens for any type of tokenizer, you have to add the following lines and save the tokenizer. Extra special tokens do not have to be modality related and can ne anything that the model often needs access to. In the below code, tokenizer at output_dir will have direct access to three more special tokens.

Base class for all slow tokenizers.

Inherits from PreTrainedTokenizerBase.

Handle all the shared methods for tokenization and special tokens as well as methods downloading/caching/loading pretrained tokenizers as well as adding tokens to the vocabulary.

This class also contain the added tokens in a unified way on top of all tokenizers so we don’t have to handle the specific vocabulary augmentation methods of the various underlying dictionary structures (BPE, sentencepiece…).

Class attributes (overridden by derived classes)

( text: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair: typing.Union[str, list[str], list[list[str]], NoneType] = None text_target: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair_target: typing.Union[str, list[str], list[list[str]], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 is_split_into_words: bool = False pad_to_multiple_of: typing.Optional[int] = None padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_token_type_ids: typing.Optional[bool] = None return_attention_mask: typing.Optional[bool] = None return_overflowing_tokens: bool = False return_special_tokens_mask: bool = False return_offsets_mapping: bool = False return_length: bool = False verbose: bool = True **kwargs ) → BatchEncoding

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

What are token type IDs?

What are attention masks?

This is only available on fast tokenizers inheriting from PreTrainedTokenizerFast, if using Python’s tokenizer, this method will raise NotImplementedError.

A BatchEncoding with the following fields: input_ids — List of token ids to be fed to a model. What are input IDs? token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names). What are token type IDs? attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names). What are attention masks? overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True). num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True). special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True). length — The length of the inputs (when return_length=True)

A BatchEncoding with the following fields:

input_ids — List of token ids to be fed to a model.

token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names).

What are token type IDs?

attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names).

What are attention masks?

overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True).

num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True).

special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True).

length — The length of the inputs (when return_length=True)

Main method to tokenize and prepare for the model one or several sequence(s) or one or several pair(s) of sequences.

( new_tokens: typing.Union[str, tokenizers.AddedToken, collections.abc.Sequence[typing.Union[str, tokenizers.AddedToken]]] special_tokens: bool = False ) → int

See details for tokenizers.AddedToken in HuggingFace tokenizers library.

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a list of new tokens to the tokenizer class. If the new tokens are not in the vocabulary, they are added to it with indices starting from length of the current vocabulary and will be isolated before the tokenization algorithm is applied. Added tokens and tokens from the vocabulary of the tokenization algorithm are therefore not treated in the same way.

Note, when adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

( special_tokens_dict: dict replace_additional_special_tokens = True ) → int

Tokens are only added if they are not already in the vocabulary (tested by checking if the tokenizer assign the index of the unk_token to them).

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a dictionary of special tokens (eos, pad, cls, etc.) to the encoder and link them to class attributes. If special tokens are NOT in the vocabulary, they are added to it (indexed starting from the last index of the current vocabulary).

When adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

Using add_special_tokens will ensure your special tokens can be used in several ways:

When possible, special tokens are already registered for provided pretrained models (for instance BertTokenizer cls_token is already registered to be '[CLS]' and XLM’s one is also registered to be '</s>').

( conversation: typing.Union[list[dict[str, str]], list[list[dict[str, str]]]] tools: typing.Optional[list[typing.Union[dict, typing.Callable]]] = None documents: typing.Optional[list[dict[str, str]]] = None chat_template: typing.Optional[str] = None add_generation_prompt: bool = False continue_final_message: bool = False tokenize: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: bool = False max_length: typing.Optional[int] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_dict: bool = False return_assistant_tokens_mask: bool = False tokenizer_kwargs: typing.Optional[dict[str, typing.Any]] = None **kwargs ) → Union[list[int], Dict]

Union[list[int], Dict]

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

Converts a list of dictionaries with "role" and "content" keys to a list of token ids. This method is intended for use with chat models, and will read the tokenizer’s chat_template attribute to determine the format and control tokens to use when converting.

( sequences: typing.Union[list[int], list[list[int]], ForwardRef('np.ndarray'), ForwardRef('torch.Tensor'), ForwardRef('tf.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → list[str]

The list of decoded sentences.

The list of decoded sentences.

Convert a list of lists of token ids into a list of strings by calling decode.

( token_ids: typing.Union[int, list[int], numpy.ndarray, ForwardRef('torch.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → str

The decoded sentence.

The decoded sentence.

Converts a sequence of ids in a string, using the tokenizer and vocabulary with options to remove special tokens and clean up tokenization spaces.

Similar to doing self.convert_tokens_to_string(self.convert_ids_to_tokens(token_ids)).

( text: typing.Union[str, list[str], list[int]] text_pair: typing.Union[str, list[str], list[int], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None **kwargs ) → list[int], torch.Tensor, tf.Tensor or np.ndarray

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

list[int], torch.Tensor, tf.Tensor or np.ndarray

The tokenized ids of the text.

The tokenized ids of the text.

Converts a string to a sequence of ids (integer), using the tokenizer and vocabulary.

Same as doing self.convert_tokens_to_ids(self.tokenize(text)).

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the tokenizer files to the 🤗 Model Hub.

( ids: typing.Union[int, list[int]] skip_special_tokens: bool = False ) → str or list[str]

The decoded token(s).

The decoded token(s).

Converts a single index or a sequence of indices in a token or a sequence of tokens, using the vocabulary and added tokens.

( tokens: typing.Union[str, list[str]] ) → int or list[int]

The token id or list of token ids.

The token id or list of token ids.

Converts a token string (or a sequence of tokens) in a single integer id (or a sequence of ids), using the vocabulary.

Returns the added tokens in the vocabulary as a dictionary of token to index. Results might be different from the fast call because for now we always add the tokens even if they are already in the vocabulary. This is something we should change.

( pair: bool = False ) → int

Number of special tokens added to sequences.

Number of special tokens added to sequences.

Returns the number of added tokens when encoding a sequence with special tokens.

This encodes a dummy input and checks the number of added tokens, and is therefore not efficient. Do not put this inside your training loop.

( text: str is_split_into_words: bool = False **kwargs ) → tuple[str, dict[str, Any]]

tuple[str, dict[str, Any]]

The prepared text and the unused kwargs.

The prepared text and the unused kwargs.

Performs any necessary transformations before tokenization.

This method should pop the arguments from kwargs and return the remaining kwargs as well. We test the kwargs at the end of the encoding process to be sure all the arguments have been used.

( text: str **kwargs ) → list[str]

Converts a string into a sequence of tokens, using the tokenizer.

Split in words for word-based vocabulary or sub-words for sub-word-based vocabularies (BPE/SentencePieces/WordPieces). Takes care of added tokens.

The PreTrainedTokenizerFast depend on the tokenizers library. The tokenizers obtained from the 🤗 tokenizers library can be loaded very simply into 🤗 transformers. Take a look at the Using tokenizers from 🤗 tokenizers page to understand how this is done.

Base class for all fast tokenizers (wrapping HuggingFace tokenizers library).

Inherits from PreTrainedTokenizerBase.

Handles all the shared methods for tokenization and special tokens, as well as methods for downloading/caching/loading pretrained tokenizers, as well as adding tokens to the vocabulary.

This class also contains the added tokens in a unified way on top of all tokenizers so we don’t have to handle the specific vocabulary augmentation methods of the various underlying dictionary structures (BPE, sentencepiece…).

Class attributes (overridden by derived classes)

( text: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair: typing.Union[str, list[str], list[list[str]], NoneType] = None text_target: typing.Union[str, list[str], list[list[str]], NoneType] = None text_pair_target: typing.Union[str, list[str], list[list[str]], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 is_split_into_words: bool = False pad_to_multiple_of: typing.Optional[int] = None padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_token_type_ids: typing.Optional[bool] = None return_attention_mask: typing.Optional[bool] = None return_overflowing_tokens: bool = False return_special_tokens_mask: bool = False return_offsets_mapping: bool = False return_length: bool = False verbose: bool = True **kwargs ) → BatchEncoding

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

What are token type IDs?

What are attention masks?

This is only available on fast tokenizers inheriting from PreTrainedTokenizerFast, if using Python’s tokenizer, this method will raise NotImplementedError.

A BatchEncoding with the following fields: input_ids — List of token ids to be fed to a model. What are input IDs? token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names). What are token type IDs? attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names). What are attention masks? overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True). num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True). special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True). length — The length of the inputs (when return_length=True)

A BatchEncoding with the following fields:

input_ids — List of token ids to be fed to a model.

token_type_ids — List of token type ids to be fed to a model (when return_token_type_ids=True or if “token_type_ids” is in self.model_input_names).

What are token type IDs?

attention_mask — List of indices specifying which tokens should be attended to by the model (when return_attention_mask=True or if “attention_mask” is in self.model_input_names).

What are attention masks?

overflowing_tokens — List of overflowing tokens sequences (when a max_length is specified and return_overflowing_tokens=True).

num_truncated_tokens — Number of tokens truncated (when a max_length is specified and return_overflowing_tokens=True).

special_tokens_mask — List of 0s and 1s, with 1 specifying added special tokens and 0 specifying regular sequence tokens (when add_special_tokens=True and return_special_tokens_mask=True).

length — The length of the inputs (when return_length=True)

Main method to tokenize and prepare for the model one or several sequence(s) or one or several pair(s) of sequences.

( new_tokens: typing.Union[str, tokenizers.AddedToken, collections.abc.Sequence[typing.Union[str, tokenizers.AddedToken]]] special_tokens: bool = False ) → int

See details for tokenizers.AddedToken in HuggingFace tokenizers library.

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a list of new tokens to the tokenizer class. If the new tokens are not in the vocabulary, they are added to it with indices starting from length of the current vocabulary and will be isolated before the tokenization algorithm is applied. Added tokens and tokens from the vocabulary of the tokenization algorithm are therefore not treated in the same way.

Note, when adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

( special_tokens_dict: dict replace_additional_special_tokens = True ) → int

Tokens are only added if they are not already in the vocabulary (tested by checking if the tokenizer assign the index of the unk_token to them).

Number of tokens added to the vocabulary.

Number of tokens added to the vocabulary.

Add a dictionary of special tokens (eos, pad, cls, etc.) to the encoder and link them to class attributes. If special tokens are NOT in the vocabulary, they are added to it (indexed starting from the last index of the current vocabulary).

When adding new tokens to the vocabulary, you should make sure to also resize the token embedding matrix of the model so that its embedding matrix matches the tokenizer.

In order to do that, please use the resize_token_embeddings() method.

Using add_special_tokens will ensure your special tokens can be used in several ways:

When possible, special tokens are already registered for provided pretrained models (for instance BertTokenizer cls_token is already registered to be '[CLS]' and XLM’s one is also registered to be '</s>').

( conversation: typing.Union[list[dict[str, str]], list[list[dict[str, str]]]] tools: typing.Optional[list[typing.Union[dict, typing.Callable]]] = None documents: typing.Optional[list[dict[str, str]]] = None chat_template: typing.Optional[str] = None add_generation_prompt: bool = False continue_final_message: bool = False tokenize: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: bool = False max_length: typing.Optional[int] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None return_dict: bool = False return_assistant_tokens_mask: bool = False tokenizer_kwargs: typing.Optional[dict[str, typing.Any]] = None **kwargs ) → Union[list[int], Dict]

Union[list[int], Dict]

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

A list of token ids representing the tokenized chat so far, including control tokens. This output is ready to pass to the model, either directly or via methods like generate(). If return_dict is set, will return a dict of tokenizer outputs instead.

Converts a list of dictionaries with "role" and "content" keys to a list of token ids. This method is intended for use with chat models, and will read the tokenizer’s chat_template attribute to determine the format and control tokens to use when converting.

( sequences: typing.Union[list[int], list[list[int]], ForwardRef('np.ndarray'), ForwardRef('torch.Tensor'), ForwardRef('tf.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → list[str]

The list of decoded sentences.

The list of decoded sentences.

Convert a list of lists of token ids into a list of strings by calling decode.

( token_ids: typing.Union[int, list[int], numpy.ndarray, ForwardRef('torch.Tensor')] skip_special_tokens: bool = False clean_up_tokenization_spaces: typing.Optional[bool] = None **kwargs ) → str

The decoded sentence.

The decoded sentence.

Converts a sequence of ids in a string, using the tokenizer and vocabulary with options to remove special tokens and clean up tokenization spaces.

Similar to doing self.convert_tokens_to_string(self.convert_ids_to_tokens(token_ids)).

( text: typing.Union[str, list[str], list[int]] text_pair: typing.Union[str, list[str], list[int], NoneType] = None add_special_tokens: bool = True padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = False truncation: typing.Union[bool, str, transformers.tokenization_utils_base.TruncationStrategy, NoneType] = None max_length: typing.Optional[int] = None stride: int = 0 padding_side: typing.Optional[str] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None **kwargs ) → list[int], torch.Tensor, tf.Tensor or np.ndarray

If left unset or set to None, this will use the predefined model maximum length if a maximum length is required by one of the truncation/padding parameters. If the model has no specific maximum input length (like XLNet) truncation/padding to a maximum length will be deactivated.

list[int], torch.Tensor, tf.Tensor or np.ndarray

The tokenized ids of the text.

The tokenized ids of the text.

Converts a string to a sequence of ids (integer), using the tokenizer and vocabulary.

Same as doing self.convert_tokens_to_ids(self.tokenize(text)).

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the tokenizer files to the 🤗 Model Hub.

( ids: typing.Union[int, list[int]] skip_special_tokens: bool = False ) → str or list[str]

The decoded token(s).

The decoded token(s).

Converts a single index or a sequence of indices in a token or a sequence of tokens, using the vocabulary and added tokens.

( tokens: typing.Union[str, collections.abc.Iterable[str]] ) → int or list[int]

The token id or list of token ids.

The token id or list of token ids.

Converts a token string (or a sequence of tokens) in a single integer id (or a Iterable of ids), using the vocabulary.

Returns the added tokens in the vocabulary as a dictionary of token to index.

( pair: bool = False ) → int

Number of special tokens added to sequences.

Number of special tokens added to sequences.

Returns the number of added tokens when encoding a sequence with special tokens.

This encodes a dummy input and checks the number of added tokens, and is therefore not efficient. Do not put this inside your training loop.

( padding_strategy: PaddingStrategy truncation_strategy: TruncationStrategy max_length: int stride: int pad_to_multiple_of: typing.Optional[int] padding_side: typing.Optional[str] )

Define the truncation and the padding strategies for fast tokenizers (provided by HuggingFace tokenizers library) and restore the tokenizer settings afterwards.

The provided tokenizer has no padding / truncation strategy before the managed section. If your tokenizer set a padding / truncation strategy before, then it will be reset to no padding / truncation when exiting the managed section.

( text_iterator vocab_size length = None new_special_tokens = None special_tokens_map = None **kwargs ) → PreTrainedTokenizerFast

PreTrainedTokenizerFast

A new tokenizer of the same type as the original one, trained on text_iterator.

A new tokenizer of the same type as the original one, trained on text_iterator.

Trains a tokenizer on a new corpus with the same defaults (in terms of special tokens or tokenization pipeline) as the current one.

( data: typing.Optional[dict[str, typing.Any]] = None encoding: typing.Union[tokenizers.Encoding, collections.abc.Sequence[tokenizers.Encoding], NoneType] = None tensor_type: typing.Union[NoneType, str, transformers.utils.generic.TensorType] = None prepend_batch_axis: bool = False n_sequences: typing.Optional[int] = None )

Holds the output of the call(), encode_plus() and batch_encode_plus() methods (tokens, attention_masks, etc).

This class is derived from a python dictionary and can be used as a dictionary. In addition, this class exposes utility methods to map from word/character space to token space.

( batch_or_char_index: int char_index: typing.Optional[int] = None sequence_index: int = 0 ) → int

Index of the token, or None if the char index refers to a whitespace only token and whitespace is trimmed with trim_offsets=True.

Index of the token, or None if the char index refers to a whitespace only token and whitespace is trimmed with trim_offsets=True.

Get the index of the token in the encoded output comprising a character in the original string for a sequence of the batch.

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e. words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_or_char_index: int char_index: typing.Optional[int] = None sequence_index: int = 0 ) → int or list[int]

Index or indices of the associated encoded token(s).

Index or indices of the associated encoded token(s).

Get the word in the original string corresponding to a character in the original string of a sequence of the batch.

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e. words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( tensor_type: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None prepend_batch_axis: bool = False )

Convert the inner content to tensors.

( batch_index: int = 0 ) → list[Optional[int]]

A list indicating the sequence id corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding sequence.

A list indicating the sequence id corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding sequence.

Return a list mapping the tokens to the id of their original sentences:

( device: typing.Union[str, ForwardRef('torch.device')] non_blocking: bool = False ) → BatchEncoding

The same instance after modification.

The same instance after modification.

Send all values to device by calling v.to(device, non_blocking=non_blocking) (PyTorch only).

( batch_or_token_index: int token_index: typing.Optional[int] = None ) → CharSpan

Span of characters in the original string, or None, if the token (e.g. , ) doesn’t correspond to any chars in the origin string.

Span of characters in the original string, or None, if the token (e.g. , ) doesn’t correspond to any chars in the origin string.

Get the character span corresponding to an encoded token in a sequence of the batch.

Character spans are returned as a CharSpan with:

( batch_or_token_index: int token_index: typing.Optional[int] = None ) → int

Index of the word in the input sequence.

Index of the word in the input sequence.

Get the index of the sequence represented by the given token. In the general use case, this method returns 0 for a single sequence or the first sequence of a pair, and 1 for the second sequence of a pair

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e., words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_or_token_index: int token_index: typing.Optional[int] = None ) → int

Index of the word in the input sequence.

Index of the word in the input sequence.

Get the index of the word corresponding (i.e. comprising) to an encoded token in a sequence of the batch.

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e., words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_index: int = 0 ) → list[str]

The list of tokens at that index.

The list of tokens at that index.

Return the list of tokens (sub-parts of the input strings after word/subword splitting and before conversion to integer indices) at a given batch index (only works for the output of a fast tokenizer).

( batch_index: int = 0 ) → list[Optional[int]]

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

Return a list mapping the tokens to their actual word in the initial sentence for a fast tokenizer.

( batch_or_word_index: int word_index: typing.Optional[int] = None sequence_index: int = 0 ) → CharSpan or list[CharSpan]

CharSpan or list[CharSpan]

Span(s) of the associated character or characters in the string. CharSpan are NamedTuple with: start: index of the first character associated to the token in the original string end: index of the character following the last character associated to the token in the original string

Span(s) of the associated character or characters in the string. CharSpan are NamedTuple with:

Get the character span in the original string corresponding to given word in a sequence of the batch.

Character spans are returned as a CharSpan NamedTuple with:

( batch_or_word_index: int word_index: typing.Optional[int] = None sequence_index: int = 0 ) → (TokenSpan, optional)

(TokenSpan, optional)

Span of tokens in the encoded sequence. Returns None if no tokens correspond to the word. This can happen especially when the token is a special token that has been used to format the tokenization. For example when we add a class token at the very beginning of the tokenization.

Span of tokens in the encoded sequence. Returns None if no tokens correspond to the word. This can happen especially when the token is a special token that has been used to format the tokenization. For example when we add a class token at the very beginning of the tokenization.

Get the encoded token span corresponding to a word in a sequence of the batch.

Token spans are returned as a TokenSpan with:

This method is particularly suited when the input sequences are provided as pre-tokenized sequences (i.e. words are defined by the user). In this case it allows to easily associate encoded tokens with provided tokenized words.

( batch_index: int = 0 ) → list[Optional[int]]

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

A list indicating the word corresponding to each token. Special tokens added by the tokenizer are mapped to None and other tokens are mapped to the index of their corresponding word (several tokens will be mapped to the same word index if they are parts of that word).

Return a list mapping the tokens to their actual word in the initial sentence for a fast tokenizer.

**Examples:**

Example 1 (unknown):
```unknown
encode_plus
```

Example 2 (unknown):
```unknown
batch_encode_plus
```

Example 3 (unknown):
```unknown
attention_mask
```

Example 4 (unknown):
```unknown
tokenizer.image_token_id
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/pipelines

**Contents:**
- Transformers
- Pipelines
- The pipeline abstraction
    - transformers.pipeline
- Pipeline batching
- Pipeline chunk batching
- Pipeline FP16 inference
- Pipeline custom code
- Implementing a pipeline
- Audio

Transformers documentation

and get access to the augmented documentation experience

The pipelines are a great and easy way to use models for inference. These pipelines are objects that abstract most of the complex code from the library, offering a simple API dedicated to several tasks, including Named Entity Recognition, Masked Language Modeling, Sentiment Analysis, Feature Extraction and Question Answering. See the task summary for examples of use.

There are two categories of pipeline abstractions to be aware about:

The pipeline abstraction is a wrapper around all the other available pipelines. It is instantiated as any other pipeline but can provide additional quality of life.

Simple call on one item:

If you want to use a specific model from the hub you can ignore the task if the model on the hub already defines it:

To call a pipeline on many items, you can call it with a list.

To iterate over full datasets it is recommended to use a dataset directly. This means you don’t need to allocate the whole dataset at once, nor do you need to do batching yourself. This should work just as fast as custom loops on GPU. If it doesn’t don’t hesitate to create an issue.

For ease of use, a generator is also possible:

( task: typing.Optional[str] = None model: typing.Union[str, ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel'), NoneType] = None config: typing.Union[str, transformers.configuration_utils.PretrainedConfig, NoneType] = None tokenizer: typing.Union[str, transformers.tokenization_utils.PreTrainedTokenizer, ForwardRef('PreTrainedTokenizerFast'), NoneType] = None feature_extractor: typing.Union[ForwardRef('SequenceFeatureExtractor'), str, NoneType] = None image_processor: typing.Union[str, transformers.image_processing_utils.BaseImageProcessor, NoneType] = None processor: typing.Union[str, transformers.processing_utils.ProcessorMixin, NoneType] = None framework: typing.Optional[str] = None revision: typing.Optional[str] = None use_fast: bool = True token: typing.Union[str, bool, NoneType] = None device: typing.Union[int, str, ForwardRef('torch.device'), NoneType] = None device_map: typing.Union[str, dict[str, typing.Union[int, str]], NoneType] = None dtype: typing.Union[str, ForwardRef('torch.dtype'), NoneType] = 'auto' trust_remote_code: typing.Optional[bool] = None model_kwargs: typing.Optional[dict[str, typing.Any]] = None pipeline_class: typing.Optional[typing.Any] = None **kwargs: typing.Any ) → Pipeline

If not provided, the default for the task will be loaded.

If not provided, the default configuration file for the requested model will be used. That means that if model is given, its default configuration will be used. However, if model is not supplied, this task’s default model’s config is used instead.

If not provided, the default tokenizer for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default tokenizer for config is loaded (if it is a string). However, if config is also not given or not a string, then the default tokenizer for the given task will be loaded.

Feature extractors are used for non-NLP models, such as Speech or Vision models as well as multi-modal models. Multi-modal models will also require a tokenizer to be passed.

If not provided, the default feature extractor for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default feature extractor for config is loaded (if it is a string). However, if config is also not given or not a string, then the default feature extractor for the given task will be loaded.

Image processors are used for Vision models and multi-modal models that require image inputs. Multi-modal models will also require a tokenizer to be passed.

If not provided, the default image processor for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default image processor for config is loaded (if it is a string).

Processors are used for multi-modal models that require multi-modal inputs, for example, a model that requires both text and image inputs.

If not provided, the default processor for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default processor for config is loaded (if it is a string).

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Do not use device_map AND device at the same time as they will conflict

A suitable pipeline for the task.

A suitable pipeline for the task.

Utility factory method to build a Pipeline.

A pipeline consists of:

All pipelines can use batching. This will work whenever the pipeline uses its streaming ability (so when passing lists or Dataset or generator).

However, this is not automatically a win for performance. It can be either a 10x speedup or 5x slowdown depending on hardware, data and the actual model being used.

Example where it’s mostly a speedup:

Example where it’s most a slowdown:

This is a occasional very long sentence compared to the other. In that case, the whole batch will need to be 400 tokens long, so the whole batch will be [64, 400] instead of [64, 4], leading to the high slowdown. Even worse, on bigger batches, the program simply crashes.

There are no good (general) solutions for this problem, and your mileage may vary depending on your use cases. Rule of thumb:

For users, a rule of thumb is:

Measure performance on your load, with your hardware. Measure, measure, and keep measuring. Real numbers are the only way to go.

If you are latency constrained (live product doing inference), don’t batch.

If you are using CPU, don’t batch.

If you are using throughput (you want to run your model on a bunch of static data), on GPU, then:

As soon as you enable batching, make sure you can handle OOMs nicely.

zero-shot-classification and question-answering are slightly specific in the sense, that a single input might yield multiple forward pass of a model. Under normal circumstances, this would yield issues with batch_size argument.

In order to circumvent this issue, both of these pipelines are a bit specific, they are ChunkPipeline instead of regular Pipeline. In short:

This should be very transparent to your code because the pipelines are used in the same way.

This is a simplified view, since the pipeline can handle automatically the batch to ! Meaning you don’t have to care about how many forward passes you inputs are actually going to trigger, you can optimize the batch_size independently of the inputs. The caveats from the previous section still apply.

Models can be run in FP16 which can be significantly faster on GPU while saving memory. Most models will not suffer noticeable performance loss from this. The larger the model, the less likely that it will.

To enable FP16 inference, you can simply pass dtype=torch.float16 or dtype='float16' to the pipeline constructor. Note that this only works for models with a PyTorch backend. Your inputs will be converted to FP16 internally.

If you want to override a specific pipeline.

Don’t hesitate to create an issue for your task at hand, the goal of the pipeline is to be easy to use and support most cases, so transformers could maybe support your use case.

If you want to try simply you can:

That should enable you to do all the custom code you want.

Implementing a new pipeline

Pipelines available for audio tasks include the following.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Audio classification pipeline using any AutoModelForAudioClassification. This pipeline predicts the class of a raw waveform or an audio file. In case of an audio file, ffmpeg should be installed to support multiple audio formats.

Learn more about the basics of using a pipeline in the pipeline tutorial

This pipeline can currently be loaded from pipeline() using the following task identifier: "audio-classification".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[numpy.ndarray, bytes, str, dict] **kwargs: typing.Any ) → A list of dict with the following keys

A list of dict with the following keys

label (str) — The label predicted. score (float) — The corresponding probability.

Classify the sequence(s) given as inputs. See the AutomaticSpeechRecognitionPipeline documentation for more information.

( model: PreTrainedModel feature_extractor: typing.Union[ForwardRef('SequenceFeatureExtractor'), str, NoneType] = None tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None decoder: typing.Union[ForwardRef('BeamSearchDecoderCTC'), str, NoneType] = None device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None **kwargs )

For more information on how to effectively use chunk_length_s, please have a look at the ASR chunking blog post.

For more information on how to effectively use stride_length_s, please have a look at the ASR chunking blog post.

Pipeline that aims at extracting spoken text contained within some audio.

The input can be either a raw waveform or a audio file. In case of the audio file, ffmpeg should be installed for to support multiple audio formats

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

( inputs: typing.Union[numpy.ndarray, bytes, str, dict] **kwargs: typing.Any ) → Dict

For CTC models, timestamps can take one of two formats:

For the Whisper model, timestamps can take one of two formats:

A dictionary with the following keys: text (str): The recognized text. chunks (optional(, list[Dict]) When using return_timestamps, the chunks will become a list containing all the various text chunks identified by the model, e.g.* [{"text": "hi ", "timestamp": (0.5, 0.9)}, {"text": "there", "timestamp": (1.0, 1.5)}]. The original full text can roughly be recovered by doing "".join(chunk["text"] for chunk in output["chunks"]).

A dictionary with the following keys:

Transcribe the audio sequence(s) given as inputs to text. See the AutomaticSpeechRecognitionPipeline documentation for more information.

( *args vocoder = None sampling_rate = None no_processor = True **kwargs )

Text-to-audio generation pipeline using any AutoModelForTextToWaveform or AutoModelForTextToSpectrogram. This pipeline generates an audio file from an input text and optional other conditional inputs.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

You can specify parameters passed to the model by using TextToAudioPipeline.__call__.forward_params or TextToAudioPipeline.__call__.generate_kwargs.

This pipeline can currently be loaded from pipeline() using the following task identifiers: "text-to-speech" or "text-to-audio".

See the list of available models on huggingface.co/models.

( text_inputs: typing.Union[str, list[str]] **forward_params ) → A dict or a list of dict

A dict or a list of dict

The dictionaries have two keys: audio (np.ndarray of shape (nb_channels, audio_length)) — The generated audio waveform. sampling_rate (int) — The sampling rate of the generated audio waveform.

The dictionaries have two keys:

Generates speech/audio from the inputs. See the TextToAudioPipeline documentation for more information.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Zero shot audio classification pipeline using ClapModel. This pipeline predicts the class of an audio when you provide an audio and a set of candidate_labels.

The default hypothesis_template is : "This is a sound of {}.". Make sure you update it for your usage.

Learn more about the basics of using a pipeline in the pipeline tutorial This audio classification pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-audio-classification". See the list of available models on huggingface.co/models.

( audios: typing.Union[numpy.ndarray, bytes, str, dict] **kwargs: typing.Any )

Assign labels to the audio(s) passed as inputs.

Pipelines available for computer vision tasks include the following.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Depth estimation pipeline using any AutoModelForDepthEstimation. This pipeline predicts the depth of an image.

Learn more about the basics of using a pipeline in the pipeline tutorial

This depth estimation pipeline can currently be loaded from pipeline() using the following task identifier: "depth-estimation".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

Predict the depth(s) of the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image classification pipeline using any AutoModelForImageClassification. This pipeline predicts the class of an image.

Learn more about the basics of using a pipeline in the pipeline tutorial

This image classification pipeline can currently be loaded from pipeline() using the following task identifier: "image-classification".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

If this argument is not specified, then it will apply the following functions according to the number of labels:

Assign labels to the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image segmentation pipeline using any AutoModelForXXXSegmentation. This pipeline predicts masks of objects and their classes.

This image segmentation pipeline can currently be loaded from pipeline() using the following task identifier: "image-segmentation".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, ForwardRef('Image.Image'), list[str], list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images. Images in a batch must all be in the same format: all as HTTP(S) links, all as local paths, or all as PIL images.

Perform segmentation (detect masks & classes) in the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image to Image pipeline using any AutoModelForImageToImage. This pipeline generates an image based on a previous image input.

This image to image pipeline can currently be loaded from pipeline() using the following task identifier: "image-to-image".

See the list of available models on huggingface.co/models.

( images: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

Transform the image(s) passed as inputs.

Keypoint matching pipeline using any AutoModelForKeypointMatching. This pipeline matches keypoints between two images.

( inputs: typing.Union[list[collections.abc.Sequence[typing.Union[ForwardRef('Image.Image'), str]]], collections.abc.Sequence[typing.Union[ForwardRef('Image.Image'), str]]] threshold: float = 0.0 **kwargs: typing.Any ) → Union[list[Match], list[list[Match]]]

The pipeline accepts either a single pair of images or a batch of image pairs, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

Union[list[Match], list[list[Match]]]

A list of matches or a list if a single image pair is provided, or of lists of matches if a batch of image pairs is provided. Each match is a dictionary containing the following keys: keypoint_image_0 (Keypoint): The keypoint in the first image (x, y coordinates). keypoint_image_1 (Keypoint): The keypoint in the second image (x, y coordinates). score (float): The matching score between the two keypoints.

A list of matches or a list if a single image pair is provided, or of lists of matches if a batch of image pairs is provided. Each match is a dictionary containing the following keys:

Find matches between keypoints in two images.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Object detection pipeline using any AutoModelForObjectDetection. This pipeline predicts bounding boxes of objects and their classes.

Learn more about the basics of using a pipeline in the pipeline tutorial

This object detection pipeline can currently be loaded from pipeline() using the following task identifier: "object-detection".

See the list of available models on huggingface.co/models.

The pipeline accepts either a single image or a batch of images. Images in a batch must all be in the same format: all as HTTP(S) links, all as local paths, or all as PIL images.

Detect objects (bounding boxes & classes) in the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Video classification pipeline using any AutoModelForVideoClassification. This pipeline predicts the class of a video.

This video classification pipeline can currently be loaded from pipeline() using the following task identifier: "video-classification".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], NoneType] = None **kwargs )

The pipeline accepts either a single video or a batch of videos, which must then be passed as a string. Videos in a batch must all be in the same format: all as http links or all as local paths.

Assign labels to the video(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Zero shot image classification pipeline using CLIPModel. This pipeline predicts the class of an image when you provide an image and a set of candidate_labels.

Learn more about the basics of using a pipeline in the pipeline tutorial

This image classification pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-image-classification".

See the list of available models on huggingface.co/models.

( image: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] candidate_labels: list **kwargs: typing.Any )

Assign labels to the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Zero shot object detection pipeline using OwlViTForObjectDetection. This pipeline predicts bounding boxes of objects when you provide an image and a set of candidate_labels.

Learn more about the basics of using a pipeline in the pipeline tutorial

This object detection pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-object-detection".

See the list of available models on huggingface.co/models.

( image: typing.Union[str, ForwardRef('Image.Image'), list[dict[str, typing.Any]]] candidate_labels: typing.Union[str, list[str], NoneType] = None **kwargs: typing.Any )

You can use this parameter to send directly a list of images, or a dataset or a generator like so:

Detect objects (bounding boxes & classes) in the image(s) passed as inputs.

Pipelines available for natural language processing tasks include the following.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

( inputs: typing.Union[str, list[str]] **kwargs: typing.Any ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as list of dictionaries with the following keys: sequence (str) — The corresponding input with the mask token prediction. score (float) — The corresponding probability. token (int) — The predicted token id (to replace the masked one). token_str (str) — The predicted token (to replace the masked one).

Each result comes as list of dictionaries with the following keys:

Fill the masked token in the text(s) given as inputs.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: PreTrainedTokenizer modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Question Answering pipeline using any ModelForQuestionAnswering. See the question answering examples for more information.

Learn more about the basics of using a pipeline in the pipeline tutorial

This question answering pipeline can currently be loaded from pipeline() using the following task identifier: "question-answering".

The models that this pipeline can use are models that have been fine-tuned on a question answering task. See the up-to-date list of available models on huggingface.co/models.

( *args **kwargs ) → A dict or a list of dict

A dict or a list of dict

Each result comes as a dictionary with the following keys: score (float) — The probability associated to the answer. start (int) — The character start index of the answer (in the tokenized version of the input). end (int) — The character end index of the answer (in the tokenized version of the input). answer (str) — The answer to the question.

Each result comes as a dictionary with the following keys:

Answer the question(s) given as inputs by using the context(s).

( question: typing.Union[str, list[str]] context: typing.Union[str, list[str]] ) → One or a list of SquadExample

One or a list of SquadExample

The corresponding SquadExample grouping question and context.

The corresponding SquadExample grouping question and context.

QuestionAnsweringPipeline leverages the SquadExample internally. This helper method encapsulate all the logic for converting question(s) and context(s) to SquadExample.

We currently support extractive question answering.

( text: str start: int end: int ) → Dictionary like `{‘answer’

Dictionary like `{‘answer’

str, ‘start’: int, ‘end’: int}`

str, ‘start’: int, ‘end’: int}`

When decoding from token probabilities, this method maps token indexes to actual word in the initial context.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Summarize news articles and other documents.

This summarizing pipeline can currently be loaded from pipeline() using the following task identifier: "summarization".

The models that this pipeline can use are models that have been fine-tuned on a summarization task, which is currently, ’bart-large-cnn’, ’google-t5/t5-small’, ’google-t5/t5-base’, ’google-t5/t5-large’, ’google-t5/t5-3b’, ’google-t5/t5-11b’. See the up-to-date list of available models on huggingface.co/models. For a list of available parameters, see the following documentation

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

( *args **kwargs ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a dictionary with the following keys: summary_text (str, present when return_text=True) — The summary of the corresponding input. summary_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the summary.

Each result comes as a dictionary with the following keys:

Summarize the text(s) given as inputs.

( args_parser = <transformers.pipelines.table_question_answering.TableQuestionAnsweringArgumentHandler object at 0x7f6352ef7700> **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Table Question Answering pipeline using a ModelForTableQuestionAnswering. This pipeline is only available in PyTorch.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This tabular question answering pipeline can currently be loaded from pipeline() using the following task identifier: "table-question-answering".

The models that this pipeline can use are models that have been fine-tuned on a tabular question answering task. See the up-to-date list of available models on huggingface.co/models.

( *args **kwargs ) → A dictionary or a list of dictionaries containing results

A dictionary or a list of dictionaries containing results

Each result is a dictionary with the following keys: answer (str) — The answer of the query given the table. If there is an aggregator, the answer will be preceded by AGGREGATOR >. coordinates (list[tuple[int, int]]) — Coordinates of the cells of the answers. cells (list[str]) — List of strings made up of the answer cell values. aggregator (str) — If the model has an aggregator, this returns the aggregator.

Each result is a dictionary with the following keys:

Answers queries according to a table. The pipeline accepts several types of inputs which are detailed below:

The table argument should be a dict or a DataFrame built from that dict, containing the whole table:

This dictionary can be passed in as such, or can be converted to a pandas DataFrame:

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Text classification pipeline using any ModelForSequenceClassification. See the sequence classification examples for more information.

Learn more about the basics of using a pipeline in the pipeline tutorial

This text classification pipeline can currently be loaded from pipeline() using the following task identifier: "sentiment-analysis" (for classifying sequences according to positive or negative sentiments).

If multiple classification labels are available (model.config.num_labels >= 2), the pipeline will run a softmax over the results. If there is a single label, the pipeline will run a sigmoid over the result. In case of regression tasks (model.config.problem_type == "regression"), will not apply any function on the output.

The models that this pipeline can use are models that have been fine-tuned on a sequence classification task. See the up-to-date list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], dict[str, str], list[dict[str, str]]] **kwargs: typing.Any ) → A list of dict

If this argument is not specified, then it will apply the following functions according to the number of labels:

Each result comes as list of dictionaries with the following keys: label (str) — The label predicted. score (float) — The corresponding probability. If top_k is used, one such dictionary is returned per label.

Each result comes as list of dictionaries with the following keys:

If top_k is used, one such dictionary is returned per label.

Classify the text(s) given as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Language generation pipeline using any ModelWithLMHead or ModelForCausalLM. This pipeline predicts the words that will follow a specified text prompt. When the underlying model is a conversational model, it can also accept one or more chats, in which case the pipeline will operate in chat mode and will continue the chat(s) by adding its response(s). Each chat takes the form of a list of dicts, where each dict contains “role” and “content” keys.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial. You can pass text generation parameters to this pipeline to control stopping criteria, decoding strategy, and more. Learn more about text generation parameters in Text generation strategies and Text generation.

This language generation pipeline can currently be loaded from pipeline() using the following task identifier: "text-generation".

The models that this pipeline can use are models that have been trained with an autoregressive language modeling objective. See the list of available text completion models and the list of conversational models on [huggingface.co/models].

( text_inputs **kwargs ) → A list or a list of lists of dict

A list or a list of lists of dict

Returns one of the following dictionaries (cannot return a combination of both generated_text and generated_token_ids): generated_text (str, present when return_text=True) — The generated text. generated_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the generated text.

Returns one of the following dictionaries (cannot return a combination of both generated_text and generated_token_ids):

Complete the prompt(s) given as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Pipeline for text to text generation using seq2seq models.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial. You can pass text generation parameters to this pipeline to control stopping criteria, decoding strategy, and more. Learn more about text generation parameters in Text generation strategies and Text generation.

This Text2TextGenerationPipeline pipeline can currently be loaded from pipeline() using the following task identifier: "text2text-generation".

The models that this pipeline can use are models that have been fine-tuned on a translation task. See the up-to-date list of available models on huggingface.co/models. For a list of available parameters, see the following documentation

( *args: typing.Union[str, list[str]] **kwargs: typing.Any ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a dictionary with the following keys: generated_text (str, present when return_text=True) — The generated text. generated_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the generated text.

Each result comes as a dictionary with the following keys:

Generate the output text(s) using text(s) given as inputs.

( input_length: int min_length: int max_length: int )

Checks whether there might be something wrong with given input with regard to the model.

( args_parser = <transformers.pipelines.token_classification.TokenClassificationArgumentHandler object at 0x7f6352f25fc0> **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Named Entity Recognition pipeline using any ModelForTokenClassification. See the named entity recognition examples for more information.

Learn more about the basics of using a pipeline in the pipeline tutorial

This token recognition pipeline can currently be loaded from pipeline() using the following task identifier: "ner" (for predicting the classes of tokens in a sequence: person, organisation, location or miscellaneous).

The models that this pipeline can use are models that have been fine-tuned on a token classification task. See the up-to-date list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str]] **kwargs: typing.Any ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a list of dictionaries (one for each token in the corresponding input, or each entity if this pipeline was instantiated with an aggregation_strategy) with the following keys: word (str) — The token/word classified. This is obtained by decoding the selected tokens. If you want to have the exact string in the original sentence, use start and end. score (float) — The corresponding probability for entity. entity (str) — The entity predicted for that token/word (it is named entity_group when aggregation_strategy is not "none". index (int, only present when aggregation_strategy="none") — The index of the corresponding token in the sentence. start (int, optional) — The index of the start of the corresponding entity in the sentence. Only exists if the offsets are available within the tokenizer end (int, optional) — The index of the end of the corresponding entity in the sentence. Only exists if the offsets are available within the tokenizer

Each result comes as a list of dictionaries (one for each token in the corresponding input, or each entity if this pipeline was instantiated with an aggregation_strategy) with the following keys:

Classify each token of the text(s) given as inputs.

( entities: list aggregation_strategy: AggregationStrategy )

Override tokens from a given word that disagree to force agreement on word boundaries.

Example: micro|soft| com|pany| B-ENT I-NAME I-ENT I-ENT will be rewritten with first strategy as microsoft| company| B-ENT I-ENT

( sentence: str input_ids: ndarray scores: ndarray offset_mapping: typing.Optional[list[tuple[int, int]]] special_tokens_mask: ndarray aggregation_strategy: AggregationStrategy word_ids: typing.Optional[list[typing.Optional[int]]] = None word_to_chars_map: typing.Optional[list[tuple[int, int]]] = None )

Fuse various numpy arrays into dicts with all the information needed for aggregation

Find and group together the adjacent tokens with the same entity predicted.

Group together the adjacent tokens with the same entity predicted.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Translates from one language to another.

This translation pipeline can currently be loaded from pipeline() using the following task identifier: "translation_xx_to_yy".

The models that this pipeline can use are models that have been fine-tuned on a translation task. See the up-to-date list of available models on huggingface.co/models. For a list of available parameters, see the following documentation

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

( *args **kwargs ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a dictionary with the following keys: translation_text (str, present when return_text=True) — The translation. translation_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the translation.

Each result comes as a dictionary with the following keys:

Translate the text(s) given as inputs.

( args_parser = <transformers.pipelines.zero_shot_classification.ZeroShotClassificationArgumentHandler object at 0x7f6352dd7910> **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

NLI-based zero-shot classification pipeline using a ModelForSequenceClassification trained on NLI (natural language inference) tasks. Equivalent of text-classification pipelines, but these models don’t require a hardcoded number of potential classes, they can be chosen at runtime. It usually means it’s slower but it is much more flexible.

Any combination of sequences and labels can be passed and each combination will be posed as a premise/hypothesis pair and passed to the pretrained model. Then, the logit for entailment is taken as the logit for the candidate label being valid. Any NLI model can be used, but the id of the entailment label must be included in the model config’s :attr:~transformers.PretrainedConfig.label2id.

Learn more about the basics of using a pipeline in the pipeline tutorial

This NLI pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-classification".

The models that this pipeline can use are models that have been fine-tuned on an NLI task. See the up-to-date list of available models on huggingface.co/models.

( sequences: typing.Union[str, list[str]] *args **kwargs ) → A dict or a list of dict

A dict or a list of dict

Each result comes as a dictionary with the following keys: sequence (str) — The sequence for which this is the output. labels (list[str]) — The labels sorted by order of likelihood. scores (list[float]) — The probabilities for each of the labels.

Each result comes as a dictionary with the following keys:

Classify the sequence(s) given as inputs. See the ZeroShotClassificationPipeline documentation for more information.

Pipelines available for multimodal tasks include the following.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Document Question Answering pipeline using any AutoModelForDocumentQuestionAnswering. The inputs/outputs are similar to the (extractive) question answering pipeline; however, the pipeline takes an image (and optional OCR’d words/boxes) as input instead of text context.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This document question answering pipeline can currently be loaded from pipeline() using the following task identifier: "document-question-answering".

The models that this pipeline can use are models that have been fine-tuned on a document question answering task. See the up-to-date list of available models on huggingface.co/models.

( image: typing.Union[ForwardRef('Image.Image'), str, list[dict[str, typing.Any]]] question: typing.Optional[str] = None word_boxes: typing.Optional[tuple[str, list[float]]] = None **kwargs: typing.Any ) → A dict or a list of dict

The pipeline accepts either a single image or a batch of images. If given a single image, it can be broadcasted to multiple questions.

A dict or a list of dict

Each result comes as a dictionary with the following keys: score (float) — The probability associated to the answer. start (int) — The start word index of the answer (in the OCR’d version of the input or provided word_boxes). end (int) — The end word index of the answer (in the OCR’d version of the input or provided word_boxes). answer (str) — The answer to the question. words (list[int]) — The index of each word/box pair that is in the answer

Each result comes as a dictionary with the following keys:

Answer the question(s) given as inputs by using the document(s). A document is defined as an image and an optional list of (word, box) tuples which represent the text in the document. If the word_boxes are not provided, it will use the Tesseract OCR engine (if available) to extract the words and boxes automatically for LayoutLM-like models which require them as input. For Donut, no OCR is run.

You can invoke the pipeline several ways:

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Feature extraction pipeline uses no model head. This pipeline extracts the hidden states from the base transformer, which can be used as features in downstream tasks.

Learn more about the basics of using a pipeline in the pipeline tutorial

This feature extraction pipeline can currently be loaded from pipeline() using the task identifier: "feature-extraction".

All models may be used for this pipeline. See a list of all models, including community-contributed models on huggingface.co/models.

( *args: typing.Union[str, list[str]] **kwargs: typing.Any ) → A nested list of float

A nested list of float

The features computed by the model.

The features computed by the model.

Extract the features of the input(s) text.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image feature extraction pipeline uses no model head. This pipeline extracts the hidden states from the base transformer, which can be used as features in downstream tasks.

Learn more about the basics of using a pipeline in the pipeline tutorial

This image feature extraction pipeline can currently be loaded from pipeline() using the task identifier: "image-feature-extraction".

All vision models may be used for this pipeline. See a list of all models, including community-contributed models on huggingface.co/models.

( *args: typing.Union[str, ForwardRef('Image.Image'), list['Image.Image'], list[str]] **kwargs: typing.Any ) → A nested list of float

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

A nested list of float

The features computed by the model.

The features computed by the model.

Extract the features of the input(s).

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image To Text pipeline using a AutoModelForVision2Seq. This pipeline predicts a caption for a given image.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This image to text pipeline can currently be loaded from pipeline() using the following task identifier: “image-to-text”.

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs ) → A list or a list of list of dict

The pipeline accepts either a single image or a batch of images.

A list or a list of list of dict

Each result comes as a dictionary with the following key: generated_text (str) — The generated text.

Each result comes as a dictionary with the following key:

Assign labels to the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image-text-to-text pipeline using an AutoModelForImageTextToText. This pipeline generates text given an image and text. When the underlying model is a conversational model, it can also accept one or more chats, in which case the pipeline will operate in chat mode and will continue the chat(s) by adding its response(s). Each chat takes the form of a list of dicts, where each dict contains “role” and “content” keys.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This image-text to text pipeline can currently be loaded from pipeline() using the following task identifier: “image-text-to-text”.

See the list of available models on huggingface.co/models.

( images: typing.Union[str, list[str], list[list[str]], ForwardRef('Image.Image'), list['Image.Image'], list[list['Image.Image']], list[dict], NoneType] = None text: typing.Union[str, list[str], list[dict], NoneType] = None **kwargs ) → A list or a list of list of dict

The pipeline accepts either a single image or a batch of images. Finally, this pipeline also supports the chat format (see text) containing images and text in this argument.

A list or a list of list of dict

Each result comes as a dictionary with the following key (cannot return a combination of both generated_text and generated_token_ids): generated_text (str, present when return_text=True) — The generated text. generated_token_ids (torch.Tensor, present when return_tensors=True) — The token ids of the generated text. input_text (str) — The input text.

Each result comes as a dictionary with the following key (cannot return a combination of both generated_text and generated_token_ids):

Generate a text given text and the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Automatic mask generation for images using SamForMaskGeneration. This pipeline predicts binary masks for an image, given an image. It is a ChunkPipeline because you can separate the points in a mini-batch in order to avoid OOM issues. Use the points_per_batch argument to control the number of points that will be processed at the same time. Default is 64.

The pipeline works in 3 steps:

preprocess: A grid of 1024 points evenly separated is generated along with bounding boxes and point labels. For more details on how the points and bounding boxes are created, check the _generate_crop_boxes function. The image is also preprocessed using the image_processor. This function yields a minibatch of points_per_batch.

forward: feeds the outputs of preprocess to the model. The image embedding is computed only once. Calls both self.model.get_image_embeddings and makes sure that the gradients are not computed, and the tensors and models are on the same device.

postprocess: The most important part of the automatic mask generation happens here. Three steps are induced:

Learn more about the basics of using a pipeline in the pipeline tutorial

This segmentation pipeline can currently be loaded from pipeline() using the following task identifier: "mask-generation".

See the list of available models on huggingface.co/models.

( image: typing.Union[str, ForwardRef('Image.Image'), list[str], list['Image.Image']] *args: typing.Any **kwargs: typing.Any ) → Dict

A dictionary with the following keys: mask (PIL.Image) — A binary mask of the detected object as a PIL Image of shape (width, height) of the original image. Returns a mask filled with zeros if no object is found. score (optional float) — Optionally, when the model is capable of estimating a confidence of the “object” described by the label and the mask.

A dictionary with the following keys:

Generates binary segmentation masks

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Visual Question Answering pipeline using a AutoModelForVisualQuestionAnswering. This pipeline is currently only available in PyTorch.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This visual question answering pipeline can currently be loaded from pipeline() using the following task identifiers: "visual-question-answering", "vqa".

The models that this pipeline can use are models that have been fine-tuned on a visual question answering task. See the up-to-date list of available models on huggingface.co/models.

( image: typing.Union[ForwardRef('Image.Image'), str, list['Image.Image'], list[str], ForwardRef('KeyDataset')] question: typing.Union[str, list[str], NoneType] = None **kwargs ) → A dictionary or a list of dictionaries containing the result. The dictionaries contain the following keys

The pipeline accepts either a single image or a batch of images. If given a single image, it can be broadcasted to multiple questions. For dataset: the passed in dataset must be of type transformers.pipelines.pt_utils.KeyDataset Example:

A dictionary or a list of dictionaries containing the result. The dictionaries contain the following keys

label (str) — The label identified by the model. score (int) — The score attributed by the model for that label.

Answers open-ended questions about images. The pipeline accepts several types of inputs which are detailed below:

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

The Pipeline class is the class from which all pipelines inherit. Refer to this class for methods shared across different pipelines.

Base class implementing pipelined operations. Pipeline workflow is defined as a sequence of the following operations:

Input -> Tokenization -> Model Inference -> Post-Processing (task dependent) -> Output

Pipeline supports running on CPU or GPU through the device argument (see below).

Some pipeline, like for instance FeatureExtractionPipeline ('feature-extraction') output large tensor object as nested-lists. In order to avoid dumping such large structure as textual data we provide the binary_output constructor argument. If set to True, the output will be stored in the pickle format.

( supported_models: typing.Union[list[str], dict] )

Check if the model class is in supported by the pipeline.

Context Manager allowing tensor allocation on the user-specified device in framework agnostic way.

( **inputs ) → dict[str, torch.Tensor]

dict[str, torch.Tensor]

The same as inputs but on the proper device.

The same as inputs but on the proper device.

Ensure PyTorch tensors are on the specified device.

( model_outputs: ModelOutput **postprocess_parameters: dict )

Postprocess will receive the raw outputs of the _forward method, generally tensors, and reformat them into something more friendly. Generally it will output a list or a dict or results (containing just strings and numbers).

Scikit / Keras interface to transformers’ pipelines. This method will forward to call().

( input_: typing.Any **preprocess_parameters: dict )

Preprocess will take the input_ of a specific pipeline and return a dictionary of everything necessary for _forward to run properly. It should contain at least one tensor, but might have arbitrary other items.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the pipeline file to the 🤗 Model Hub.

( save_directory: typing.Union[str, os.PathLike] safe_serialization: bool = True **kwargs: typing.Any )

Save the pipeline’s model and tokenizer.

Scikit / Keras interface to transformers’ pipelines. This method will forward to call().

**Examples:**

Example 1 (unknown):
```unknown
"audio-classification"
```

Example 2 (unknown):
```unknown
"automatic-speech-recognition"
```

Example 3 (unknown):
```unknown
"depth-estimation"
```

Example 4 (unknown):
```unknown
"document-question-answering"
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/image_processor

**Contents:**
- Transformers
- Image Processor
- ImageProcessingMixin
  - class transformers.ImageProcessingMixin
    - from_pretrained
    - save_pretrained
- BatchFeature
  - class transformers.BatchFeature
    - convert_to_tensors
    - to

Transformers documentation

and get access to the augmented documentation experience

An image processor is in charge of loading images (optionally), preparing input features for vision models and post processing their outputs. This includes transformations such as resizing, normalization, and conversion to PyTorch and Numpy tensors. It may also include model specific post-processing such as converting logits to segmentation masks. Fast image processors are available for a few models and more will be added in the future. They are based on the torchvision library and provide a significant speed-up, especially when processing on GPU. They have the same API as the base image processors and can be used as drop-in replacements. To use a fast image processor, you need to install the torchvision library, and set the use_fast argument to True when instantiating the image processor:

Note that use_fast will be set to True by default in a future release.

When using a fast image processor, you can also set the device argument to specify the device on which the processing should be done. By default, the processing is done on the same device as the inputs if the inputs are tensors, or on the CPU otherwise.

Here are some speed comparisons between the base and fast image processors for the DETR and RT-DETR models, and how they impact overall inference time:

These benchmarks were run on an AWS EC2 g5.2xlarge instance, utilizing an NVIDIA A10G Tensor Core GPU.

This is an image processor mixin used to provide saving/loading functionality for sequential and image feature extractors.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a type of ImageProcessingMixin from an image processor.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save an image processor object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

( data: typing.Optional[dict[str, typing.Any]] = None tensor_type: typing.Union[NoneType, str, transformers.utils.generic.TensorType] = None )

Holds the output of the pad() and feature extractor specific __call__ methods.

This class is derived from a python dictionary and can be used as a dictionary.

( tensor_type: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None )

Convert the inner content to tensors.

( *args **kwargs ) → BatchFeature

The same instance after modification.

The same instance after modification.

Send all values to device by calling v.to(*args, **kwargs) (PyTorch only). This should support casting in different dtypes and sending the BatchFeature to a different device.

( image: ndarray size: dict data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None input_data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None **kwargs )

Center crop an image to (size["height"], size["width"]). If the input size is smaller than crop_size along any edge, the image is padded with 0’s and then center cropped.

( image: ndarray mean: typing.Union[float, collections.abc.Iterable[float]] std: typing.Union[float, collections.abc.Iterable[float]] data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None input_data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None **kwargs ) → np.ndarray

The normalized image.

The normalized image.

Normalize an image. image = (image - image_mean) / image_std.

( image: ndarray scale: float data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None input_data_format: typing.Union[transformers.image_utils.ChannelDimension, str, NoneType] = None **kwargs ) → np.ndarray

Rescale an image by a scale factor. image = image * scale.

( **kwargs: typing_extensions.Unpack[transformers.image_processing_utils_fast.DefaultFastImageProcessorKwargs] )

( image: torch.Tensor size: SizeDict **kwargs ) → torch.Tensor

The center cropped image.

The center cropped image.

Note: override torchvision’s center_crop to have the same behavior as the slow processor. Center crop an image to (size["height"], size["width"]). If the input size is smaller than crop_size along any edge, the image is padded with 0’s and then center cropped.

( image: torch.Tensor new_size: tuple interpolation: typing.Optional[ForwardRef('F.InterpolationMode')] = None antialias: bool = True )

A wrapper around F.resize so that it is compatible with torch.compile when the image is a uint8 tensor.

( image: typing.Union[ForwardRef('PIL.Image.Image'), numpy.ndarray, ForwardRef('torch.Tensor'), list['PIL.Image.Image'], list[numpy.ndarray], list['torch.Tensor']] ) → ImageInput

Converts an image to RGB format. Only converts if the image is of type PIL.Image.Image, otherwise returns the image as is.

Filter out the unused kwargs from the kwargs dictionary.

( image: torch.Tensor mean: typing.Union[float, collections.abc.Iterable[float]] std: typing.Union[float, collections.abc.Iterable[float]] **kwargs ) → torch.Tensor

The normalized image.

The normalized image.

Normalize an image. image = (image - image_mean) / image_std.

( images: torch.Tensor pad_size: SizeDict = None fill_value: typing.Optional[int] = 0 padding_mode: typing.Optional[str] = 'constant' return_mask: bool = False disable_grouping: typing.Optional[bool] = False **kwargs ) → torch.Tensor

Pads images to (pad_size["height"], pad_size["width"]) or to the largest size in the batch.

( images: typing.Union[ForwardRef('PIL.Image.Image'), numpy.ndarray, ForwardRef('torch.Tensor'), list['PIL.Image.Image'], list[numpy.ndarray], list['torch.Tensor']] *args **kwargs: typing_extensions.Unpack[transformers.image_processing_utils_fast.DefaultFastImageProcessorKwargs] ) → <class 'transformers.image_processing_base.BatchFeature'>

<class 'transformers.image_processing_base.BatchFeature'>

data (dict) — Dictionary of lists/arrays/tensors returned by the call method (‘pixel_values’, etc.). tensor_type (Union[None, str, TensorType], optional) — You can give a tensor_type here to convert the lists of integers in PyTorch/TensorFlow/Numpy Tensors at initialization.

( image: torch.Tensor scale: float **kwargs ) → torch.Tensor

Rescale an image by a scale factor. image = image * scale.

( images: torch.Tensor do_rescale: bool rescale_factor: float do_normalize: bool image_mean: typing.Union[float, list[float]] image_std: typing.Union[float, list[float]] )

Rescale and normalize images.

( image: torch.Tensor size: SizeDict interpolation: typing.Optional[ForwardRef('F.InterpolationMode')] = None antialias: bool = True **kwargs ) → torch.Tensor

Resize an image to (size["height"], size["width"]).

**Examples:**

Example 1 (unknown):
```unknown
torchvision
```

Example 2 (unknown):
```unknown
os.PathLike
```

Example 3 (unknown):
```unknown
./my_model_directory/
```

Example 4 (unknown):
```unknown
./my_model_directory/preprocessor_config.json
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/quantization

**Contents:**
- Transformers
- Quantization
- QuantoConfig
  - class transformers.QuantoConfig
    - post_init
- AqlmConfig
  - class transformers.AqlmConfig
    - post_init
- VptqConfig
  - class transformers.VptqConfig

Transformers documentation

and get access to the augmented documentation experience

Quantization techniques reduce memory and computational costs by representing weights and activations with lower-precision data types like 8-bit integers (int8). This enables loading larger models you normally wouldn’t be able to fit into memory, and speeding up inference. Transformers supports the AWQ and GPTQ quantization algorithms and it supports 8-bit and 4-bit quantization with bitsandbytes.

Quantization techniques that aren’t supported in Transformers can be added with the HfQuantizer class.

Learn how to quantize models in the Quantization guide.

( weights = 'int8' activations = None modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using quanto.

Safety checker that arguments are correct

( in_group_size: int = 8 out_group_size: int = 1 num_codebooks: int = 1 nbits_per_codebook: int = 16 linear_weights_not_to_quantize: typing.Optional[list[str]] = None **kwargs )

This is a wrapper class about aqlm parameters.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( enable_proxy_error: bool = False config_for_layers: dict = {} shared_layer_config: dict = {} modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about vptq parameters.

Safety checker that arguments are correct

( bits: int = 4 group_size: int = 128 zero_point: bool = True version: AWQLinearVersion = <AWQLinearVersion.GEMM: 'gemm'> backend: AwqBackendPackingMethod = <AwqBackendPackingMethod.AUTOAWQ: 'autoawq'> do_fuse: typing.Optional[bool] = None fuse_max_seq_len: typing.Optional[int] = None modules_to_fuse: typing.Optional[dict] = None modules_to_not_convert: typing.Optional[list] = None exllama_config: typing.Optional[dict[str, int]] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using auto-awq library awq quantization relying on auto_awq backend.

Safety checker that arguments are correct

( weights: str = 'int8' modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using eetq.

Safety checker that arguments are correct

( bits: int tokenizer: typing.Any = None dataset: typing.Union[list[str], str, NoneType] = None group_size: int = 128 damp_percent: float = 0.1 desc_act: bool = False sym: bool = True true_sequential: bool = True checkpoint_format: str = 'gptq' meta: typing.Optional[dict[str, typing.Any]] = None backend: typing.Optional[str] = None use_cuda_fp16: bool = False model_seqlen: typing.Optional[int] = None block_name_to_quantize: typing.Optional[str] = None module_name_preceding_first_block: typing.Optional[list[str]] = None batch_size: int = 1 pad_token_id: typing.Optional[int] = None use_exllama: typing.Optional[bool] = None max_input_length: typing.Optional[int] = None exllama_config: typing.Optional[dict[str, typing.Any]] = None cache_block_outputs: bool = True modules_in_block_to_quantize: typing.Optional[list[list[str]]] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using optimum api for gptq quantization relying on auto_gptq backend.

Get compatible class with optimum gptq config dict

Safety checker that arguments are correct

Get compatible dict for optimum gptq config

( load_in_8bit = False load_in_4bit = False llm_int8_threshold = 6.0 llm_int8_skip_modules = None llm_int8_enable_fp32_cpu_offload = False llm_int8_has_fp16_weight = False bnb_4bit_compute_dtype = None bnb_4bit_quant_type = 'fp4' bnb_4bit_use_double_quant = False bnb_4bit_quant_storage = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using bitsandbytes.

This replaces load_in_8bit or load_in_4bittherefore both options are mutually exclusive.

Currently only supports LLM.int8(), FP4, and NF4 quantization. If more methods are added to bitsandbytes, then more arguments will be added to this class.

Returns True if the model is quantizable, False otherwise.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

This method returns the quantization method used for the model. If the model is not quantizable, it returns None.

Dictionary of all the attributes that make up this configuration instance,

Dictionary of all the attributes that make up this configuration instance,

Removes all attributes from config which correspond to the default config attributes for better readability and serializes to a Python dictionary.

( quantization_config: QuantizationConfigMixin **kwargs )

Abstract class of the HuggingFace quantizer. Supports for now quantizing HF transformers models for inference and/or quantization. This class is used only for transformers.PreTrainedModel.from_pretrained and cannot be easily used outside the scope of that method yet.

Attributes quantization_config (transformers.utils.quantization_config.QuantizationConfigMixin): The quantization config that defines the quantization parameters of your model that you want to quantize. modules_to_not_convert (list[str], optional): The list of module names to not convert when quantizing the model. required_packages (list[str], optional): The list of required pip packages to install prior to using the quantizer requires_calibration (bool): Whether the quantization method requires to calibrate the model before using it. requires_parameters_quantization (bool): Whether the quantization method requires to create a new Parameter. For example, for bitsandbytes, it is required to create a new xxxParameter in order to properly quantize the model.

adjust max_memory argument for infer_auto_device_map() if extra memory is needed for quantization

( dtype: torch.dtype )

Override this method if you want to adjust the target_dtype variable used in from_pretrained to compute the device_map in case the device_map is a str. E.g. for bitsandbytes we force-set target_dtype to torch.int8 and for 4-bit we pass a custom enum accelerate.CustomDtype.int4.

DEPRECATED -> remove in v5

Take needed components from state_dict (those from which param_needs_quantization is True) and create quantized param. It usually also load the new param directly in the model. Note: only applicable if requires_parameters_quantization == True.

Potentially dequantize the model to retrieve the original model, with some loss in accuracy / performance. Note not all quantization schemes support this.

The factor to be used in caching_allocator_warmup to get the number of bytes to pre-allocate to warm up accelerator. A factor of 2 means we allocate all bytes in the empty model (since we allocate in fp16), a factor of 4 means we allocate half the memory of the weights residing in the empty model, etc…

Override this method if you want to adjust the param_name.

( model dtype: torch.dtype )

returns dtypes for modules that are not quantized - used for the computation of the device_map in case one passes a str as a device_map. The method will use the modules_to_not_convert that is modified in _process_model_before_weight_loading.

( model safe_serialization = False )

Get state dict and metadata. Useful when we need to modify a bit the state dict due to quantization

( model: PreTrainedModel param_name: str **kwargs )

Check whether a given param needs quantization as defined by create_quantized_param.

( model: PreTrainedModel **kwargs )

Post-process the model post weights loading. Make sure to override the abstract method _process_model_after_weight_loading.

( model: PreTrainedModel **kwargs )

Setting model attributes and/or converting model before weights loading. At this point the model should be initialized on the meta device so you can freely manipulate the skeleton of the model in order to replace modules in-place. Make sure to override the abstract method _process_model_before_weight_loading.

Remove the quantization config from the model.

( device_map: typing.Optional[dict[str, typing.Any]] )

Override this method if you want to pass a override the existing device map with a new one. E.g. for bitsandbytes, since accelerate is a hard requirement, if no device_map is passed, the device_map is set to `“auto”“

( dtype: torch.dtype )

Some quantization methods require to explicitly set the dtype of the model to a target dtype. You need to override this method in case you want to make sure that behavior is preserved

updates the tp plan for the scales

( model expected_keys: list loaded_keys: list )

Override this method if you want to adjust the update_expected_keys.

( model missing_keys: list prefix: str )

Override this method if you want to adjust the missing_keys.

( state_dict metadata )

Update state dict with metadata. Default behaviour returns state_dict

( dtype: torch.dtype )

Deprecared in favor of update_dtype!

updates the tp plan for the scales

This method is used to potentially check for potential conflicts with arguments that are passed in from_pretrained. You need to define it for all future quantizers that are integrated with transformers. If no explicit check are needed, simply return nothing.

( bits: int = 4 p: int = 2 modules_to_not_convert: typing.Optional[list[str]] = None hadamard_size: int = 512 group_size: int = 256 tune_metadata: typing.Optional[dict[str, typing.Any]] = None **kwargs )

HiggsConfig is a configuration class for quantization using the HIGGS method.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( nbits: int = 4 group_size: int = 64 view_as_float: bool = False axis: typing.Optional[int] = None dynamic_config: typing.Optional[dict] = None skip_modules: list = ['lm_head'] **kwargs )

This is wrapper around hqq’s BaseQuantizeConfig.

Override from_dict, used in AutoQuantizationConfig.from_dict in quantizers/auto.py

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

Dictionary of all the attributes that make up this configuration instance,

Dictionary of all the attributes that make up this configuration instance,

Removes all attributes from config which correspond to the default config attributes for better readability and serializes to a Python dictionary.

( modules_to_not_convert: typing.Optional[list] = None dequantize: bool = False **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using mxfp4 quantization.

( activation_scale_ub: float = 1200.0 modules_to_not_convert: typing.Optional[list] = None **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded using fbgemm fp8 quantization.

( config_groups: typing.Optional[dict[str, typing.Union[ForwardRef('QuantizationScheme'), list[str]]]] = None format: str = 'dense' quantization_status: QuantizationStatus = 'initialized' kv_cache_scheme: typing.Optional[ForwardRef('QuantizationArgs')] = None global_compression_ratio: typing.Optional[float] = None ignore: typing.Optional[list[str]] = None sparsity_config: typing.Optional[dict[str, typing.Any]] = None quant_method: str = 'compressed-tensors' run_compressed: bool = True **kwargs )

This is a wrapper class that handles compressed-tensors quantization config options. It is a wrapper around compressed_tensors.QuantizationConfig

( config_dict return_unused_kwargs = False **kwargs ) → QuantizationConfigMixin

QuantizationConfigMixin

The configuration object instantiated from those parameters.

The configuration object instantiated from those parameters.

Instantiates a CompressedTensorsConfig from a Python dictionary of parameters. Optionally unwraps any args from the nested quantization_config

Quantization config to be added to config.json

Serializes this instance to a Python dictionary. Returns: dict[str, Any]: Dictionary of all the attributes that make up this configuration instance.

Dictionary of all the attributes that make up this configuration instance,

Dictionary of all the attributes that make up this configuration instance,

Removes all attributes from config which correspond to the default config attributes for better readability and serializes to a Python dictionary.

( quant_type: typing.Union[str, ForwardRef('AOBaseConfig')] modules_to_not_convert: typing.Optional[list] = None include_input_output_embeddings: bool = False untie_embedding_weights: bool = False **kwargs )

( config_dict return_unused_kwargs = False **kwargs )

Create configuration from a dictionary.

Create the appropriate quantization method based on configuration.

Validate configuration and set defaults.

Convert configuration to a dictionary.

( modules_to_not_convert: typing.Optional[list] = None linear_class: str = 'bitlinear' quantization_mode: str = 'offline' use_rms_norm: bool = False rms_norm_eps: typing.Optional[float] = 1e-06 **kwargs )

Configuration class for applying BitNet quantization.

Safety checker that arguments are correct

( bits: int = 3 beta1: int = 16 beta2: int = 16 shapes: typing.Optional[dict[str, int]] = None modules_to_not_convert: typing.Optional[list[str]] = None **kwargs )

This is a wrapper class about spqr parameters. Refer to the original publication for more details.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( activation_scheme: str = 'dynamic' weight_block_size: tuple = (128, 128) modules_to_not_convert: typing.Optional[list] = None **kwargs )

FineGrainedFP8Config is a configuration class for fine-grained FP8 quantization used mainly for deepseek models.

Safety checker that arguments are correct

( forward_dtype: str = 'nvfp4' forward_method: str = 'abs_max' backward_dtype: str = 'bf16' store_master_weights: bool = False hadamard_group_size: typing.Optional[int] = None pseudoquantization: bool = False transform_init: str = 'hadamard' modules_to_not_convert: typing.Optional[list[str]] = None **kwargs )

FPQuantConfig is a configuration class for quantization using the FPQuant method.

Safety checker that arguments are correct - also replaces some NoneType arguments with their default values.

( bits: int = 4 group_size: int = 128 sym: bool = True backend: str = 'auto' **kwargs )

This is a wrapper class about all possible attributes and features that you can play with a model that has been loaded AutoRound quantization.

Safety checker that arguments are correct.

**Examples:**

Example 1 (unknown):
```unknown
HfQuantizer
```

Example 2 (unknown):
```unknown
Optional[list[str]]
```

Example 3 (unknown):
```unknown
dict[str, Any]
```

Example 4 (unknown):
```unknown
dict[str, Any]
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/backbones

**Contents:**
- Transformers
- Backbone
- AutoBackbone
  - class transformers.AutoBackbone
- BackboneMixin
  - class transformers.utils.BackboneMixin
    - to_dict
- BackboneConfigMixin
  - class transformers.utils.BackboneConfigMixin
    - to_dict

Transformers documentation

and get access to the augmented documentation experience

A backbone is a model used for feature extraction for higher level computer vision tasks such as object detection and image classification. Transformers provides an AutoBackbone class for initializing a Transformers backbone from pretrained model weights, and two utility classes:

timm models are loaded with the TimmBackbone and TimmBackboneConfig classes.

Backbones are supported for the following models:

Serializes this instance to a Python dictionary. Override the default to_dict() from PretrainedConfig to include the out_features and out_indices attributes.

A Mixin to support handling the out_features and out_indices attributes for the backbone configurations.

Serializes this instance to a Python dictionary. Override the default to_dict() from PretrainedConfig to include the out_features and out_indices attributes.

Wrapper class for timm models to be used as backbones. This enables using the timm models interchangeably with the other models in the library keeping the same API.

( backbone = None num_channels = 3 features_only = True use_pretrained_backbone = True out_indices = None freeze_batch_norm_2d = False **kwargs )

This is the configuration class to store the configuration for a timm backbone TimmBackbone.

It is used to instantiate a timm backbone model according to the specified arguments, defining the model.

Configuration objects inherit from PretrainedConfig and can be used to control the model outputs. Read the documentation from PretrainedConfig for more information.

**Examples:**

Example 1 (unknown):
```unknown
PretrainedConfig
```

Example 2 (unknown):
```unknown
out_features
```

Example 3 (unknown):
```unknown
out_indices
```

Example 4 (unknown):
```unknown
out_features
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/optimizer_schedules

**Contents:**
- Transformers
- Optimization
- AdaFactor
  - class transformers.Adafactor
    - step
- Schedules
  - SchedulerType
  - class transformers.SchedulerType
  - get_scheduler
    - transformers.get_scheduler

Transformers documentation

and get access to the augmented documentation experience

The .optimization module provides:

( params lr = None eps = (1e-30, 0.001) clip_threshold = 1.0 decay_rate = -0.8 beta1 = None weight_decay = 0.0 scale_parameter = True relative_step = True warmup_init = False )

AdaFactor pytorch implementation can be used as a drop in replacement for Adam original fairseq code: https://github.com/pytorch/fairseq/blob/master/fairseq/optim/adafactor.py

Paper: Adafactor: Adaptive Learning Rates with Sublinear Memory Cost https://huggingface.co/papers/1804.04235 Note that this optimizer internally adjusts the learning rate depending on the scale_parameter, relative_step and warmup_init options. To use a manual (external) learning rate schedule you should set scale_parameter=False and relative_step=False.

This implementation handles low-precision (FP16, bfloat) values, but we have not thoroughly tested.

Recommended T5 finetuning settings (https://discuss.huggingface.co/t/t5-finetuning-tips/684/3):

Training without LR warmup or clip_threshold is not recommended.

Disable relative updates

Use scale_parameter=False

Additional optimizer operations like gradient clipping should not be used alongside Adafactor

Others reported the following combination to work well:

When using lr=None with Trainer you will most likely need to use AdafactorSchedule

scheduler as following:

Performs a single optimization step

( value names = None module = None qualname = None type = None start = 1 )

Scheduler names for the parameter lr_scheduler_type in TrainingArguments. By default, it uses “linear”. Internally, this retrieves get_linear_schedule_with_warmup scheduler from Trainer. Scheduler types:

( name: typing.Union[str, transformers.trainer_utils.SchedulerType] optimizer: Optimizer num_warmup_steps: typing.Optional[int] = None num_training_steps: typing.Optional[int] = None scheduler_specific_kwargs: typing.Optional[dict] = None )

Unified API to get any scheduler from its name.

( optimizer: Optimizer last_epoch: int = -1 )

Create a schedule with a constant learning rate, using the learning rate set in optimizer.

( optimizer: Optimizer num_warmup_steps: int last_epoch: int = -1 )

Create a schedule with a constant learning rate preceded by a warmup period during which the learning rate increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: float = 0.5 last_epoch: int = -1 )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to 0, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: int = 1 last_epoch: int = -1 )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to 0, with several hard restarts, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: float = 0.5 last_epoch: int = -1 min_lr: typing.Optional[float] = None min_lr_rate: typing.Optional[float] = None )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to min_lr, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer: Optimizer num_warmup_steps: int num_training_steps: int num_cycles: float = 0.5 last_epoch: int = -1 min_lr: typing.Optional[float] = None min_lr_rate: typing.Optional[float] = None warmup_lr_rate: typing.Optional[float] = None )

Create a schedule with a learning rate that decreases following the values of the cosine function between the initial lr set in the optimizer to min_lr, after a warmup period during which it increases linearly between 0 and the initial lr set in the optimizer.

( optimizer num_warmup_steps num_training_steps last_epoch = -1 )

Create a schedule with a learning rate that decreases linearly from the initial lr set in the optimizer to 0, after a warmup period during which it increases linearly from 0 to the initial lr set in the optimizer.

( optimizer num_warmup_steps num_training_steps lr_end = 1e-07 power = 1.0 last_epoch = -1 )

Create a schedule with a learning rate that decreases as a polynomial decay from the initial lr set in the optimizer to end lr defined by lr_end, after a warmup period during which it increases linearly from 0 to the initial lr set in the optimizer.

Note: power defaults to 1.0 as in the fairseq implementation, which in turn is based on the original BERT implementation at https://github.com/google-research/bert/blob/f39e881b169b9d53bea03d2d341b31707a6c052b/optimization.py#L37

( optimizer: Optimizer num_warmup_steps: int timescale: typing.Optional[int] = None last_epoch: int = -1 )

Create a schedule with an inverse square-root learning rate, from the initial lr set in the optimizer, after a warmup period which increases lr linearly from 0 to the initial lr set in the optimizer.

( optimizer: Optimizer **kwargs )

Create a schedule with a constant learning rate that decreases when a metric has stopped improving.

( optimizer: Optimizer num_warmup_steps: int num_decay_steps: int num_training_steps: typing.Optional[int] = None num_stable_steps: typing.Optional[int] = None warmup_type: str = 'linear' decay_type: str = 'cosine' min_lr_ratio: float = 0 num_cycles: float = 0.5 last_epoch: int = -1 )

Create a schedule with a learning rate that has three stages:

**Examples:**

Example 1 (unknown):
```unknown
.optimization
```

Example 2 (unknown):
```unknown
_LRSchedule
```

Example 3 (unknown):
```unknown
Iterable[nn.parameter.Parameter]
```

Example 4 (unknown):
```unknown
tuple[float, float]
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/backbones

**Contents:**
- Transformers
- Backbone
- AutoBackbone
  - class transformers.AutoBackbone
- BackboneMixin
  - class transformers.utils.BackboneMixin
    - to_dict
- BackboneConfigMixin
  - class transformers.utils.BackboneConfigMixin
    - to_dict

Transformers documentation

and get access to the augmented documentation experience

A backbone is a model used for feature extraction for higher level computer vision tasks such as object detection and image classification. Transformers provides an AutoBackbone class for initializing a Transformers backbone from pretrained model weights, and two utility classes:

timm models are loaded with the TimmBackbone and TimmBackboneConfig classes.

Backbones are supported for the following models:

Serializes this instance to a Python dictionary. Override the default to_dict() from PretrainedConfig to include the out_features and out_indices attributes.

A Mixin to support handling the out_features and out_indices attributes for the backbone configurations.

Serializes this instance to a Python dictionary. Override the default to_dict() from PretrainedConfig to include the out_features and out_indices attributes.

Wrapper class for timm models to be used as backbones. This enables using the timm models interchangeably with the other models in the library keeping the same API.

( backbone = None num_channels = 3 features_only = True use_pretrained_backbone = True out_indices = None freeze_batch_norm_2d = False **kwargs )

This is the configuration class to store the configuration for a timm backbone TimmBackbone.

It is used to instantiate a timm backbone model according to the specified arguments, defining the model.

Configuration objects inherit from PretrainedConfig and can be used to control the model outputs. Read the documentation from PretrainedConfig for more information.

**Examples:**

Example 1 (unknown):
```unknown
PretrainedConfig
```

Example 2 (unknown):
```unknown
out_features
```

Example 3 (unknown):
```unknown
out_indices
```

Example 4 (unknown):
```unknown
out_features
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/video_processor

**Contents:**
- Transformers
- Video Processor
  - Usage Example
    - Sampling behavior
- BaseVideoProcessor
  - class transformers.BaseVideoProcessor
    - convert_to_rgb
    - fetch_videos
    - from_dict
    - from_json_file

Transformers documentation

and get access to the augmented documentation experience

A Video Processor is a utility responsible for preparing input features for video models, as well as handling the post-processing of their outputs. It provides transformations such as resizing, normalization, and conversion into PyTorch. Along ith transformations the VideoProcessor class handles video decoding from local paths or URLs (requires torchcodec) and frame sampling according to model-specific strategies.

The video processor extends the functionality of image processors by allowing Vision Large Language Models (VLMs) to handle videos with a distinct set of arguments compared to images. It serves as the bridge between raw video data and the model, ensuring that input features are optimized for the VLM.

When adding a new VLM or updating an existing one to enable distinct video preprocessing, saving and reloading the processor configuration will store the video related arguments in a dedicated file named video_preprocessing_config.json. Don’t worry if you haven’t updated your VLM, the processor will try to load video related configurations from a file named preprocessing_config.json.

Here’s an example of how to load a video processor with llava-hf/llava-onevision-qwen2-0.5b-ov-hf model:

Currently, if using base image processor for videos, it processes video data by treating each frame as an individual image and applying transformations frame-by-frame. While functional, this approach is not highly efficient. Using AutoVideoProcessor allows us to take advantage of fast video processors, leveraging the torchvision library. Fast processors handle the whole batch of videos at once, without iterating over each video or frame. These updates introduce GPU acceleration and significantly enhance processing speed, especially for tasks requiring high throughput.

Fast video processors are available for all models and are loaded by default when an AutoVideoProcessor is initialized. When using a fast video processor, you can also set the device argument to specify the device on which the processing should be done. By default, the processing is done on the same device as the inputs if the inputs are tensors, or on the CPU otherwise. For even more speed improvement, we can compile the processor when using ‘cuda’ as device.

The video processor can also sample video frames using the technique best suited for the given model. Sampling behavior is controlled with the do_sample_frames argument and can be configured through model-specific parameters such as num_frames or fps (the rate at which the video will be sampled). If the input video is given as a local path or URL (str), the processor will decode it automatically. To obtain metadata about the decoded video, such as sampled frame indices, original dimensions, duration, and fps, pass return_metadata=True to the processor.

Specifying num_frames does not guarantee the output will contain exactly that number of frames. Depending on the model, the sampler may enforce minimum or maximum frame limits.

The default decoder is torchcodec, which must be installed.

If you pass an already decoded video array but still want to enable model-specific frame sampling, it is strongly recommended to provide video_metadata. This allows the sampler to know the original video’s duration and FPS. You can pass metadata as a VideoMetadata object or as a plain dict.

( **kwargs: typing_extensions.Unpack[transformers.processing_utils.VideosKwargs] )

Constructs a base VideoProcessor.

( video: torch.Tensor ) → torch.Tensor

Converts a video to RGB format.

( video_url_or_urls: typing.Union[str, list[str], list[list[str]]] sample_indices_fn = None )

Convert a single or a list of urls into the corresponding np.array objects.

If a single url is passed, the return value will be a single object. If a list is passed a list of objects is returned.

( video_processor_dict: dict **kwargs ) → ~video_processing_utils.VideoProcessorBase

~video_processing_utils.VideoProcessorBase

The video processor object instantiated from those parameters.

The video processor object instantiated from those parameters.

Instantiates a type of ~video_processing_utils.VideoProcessorBase from a Python dictionary of parameters.

( json_file: typing.Union[str, os.PathLike] ) → A video processor of type ~video_processing_utils.VideoProcessorBase

A video processor of type ~video_processing_utils.VideoProcessorBase

The video_processor object instantiated from that JSON file.

The video_processor object instantiated from that JSON file.

Instantiates a video processor of type ~video_processing_utils.VideoProcessorBase from the path to a JSON file of parameters.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a type of ~video_processing_utils.VideoProcessorBase from an video processor.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] **kwargs ) → tuple[Dict, Dict]

The dictionary(ies) that will be used to instantiate the video processor object.

The dictionary(ies) that will be used to instantiate the video processor object.

From a pretrained_model_name_or_path, resolve to a dictionary of parameters, to be used for instantiating a video processor of type ~video_processing_utils.VideoProcessorBase using from_dict.

( videos: typing.Union[list['PIL.Image.Image'], numpy.ndarray, ForwardRef('torch.Tensor'), list[numpy.ndarray], list['torch.Tensor'], list[list['PIL.Image.Image']], list[list[numpy.ndarray]], list[list['torch.Tensor']], transformers.video_utils.URL, list[transformers.video_utils.URL], list[list[transformers.video_utils.URL]], transformers.video_utils.Path, list[transformers.video_utils.Path], list[list[transformers.video_utils.Path]]] **kwargs: typing_extensions.Unpack[transformers.processing_utils.VideosKwargs] )

( auto_class = 'AutoVideoProcessor' )

Register this class with a given auto class. This should only be used for custom video processors as the ones in the library are already mapped with AutoVideoProcessor .

This API is experimental and may have some slight breaking changes in the next releases.

( metadata: VideoMetadata num_frames: typing.Optional[int] = None fps: typing.Union[int, float, NoneType] = None **kwargs ) → np.ndarray

Indices to sample video frames.

Indices to sample video frames.

Default sampling function which uniformly samples the desired number of frames between 0 and total number of frames. If fps is passed along with metadata, fps frames per second are sampled uniformty. Arguments num_frames and fps are mutually exclusive.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save an video processor object to the directory save_directory, so that it can be re-loaded using the ~video_processing_utils.VideoProcessorBase.from_pretrained class method.

Dictionary of all the attributes that make up this video processor instance.

Dictionary of all the attributes that make up this video processor instance.

Serializes this instance to a Python dictionary.

**Examples:**

Example 1 (unknown):
```unknown
VideoProcessor
```

Example 2 (unknown):
```unknown
video_preprocessing_config.json
```

Example 3 (unknown):
```unknown
preprocessing_config.json
```

Example 4 (unknown):
```unknown
llava-hf/llava-onevision-qwen2-0.5b-ov-hf
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/en/main_classes/text_generation

**Contents:**
- Transformers
- Generation
- GenerationConfig
  - class transformers.GenerationConfig
    - from_pretrained
    - from_model_config
    - save_pretrained
    - update
    - validate
    - get_generation_mode

Transformers documentation

and get access to the augmented documentation experience

Each framework has a generate method for text generation implemented in their respective GenerationMixin class:

You can parameterize the generate method with a GenerationConfig class instance. Please refer to this class for the complete list of generation parameters, which control the behavior of the generation method.

To learn how to inspect a model’s generation configuration, what are the defaults, how to change the parameters ad hoc, and how to create and save a customized generation configuration, refer to the text generation strategies guide. The guide also explains how to use related features, like token streaming.

Parameters that control the length of the output

Parameters that control the generation strategy used

Parameters that control the cache

If none is specified, we will use the default cache for the model (which is often DynamicCache). See our cache documentation for further information.

Parameters for manipulation of the model output logits

Parameters that define the output variables of generate

Special tokens that can be used at generation time

Generation parameters exclusive to encoder-decoder models

Generation parameters exclusive to assistant generation

Parameters related to performances and compilation

Class that holds a configuration for a generation task. A generate call supports the following generation methods for text-decoder, text-to-text, speech-to-text, and vision-to-text models:

To learn more about decoding strategies refer to the text generation strategies guide.

A large number of these flags control the logits or the stopping criteria of the generation. Make sure you check the generate-related classes for a full description of the possible manipulations, as well as examples of their usage.

( pretrained_model_name: typing.Union[str, os.PathLike] config_file_name: typing.Union[str, os.PathLike, NoneType] = None cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[str, bool, NoneType] = None revision: str = 'main' **kwargs ) → GenerationConfig

To test a pull request you made on the Hub, you can pass revision="refs/pr/<pr_number>".

If True, then this functions returns a Tuple(config, unused_kwargs) where unused_kwargs is a dictionary consisting of the key/value pairs whose keys are not configuration attributes: i.e., the part of kwargs which has not been used to update config and is otherwise ignored.

The configuration object instantiated from this pretrained model.

The configuration object instantiated from this pretrained model.

Instantiate a GenerationConfig from a generation configuration file.

( model_config: PretrainedConfig ) → GenerationConfig

The configuration object instantiated from those parameters.

The configuration object instantiated from those parameters.

Instantiates a GenerationConfig from a PretrainedConfig. This function is useful to convert legacy PretrainedConfig objects, which may contain generation parameters, into a stand-alone GenerationConfig.

( save_directory: typing.Union[str, os.PathLike] config_file_name: typing.Union[str, os.PathLike, NoneType] = None push_to_hub: bool = False **kwargs )

Save a generation configuration object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

( **kwargs ) → dict[str, Any]

Dictionary containing all the key-value pairs that were not used to update the instance.

Dictionary containing all the key-value pairs that were not used to update the instance.

Updates attributes of this class instance with attributes from kwargs if they match existing attributes, returning all the unused kwargs.

Validates the values of the attributes of the GenerationConfig instance. Raises exceptions in the presence of parameterization that can be detected as incorrect from the configuration instance alone.

Note that some parameters not validated here are best validated at generate runtime, as they may depend on other inputs and/or the model, such as parameters related to the generation length.

( assistant_model: typing.Optional[ForwardRef('PreTrainedModel')] = None ) → GenerationMode

The generation mode triggered by the instance.

The generation mode triggered by the instance.

Returns the generation mode triggered by the GenerationConfig instance.

A class containing all functions for auto-regressive text generation, to be used as a mixin in model classes. Inheriting from this class causes the model to have special generation-related behavior, such as loading a GenerationConfig at initialization time or ensuring generate-related tests are run in transformers CI.

A model class should inherit from GenerationMixin to enable calling methods like generate, or when it has defined a custom generate method that relies on GenerationMixin, directly or indirectly, which approximately shares the same interface to public methods like generate. Three examples:

The class exposes generate(), which can be used for:

To learn more about decoding strategies refer to the text generation strategies guide.

( inputs: typing.Optional[torch.Tensor] = None generation_config: typing.Optional[transformers.generation.configuration_utils.GenerationConfig] = None logits_processor: typing.Optional[transformers.generation.logits_process.LogitsProcessorList] = None stopping_criteria: typing.Optional[transformers.generation.stopping_criteria.StoppingCriteriaList] = None prefix_allowed_tokens_fn: typing.Optional[typing.Callable[[int, torch.Tensor], list[int]]] = None synced_gpus: typing.Optional[bool] = None assistant_model: typing.Optional[ForwardRef('PreTrainedModel')] = None streamer: typing.Optional[ForwardRef('BaseStreamer')] = None negative_prompt_ids: typing.Optional[torch.Tensor] = None negative_prompt_attention_mask: typing.Optional[torch.Tensor] = None use_model_defaults: typing.Optional[bool] = None custom_generate: typing.Union[str, typing.Callable, NoneType] = None **kwargs ) → ModelOutput or torch.LongTensor

ModelOutput or torch.LongTensor

A ModelOutput (if return_dict_in_generate=True or when config.return_dict_in_generate=True) or a torch.LongTensor. If the model is not an encoder-decoder model (model.config.is_encoder_decoder=False), the possible ModelOutput types are: GenerateDecoderOnlyOutput, GenerateBeamDecoderOnlyOutput If the model is an encoder-decoder model (model.config.is_encoder_decoder=True), the possible ModelOutput types are: GenerateEncoderDecoderOutput, GenerateBeamEncoderDecoderOutput

A ModelOutput (if return_dict_in_generate=True or when config.return_dict_in_generate=True) or a torch.LongTensor.

If the model is not an encoder-decoder model (model.config.is_encoder_decoder=False), the possible ModelOutput types are:

If the model is an encoder-decoder model (model.config.is_encoder_decoder=True), the possible ModelOutput types are:

Generates sequences of token ids for models with a language modeling head.

Most generation-controlling parameters are set in generation_config which, if not passed, will be set to the model’s default generation configuration. You can override any generation_config by passing the corresponding parameters to generate(), e.g. .generate(inputs, num_beams=4, do_sample=True).

For an overview of generation strategies and code examples, check out the following guide.

( sequences: Tensor scores: tuple beam_indices: typing.Optional[torch.Tensor] = None normalize_logits: bool = False ) → torch.Tensor

A torch.Tensor of shape (batch_size*num_return_sequences, sequence_length) containing the transition scores (logits)

A torch.Tensor of shape (batch_size*num_return_sequences, sequence_length) containing the transition scores (logits)

Computes the transition scores of sequences given the generation scores (and beam indices, if beam search was used). This is a convenient method to quickly obtain the scores of the selected tokens at generation time.

**Examples:**

Example 1 (unknown):
```unknown
GenerationMixin
```

Example 2 (unknown):
```unknown
max_new_tokens
```

Example 3 (unknown):
```unknown
max_new_tokens
```

Example 4 (unknown):
```unknown
min_new_tokens
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/main_classes/output

**Contents:**
- Transformers
- Model outputs
- ModelOutput
  - class transformers.utils.ModelOutput
    - to_tuple
- BaseModelOutput
  - class transformers.modeling_outputs.BaseModelOutput
- BaseModelOutputWithPooling
  - class transformers.modeling_outputs.BaseModelOutputWithPooling
- BaseModelOutputWithCrossAttentions

Transformers documentation

and get access to the augmented documentation experience

All models have outputs that are instances of subclasses of ModelOutput. Those are data structures containing all the information returned by the model, but that can also be used as tuples or dictionaries.

Let’s see how this looks in an example:

The outputs object is a SequenceClassifierOutput, as we can see in the documentation of that class below, it means it has an optional loss, a logits, an optional hidden_states and an optional attentions attribute. Here we have the loss since we passed along labels, but we don’t have hidden_states and attentions because we didn’t pass output_hidden_states=True or output_attentions=True.

When passing output_hidden_states=True you may expect the outputs.hidden_states[-1] to match outputs.last_hidden_state exactly. However, this is not always the case. Some models apply normalization or subsequent process to the last hidden state when it’s returned.

You can access each attribute as you would usually do, and if that attribute has not been returned by the model, you will get None. Here for instance outputs.loss is the loss computed by the model, and outputs.attentions is None.

When considering our outputs object as tuple, it only considers the attributes that don’t have None values. Here for instance, it has two elements, loss then logits, so

will return the tuple (outputs.loss, outputs.logits) for instance.

When considering our outputs object as dictionary, it only considers the attributes that don’t have None values. Here for instance, it has two keys that are loss and logits.

We document here the generic model outputs that are used by more than one model type. Specific output types are documented on their corresponding model page.

Base class for all model outputs as dataclass. Has a __getitem__ that allows indexing by integer or slice (like a tuple) or strings (like a dictionary) that will ignore the None attributes. Otherwise behaves like a regular python dictionary.

You can’t unpack a ModelOutput directly. Use the to_tuple() method to convert it to a tuple before.

Convert self to a tuple containing all the attributes/keys that are not None.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model’s outputs, with potential hidden states and attentions.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None pooler_output: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model’s outputs that also contains a pooling of the last hidden states.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Base class for model’s outputs, with potential hidden states and attentions.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None pooler_output: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if config.is_encoder_decoder=True in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Base class for model’s outputs that also contains a pooling of the last hidden states.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if config.is_encoder_decoder=True in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model’s outputs that may also contain a past key/values (to speed up sequential decoding).

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and optionally if config.is_encoder_decoder=True in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Base class for model’s outputs that may also contain a past key/values (to speed up sequential decoding).

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for model encoder’s outputs that also contains : pre-computed hidden states that can speed up sequential decoding.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for causal language model (or autoregressive) outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Cross attentions weights after the attention softmax, used to compute the weighted average in the cross-attention heads.

Contains pre-computed hidden-states (key and values in the attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Base class for causal language model (or autoregressive) outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.Cache] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for causal language model (or autoregressive) outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for masked language models outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for sequence-to-sequence language models outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of models predicting if two sentences are consecutive or not.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of sentence classification models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of sequence-to-sequence sentence classification models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Classification scores (before SoftMax).

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of multiple choice models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of token classification models.

( loss: typing.Optional[torch.FloatTensor] = None start_logits: typing.Optional[torch.FloatTensor] = None end_logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of question answering models.

( loss: typing.Optional[torch.FloatTensor] = None start_logits: typing.Optional[torch.FloatTensor] = None end_logits: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of sequence-to-sequence question answering models.

( loss: typing.Optional[torch.FloatTensor] = None spectrogram: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for sequence-to-sequence spectrogram outputs.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

The logits returned do not necessarily have the same size as the pixel_values passed as inputs. This is to avoid doing two interpolations and lose some quality when a user needs to resize the logits to the original image size as post-processing. You should always check your logits shape and resize as needed.

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of semantic segmentation models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of image classification models.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Base class for outputs of image classification models.

( loss: typing.Optional[torch.FloatTensor] = None predicted_depth: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for outputs of depth estimation models.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None extract_features: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for models that have been trained with the Wav2Vec2 loss objective.

( loss: typing.Optional[torch.FloatTensor] = None logits: typing.Optional[torch.FloatTensor] = None embeddings: typing.Optional[torch.FloatTensor] = None hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None )

Hidden-states of the model at the output of each layer plus the initial embedding outputs.

Attentions weights after the attention softmax, used to compute the weighted average in the self-attention heads.

Output type of Wav2Vec2ForXVector.

( last_hidden_state: typing.Optional[torch.FloatTensor] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None loc: typing.Optional[torch.FloatTensor] = None scale: typing.Optional[torch.FloatTensor] = None static_features: typing.Optional[torch.FloatTensor] = None )

If past_key_values is used only the last hidden-state of the sequences of shape (batch_size, 1, hidden_size) is output.

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the optional initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for time series model’s encoder outputs that also contains pre-computed hidden states that can speed up sequential decoding.

( loss: typing.Optional[torch.FloatTensor] = None params: typing.Optional[tuple[torch.FloatTensor, ...]] = None past_key_values: typing.Optional[transformers.cache_utils.EncoderDecoderCache] = None decoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None decoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None cross_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_last_hidden_state: typing.Optional[torch.FloatTensor] = None encoder_hidden_states: typing.Optional[tuple[torch.FloatTensor, ...]] = None encoder_attentions: typing.Optional[tuple[torch.FloatTensor, ...]] = None loc: typing.Optional[torch.FloatTensor] = None scale: typing.Optional[torch.FloatTensor] = None static_features: typing.Optional[torch.FloatTensor] = None )

Contains pre-computed hidden-states (key and values in the self-attention blocks and in the cross-attention blocks) that can be used (see past_key_values input) to speed up sequential decoding.

Hidden-states of the decoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the decoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Attentions weights of the decoder’s cross-attention layer, after the attention softmax, used to compute the weighted average in the cross-attention heads.

Hidden-states of the encoder at the output of each layer plus the initial embedding outputs.

Attentions weights of the encoder, after the attention softmax, used to compute the weighted average in the self-attention heads.

Base class for time series model’s decoder outputs that also contain the loss as well as the parameters of the chosen distribution.

( sequences: typing.Optional[torch.FloatTensor] = None )

Base class for time series model’s predictions outputs that contains the sampled values from the chosen distribution.

**Examples:**

Example 1 (unknown):
```unknown
hidden_states
```

Example 2 (unknown):
```unknown
hidden_states
```

Example 3 (unknown):
```unknown
output_hidden_states=True
```

Example 4 (unknown):
```unknown
output_attentions=True
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/models

**Contents:**
- Transformers
- Loading models
- Models and configurations
- Model classes
- Large models
  - Sharded checkpoints
  - Big Model Inference
  - Model data type
- Custom models

Transformers documentation

and get access to the augmented documentation experience

Transformers provides many pretrained models that are ready to use with a single line of code. It requires a model class and the from_pretrained() method.

Call from_pretrained() to download and load a model’s weights and configuration stored on the Hugging Face Hub.

The from_pretrained() method loads weights stored in the safetensors file format if they’re available. Traditionally, PyTorch model weights are serialized with the pickle utility which is known to be unsecure. Safetensor files are more secure and faster to load.

This guide explains how models are loaded, the different ways you can load a model, how to overcome memory issues for really big models, and how to load custom models.

All models have a configuration.py file with specific attributes like the number of hidden layers, vocabulary size, activation function, and more. You’ll also find a modeling.py file that defines the layers and mathematical operations taking place inside each layer. The modeling.py file takes the model attributes in configuration.py and builds the model accordingly. At this point, you have a model with random weights that needs to be trained to output meaningful results.

An architecture refers to the model’s skeleton and a checkpoint refers to the model’s weights for a given architecture. For example, BERT is an architecture while google-bert/bert-base-uncased is a checkpoint. You’ll see the term model used interchangeably with architecture and checkpoint.

There are two general types of models you can load:

To get a pretrained model, you need to load the weights into the model. This is done by calling from_pretrained() which accepts weights from the Hugging Face Hub or a local directory.

There are two model classes, the AutoModel class and a model-specific class.

The AutoModel class is a convenient way to load an architecture without needing to know the exact model class name because there are many models available. It automatically selects the correct model class based on the configuration file. You only need to know the task and checkpoint you want to use.

Easily switch between models or tasks, as long as the architecture is supported for a given task.

For example, the same model can be used for separate tasks.

In other cases, you may want to quickly try out several different models for a task.

Large pretrained models require a lot of memory to load. The loading process involves:

You need enough memory to hold two copies of the model weights (random and pretrained) which may not be possible depending on your hardware. In distributed training environments, this is even more challenging because each process loads a pretrained model.

Transformers reduces some of these memory-related challenges with fast initialization, sharded checkpoints, Accelerate’s Big Model Inference feature, and supporting lower bit data types.

The save_pretrained() method automatically shards checkpoints larger than 10GB.

Each shard is loaded sequentially after the previous shard is loaded, limiting memory usage to only the model size and the largest shard size.

The max_shard_size parameter defaults to 5GB for each shard because it is easier to run on free-tier GPU instances without running out of memory.

For example, create some shards checkpoints for BioMistral/BioMistral-7B in save_pretrained().

Reload the sharded checkpoint with from_pretrained().

Sharded checkpoints can also be directly loaded with load_sharded_checkpoint().

The save_pretrained() method creates an index file that maps parameter names to the files they’re stored in. The index file has two keys, metadata and weight_map.

The metadata key provides the total model size.

The weight_map key maps each parameter to the shard it’s stored in.

Make sure you have Accelerate v0.9.0 and PyTorch v1.9.0 or later installed to use this feature!

from_pretrained() is supercharged with Accelerate’s Big Model Inference feature.

Big Model Inference creates a model skeleton on the PyTorch meta device. The meta device doesn’t store any real data, only the metadata.

Randomly initialized weights are only created when the pretrained weights are loaded to avoid maintaining two copies of the model in memory at the same time. The maximum memory usage is only the size of the model.

Learn more about device placement in Designing a device map.

Big Model Inference’s second feature relates to how weights are loaded and dispatched in the model skeleton. Model weights are dispatched across all available devices, starting with the fastest device (usually the GPU) and then offloading any remaining weights to slower devices (CPU and hard drive).

Both features combined reduces memory usage and loading times for big pretrained models.

Set device_map to "auto" to enable Big Model Inference.

You can also manually assign layers to a device in device_map. It should map all model parameters to a device, but you don’t have to detail where all the submodules of a layer go if the entire layer is on the same device.

Access the hf_device_map attribute to see how a model is distributed across devices.

PyTorch model weights are initialized in torch.float32 by default. Loading a model in a different data type, like torch.float16, requires additional memory because the model is loaded again in the desired data type.

Explicitly set the dtype parameter to directly initialize the model in the desired data type instead of loading the weights twice (torch.float32 then torch.float16). You could also set dtype="auto" to automatically load the weights in the data type they are stored in.

The dtype parameter can also be configured in AutoConfig for models instantiated from scratch.

Custom models builds on Transformers’ configuration and modeling classes, supports the AutoClass API, and are loaded with from_pretrained(). The difference is that the modeling code is not from Transformers.

Take extra precaution when loading a custom model. While the Hub includes malware scanning for every repository, you should still be careful to avoid inadvertently executing malicious code.

Set trust_remote_code=True in from_pretrained() to load a custom model.

As an extra layer of security, load a custom model from a specific revision to avoid loading model code that may have changed. The commit hash can be copied from the models commit history.

Refer to the Customize models guide for more information.

**Examples:**

Example 1 (unknown):
```unknown
configuration.py
```

Example 2 (unknown):
```unknown
modeling.py
```

Example 3 (unknown):
```unknown
modeling.py
```

Example 4 (unknown):
```unknown
configuration.py
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/feature_extractor

**Contents:**
- Transformers
- Feature Extractor
- FeatureExtractionMixin
  - class transformers.FeatureExtractionMixin
    - from_pretrained
    - save_pretrained
- SequenceFeatureExtractor
  - class transformers.SequenceFeatureExtractor
    - pad
- BatchFeature

Transformers documentation

and get access to the augmented documentation experience

A feature extractor is in charge of preparing input features for audio or vision models. This includes feature extraction from sequences, e.g., pre-processing audio files to generate Log-Mel Spectrogram features, feature extraction from images, e.g., cropping image files, but also padding, normalization, and conversion to NumPy and PyTorch tensors.

This is a feature extraction mixin used to provide saving/loading functionality for sequential and image feature extractors.

( pretrained_model_name_or_path: typing.Union[str, os.PathLike] cache_dir: typing.Union[str, os.PathLike, NoneType] = None force_download: bool = False local_files_only: bool = False token: typing.Union[bool, str, NoneType] = None revision: str = 'main' **kwargs )

Instantiate a type of FeatureExtractionMixin from a feature extractor, e.g. a derived class of SequenceFeatureExtractor.

( save_directory: typing.Union[str, os.PathLike] push_to_hub: bool = False **kwargs )

Save a feature_extractor object to the directory save_directory, so that it can be re-loaded using the from_pretrained() class method.

( feature_size: int sampling_rate: int padding_value: float **kwargs )

This is a general feature extraction class for speech recognition.

( processed_features: typing.Union[transformers.feature_extraction_utils.BatchFeature, list[transformers.feature_extraction_utils.BatchFeature], dict[str, transformers.feature_extraction_utils.BatchFeature], dict[str, list[transformers.feature_extraction_utils.BatchFeature]], list[dict[str, transformers.feature_extraction_utils.BatchFeature]]] padding: typing.Union[bool, str, transformers.utils.generic.PaddingStrategy] = True max_length: typing.Optional[int] = None truncation: bool = False pad_to_multiple_of: typing.Optional[int] = None return_attention_mask: typing.Optional[bool] = None return_tensors: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None )

Instead of list[float] you can have tensors (numpy arrays, PyTorch tensors or TensorFlow tensors), see the note above for the return type.

This is especially useful to enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta), or on TPUs which benefit from having sequence lengths be a multiple of 128.

What are attention masks?

Pad input values / input vectors or a batch of input values / input vectors up to predefined length or to the max sequence length in the batch.

Padding side (left/right) padding values are defined at the feature extractor level (with self.padding_side, self.padding_value)

If the processed_features passed are dictionary of numpy arrays, PyTorch tensors or TensorFlow tensors, the result will use the same type unless you provide a different tensor type with return_tensors. In the case of PyTorch tensors, you will lose the specific device of your tensors however.

( data: typing.Optional[dict[str, typing.Any]] = None tensor_type: typing.Union[NoneType, str, transformers.utils.generic.TensorType] = None )

Holds the output of the pad() and feature extractor specific __call__ methods.

This class is derived from a python dictionary and can be used as a dictionary.

( tensor_type: typing.Union[str, transformers.utils.generic.TensorType, NoneType] = None )

Convert the inner content to tensors.

( *args **kwargs ) → BatchFeature

The same instance after modification.

The same instance after modification.

Send all values to device by calling v.to(*args, **kwargs) (PyTorch only). This should support casting in different dtypes and sending the BatchFeature to a different device.

Mixin that contain utilities for preparing image features.

( image size ) → new_image

A center cropped PIL.Image.Image or np.ndarray or torch.Tensor of shape: (n_channels, height, width).

A center cropped PIL.Image.Image or np.ndarray or torch.Tensor of shape: (n_channels, height, width).

Crops image to the given size using a center crop. Note that if the image is too small to be cropped to the size given, it will be padded (so the returned result has the size asked).

Converts PIL.Image.Image to RGB format.

Expands 2-dimensional image to 3 dimensions.

Flips the channel order of image from RGB to BGR, or vice versa. Note that this will trigger a conversion of image to a NumPy array if it’s a PIL Image.

( image mean std rescale = False )

Normalizes image with mean and std. Note that this will trigger a conversion of image to a NumPy array if it’s a PIL Image.

( image: ndarray scale: typing.Union[float, int] )

Rescale a numpy image by scale amount

( image size resample = None default_to_square = True max_size = None ) → image

If size is an int and default_to_square is True, then image will be resized to (size, size). If size is an int and default_to_square is False, then smaller edge of the image will be matched to this number. i.e, if height > width, then image will be rescaled to (size * height / width, size).

A resized PIL.Image.Image.

A resized PIL.Image.Image.

Resizes image. Enforces conversion of input to PIL.Image.

( image angle resample = None expand = 0 center = None translate = None fillcolor = None ) → image

A rotated PIL.Image.Image.

A rotated PIL.Image.Image.

Returns a rotated copy of image. This method returns a copy of image, rotated the given number of degrees counter clockwise around its centre.

( image rescale = None channel_first = True )

Converts image to a numpy array. Optionally rescales it and puts the channel dimension as the first dimension.

( image rescale = None )

Converts image to a PIL Image. Optionally rescales it and puts the channel dimension back as the last axis if needed.

**Examples:**

Example 1 (unknown):
```unknown
os.PathLike
```

Example 2 (unknown):
```unknown
./my_model_directory/
```

Example 3 (unknown):
```unknown
./my_model_directory/preprocessor_config.json
```

Example 4 (unknown):
```unknown
os.PathLike
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/main_classes/pipelines

**Contents:**
- Transformers
- Pipelines
- The pipeline abstraction
    - transformers.pipeline
- Pipeline batching
- Pipeline chunk batching
- Pipeline FP16 inference
- Pipeline custom code
- Implementing a pipeline
- Audio

Transformers documentation

and get access to the augmented documentation experience

The pipelines are a great and easy way to use models for inference. These pipelines are objects that abstract most of the complex code from the library, offering a simple API dedicated to several tasks, including Named Entity Recognition, Masked Language Modeling, Sentiment Analysis, Feature Extraction and Question Answering. See the task summary for examples of use.

There are two categories of pipeline abstractions to be aware about:

The pipeline abstraction is a wrapper around all the other available pipelines. It is instantiated as any other pipeline but can provide additional quality of life.

Simple call on one item:

If you want to use a specific model from the hub you can ignore the task if the model on the hub already defines it:

To call a pipeline on many items, you can call it with a list.

To iterate over full datasets it is recommended to use a dataset directly. This means you don’t need to allocate the whole dataset at once, nor do you need to do batching yourself. This should work just as fast as custom loops on GPU. If it doesn’t don’t hesitate to create an issue.

For ease of use, a generator is also possible:

( task: typing.Optional[str] = None model: typing.Union[str, ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel'), NoneType] = None config: typing.Union[str, transformers.configuration_utils.PretrainedConfig, NoneType] = None tokenizer: typing.Union[str, transformers.tokenization_utils.PreTrainedTokenizer, ForwardRef('PreTrainedTokenizerFast'), NoneType] = None feature_extractor: typing.Union[ForwardRef('SequenceFeatureExtractor'), str, NoneType] = None image_processor: typing.Union[str, transformers.image_processing_utils.BaseImageProcessor, NoneType] = None processor: typing.Union[str, transformers.processing_utils.ProcessorMixin, NoneType] = None framework: typing.Optional[str] = None revision: typing.Optional[str] = None use_fast: bool = True token: typing.Union[str, bool, NoneType] = None device: typing.Union[int, str, ForwardRef('torch.device'), NoneType] = None device_map: typing.Union[str, dict[str, typing.Union[int, str]], NoneType] = None dtype: typing.Union[str, ForwardRef('torch.dtype'), NoneType] = 'auto' trust_remote_code: typing.Optional[bool] = None model_kwargs: typing.Optional[dict[str, typing.Any]] = None pipeline_class: typing.Optional[typing.Any] = None **kwargs: typing.Any ) → Pipeline

If not provided, the default for the task will be loaded.

If not provided, the default configuration file for the requested model will be used. That means that if model is given, its default configuration will be used. However, if model is not supplied, this task’s default model’s config is used instead.

If not provided, the default tokenizer for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default tokenizer for config is loaded (if it is a string). However, if config is also not given or not a string, then the default tokenizer for the given task will be loaded.

Feature extractors are used for non-NLP models, such as Speech or Vision models as well as multi-modal models. Multi-modal models will also require a tokenizer to be passed.

If not provided, the default feature extractor for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default feature extractor for config is loaded (if it is a string). However, if config is also not given or not a string, then the default feature extractor for the given task will be loaded.

Image processors are used for Vision models and multi-modal models that require image inputs. Multi-modal models will also require a tokenizer to be passed.

If not provided, the default image processor for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default image processor for config is loaded (if it is a string).

Processors are used for multi-modal models that require multi-modal inputs, for example, a model that requires both text and image inputs.

If not provided, the default processor for the given model will be loaded (if it is a string). If model is not specified or not a string, then the default processor for config is loaded (if it is a string).

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Do not use device_map AND device at the same time as they will conflict

A suitable pipeline for the task.

A suitable pipeline for the task.

Utility factory method to build a Pipeline.

A pipeline consists of:

All pipelines can use batching. This will work whenever the pipeline uses its streaming ability (so when passing lists or Dataset or generator).

However, this is not automatically a win for performance. It can be either a 10x speedup or 5x slowdown depending on hardware, data and the actual model being used.

Example where it’s mostly a speedup:

Example where it’s most a slowdown:

This is a occasional very long sentence compared to the other. In that case, the whole batch will need to be 400 tokens long, so the whole batch will be [64, 400] instead of [64, 4], leading to the high slowdown. Even worse, on bigger batches, the program simply crashes.

There are no good (general) solutions for this problem, and your mileage may vary depending on your use cases. Rule of thumb:

For users, a rule of thumb is:

Measure performance on your load, with your hardware. Measure, measure, and keep measuring. Real numbers are the only way to go.

If you are latency constrained (live product doing inference), don’t batch.

If you are using CPU, don’t batch.

If you are using throughput (you want to run your model on a bunch of static data), on GPU, then:

As soon as you enable batching, make sure you can handle OOMs nicely.

zero-shot-classification and question-answering are slightly specific in the sense, that a single input might yield multiple forward pass of a model. Under normal circumstances, this would yield issues with batch_size argument.

In order to circumvent this issue, both of these pipelines are a bit specific, they are ChunkPipeline instead of regular Pipeline. In short:

This should be very transparent to your code because the pipelines are used in the same way.

This is a simplified view, since the pipeline can handle automatically the batch to ! Meaning you don’t have to care about how many forward passes you inputs are actually going to trigger, you can optimize the batch_size independently of the inputs. The caveats from the previous section still apply.

Models can be run in FP16 which can be significantly faster on GPU while saving memory. Most models will not suffer noticeable performance loss from this. The larger the model, the less likely that it will.

To enable FP16 inference, you can simply pass dtype=torch.float16 or dtype='float16' to the pipeline constructor. Note that this only works for models with a PyTorch backend. Your inputs will be converted to FP16 internally.

If you want to override a specific pipeline.

Don’t hesitate to create an issue for your task at hand, the goal of the pipeline is to be easy to use and support most cases, so transformers could maybe support your use case.

If you want to try simply you can:

That should enable you to do all the custom code you want.

Implementing a new pipeline

Pipelines available for audio tasks include the following.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Audio classification pipeline using any AutoModelForAudioClassification. This pipeline predicts the class of a raw waveform or an audio file. In case of an audio file, ffmpeg should be installed to support multiple audio formats.

Learn more about the basics of using a pipeline in the pipeline tutorial

This pipeline can currently be loaded from pipeline() using the following task identifier: "audio-classification".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[numpy.ndarray, bytes, str, dict] **kwargs: typing.Any ) → A list of dict with the following keys

A list of dict with the following keys

label (str) — The label predicted. score (float) — The corresponding probability.

Classify the sequence(s) given as inputs. See the AutomaticSpeechRecognitionPipeline documentation for more information.

( model: PreTrainedModel feature_extractor: typing.Union[ForwardRef('SequenceFeatureExtractor'), str, NoneType] = None tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None decoder: typing.Union[ForwardRef('BeamSearchDecoderCTC'), str, NoneType] = None device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None **kwargs )

For more information on how to effectively use chunk_length_s, please have a look at the ASR chunking blog post.

For more information on how to effectively use stride_length_s, please have a look at the ASR chunking blog post.

Pipeline that aims at extracting spoken text contained within some audio.

The input can be either a raw waveform or a audio file. In case of the audio file, ffmpeg should be installed for to support multiple audio formats

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

( inputs: typing.Union[numpy.ndarray, bytes, str, dict] **kwargs: typing.Any ) → Dict

For CTC models, timestamps can take one of two formats:

For the Whisper model, timestamps can take one of two formats:

A dictionary with the following keys: text (str): The recognized text. chunks (optional(, list[Dict]) When using return_timestamps, the chunks will become a list containing all the various text chunks identified by the model, e.g.* [{"text": "hi ", "timestamp": (0.5, 0.9)}, {"text": "there", "timestamp": (1.0, 1.5)}]. The original full text can roughly be recovered by doing "".join(chunk["text"] for chunk in output["chunks"]).

A dictionary with the following keys:

Transcribe the audio sequence(s) given as inputs to text. See the AutomaticSpeechRecognitionPipeline documentation for more information.

( *args vocoder = None sampling_rate = None no_processor = True **kwargs )

Text-to-audio generation pipeline using any AutoModelForTextToWaveform or AutoModelForTextToSpectrogram. This pipeline generates an audio file from an input text and optional other conditional inputs.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

You can specify parameters passed to the model by using TextToAudioPipeline.__call__.forward_params or TextToAudioPipeline.__call__.generate_kwargs.

This pipeline can currently be loaded from pipeline() using the following task identifiers: "text-to-speech" or "text-to-audio".

See the list of available models on huggingface.co/models.

( text_inputs: typing.Union[str, list[str]] **forward_params ) → A dict or a list of dict

A dict or a list of dict

The dictionaries have two keys: audio (np.ndarray of shape (nb_channels, audio_length)) — The generated audio waveform. sampling_rate (int) — The sampling rate of the generated audio waveform.

The dictionaries have two keys:

Generates speech/audio from the inputs. See the TextToAudioPipeline documentation for more information.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Zero shot audio classification pipeline using ClapModel. This pipeline predicts the class of an audio when you provide an audio and a set of candidate_labels.

The default hypothesis_template is : "This is a sound of {}.". Make sure you update it for your usage.

Learn more about the basics of using a pipeline in the pipeline tutorial This audio classification pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-audio-classification". See the list of available models on huggingface.co/models.

( audios: typing.Union[numpy.ndarray, bytes, str, dict] **kwargs: typing.Any )

Assign labels to the audio(s) passed as inputs.

Pipelines available for computer vision tasks include the following.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Depth estimation pipeline using any AutoModelForDepthEstimation. This pipeline predicts the depth of an image.

Learn more about the basics of using a pipeline in the pipeline tutorial

This depth estimation pipeline can currently be loaded from pipeline() using the following task identifier: "depth-estimation".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

Predict the depth(s) of the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image classification pipeline using any AutoModelForImageClassification. This pipeline predicts the class of an image.

Learn more about the basics of using a pipeline in the pipeline tutorial

This image classification pipeline can currently be loaded from pipeline() using the following task identifier: "image-classification".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

If this argument is not specified, then it will apply the following functions according to the number of labels:

Assign labels to the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image segmentation pipeline using any AutoModelForXXXSegmentation. This pipeline predicts masks of objects and their classes.

This image segmentation pipeline can currently be loaded from pipeline() using the following task identifier: "image-segmentation".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, ForwardRef('Image.Image'), list[str], list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images. Images in a batch must all be in the same format: all as HTTP(S) links, all as local paths, or all as PIL images.

Perform segmentation (detect masks & classes) in the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image to Image pipeline using any AutoModelForImageToImage. This pipeline generates an image based on a previous image input.

This image to image pipeline can currently be loaded from pipeline() using the following task identifier: "image-to-image".

See the list of available models on huggingface.co/models.

( images: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs: typing.Any )

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

Transform the image(s) passed as inputs.

Keypoint matching pipeline using any AutoModelForKeypointMatching. This pipeline matches keypoints between two images.

( inputs: typing.Union[list[collections.abc.Sequence[typing.Union[ForwardRef('Image.Image'), str]]], collections.abc.Sequence[typing.Union[ForwardRef('Image.Image'), str]]] threshold: float = 0.0 **kwargs: typing.Any ) → Union[list[Match], list[list[Match]]]

The pipeline accepts either a single pair of images or a batch of image pairs, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

Union[list[Match], list[list[Match]]]

A list of matches or a list if a single image pair is provided, or of lists of matches if a batch of image pairs is provided. Each match is a dictionary containing the following keys: keypoint_image_0 (Keypoint): The keypoint in the first image (x, y coordinates). keypoint_image_1 (Keypoint): The keypoint in the second image (x, y coordinates). score (float): The matching score between the two keypoints.

A list of matches or a list if a single image pair is provided, or of lists of matches if a batch of image pairs is provided. Each match is a dictionary containing the following keys:

Find matches between keypoints in two images.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Object detection pipeline using any AutoModelForObjectDetection. This pipeline predicts bounding boxes of objects and their classes.

Learn more about the basics of using a pipeline in the pipeline tutorial

This object detection pipeline can currently be loaded from pipeline() using the following task identifier: "object-detection".

See the list of available models on huggingface.co/models.

The pipeline accepts either a single image or a batch of images. Images in a batch must all be in the same format: all as HTTP(S) links, all as local paths, or all as PIL images.

Detect objects (bounding boxes & classes) in the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Video classification pipeline using any AutoModelForVideoClassification. This pipeline predicts the class of a video.

This video classification pipeline can currently be loaded from pipeline() using the following task identifier: "video-classification".

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], NoneType] = None **kwargs )

The pipeline accepts either a single video or a batch of videos, which must then be passed as a string. Videos in a batch must all be in the same format: all as http links or all as local paths.

Assign labels to the video(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Zero shot image classification pipeline using CLIPModel. This pipeline predicts the class of an image when you provide an image and a set of candidate_labels.

Learn more about the basics of using a pipeline in the pipeline tutorial

This image classification pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-image-classification".

See the list of available models on huggingface.co/models.

( image: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] candidate_labels: list **kwargs: typing.Any )

Assign labels to the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Zero shot object detection pipeline using OwlViTForObjectDetection. This pipeline predicts bounding boxes of objects when you provide an image and a set of candidate_labels.

Learn more about the basics of using a pipeline in the pipeline tutorial

This object detection pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-object-detection".

See the list of available models on huggingface.co/models.

( image: typing.Union[str, ForwardRef('Image.Image'), list[dict[str, typing.Any]]] candidate_labels: typing.Union[str, list[str], NoneType] = None **kwargs: typing.Any )

You can use this parameter to send directly a list of images, or a dataset or a generator like so:

Detect objects (bounding boxes & classes) in the image(s) passed as inputs.

Pipelines available for natural language processing tasks include the following.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

( inputs: typing.Union[str, list[str]] **kwargs: typing.Any ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as list of dictionaries with the following keys: sequence (str) — The corresponding input with the mask token prediction. score (float) — The corresponding probability. token (int) — The predicted token id (to replace the masked one). token_str (str) — The predicted token (to replace the masked one).

Each result comes as list of dictionaries with the following keys:

Fill the masked token in the text(s) given as inputs.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: PreTrainedTokenizer modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Question Answering pipeline using any ModelForQuestionAnswering. See the question answering examples for more information.

Learn more about the basics of using a pipeline in the pipeline tutorial

This question answering pipeline can currently be loaded from pipeline() using the following task identifier: "question-answering".

The models that this pipeline can use are models that have been fine-tuned on a question answering task. See the up-to-date list of available models on huggingface.co/models.

( *args **kwargs ) → A dict or a list of dict

A dict or a list of dict

Each result comes as a dictionary with the following keys: score (float) — The probability associated to the answer. start (int) — The character start index of the answer (in the tokenized version of the input). end (int) — The character end index of the answer (in the tokenized version of the input). answer (str) — The answer to the question.

Each result comes as a dictionary with the following keys:

Answer the question(s) given as inputs by using the context(s).

( question: typing.Union[str, list[str]] context: typing.Union[str, list[str]] ) → One or a list of SquadExample

One or a list of SquadExample

The corresponding SquadExample grouping question and context.

The corresponding SquadExample grouping question and context.

QuestionAnsweringPipeline leverages the SquadExample internally. This helper method encapsulate all the logic for converting question(s) and context(s) to SquadExample.

We currently support extractive question answering.

( text: str start: int end: int ) → Dictionary like `{‘answer’

Dictionary like `{‘answer’

str, ‘start’: int, ‘end’: int}`

str, ‘start’: int, ‘end’: int}`

When decoding from token probabilities, this method maps token indexes to actual word in the initial context.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Summarize news articles and other documents.

This summarizing pipeline can currently be loaded from pipeline() using the following task identifier: "summarization".

The models that this pipeline can use are models that have been fine-tuned on a summarization task, which is currently, ’bart-large-cnn’, ’google-t5/t5-small’, ’google-t5/t5-base’, ’google-t5/t5-large’, ’google-t5/t5-3b’, ’google-t5/t5-11b’. See the up-to-date list of available models on huggingface.co/models. For a list of available parameters, see the following documentation

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

( *args **kwargs ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a dictionary with the following keys: summary_text (str, present when return_text=True) — The summary of the corresponding input. summary_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the summary.

Each result comes as a dictionary with the following keys:

Summarize the text(s) given as inputs.

( args_parser = <transformers.pipelines.table_question_answering.TableQuestionAnsweringArgumentHandler object at 0x7f6352ef7700> **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Table Question Answering pipeline using a ModelForTableQuestionAnswering. This pipeline is only available in PyTorch.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This tabular question answering pipeline can currently be loaded from pipeline() using the following task identifier: "table-question-answering".

The models that this pipeline can use are models that have been fine-tuned on a tabular question answering task. See the up-to-date list of available models on huggingface.co/models.

( *args **kwargs ) → A dictionary or a list of dictionaries containing results

A dictionary or a list of dictionaries containing results

Each result is a dictionary with the following keys: answer (str) — The answer of the query given the table. If there is an aggregator, the answer will be preceded by AGGREGATOR >. coordinates (list[tuple[int, int]]) — Coordinates of the cells of the answers. cells (list[str]) — List of strings made up of the answer cell values. aggregator (str) — If the model has an aggregator, this returns the aggregator.

Each result is a dictionary with the following keys:

Answers queries according to a table. The pipeline accepts several types of inputs which are detailed below:

The table argument should be a dict or a DataFrame built from that dict, containing the whole table:

This dictionary can be passed in as such, or can be converted to a pandas DataFrame:

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Text classification pipeline using any ModelForSequenceClassification. See the sequence classification examples for more information.

Learn more about the basics of using a pipeline in the pipeline tutorial

This text classification pipeline can currently be loaded from pipeline() using the following task identifier: "sentiment-analysis" (for classifying sequences according to positive or negative sentiments).

If multiple classification labels are available (model.config.num_labels >= 2), the pipeline will run a softmax over the results. If there is a single label, the pipeline will run a sigmoid over the result. In case of regression tasks (model.config.problem_type == "regression"), will not apply any function on the output.

The models that this pipeline can use are models that have been fine-tuned on a sequence classification task. See the up-to-date list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], dict[str, str], list[dict[str, str]]] **kwargs: typing.Any ) → A list of dict

If this argument is not specified, then it will apply the following functions according to the number of labels:

Each result comes as list of dictionaries with the following keys: label (str) — The label predicted. score (float) — The corresponding probability. If top_k is used, one such dictionary is returned per label.

Each result comes as list of dictionaries with the following keys:

If top_k is used, one such dictionary is returned per label.

Classify the text(s) given as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Language generation pipeline using any ModelWithLMHead or ModelForCausalLM. This pipeline predicts the words that will follow a specified text prompt. When the underlying model is a conversational model, it can also accept one or more chats, in which case the pipeline will operate in chat mode and will continue the chat(s) by adding its response(s). Each chat takes the form of a list of dicts, where each dict contains “role” and “content” keys.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial. You can pass text generation parameters to this pipeline to control stopping criteria, decoding strategy, and more. Learn more about text generation parameters in Text generation strategies and Text generation.

This language generation pipeline can currently be loaded from pipeline() using the following task identifier: "text-generation".

The models that this pipeline can use are models that have been trained with an autoregressive language modeling objective. See the list of available text completion models and the list of conversational models on [huggingface.co/models].

( text_inputs **kwargs ) → A list or a list of lists of dict

A list or a list of lists of dict

Returns one of the following dictionaries (cannot return a combination of both generated_text and generated_token_ids): generated_text (str, present when return_text=True) — The generated text. generated_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the generated text.

Returns one of the following dictionaries (cannot return a combination of both generated_text and generated_token_ids):

Complete the prompt(s) given as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Pipeline for text to text generation using seq2seq models.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial. You can pass text generation parameters to this pipeline to control stopping criteria, decoding strategy, and more. Learn more about text generation parameters in Text generation strategies and Text generation.

This Text2TextGenerationPipeline pipeline can currently be loaded from pipeline() using the following task identifier: "text2text-generation".

The models that this pipeline can use are models that have been fine-tuned on a translation task. See the up-to-date list of available models on huggingface.co/models. For a list of available parameters, see the following documentation

( *args: typing.Union[str, list[str]] **kwargs: typing.Any ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a dictionary with the following keys: generated_text (str, present when return_text=True) — The generated text. generated_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the generated text.

Each result comes as a dictionary with the following keys:

Generate the output text(s) using text(s) given as inputs.

( input_length: int min_length: int max_length: int )

Checks whether there might be something wrong with given input with regard to the model.

( args_parser = <transformers.pipelines.token_classification.TokenClassificationArgumentHandler object at 0x7f6352f25fc0> **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Named Entity Recognition pipeline using any ModelForTokenClassification. See the named entity recognition examples for more information.

Learn more about the basics of using a pipeline in the pipeline tutorial

This token recognition pipeline can currently be loaded from pipeline() using the following task identifier: "ner" (for predicting the classes of tokens in a sequence: person, organisation, location or miscellaneous).

The models that this pipeline can use are models that have been fine-tuned on a token classification task. See the up-to-date list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str]] **kwargs: typing.Any ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a list of dictionaries (one for each token in the corresponding input, or each entity if this pipeline was instantiated with an aggregation_strategy) with the following keys: word (str) — The token/word classified. This is obtained by decoding the selected tokens. If you want to have the exact string in the original sentence, use start and end. score (float) — The corresponding probability for entity. entity (str) — The entity predicted for that token/word (it is named entity_group when aggregation_strategy is not "none". index (int, only present when aggregation_strategy="none") — The index of the corresponding token in the sentence. start (int, optional) — The index of the start of the corresponding entity in the sentence. Only exists if the offsets are available within the tokenizer end (int, optional) — The index of the end of the corresponding entity in the sentence. Only exists if the offsets are available within the tokenizer

Each result comes as a list of dictionaries (one for each token in the corresponding input, or each entity if this pipeline was instantiated with an aggregation_strategy) with the following keys:

Classify each token of the text(s) given as inputs.

( entities: list aggregation_strategy: AggregationStrategy )

Override tokens from a given word that disagree to force agreement on word boundaries.

Example: micro|soft| com|pany| B-ENT I-NAME I-ENT I-ENT will be rewritten with first strategy as microsoft| company| B-ENT I-ENT

( sentence: str input_ids: ndarray scores: ndarray offset_mapping: typing.Optional[list[tuple[int, int]]] special_tokens_mask: ndarray aggregation_strategy: AggregationStrategy word_ids: typing.Optional[list[typing.Optional[int]]] = None word_to_chars_map: typing.Optional[list[tuple[int, int]]] = None )

Fuse various numpy arrays into dicts with all the information needed for aggregation

Find and group together the adjacent tokens with the same entity predicted.

Group together the adjacent tokens with the same entity predicted.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Translates from one language to another.

This translation pipeline can currently be loaded from pipeline() using the following task identifier: "translation_xx_to_yy".

The models that this pipeline can use are models that have been fine-tuned on a translation task. See the up-to-date list of available models on huggingface.co/models. For a list of available parameters, see the following documentation

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

( *args **kwargs ) → A list or a list of list of dict

A list or a list of list of dict

Each result comes as a dictionary with the following keys: translation_text (str, present when return_text=True) — The translation. translation_token_ids (torch.Tensor or tf.Tensor, present when return_tensors=True) — The token ids of the translation.

Each result comes as a dictionary with the following keys:

Translate the text(s) given as inputs.

( args_parser = <transformers.pipelines.zero_shot_classification.ZeroShotClassificationArgumentHandler object at 0x7f6352dd7910> **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

NLI-based zero-shot classification pipeline using a ModelForSequenceClassification trained on NLI (natural language inference) tasks. Equivalent of text-classification pipelines, but these models don’t require a hardcoded number of potential classes, they can be chosen at runtime. It usually means it’s slower but it is much more flexible.

Any combination of sequences and labels can be passed and each combination will be posed as a premise/hypothesis pair and passed to the pretrained model. Then, the logit for entailment is taken as the logit for the candidate label being valid. Any NLI model can be used, but the id of the entailment label must be included in the model config’s :attr:~transformers.PretrainedConfig.label2id.

Learn more about the basics of using a pipeline in the pipeline tutorial

This NLI pipeline can currently be loaded from pipeline() using the following task identifier: "zero-shot-classification".

The models that this pipeline can use are models that have been fine-tuned on an NLI task. See the up-to-date list of available models on huggingface.co/models.

( sequences: typing.Union[str, list[str]] *args **kwargs ) → A dict or a list of dict

A dict or a list of dict

Each result comes as a dictionary with the following keys: sequence (str) — The sequence for which this is the output. labels (list[str]) — The labels sorted by order of likelihood. scores (list[float]) — The probabilities for each of the labels.

Each result comes as a dictionary with the following keys:

Classify the sequence(s) given as inputs. See the ZeroShotClassificationPipeline documentation for more information.

Pipelines available for multimodal tasks include the following.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Document Question Answering pipeline using any AutoModelForDocumentQuestionAnswering. The inputs/outputs are similar to the (extractive) question answering pipeline; however, the pipeline takes an image (and optional OCR’d words/boxes) as input instead of text context.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This document question answering pipeline can currently be loaded from pipeline() using the following task identifier: "document-question-answering".

The models that this pipeline can use are models that have been fine-tuned on a document question answering task. See the up-to-date list of available models on huggingface.co/models.

( image: typing.Union[ForwardRef('Image.Image'), str, list[dict[str, typing.Any]]] question: typing.Optional[str] = None word_boxes: typing.Optional[tuple[str, list[float]]] = None **kwargs: typing.Any ) → A dict or a list of dict

The pipeline accepts either a single image or a batch of images. If given a single image, it can be broadcasted to multiple questions.

A dict or a list of dict

Each result comes as a dictionary with the following keys: score (float) — The probability associated to the answer. start (int) — The start word index of the answer (in the OCR’d version of the input or provided word_boxes). end (int) — The end word index of the answer (in the OCR’d version of the input or provided word_boxes). answer (str) — The answer to the question. words (list[int]) — The index of each word/box pair that is in the answer

Each result comes as a dictionary with the following keys:

Answer the question(s) given as inputs by using the document(s). A document is defined as an image and an optional list of (word, box) tuples which represent the text in the document. If the word_boxes are not provided, it will use the Tesseract OCR engine (if available) to extract the words and boxes automatically for LayoutLM-like models which require them as input. For Donut, no OCR is run.

You can invoke the pipeline several ways:

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Feature extraction pipeline uses no model head. This pipeline extracts the hidden states from the base transformer, which can be used as features in downstream tasks.

Learn more about the basics of using a pipeline in the pipeline tutorial

This feature extraction pipeline can currently be loaded from pipeline() using the task identifier: "feature-extraction".

All models may be used for this pipeline. See a list of all models, including community-contributed models on huggingface.co/models.

( *args: typing.Union[str, list[str]] **kwargs: typing.Any ) → A nested list of float

A nested list of float

The features computed by the model.

The features computed by the model.

Extract the features of the input(s) text.

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image feature extraction pipeline uses no model head. This pipeline extracts the hidden states from the base transformer, which can be used as features in downstream tasks.

Learn more about the basics of using a pipeline in the pipeline tutorial

This image feature extraction pipeline can currently be loaded from pipeline() using the task identifier: "image-feature-extraction".

All vision models may be used for this pipeline. See a list of all models, including community-contributed models on huggingface.co/models.

( *args: typing.Union[str, ForwardRef('Image.Image'), list['Image.Image'], list[str]] **kwargs: typing.Any ) → A nested list of float

The pipeline accepts either a single image or a batch of images, which must then be passed as a string. Images in a batch must all be in the same format: all as http links, all as local paths, or all as PIL images.

A nested list of float

The features computed by the model.

The features computed by the model.

Extract the features of the input(s).

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image To Text pipeline using a AutoModelForVision2Seq. This pipeline predicts a caption for a given image.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This image to text pipeline can currently be loaded from pipeline() using the following task identifier: “image-to-text”.

See the list of available models on huggingface.co/models.

( inputs: typing.Union[str, list[str], ForwardRef('Image.Image'), list['Image.Image']] **kwargs ) → A list or a list of list of dict

The pipeline accepts either a single image or a batch of images.

A list or a list of list of dict

Each result comes as a dictionary with the following key: generated_text (str) — The generated text.

Each result comes as a dictionary with the following key:

Assign labels to the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Image-text-to-text pipeline using an AutoModelForImageTextToText. This pipeline generates text given an image and text. When the underlying model is a conversational model, it can also accept one or more chats, in which case the pipeline will operate in chat mode and will continue the chat(s) by adding its response(s). Each chat takes the form of a list of dicts, where each dict contains “role” and “content” keys.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This image-text to text pipeline can currently be loaded from pipeline() using the following task identifier: “image-text-to-text”.

See the list of available models on huggingface.co/models.

( images: typing.Union[str, list[str], list[list[str]], ForwardRef('Image.Image'), list['Image.Image'], list[list['Image.Image']], list[dict], NoneType] = None text: typing.Union[str, list[str], list[dict], NoneType] = None **kwargs ) → A list or a list of list of dict

The pipeline accepts either a single image or a batch of images. Finally, this pipeline also supports the chat format (see text) containing images and text in this argument.

A list or a list of list of dict

Each result comes as a dictionary with the following key (cannot return a combination of both generated_text and generated_token_ids): generated_text (str, present when return_text=True) — The generated text. generated_token_ids (torch.Tensor, present when return_tensors=True) — The token ids of the generated text. input_text (str) — The input text.

Each result comes as a dictionary with the following key (cannot return a combination of both generated_text and generated_token_ids):

Generate a text given text and the image(s) passed as inputs.

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Automatic mask generation for images using SamForMaskGeneration. This pipeline predicts binary masks for an image, given an image. It is a ChunkPipeline because you can separate the points in a mini-batch in order to avoid OOM issues. Use the points_per_batch argument to control the number of points that will be processed at the same time. Default is 64.

The pipeline works in 3 steps:

preprocess: A grid of 1024 points evenly separated is generated along with bounding boxes and point labels. For more details on how the points and bounding boxes are created, check the _generate_crop_boxes function. The image is also preprocessed using the image_processor. This function yields a minibatch of points_per_batch.

forward: feeds the outputs of preprocess to the model. The image embedding is computed only once. Calls both self.model.get_image_embeddings and makes sure that the gradients are not computed, and the tensors and models are on the same device.

postprocess: The most important part of the automatic mask generation happens here. Three steps are induced:

Learn more about the basics of using a pipeline in the pipeline tutorial

This segmentation pipeline can currently be loaded from pipeline() using the following task identifier: "mask-generation".

See the list of available models on huggingface.co/models.

( image: typing.Union[str, ForwardRef('Image.Image'), list[str], list['Image.Image']] *args: typing.Any **kwargs: typing.Any ) → Dict

A dictionary with the following keys: mask (PIL.Image) — A binary mask of the detected object as a PIL Image of shape (width, height) of the original image. Returns a mask filled with zeros if no object is found. score (optional float) — Optionally, when the model is capable of estimating a confidence of the “object” described by the label and the mask.

A dictionary with the following keys:

Generates binary segmentation masks

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

Visual Question Answering pipeline using a AutoModelForVisualQuestionAnswering. This pipeline is currently only available in PyTorch.

Unless the model you’re using explicitly sets these generation parameters in its configuration files (generation_config.json), the following default values will be used:

Learn more about the basics of using a pipeline in the pipeline tutorial

This visual question answering pipeline can currently be loaded from pipeline() using the following task identifiers: "visual-question-answering", "vqa".

The models that this pipeline can use are models that have been fine-tuned on a visual question answering task. See the up-to-date list of available models on huggingface.co/models.

( image: typing.Union[ForwardRef('Image.Image'), str, list['Image.Image'], list[str], ForwardRef('KeyDataset')] question: typing.Union[str, list[str], NoneType] = None **kwargs ) → A dictionary or a list of dictionaries containing the result. The dictionaries contain the following keys

The pipeline accepts either a single image or a batch of images. If given a single image, it can be broadcasted to multiple questions. For dataset: the passed in dataset must be of type transformers.pipelines.pt_utils.KeyDataset Example:

A dictionary or a list of dictionaries containing the result. The dictionaries contain the following keys

label (str) — The label identified by the model. score (int) — The score attributed by the model for that label.

Answers open-ended questions about images. The pipeline accepts several types of inputs which are detailed below:

( model: typing.Union[ForwardRef('PreTrainedModel'), ForwardRef('TFPreTrainedModel')] tokenizer: typing.Optional[transformers.tokenization_utils.PreTrainedTokenizer] = None feature_extractor: typing.Optional[ForwardRef('SequenceFeatureExtractor')] = None image_processor: typing.Optional[transformers.image_processing_utils.BaseImageProcessor] = None processor: typing.Optional[transformers.processing_utils.ProcessorMixin] = None modelcard: typing.Optional[transformers.modelcard.ModelCard] = None framework: typing.Optional[str] = None task: str = '' device: typing.Union[int, ForwardRef('torch.device'), NoneType] = None binary_output: bool = False **kwargs )

If no framework is specified, will default to the one currently installed. If no framework is specified and both frameworks are installed, will default to the framework of the model, or to PyTorch if no model is provided.

The Pipeline class is the class from which all pipelines inherit. Refer to this class for methods shared across different pipelines.

Base class implementing pipelined operations. Pipeline workflow is defined as a sequence of the following operations:

Input -> Tokenization -> Model Inference -> Post-Processing (task dependent) -> Output

Pipeline supports running on CPU or GPU through the device argument (see below).

Some pipeline, like for instance FeatureExtractionPipeline ('feature-extraction') output large tensor object as nested-lists. In order to avoid dumping such large structure as textual data we provide the binary_output constructor argument. If set to True, the output will be stored in the pickle format.

( supported_models: typing.Union[list[str], dict] )

Check if the model class is in supported by the pipeline.

Context Manager allowing tensor allocation on the user-specified device in framework agnostic way.

( **inputs ) → dict[str, torch.Tensor]

dict[str, torch.Tensor]

The same as inputs but on the proper device.

The same as inputs but on the proper device.

Ensure PyTorch tensors are on the specified device.

( model_outputs: ModelOutput **postprocess_parameters: dict )

Postprocess will receive the raw outputs of the _forward method, generally tensors, and reformat them into something more friendly. Generally it will output a list or a dict or results (containing just strings and numbers).

Scikit / Keras interface to transformers’ pipelines. This method will forward to call().

( input_: typing.Any **preprocess_parameters: dict )

Preprocess will take the input_ of a specific pipeline and return a dictionary of everything necessary for _forward to run properly. It should contain at least one tensor, but might have arbitrary other items.

( repo_id: str use_temp_dir: typing.Optional[bool] = None commit_message: typing.Optional[str] = None private: typing.Optional[bool] = None token: typing.Union[bool, str, NoneType] = None max_shard_size: typing.Union[str, int, NoneType] = '5GB' create_pr: bool = False safe_serialization: bool = True revision: typing.Optional[str] = None commit_description: typing.Optional[str] = None tags: typing.Optional[list[str]] = None **deprecated_kwargs )

Upload the pipeline file to the 🤗 Model Hub.

( save_directory: typing.Union[str, os.PathLike] safe_serialization: bool = True **kwargs: typing.Any )

Save the pipeline’s model and tokenizer.

Scikit / Keras interface to transformers’ pipelines. This method will forward to call().

**Examples:**

Example 1 (unknown):
```unknown
"audio-classification"
```

Example 2 (unknown):
```unknown
"automatic-speech-recognition"
```

Example 3 (unknown):
```unknown
"depth-estimation"
```

Example 4 (unknown):
```unknown
"document-question-answering"
```

---

## Transformers

**URL:** https://huggingface.co/docs/transformers/v4.57.1/en/model_doc/auto

**Contents:**
- Transformers
- Auto Classes
- Extending the Auto Classes
- AutoConfig
  - class transformers.AutoConfig
    - from_pretrained
    - register
- AutoTokenizer
  - class transformers.AutoTokenizer
    - from_pretrained

Transformers documentation

and get access to the augmented documentation experience

In many cases, the architecture you want to use can be guessed from the name or the path of the pretrained model you are supplying to the from_pretrained() method. AutoClasses are here to do this job for you so that you automatically retrieve the relevant model given the name/path to the pretrained weights/config/vocabulary.

Instantiating one of AutoConfig, AutoModel, and AutoTokenizer will directly create a class of the relevant architecture. For instance

will create a model that is an instance of BertModel.

There is one class of AutoModel for each task.

Each of the auto classes has a method to be extended with your custom classes. For instance, if you have defined a custom class of model NewModel, make sure you have a NewModelConfig then you can add those to the auto classes like this:

You will then be able to use the auto classes like you would usually do!

If your NewModelConfig is a subclass of PretrainedConfig, make sure its model_type attribute is set to the same key you use when registering the config (here "new-model").

Likewise, if your NewModel is a subclass of PreTrainedModel, make sure its config_class attribute is set to the same class you use when registering the model (here NewModelConfig).

This is a generic configuration class that will be instantiated as one of the configuration classes of the library when created with the from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path: typing.Union[str, os.PathLike[str]] **kwargs )

If True, then this functions returns a Tuple(config, unused_kwargs) where unused_kwargs is a dictionary consisting of the key/value pairs whose keys are not configuration attributes: i.e., the part of kwargs which has not been used to update config and is otherwise ignored.

Instantiate one of the configuration classes of the library from a pretrained model configuration.

The configuration class to instantiate is selected based on the model_type property of the config object that is loaded, or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

( model_type config exist_ok = False )

Register a new configuration for this class.

This is a generic tokenizer class that will be instantiated as one of the tokenizer classes of the library when created with the AutoTokenizer.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path *inputs **kwargs )

Instantiate one of the tokenizer classes of the library from a pretrained model vocabulary.

The tokenizer class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

( config_class slow_tokenizer_class = None fast_tokenizer_class = None exist_ok = False )

Register a new tokenizer in this mapping.

This is a generic feature extractor class that will be instantiated as one of the feature extractor classes of the library when created with the AutoFeatureExtractor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path **kwargs )

Instantiate one of the feature extractor classes of the library from a pretrained model vocabulary.

The feature extractor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

Passing token=True is required when you want to use a private model.

( config_class feature_extractor_class exist_ok = False )

Register a new feature extractor for this class.

This is a generic image processor class that will be instantiated as one of the image processor classes of the library when created with the AutoImageProcessor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path *inputs **kwargs )

Instantiate one of the image processor classes of the library from a pretrained model vocabulary.

The image processor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

Passing token=True is required when you want to use a private model.

( config_class image_processor_class = None slow_image_processor_class = None fast_image_processor_class = None exist_ok = False )

Register a new image processor for this class.

This is a generic video processor class that will be instantiated as one of the video processor classes of the library when created with the AutoVideoProcessor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path *inputs **kwargs )

Instantiate one of the video processor classes of the library from a pretrained model vocabulary.

The video processor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

Passing token=True is required when you want to use a private model.

( config_class video_processor_class exist_ok = False )

Register a new video processor for this class.

This is a generic processor class that will be instantiated as one of the processor classes of the library when created with the AutoProcessor.from_pretrained() class method.

This class cannot be instantiated directly using __init__() (throws an error).

( pretrained_model_name_or_path **kwargs )

Instantiate one of the processor classes of the library from a pretrained model vocabulary.

The processor class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible):

Passing token=True is required when you want to use a private model.

( config_class processor_class exist_ok = False )

Register a new processor for this class.

The following auto classes are available for instantiating a base model class without a specific head.

This is a generic model class that will be instantiated as one of the base model classes of the library when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the base model classes of the library from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the base model classes of the library from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for instantiating a model with a pretraining head.

This is a generic model class that will be instantiated as one of the model classes of the library (with a pretraining head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a pretraining head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a pretraining head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following natural language processing tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a causal language modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a causal language modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a causal language modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a masked language modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a masked language modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a masked language modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a sequence-to-sequence language modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a sequence-to-sequence language modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a sequence-to-sequence language modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a sequence classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a sequence classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a sequence classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a multiple choice head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a multiple choice head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a multiple choice head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a next sentence prediction head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a next sentence prediction head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a next sentence prediction head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a token classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a token classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a token classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following computer vision tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a depth estimation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a depth estimation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a depth estimation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a image classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a image classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a image classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a video classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a video classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a video classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a masked image modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a masked image modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a masked image modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a object detection head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a object detection head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a object detection head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a image segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a image segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a image segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a semantic segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a semantic segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a semantic segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a instance segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a instance segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a instance segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a universal image segmentation head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a universal image segmentation head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a universal image segmentation head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a zero-shot image classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a zero-shot image classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a zero-shot image classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a zero-shot object detection head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a zero-shot object detection head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a zero-shot object detection head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following audio tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio frame (token) classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio frame (token) classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio frame (token) classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a connectionist temporal classification head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a connectionist temporal classification head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a connectionist temporal classification head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a sequence-to-sequence speech-to-text modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a sequence-to-sequence speech-to-text modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a sequence-to-sequence speech-to-text modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio retrieval via x-vector head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio retrieval via x-vector head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio retrieval via x-vector head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a audio tokenization through codebooks head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a audio tokenization through codebooks head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a audio tokenization through codebooks head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

The following auto classes are available for the following multimodal tasks.

This is a generic model class that will be instantiated as one of the model classes of the library (with a table question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a table question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a table question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a document question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a document question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a document question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a visual question answering head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a visual question answering head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a visual question answering head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a image-text-to-text modeling head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a image-text-to-text modeling head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a image-text-to-text modeling head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

This is a generic model class that will be instantiated as one of the model classes of the library (with a time-series prediction head) when created with the from_pretrained() class method or the from_config() class method.

This class cannot be instantiated directly using __init__() (throws an error).

Instantiates one of the model classes of the library (with a time-series prediction head) from a configuration.

Note: Loading a model from its configuration file does not load the model weights. It only affects the model’s configuration. Use from_pretrained() to load the model weights.

( *model_args **kwargs )

This option can be used if you want to create a model from a pretrained configuration but load your own weights. In this case though, you should check if using save_pretrained() and from_pretrained() is not a simpler option.

Instantiate one of the model classes of the library (with a time-series prediction head) from a pretrained model.

The model class to instantiate is selected based on the model_type property of the config object (either passed as an argument or loaded from pretrained_model_name_or_path if possible), or when it’s missing, by falling back to using pattern matching on pretrained_model_name_or_path:

The model is set in evaluation mode by default using model.eval() (so for instance, dropout modules are deactivated). To train the model, you should first set it back in training mode with model.train()

**Examples:**

Example 1 (unknown):
```unknown
from_pretrained()
```

Example 2 (unknown):
```unknown
NewModelConfig
```

Example 3 (unknown):
```unknown
NewModelConfig
```

Example 4 (unknown):
```unknown
"new-model"
```

---
